#include<iostream>
using namespace std;

int main()
{
	freopen( "decode.in" , "r" , stdin );
	freopen( "decode.out" , "w" , stdout );
	long long k , e , n , d ;
	bool t = false , b = false;
	scanf( "%lld" , &k );
	for( int i = 1 ; i <= k ; i ++ )
	{
		t = false , b = false ;
		cin >> n >> e >> d ;
		for( int j = 1 ; j <= n ; j ++ )
		{
			for( int x = j - 1 ; x <= n ; x ++ )
			{
				if( x * j == n && e * d == ( j - 1 ) * ( x - 1 ) + 1 && !b )
				{
					cout << j << " " << x << "\n" ;
					t = true ;
					b = true;
					break;
				}
			}
		}
		if( !t ) cout << "NO";
	}
	return 0;
}
