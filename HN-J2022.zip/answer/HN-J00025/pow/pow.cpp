#include<iostream>
using namespace std;

int main()
{
	freopen( "pow.in" , "r" , stdin );
	freopen( "pow.out" , "w" , stdout );
	long long a , p , d ;
	cin >> p >> d ;
	a = p ;
	 p = 1 ;
	for( int i = 1 ; i <= d ; i ++ )
	{
		p *= a ;
		if( p > 1e9 )
		{
			cout << "-1";
			return 0;
		}
	}
	if( p <= 1e9 ) cout << p ;
	if( p > 1e9 ) cout << "-1";
	return 0;
}
