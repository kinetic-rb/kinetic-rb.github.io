#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a;
	int b;
	cin>>a>>b;
	int n=pow(10,9);
	if(n>=pow(a,b)){
		long long c=pow(a,b);
		cout<<c;
	}else{
		cout<<-1;
	}
	return 0;
}
