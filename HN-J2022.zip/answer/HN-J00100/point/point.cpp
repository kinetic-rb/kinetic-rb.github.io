#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n<<k;
	int x[510],y[510];
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
	}
	cout<<n/k;
	return 0;
}
