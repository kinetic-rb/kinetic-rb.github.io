#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	int n[10010],d[10010],e[10010],p[10010],q[10010];
	for(int i=1;i<=k;i++){
		cin>>n[i]>>d[i]>>e[i];
	}
	for(int i=1;i<=k;i++){
		for(p[i]=1;p[i]<=n[i];p[i]++){
			q[i]=n[i]/p[i];
			if(n[i]%p[i]!=0){
				continue;
			}
			if(p[i]>q[i]){
				cout<<"NO"<<endl;
				break;
			}
			if(q[i]*p[i]-q[i]-p[i]+2==e[i]*d[i]){
				cout<<p[i]<<' '<<q[i]<<endl;
				break;
			}
		}
	}
	return 0;
}
