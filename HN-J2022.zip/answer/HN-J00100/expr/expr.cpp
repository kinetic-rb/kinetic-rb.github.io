#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	bool vis;
	stack<bool> num;
	int a=0,b=0;
	for(int i=0;i<s.size();i++){
		if(s[i]=='0'){
			num.push(false);
		}else{
			num.push(true);
		}
		if(num.size()!=1){
			if(s[i]=='&'){
				vis=num.top();
				num.pop();
				vis=vis&&num.top();
				num.pop();
				a++;
			}if(s[i]=='|'){
				vis=num.top();
				num.pop();
				vis=vis&&num.top();
				num.pop();
				num.push(vis);
				b++;
			}
		}
	}
	if(num.top()){
		cout<<1<<endl;
	}else{
		cout<<0<<endl;
	}
	cout<<a<<' '<<b;
	return 0;
}
