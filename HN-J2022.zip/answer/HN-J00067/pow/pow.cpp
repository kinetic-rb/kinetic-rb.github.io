#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,s=1;
	cin>>a>>b;
	for(int i=1;i<=b;i++)
	{
		s=s*a;
		if(s>10000000000)
		{
			cout<<"-1";return 0;
		}
	}
	cout<<s;
	return 0;
 } 
