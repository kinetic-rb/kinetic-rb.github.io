#include<bits/stdc++.h>
using namespace std;
long long n[100005],e[100005],d[100005],s1,s2;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	for(int i=1;i<=k;i++) cin>>n[i]>>e[i]>>d[i];
	for(int i=1;i<=k;i++) 
	{
		int f=0;
		for(int j=1;j<=sqrt(n[i]);j++)
			if(n[i]%j==0)
			{
				s1=n[i]/j-1;s2=j-1;
				if(s1*s2+1==e[i]*d[i])
				{
					f=1;cout<<j<<" "<<n[i]/j<<endl;break;
				}
			}
		if(f==0) cout<<"NO"<<endl;
	}
	return 0;
}

