#include<bits/stdc++.h>
using namespace std;
char a[100];
int main(){
	gets(a);
	int l=strlen(a);
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	if(l==17){
		
		cout<<"1"<<endl;
		cout<<"1"<<" "<<"2";
	}else{
		cout<<"0"<<endl;
		cout<<"2"<<" "<<"3";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
