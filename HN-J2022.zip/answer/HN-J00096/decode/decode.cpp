#include<bits/stdc++.h>
using namespace std;
long long n[1000000000];
long long e[1000000000];
long long d[1000000000];
long long a,b;
void f(int x,int y,int z){
	a=0;
	b=0;
	for(a=0;a<=x;a++){
		for(b=0;b<=x;b++){
			if(x==a*b&&y*z==(a-1)*(b-1)+1){
				return;
			}
		} 
	}
	a=-1;
	b=-1;
}
int main(){
	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n[i]>>e[i]>>d[i];
	}
	for(int i=1;i<=k;i++){
		f(n[i],e[i],d[i]);
		if(b==-1&&a==-1){
			cout<<"NO"<<endl;
		}else{
			cout<<a<<" "<<b<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
