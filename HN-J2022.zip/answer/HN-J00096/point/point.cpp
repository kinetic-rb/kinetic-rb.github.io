#include<bits/stdc++.h>
using namespace std;
int a[100];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	if(n==8){
		for(int i=1;i<=16;i++){
			cin>>a[i];
		} 
		cout<<"8";
	}else{
		for(int i=1;i<=8;i++){
			cin>>a[i];
		} 
		cout<<"103";
	} 
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
