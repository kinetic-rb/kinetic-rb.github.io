#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int b;
	long long a;
	cin>>a>>b;
	long long z=1;
	for(int i=1;i<=b;i++){
		z=z*a;
		if(z>1000000000){
			cout<<"-1";
			return 0; 
		}
	}
	cout<<z;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
