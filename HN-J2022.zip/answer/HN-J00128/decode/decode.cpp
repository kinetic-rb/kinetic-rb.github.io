#include<bits/stdc++.h>
using namespace std;
long long k,n,d,e,m;
int main(){
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
    cin >> k;
    while (k--) {
        cin >> n >> d >> e; 
        int f=1;
        for (int i=1; i*i<=n; i++) {
            if (n%i==0 && (i-1)*(n/i-1)+1==e*d) {
                f=0;
                cout << i << " " << n/i << '\n';
                break; 
            }
        }
        if (f==1) {
            cout << "NO" << '\n';
        }
    }
    return 0;
}
