#include<bits/stdc++.h>
using namespace std;
string a;
bool f;
int s1,s2; 
void dfs (int x) {
    if (a[x]=='|') {
        if (f==1) {
            s2++;
        } else {
            f=a[x+1]-'0';
        }
    } else if(a[x]=='&') {
        if (f==0) {
            s1++;
        } else {
            f=a[x+1]-'0';
        }
    } 
    if (x<a.size()) {
        dfs (x+1);
    }
}
int main() {
    freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
    cin >> a;
    if (a[0]=='1') {
        f=1;
    } else if (a[1]=='1') {
        f=1;
    }
    dfs(0);
    cout << f << '\n' << s1 << " " <<  s2;
    return 0;
} 
