#include<bits/stdc++.h>
using namespace std;
long long a,b,c,d=1e9;
int main(){
    freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
    cin >> a >> b;
    c=pow(a,b);
    if (c<0 || c>d) {
        cout << -1;
    } else {
        cout << c;
    }
    return 0;
}
