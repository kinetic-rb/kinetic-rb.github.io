#include<bits/stdc++.h>
using namespace std;
int n,k,s,ans,f=1,max1,l;
int x[1000], y[1000],v[1000];
void dfs1 (int x1, int y1, int ans, int s,int f) {
   max1=max(max1,ans);
    if (f==0) {
        return;
    } 
    f=0;
    for (int i=1; i<=n; i++) {
        if ((x1+1==x[i] && y1==y[i] && v[i]==0) ||( x1==x[i] && y1+1==y[i] && v[i]==0)){
           v[i]=1;
           dfs1 (x[i],y[i],ans+1,s,1);
        }
    }
    if (s<k) {
        dfs1 (x1+1,y1,ans+1,s+1,1);
        dfs1 (x1,y1+1,ans+1,s+1,1);
    }
}
int main(){
    freopen("point.in","r",stdin);
    freopen("point.out","w",stdout);
    cin >> n >> k;
    for (int i=1; i<=n; i++) {
        cin >> x[i] >> y[i];
    }
    for (int i=1; i<=n; i++) {
        for (int j=1; j<=n; j++) {
            v[j]=0;
        }
        v[i]=1;
        dfs1 (x[i],y[i],1,0,1); 
    }
    cout << max1;
    return 0;
}
