#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;cin>>a>>b;
	if(!a)cout<<0;
	else if(a==1)cout<<1;
	else{
		long long res=1;int i=1;
		for(i=0;i<b;i++){
			res*=a;
			if(res>1000000000)return cout<<-1,0;
		}
		cout<<res;
	}
	return 0;
}
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
//If it is not 100pts,I eat my computer!!!!
