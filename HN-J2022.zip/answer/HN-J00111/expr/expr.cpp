#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char a,b,c;cin>>a>>b>>c;
	if(a=='(')printf("%c\n0 0",b);
	else{
		if(b=='&'){
			if(a=='0'){
				cout<<"0\n1 0";
			}
			else{
				if(c=='0'){
					cout<<"0\n0 0";
				}
				else{
					cout<<"1\n0 0";
				}
			}
		}
		else{
			if(a=='1'){
				cout<<"1\n0 1";
			}
			else{
				if(c=='0'){
					cout<<"0\n0 0";
				}
				else{
					cout<<"1\n0 0";
				}
			}
		}
	}
	return 0; 
}
//10pts gets.
//n<=3 is too EZ.
