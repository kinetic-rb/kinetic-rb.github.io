#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	srand(time(0));
	cout<<(rand()*rand()+rand())%10000;
	return 0;
}
//I can't solve this problem qwq
//Wish rand() can get 10pts!!!
//RP=(unsigned long long)-1!!!
//CSP-J 220pts!!!
