#include<bits/stdc++.h>
using namespace std;
bool issq(long long m){
	double i=sqrt(m);
	long long j=(long long)(i+0.5);
	return j*j==m;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int t;cin>>t;
	while(t--){
		long long n,e,d;cin>>n>>e>>d;
		long long x=n+2-e*d;//a+b;n=ab
		if(x<0)continue;
		long long k=x*x-n-n;//a^2+b^2
		long long m=k-n-n;
		if(issq(m)){
			long long y=(long long)(sqrt(m)+0.5);//a-b
			long long a=x+y>>1;
			long long b=x-y>>1;
			cout<<min(a,b)<<' '<<max(a,b)<<endl;
		}
		else puts("NO");
	}
	return 0;
}
/*
known: ab,a+b;
(a+b)^2=a^2+2ab+b^2;
a^2+b^2=(a+b)^2-2ab;
(a-b)^2=a^2-2ab+b^2;
a+b,a-b->a,b;
*/
