#include<bits/stdc++.h>
using namespace std;
int k,n,e,d,ans,ams;
void decode(int x,int y,int z){
	ans=-1,ams=-1;
	for(int i=0;i<=x;i++){
		for(int j=0;j<=x;j++){
			if(i*j==x&&y*z==((i-1)*(j-1))+1&&i<j){
				ans=i,ams=j;
				return;
			}     
		}
	}
	return;
}
int main(){
	//freopen("decode.in","r",stdin);
	//freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++){
		scanf("%d%d%d",&n,&e,&d);
		decode(n,e,d);
		if(ans==-1&&ams==-1)printf("NO\n");
		else printf("%d %d\n",ans,ams);
	}
	return 0;
}
