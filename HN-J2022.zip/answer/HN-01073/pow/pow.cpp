#include<bits/stdc++.h>
using namespace std;
int a,b,ans=1;
int main(){
	//freopen("pow.in","r",stdin);
	//freopen("Pow.out","w",stdout);
	scanf("%d%d",&a,&b);
	for(int i=1;i<=b;i++){
		if(ans*a>1000000000){
			printf("-1");
			return 0;
		}
		ans*=a;
	}
	printf("%d",ans);
	return 0;
}
