#include <iostream>
#include <cstring>

using namespace std;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	char a,b,c;
	a=s[0];
	b=s[1];
	c=s[2];
	if(b=='|'){
		if(a=='1'){
			cout<<1<<endl<<0<<" "<<1;
		}
		else{
			if(c=='1'){
				cout<<1<<endl<<0<<" "<<0;
			}
		}
	}
	else{
		if(b=='&'){
			if(a=='0'){
				cout<<0<<endl<<1<<" "<<0;
			}
			else{
				if(c=='0'){
					cout<<0<<endl<<0<<" "<<0;
				}
			}
		}
	}
	return 0;
}
