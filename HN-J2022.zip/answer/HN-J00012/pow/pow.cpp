#include <iostream>

using namespace std;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout); 
	long long a,b;
	cin>>a>>b;
	long long c=a;
	int u=0;
	for(int i=1;i<b;i++){
		a*=c;
		if(a>1000000000){
			cout<<-1;
			u=1;
			break;
		}
	}
	if(u==0){
		cout<<a;
	}
	return 0;
} 
