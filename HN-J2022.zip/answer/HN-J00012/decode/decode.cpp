#include <iostream>

using namespace std;

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	long long n,d,e,p,q;
	for(int i=0;i<k;i++){
		cin>>n>>d>>e;
		p=1;
		q=-1;
		for(;p*p<=n;p++){    
			if(n%p==0){
				q=n/p;
				if((e*d)==(((p-1)*(q-1)+1))){
					if(q<p){
						long long v=q;
						q=p;
						p=v;
					}
					break;
				}
				else{
					q=-1;
				}
			}
		}
		if(q==-1){
			cout<<"NO"<<endl;
		}
		else{
			cout<<p<<" "<<q<<endl; 
		}
	}
	return 0;
} 
