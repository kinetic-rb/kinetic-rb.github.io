#include<bits/stdc++.h>
using namespace std;
int n,m;

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>m;
	srand(time(0));
	for(int i=1,a,b;i<=n;i++)
	{
		scanf("%d%d",&a,&b);
	}
	cout<<rand()%(m+n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
