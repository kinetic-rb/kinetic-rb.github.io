#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b;

ll quick(ll x,ll y,ll z)
{
	ll cnt=1;
	for(;y>0;y=y>>1)
	{
		if(x>z) return -1;
		if(y&1) 
		{
			if(cnt*x>z) return -1;
			cnt=cnt*x;
		}
		x=x*x;
	}
	return cnt;
}

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	cout<<quick(a,b,1000000000);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
