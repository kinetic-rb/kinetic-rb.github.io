#include<bits/stdc++.h>
using namespace std;
stack <int> num;
stack <char> q;
int ans1,ans2;

int yu(int x,int y)
{
	if(x==1&&y==1) return 1;
	else return 0;
}

int huo(int x,int y)
{
	if(x==1||y==1) return 1;
	else return 0;
}

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
    int b=0;
    s[0]='0';
	while(s[b]!='\n') s[++b]=getchar();
	for(int i=1;i<=b;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			/*if(q.top()=='|')
			{
				if(num.top()==1&&s[i]-48==1) 
				{
					q.pop();
				}
				else 
				{
					num.pop();
					num.push(0);
					q.pop();
				}
			}
			if(q.top()=='&')
			{
				if(num.top()==1||s[i]-48==1) 
				{
					num.pop();
					num.push(1);
					q.pop();
				}
				else 
				{
					num.pop();
					num.push(0);
					q.pop();
				}
			}
			else*/ num.push(s[i]-48);
		}
		else
		{   
		    if(s[i]==')') 
		    {
		    	int cnt=1;
		    	while(cnt>0)
		    	{
		    		if(q.top()=='(') cnt--;
		    		else if(q.top()==')')cnt++;
		    		q.pop();
				}
			}else
			if(s[i]=='|'&&num.top()==1) 
			{
				ans2++;
				if(s[1+i]=='(') 
				{
					int cnt=1;i++;
					while(cnt>0)
					{
						if(s[++i]==')') cnt--;
						else if(s[i]=='(') cnt++;
					}
				}
				else if(s[i+1]>='0'&&s[i+1]<='9')
				{
					i++;
				}
			} 
			else if(s[i]=='&'&&num.top()==0) 
			{
				ans1++;
				if(s[1+i]=='(') 
				{
					int cnt=1;i++;
					while(cnt>0)
					{
						if(s[++i]==')') cnt--;
						else if(s[i]=='(') cnt++;
					}
				}
				else if(s[i+1]>='0'&&s[i+1]<='9')
				{
					i++;
				}
			}else q.push(s[i]);
		}
	}
	cout<<num.top()<<endl<<ans1<<' '<<ans2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

