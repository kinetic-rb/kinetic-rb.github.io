#include<bits/stdc++.h>
#define ll long long
using namespace std;


long long read()
{
	long long x=0,y=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-') y=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<3)+(x<<1)+(c^48);
		c=getchar();
	}
	return x*y;
}

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	k=read();
	while(k--)
	{
		long long n=read(),d=read(),e=read(),p=0,q=0,sum=n+2-e*d;
		for(long long i=1;i*i<=n;i++)
		{
			if(i+n/i==sum&&n%i==0) 
			{
				p=i;
				q=n/i;
			}
		}
		if(p==0||q==0) printf("NO\n");
		else printf("%lld %lld\n",p,q);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
