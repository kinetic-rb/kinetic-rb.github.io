#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	long long c=1;
	bool q=0;
	for(int i=1;i<=b;i++){
		c*=a;
		if(c>1000000000){
			q=1;
			break;
		}
	}
	if(q==0){
		cout<<c;
	}else{
		cout<<"-1";
	}
	return 0;
}
