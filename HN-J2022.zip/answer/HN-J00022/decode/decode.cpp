#include<bits/stdc++.h>
using namespace std;
long long a[1000001][3];
bool b[1000001];
int c[1000001][2];
bool q(int i,int w,int e){
	if(w*e==a[i][0]&&a[i][1]*a[i][2]==(w-1)*(e-1)+1){
		b[i]=1;
		return 1;
	}
	return 0;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i][0]>>a[i][1]>>a[i][2];
	}
	for(int k=0;k<n;k++){
		for(long long i=1;i<=1000;i++){
			for(long long j=1;j<=1000;j++){
				if(q(k,i,j)==1){
					c[k][0]=j;
					c[k][1]=i;
				}
			}
		}	
	}
	for(int i=0;i<n;i++){
		if(b[i]==1){
			cout<<c[i][0]<<" "<<c[i][1]<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}

