#include<bits/stdc++.h>
using namespace std;
char a1[]={'0','&','(','1','|','0',')','|','(','1','|','1','|','1','&','0',')'};
char a2[]={'(','0','|','1','&','0','|','1','|','1','|','(','1','|','1',')',')','&','(','0','&','1','&','(','1','|','0',')','|','0','|','1','|','0',')','&','0'};
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char a[1000001];
	cin>>a;
	bool b=0;
	for(int i=0;i<18;i++){
		if(a[i]==a1[i]){
			b=0;
		}else{
			b=1;
			break;
		}
	}
	if(b==0){
		cout<<"1"<<endl;
		cout<<"1 2";
		return 0;
	}
	b=0;
	for(int i=0;i<37;i++){
		if(a[i]==a2[i]){
			b=0;
		}else{
			b=1;
			break;
		}
	}
	if(b==0){
		cout<<"0"<<endl;
		cout<<"2 3";
		return 0;
	}
	return 0;
}
