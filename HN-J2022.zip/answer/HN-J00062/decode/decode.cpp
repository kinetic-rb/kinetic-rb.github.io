#include<bits/stdc++.h>
using namespace std;
int k,a,b,c;
string n,e,d,p,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n>>d>>e;
		n[i]=p[i]*q[i];
		a=(p[i]-1);
		b=(q[i]-1);
		c=e[i]*d[i];
		if(c!=a*b+1)cout<<"NO";
		else{
			for(int i=1;i<=k;i++){
			cout<<p<<" "<<q<<endl;
		}
	}
	}
	return 0;
}
