#include<bits/stdc++.h>
using namespace std;
int a,b,c,d,e,f,g,h,i,j,k,cnt=0;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(b==1)cout<<a;
	if(b==2)cout<<a*a;
	if(b==3)cout<<a*a*a;
	if(b==4)cout<<a*a*a*a;
	if(b==5)cout<<a*a*a*a*a;
	if(b==6)cout<<a*a*a*a*a*a;
	if(b==7)cout<<a*a*a*a*a*a*a;
	if(b==8)cout<<a*a*a*a*a*a*a*a;
	if(b==9)cout<<a*a*a*a*a*a*a*a*a;
	if(b>9)cout<<-1;
	return 0;
}
