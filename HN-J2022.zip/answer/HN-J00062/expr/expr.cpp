#include<bits/stdc++.h>
using namespace std;
char a;
string s;
int main(){
	cin>>s;
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<1<<endl<<1<<" "<<12;
	return 0;
}
