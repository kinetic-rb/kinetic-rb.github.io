#include<bits/stdc++.h>
using namespace std;

int a,b;
int c[114514],d[114514];
int lc=0,ld=0;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%d%d",&a,&b);
	while(a)
	{
		c[++lc]=a%10;
		d[++ld]=a%10;
		a/=10;
	}//c��¼�����d��¼a
	if(lc==10)
	{
		for(int i=1;i<lc;i++)
			if(c[i]!=0)
			{
				printf("-1");
				return 0;
			}
	}
	b=b-1; 
	while(b--)
	{
		int x=0;
		int e[101]={0},le=0;
		for(int i=1;i<=lc;i++)
		{
			int x=0;
			for(int j=1;j<=ld;j++)
			{
				e[i+j-1]+=x+c[i]*d[j];
				x=e[i+j-1]/10;
				e[i+j-1]%=10;
			}
			le=i+ld-1; 
			while(x)
			{
				e[++le]=x%10;
				x/=10;
			}
		}
		for(int i=1;i<=le;i++)
			c[i]=e[i];
		lc=le;
		if(lc>10)
		{
			printf("-1");
			return 0;
		}
		if(lc==10)
		{
			for(int i=1;i<lc;i++)
				if(c[i]!=0)
				{
					printf("-1");
					return 0;
				}
		}
	}
	for(int i=lc;i>=1;i--)
		printf("%d",c[i]); 
	return 0;
}
