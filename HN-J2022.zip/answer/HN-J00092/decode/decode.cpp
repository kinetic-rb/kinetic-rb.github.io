#include<bits/stdc++.h>
using namespace std;

long long n,e,d;
long long k;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	while(k--)
	{
		scanf("%lld%lld%lld",&n,&e,&d);
		register bool flag=0;
		long long s=sqrt(n);
		if(n%s==0&&(s*s-(s+s)+2)%d==0&&(s*s-(s+s)+2)/d==e)
			printf("%lld %lld\n",s,s);
		for(register long long p=1;p*p<n;p++)
			if(n%p==0)
			{
				register long long q=n/p;
				if((q*p-(q+p)+2)%d==0&&(q*p-(q+p)+2)/d==e)
				{
					flag=1;
					printf("%lld %lld\n",p,q);
					break;
				}
			}
		if(flag==0)
			printf("NO\n");
	}
	return 0;
}
