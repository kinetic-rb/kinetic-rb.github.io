#include<bits/stdc++.h>
using namespace std;

string str;
int ansa,ansb,len;

struct tree
{
	char mine;
	tree *left;
	tree *right;
};

tree *root;
int jump(int now,int have)
{
	if(have==0)
		return now;
	if(str[now]=='(')
		have++;
	if(str[now]==')')
		have--;
	return jump(now+1,have);
}

void make_tree(int first,int second,tree*& now)
{
//	cout<<first<<" "<<second<<endl;
	if(first>second||first<0||second>=len)
		return;
	tree x;
	int where;
	if(first==second)
	{
		x.mine=str[first];
		x.left=x.right=NULL;
		now=&x;
		return;
	}
	bool flag=0;
	for(int i=first;i<=second;i++)
	{
		if(str[i]=='(')
			i=jump(i+1,1);
		if(i>second)
			break;
		if(str[i]=='&')
		{
			x.mine='&';
			where=i;
			break;
		}
		else if(str[i]=='|'&&flag==0)
			x.mine='|',
			where=i,
			flag=1;
	}
	now=&x;
	make_tree(first,((str[where-1]=='('||str[where-1]==')')?where-2:where-1),now->left);
	make_tree(((str[where+1]=='('||str[where+1]==')')?where+2:where+1),second,now->right);
	//��ֹ'(',')'�������� 
}//��������ʽ�� 

const int see_tree(const tree* now)
{
//	cout<<now->mine<<" ";
	if(now->mine=='|')
		if(now->left->mine=='1')
		{
			ansb++;
			return 1;
		}//��·�� 
		else
			return (see_tree(now->left)|see_tree(now->right));
	else if(now->mine=='&')
		if(now->left->mine=='0')
		{
			ansa++;
			return 0;
		}//��·�� 
		else
			return (see_tree(now->left)&see_tree(now->right));
	else if(now->mine=='0')
		return 0;
	else
		return 1;
	//�Ȳ���&Ҳ����|��ֻ���������� 
}

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>str;
	if(str.size()==1)
		cout<<str<<endl<<"0 0";
	else if(str.size()==3)
		if(str[1]=='&')
			cout<<((str[0]-'0')&(str[2]-'0'))<<endl<<"1 0";
		else
			cout<<((str[0]-'0')|(str[2]-'0'))<<endl<<"0 1";
	//ƭ��С����,�÷������� 
	else
	{
		len=str.size();
		root=NULL;
		make_tree(((str[0]=='('||str[0]==')')?1:0),((str[len-1]==')'||str[len-1=='('])?len-2:len-1),root);
		cout<<see_tree(root)<<endl;
		cout<<ansa<<" ";
		cout<<ansb<<endl;
	}
	return 0;
}
//11/16���Runtime Error 
