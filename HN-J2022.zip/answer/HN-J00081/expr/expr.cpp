#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	cout<<"1"<<endl<<"1"<<' '<<"2";
	return 0;	
}
