#include<bits/stdc++.h>
using namespace std;
const int N=1e6+8;	
int a[N];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	int a;
	while(cin>>a){
		break;
	}
	for(int i=1; i<=k; ++i){
		cout<<"NO";
		cout<<endl;
	}
	return 0;
}
