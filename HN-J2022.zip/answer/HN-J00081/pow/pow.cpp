#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,sum=0;
	cin>>a>>b;
	for(int i=1; i<=b; ++i){
		a*=b;
		sum=a;
	}
	if(sum>=1000000000){
		cout<<"-1";
	}
	else{
		cout<<sum;
	}
	return 0;
}
