#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	long long n; 
	while(cin>>n){
		break;
	}
	cout<<"8";
	return 0;
}
