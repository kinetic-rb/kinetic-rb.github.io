#include<bits/stdc++.h>
using namespace std;
long long qpow(long long x,long long n){
	if(n==1){
		if(x>1e9){
			cout<<"-1";
			exit(0);
		}
		return x;
	}
	long long ans=qpow(x,n/2);
	if(n%2){
		if(ans*ans*x>1e9){
			cout<<"-1";
			exit(0);
		}
		return ans*ans*x;
	}
	if(ans*ans>1e9){
		cout<<"-1";
		exit(0);
	}
	return ans*ans;
}
long long a,b;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	cout<<qpow(a,b);
	return 0;
}
