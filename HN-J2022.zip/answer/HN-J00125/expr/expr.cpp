#include<bits/stdc++.h>
using namespace std;
string s;
int huo,yu;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.length()<=3){
		if(s.length()==3){
			if(s[1]=='&'){
				if(s[0]=='0'){
					cout<<"0\n1 0";
				}else{
					if(s[2]=='1'){
						cout<<"1\n0 0";
					}else{
						cout<<"0\n0 0";
					}
				}
			}else if(s[1]=='|'){
				if(s[0]=='1'){
					cout<<"1\n0 1";
				}else{
					if(s[2]=='1'){
						cout<<"1\n0 0";
					}else{
						cout<<"0\n0 0";
					}
				}
			}else{
				cout<<s[1];
			}
			
		}else{
			cout<<s[0]<<"\n0 0";
		}
		return 0;
	}
	srand(time(0));
	srand(rand());
	for(int i=0;i<s.length();i++){
		if(s[i]=='&'){
			yu++;
		}
		if(s[i]=='1'&&s[i+1]=='|'){
			huo++;
		}
	}
	if(yu==1){
		yu++;
	}
	if(huo==1){
		huo++;
	}
	cout<<rand()%2<<"\n";
	cout<<rand()%yu<<" "<<rand()%huo;
	return 0;
}
