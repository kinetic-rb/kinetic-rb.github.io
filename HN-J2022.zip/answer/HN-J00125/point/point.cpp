#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y;
}p[510];
int n,k;
int dis[510][510],ans;
int siz[510];
int f[510];
struct edge{
	int to;
	int next;
	int w;
}e[1010];
int tot,head[510];
void add(int x,int y,int z){
	tot++;
	e[tot].to=y;
	e[tot].next=head[x];
	head[x]=tot;
	e[tot].w=z;
}
bool vis[510];
int dfs(int x,int fa){
	int ans=1;
	vis[x]=1;
	for(int i=head[x];i;i=e[i].next){
		int y=e[i].to;
		if(y==fa){
			continue;
		}
		ans+=dfs(y,x);
	}
	return ans;
}
bool have[510][510];
int Ans[510];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>p[i].x>>p[i].y;
		siz[i]=1;
	}
	for(int i=1;i<n;i++){
		for(int j=1;j<=n;j++){
			if(p[j].x<p[i].x||p[j].y<p[i].y){
				dis[i][j]=-1;
				continue;
			}
			dis[i][j]=(p[j].x-p[i].x)+(p[j].y-p[i].y);
			if(dis[i][j]!=1){
				continue;
			}
			if(!have[i][j]&&!have[j][i]){
				add(i,j,dis[i][j]);
				add(j,i,dis[i][j]);
				have[i][j]=1;
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			Ans[i]=dfs(i,i);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(dis[i][j]<=k){
				ans=max(ans,Ans[i]+Ans[j]);
			}
		}
	}
	cout<<ans;
	return 0;
	
}
