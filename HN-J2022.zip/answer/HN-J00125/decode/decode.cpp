#include<bits/stdc++.h>
using namespace std;
int k;
bool prime(long long x){
	for(long long i=2;i<(int)sqrt(x)+1;i++){
		long long j=sqrt(x)+1-i;
		if((x%i==0)||(x%j==0)){
			return false;
		}
	}
	return true;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		long long n,e,d;
		scanf("%lld%lld%lld",&n,&e,&d);
		if(prime(n)){
			cout<<"NO\n";
			continue;
		}
		long long cha=n-e*d+2;
		bool f=0;
		for(long long p=1;p<(cha/2+1);p++){
			long long q=cha-p;
			if(p*q==n){
				cout<<p<<" "<<q<<"\n";
				f=1;
				break;
			}
		}
		if(!f){
			cout<<"NO\n";
		}
	}
	return 0;
}
