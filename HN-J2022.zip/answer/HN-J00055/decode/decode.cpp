#include<bits/stdc++.h>
using namespace std;
int k;
long long n,e,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
    scanf("%d",&k);
    for(register int i=1;i<=k;++i){
    	scanf("%lld%lld%lld",&n,&e,&d);
    	long long op=n-(e*d);
    	if(op+2<sqrt(n)*2){
    		cout<<"NO"<<endl;
    		continue;
		}
    	int l=0;
    	for(register int j=1;j<=sqrt(n);++j){
    		if(n%j==0&&j+(n/j)-2==op){
    			printf("%d %d\n",j,n/j);
    			l=1;
    			break;
			}
		}
		if(l!=1){
		    cout<<"NO"<<endl;
		}
	}
	return 0;
}
