#include<bits/stdc++.h>
using namespace std;
struct node{
    int ans,z;	
}dp[200][200];
int n,k,dist[200][200];
int dfs(int x,int y,int p){
	if(x>12||y>12){
		dist[x][y]=max(dist[x][y],dp[x][y].ans);
		return 0;
	}
	if(p==k&&dp[x][y+1].z!=1&&dp[x+1][y].z!=1){
		dist[x][y]=max(dist[x][y],dp[x][y].ans);
		return 0;
	}
	else{
		if(dp[x][y+1].z==1){
			dp[x][y+1].ans=dp[x][y].ans+1;
			dfs(x,y+1,p);
			dp[x][y+1].ans=0;
		}
		else{
			dp[x][y+1].ans=dp[x][y].ans+1;
			dfs(x,y+1,p+1);
			dp[x][y+1].ans=0;
		}
		if(dp[x+1][y].z==1){
			dp[x+1][y].ans=dp[x][y].ans+1;
			dfs(x+1,y,p);
			dp[x+1][y].ans=0;
		}
		else{
			dp[x+1][y].ans=dp[x][y].ans+1;
			dfs(x+1,y,p+1);
			dp[x+1][y].ans=0;
		}
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
    memset(dp,0,sizeof(dp));
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++){
    	int l,p;
    	scanf("%d%d",&l,&p);
    	dp[l][p].z=1;
	}
	int ko=0;
	dfs(1,1,0);
	for(int i=1;i<=12;i++){
		for(int j=1;j<=12;j++){
			ko=max(ko,dist[i][j]);
		}
	}
	cout<<ko;
	return 0;
}
