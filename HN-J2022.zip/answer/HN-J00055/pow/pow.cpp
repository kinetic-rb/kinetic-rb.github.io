#include<bits/stdc++.h>
using namespace std;
int a[20]={0,2,3,4,5,6,7,8,11,14,20,32,64,178,1001,31623,1000000000};
int b[20]={100,30,19,15,13,12,11,10,9,8,7,6,5,4,3,2,1};
long long n=0,m=0;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
    scanf("%lld%lld",&n,&m);
	if(n==1){
		cout<<1;
		return 0;
	}
	if(n>1000000000){
		cout<<-1;
		return 0;
	}
	if(m>=31){
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=16;i++){
		if(n>=a[i-1]&&n<a[i]){
			if(m>=b[i-1]){
				cout<<-1;
				return 0;
			}
			else{
				long long op=1;
				for(register int j=1;j<=m;++j){
					op*=n;
				}
				printf("%lld",op);
				return 0;
			}
		}
	}
	return 0;
}
