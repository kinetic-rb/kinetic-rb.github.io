#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
    cin>>s;
    int op=s.size();
    int k=2,l=s[0]-'0';
    int ans1=0,ans2=0;
    for(int i=1;i<op;i++){
    		k=l;
    		if(k==0){
    			if(s[i]-'0'=='&'-'0'){
    				ans1++;
				}
				l=0;
			}
			if(k==1&&s[i]-'0'!='&'-'0'){
				ans2++;
				l=1;
			}
			i++;
	}
	cout<<l<<endl<<ans1<<" "<<ans2;
	return 0;
}
