#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k,i,j;
	cin>>k;
	for(i=1;i<=k;i++){
		long long n,d,e,p,q;
		cin>>n>>d>>e;
		for(j=1;j<=n/2;j++){
			p=j;
			q=n/p;
			if(d*e==(p-1)*(q-1)+1&&p*q==n){
					cout<<p<<" "<<q<<endl;
					break;
				}else if(j==n/2) 
					cout<<"No"<<endl;
		}
	}
	return 0;
}
