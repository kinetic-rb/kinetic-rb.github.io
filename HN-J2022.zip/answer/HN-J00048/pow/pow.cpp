#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long m=1000000000,a,b,i,s=1;
	cin>>a>>b;
	for(i=1;i<=b;i++)
		s*=a;
	if(s>m) cout<<"-1"<<endl;
	else cout<<s<<endl;
	return 0;
} 
