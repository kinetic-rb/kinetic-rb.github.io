#include<bits/stdc++.h>
using namespace std;
long long sum=1000000000,a,b;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	long long c=a;
	if((a!=1&&b>30))
	{
		cout<<-1;
		return 0;
	}
	for(int i=1;i<b;i++)
	{
		a*=c;
		if(a>sum)
		{
			cout<<-1;
			return 0;
		}
	}
	cout<<a;
	return 0;
}
