#include<bits/stdc++.h>
using namespace std;
long long T,a,b,c,sum;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++)cout<<"NO"<<endl;
	return 0;
}
