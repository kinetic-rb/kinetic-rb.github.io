#include<bits/stdc++.h>
using namespace std;
long long T,a,b,c,sum;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>T;
	cout<<T;
	return 0;
}
