#include<bits/stdc++.h>
using namespace std;
int f;
string s;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.size()==1)
	{
		cout<<s[0]-'0'<<endl;
		cout<<0<<" "<<0;
	}
	if(s.size()==3)
	{
		if(s[0]=='('&&s[2]==')')
		{
			cout<<s[1]-'0'<<endl;
			cout<<0<<" "<<0;
			return 0;
		}
		else
		{
			if(s[0]=='0'&&s[1]=='&')
			{
				cout<<0<<endl;
				cout<<1<<" "<<0;
				return 0; 
			}
			else if(s[0]=='1'&&s[1]=='|')
			{
				cout<<1<<endl;
				cout<<0<<" "<<1;
				return 0;
			}
			else if((s[0]=='1'&&s[1]=='&'&&s[2]=='1')||(s[2]=='1'&&s[1]=='|'))
			{
				cout<<1<<endl;
				cout<<0<<" "<<0;
				return 0;
			}
			else
			{
				cout<<0<<endl;
				cout<<0<<" "<<0;
				return 0;
			}
		}
	}
	else if(s.size()==5)
	{
		if(s[0]=='('&&s[4]==')')
		{
			if(s[2]=='|')
			{
				if(s[1]=='1')
				{
					cout<<1<<endl;
					cout<<0<<" "<<1;
					return 0;
				}
				else if(s[3]=='1')
				{
					cout<<1<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
				else
				{
					cout<<0<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
			}
			else
			{
				if(s[1]=='0')
				{
					cout<<0<<endl;
					cout<<1<<" "<<0;
					return 0;
				}
				else if(s[3]=='0')
				{
					cout<<0<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
				else
				{
					cout<<1<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
			}
		}
		else if(s[0]=='('&&s[2]==')')
		{
			if(s[3]=='|')
			{
				if(s[1]=='1')
				{
					cout<<1<<endl;
					cout<<0<<" "<<1;
					return 0;
				}
				else if(s[4]=='1')
				{
					cout<<1<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
				else
				{
					cout<<0<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
			}
			else
			{
				if(s[1]=='0')
				{
					cout<<0<<endl;
					cout<<1<<" "<<0;
					return 0;
				}
				else if(s[4]=='0')
				{
					cout<<0<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
				else
				{
					cout<<1<<endl;
					cout<<0<<" "<<0;
					return 0;
				}
			}
		}
	}
	else
	{
		for(int i=0;i<s.size();i++)
		{
			if(s[i]=='|')f=1;
			if(s[i]=='&')f=2;
			if(f)break;
		}
		if(f==1)
		{ 
			for(int i=0;i<s.size();i++)
			{
				if(s[i]=='1')
				{
					cout<<1<<endl;
					cout<<0<<" "<<1;
					return 0; 
				}
			}
			cout<<0<<endl;
			cout<<0<<" "<<0;
			return 0;
		}
		else
		{
			for(int i=0;i<s.size();i++)
			{
				if(s[i]=='0')
				{
					cout<<0<<endl;
					cout<<1<<" "<<0;
					return 0; 
				}
			}
			cout<<1<<endl;
			cout<<0<<" "<<0;
			return 0;
		}
	}
	return 0; 
}
