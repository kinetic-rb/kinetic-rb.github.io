#include<bits/stdc++.h>
using namespace std;
long long a,b,c=1,flag;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=b;i++)
	{
		c*=a;
		if(c>1e9) 
		{
			flag=1;
			cout<<-1;
			break;
		}
	}
	if(!flag) cout<<c;
	return 0;
}
