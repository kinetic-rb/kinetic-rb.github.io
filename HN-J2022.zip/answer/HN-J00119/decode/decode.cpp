#include<bits/stdc++.h>
using namespace std;
int k,flag;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		flag=0;
		long long n,d,e;
		cin>>n>>d>>e;
		int m=n-e*d+2;
		if(m<0) cout<<"NO"<<endl;
		for(int i=1;i<=m/2&&i*i<=n;i++)
		{
			if(n%i==0&&(i+n/i)==m)
			{
				flag=1;
				cout<<i<<" "<<n/i<<endl;
				break;
			}
		}
		if(!flag) cout<<"NO"<<endl;
	}
	return 0;
}
