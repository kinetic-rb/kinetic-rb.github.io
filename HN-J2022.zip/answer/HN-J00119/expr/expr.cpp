#include<bits/stdc++.h>
using namespace std;
string a;
int ans1,ans2,s;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	s=a.size()-1;
	int i;
	for(i=0;i<=s;i++)
	{
		if(a[i]=='&')
		{
			if(a[i-1]=='0')
			{
				ans1++;
				a[i+1]='0';
			}
		}
		if(a[i]=='|')
		{
			if(a[i-1]=='1')
			{
				a[i+1]='1';
				ans2++;
			}
		}
	}
	cout<<a[i-1]<<endl;
	cout<<ans1<<" "<<ans2;
	return 0;
}
