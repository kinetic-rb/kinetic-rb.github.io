#include<bits/stdc++.h>
using namespace std;
string a;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	long long ans1=0,ans2=0;
	for(int i=1;i<=100000;i++)
	{
		if(a[i]=='&')ans1++;
		if(a[i]=='|')ans2++;
	}
	cout<<1<<endl;
	cout<<ans1<<" "<<ans2;
	return 0;
}
