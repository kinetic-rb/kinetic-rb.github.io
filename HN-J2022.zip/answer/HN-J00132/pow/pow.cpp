#include<bits/stdc++.h>
using namespace std;
const int c=1e9; 
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,d;
	cin>>a>>b;
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	d=a;
	for(int i=1;i<b;i++)
	{
		a*=d;
		if(a>c)
		{
			cout<<-1;
			return 0;
		}
	}
	cout<<a;
	return 0;
}
