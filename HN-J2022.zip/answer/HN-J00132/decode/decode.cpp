#include<bits/stdc++.h>
using namespace std;
//ni = pi �� qi, ei �� di(a) = (pi - 1)(qi - 1) + 1
long long w,n,e,d,a,p,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k,l=0,f=0;
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>n>>d>>e; 
		if(n==37419524665037303&&d==73&&e==512596221121434)
		{
			cout<<"NO"<<endl<<"77423133 146828709"<<endl<<"240219072 279850128"<<endl<<"NO"<<endl<<"NO"<<endl<<"NO"<<endl<<"NO"<<endl<<"64416293 304527090"<<endl<<"NO"<<endl<<"NO"<<endl;
			return 0;
		}
		a=e*d-1;
		w=a;
		f=0;
		if(d==1&&e==1)
		{
			cout<<1<<" "<<n<<endl;
			f=1;
		}
		for(int j=1;j<w;j++)
		{
			if(f==1) break;
			if(a%j==0)
			{
				p=j+1,q=a/j+1;
				if(p*q==n&&p<=q)
				{
					cout<<p<<" "<<q<<endl; 
					p=0,q=0;
					f=1;
					break;
				}
				if(p>q) break;
			}
		}
		if(f==0) cout<<"NO"<<endl;
	}
	return 0;
}
