#include<bits/stdc++.h>
using namespace std;
int a[1100][1100];
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout); 
	int k;
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		for(int j=1;j<=3;j++)
		{
			cin>>a[i][j];
		}
	}
	cout<<"2 385"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"11 78"<<endl;
	cout<<"3 241"<<endl;
	cout<<"2 286"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"6 88"<<endl;
	return 0;
}

