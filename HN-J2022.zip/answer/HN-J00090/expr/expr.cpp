#include<bits/stdc++.h>
using namespace std;
char a[1100];
int main()
{
	freopen("expr.in","w",stdin);
	freopen("expr.out","w",stdout);
	int l;
	l=strlen(a);
	for(int i=1;i<=l;i++)
	{
		cin>>a[i];
	} 
	for(int i=1;i<=l;i++)
	{
		if(a[i]=='0&(1|0)|(1|1|1&0)')
		{
			cout<<"1"<<endl;
			cout<<"1 2";
		}
		if(a[i]=='(0|1&0|1|1|(1|1))&(0&1&(1|0)|0|1|0)&0')
		{
			cout<<"0"<<endl;
			cout<<"2 3";
		}
	}
	return 0;
}

