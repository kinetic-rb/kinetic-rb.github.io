#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b,num,all=0;
	cin>>a>>b;
	num=a;
	for(int i=2;i<=b;i++)
	{
		num*=a;
		if(num>1000000000)
		{
			printf("-1\n");
			return 0;
		}
	}
	printf("%d\n",num);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
