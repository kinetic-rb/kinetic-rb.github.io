#include<iostream>
#include<cstdio>
using namespace std;
bool finded(int e,int d,int p,int q)
{
	if(e*d==(p*q-p-q+2))
	{
		printf("%d %d\n",p,q);
		return true;
	}
	return false;
}
void findn(long long n,int e,int d)
{
	if(n<e*d)
	{
		printf("NO\n");
		return;
	}
	int flag=false;
	for(int i=1;i*i<=n;i++)
	{
		if(n%i==0 and i<=n/i)
		{
			flag=finded(e,d,i,n/i);
			if(flag)
				return;
		}
	}
	printf("NO\n");
	return;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n;
	int k,e,d;
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>n>>e>>d;
		findn(n,e,d);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
