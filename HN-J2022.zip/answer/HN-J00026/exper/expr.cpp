#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int a,b;
string c;
void cl(int top,int end)
{
	for(int i=top;i<=end;i++)
		c[i]='-';
		return;
}
bool if_or(int x,int y)
{
	bool flag=false; 
	for(int i=x;i<y;i++)
		if(c[i]=='|')
			flag=true;
	return flag;
}
void use_aor(int x,int y)
{
	int top,end;
	top=end=0;
	int temp=0;
	while(if_or(x,y))
	{
		for(int i=x;i<y;i++)
		{
			if(c[i]=='1')
				top=i;
			if(c[i]=='0')
				top=i;
			if(c[i]=='|')
			{
				temp=i+1;
				while(c[temp]=='-')
				{
					temp++;
				}
				end=temp;
				if(c[top]=='1')
				{
					a++;
					cl(top,end);
					c[(top+end)/2]='1';
				}
				else
				{
					temp=(c[top]-48)or(c[top]-48);
					cl(top,end);
					c[(top+end)/2]=char(temp+48);
					top=end=0;
					break;
				}
			}
		}
	}
}
bool if_and(int x,int y)
{
	bool flag=false; 
	for(int i=x;i<y;i++)
		if(c[i]=='&')
			flag=true;
	return flag;
}
void use_and(int x,int y)
{
	int top,end;
	top=end=0;
	int temp=0;
	while(if_and(x,y))
	{
		for(int i=x;i<y;i++)
		{
			if(c[i]=='1')
				top=i;
			if(c[i]=='0')
				top=i;
			if(c[i]=='&')
			{
				temp=i+1;
				while(c[temp]=='-')
				{
					temp++;
				}
				end=temp;
				if(c[top]=='0')
				{
					b++;
					cl(top,end);
					c[(top+end)/2]='0';
				}
				else
				{
					temp=(c[top]-48)and(c[top]-48);
					cl(top,end);
					c[(top+end)/2]=char(temp+48);
					top=end=0;
					break;
				}
			}
		}
	}
}
void k(int top,int end)
{
	use_and(top,end);
	use_aor(top,end);
}
bool if_k()
{
	bool flag=false; 
	for(int i=0;i<c.length();i++)
		if(c[i]=='(')
			flag=true;
	return flag;
}
void use_k()
{
	int top,end;
	top=end=0;
	while(if_k())
	{
		for(int i=0;i<c.length();i++)
		{
			if(c[i]=='(')
				top=i;
			if(c[i]==')')
				end=i;
			if(end!=0)
			{
				k(top,end);
				c[top]=c[end]='-';
				top=end=0;
				break;
			}
		}
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>c;
	int top,end;
	use_k();
	use_and(0,c.length());
	use_aor(0,c.length());
	for(int i=0;i<c.length();i++)
		if(c[i]=='1' or c[i]=='0')
		{
			printf("%d\n",int(c[i]-48));
			break;
		}
	printf("%d %d\n",b,a); 
	fclose(stdin);
	fclose(stdout);  
	return 0;
}
