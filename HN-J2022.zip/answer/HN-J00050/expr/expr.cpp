#include<bits/stdc++.h>
using namespace std;
int a,x,y;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a>>x>>y;
	for (int i=1;i<=1;i++){
		cout<<1<<endl<<1<<" "<<2;
	} 
	return 0;
}
