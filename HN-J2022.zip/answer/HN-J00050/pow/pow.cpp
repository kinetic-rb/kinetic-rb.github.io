#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b=1,cnt;
	cin >>a >>b;
	cnt=a*a*a*a*a*a*a*a*a;
	if(cnt >1000000009||cnt>=0) cout << cnt;
	else cout << -1;
	return 0;
}
