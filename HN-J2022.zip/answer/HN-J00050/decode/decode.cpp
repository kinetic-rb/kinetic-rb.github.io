#include<bits/stdc++.h>
using namespace std;
int k,n,e,d;
int p,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for (int k=0;k<=n;k++){
		cin>>n,d,e;
		if (p<=q)
			cout <<k;
		else 
			cout <<"NO";
	}
	return 0;
}
