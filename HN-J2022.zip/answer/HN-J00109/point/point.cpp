#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cout<<0;
	return 0;
}
