#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n;
	cin>>n;
	for(long long i=1;i<=n;i++){
		long long x,y,z;
		cin>>x>>y>>z;
		long long pp=x-y*z+2;
		long long l=1,r,ans=-100;
		if(pp%2==0){
			r=pp/2;
		}else{
			r=(pp+1)/2;
		}
		while(l<=r){
			long long mid=(l+r)/2;
			if(mid*(pp-mid)==x){
				ans=mid;
				break;
			}else{
				if(mid*(pp-mid)>x){
					r=mid-1;
				}else{
					l=mid+1;
				}
			}
		}
		if(ans==-100){
			cout<<"NO"<<endl;
		}else{
			long long opiu=pp-ans;
			if(opiu>ans){
				cout<<ans<<" "<<opiu<<endl;
			}else{
				cout<<opiu<<" "<<ans<<endl;
			}
		}
	}
	return 0;
}
