#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	if(n>1000000000){
		cout<<-1;
		return 0;
	}
	long long sum=n;
	n=1;
	while(m>0){
		if(m%2==1){
			m=m-1;
			n=n*sum;
			if(n>1000000000){
				cout<<-1;
				return 0;
			}
		}
		if(m==0){
			break;
		}
		m=m/2;
		sum=sum*sum;
		if(sum>1000000000){
			cout<<-1;
			return 0;
		}
	}
	cout<<n;
	return 0;
}
