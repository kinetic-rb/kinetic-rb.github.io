#include "bits/stdc++.h"
using namespace std;

int a, b;

int main ()
{
	freopen ("pow.in", "r", stdin);
	freopen ("pow.out", "w", stdout);
	cin >> a >> b;
	if ((int) pow (a, b) == pow (a, b))
	{
		cout << (int) pow (a, b) << endl;
	}
	else
	{
		cout << -1 << endl;
	}
    return 0;
}

