#include "bits/stdc++.h"
using namespace std;

long long t, n, e, d, p, q;
bool b;

int main ()
{
	freopen ("decode.in", "r", stdin);
	freopen ("decode.out", "w", stdout);
	cin >> t;
	while (t--)
	{
		cin >> n >> e >> d;
		b = 1;
		for (p = 1; p <= sqrt(n) + 1; p++)
		{
			q = n / p;
			if ((p * q == n) && e * d == ((p - 1) * (q - 1) + 1) && p < q)
			{
				b = 0;
				cout << p << ' ' << q << endl;
				break;
			}
		}
		if (b)
		{
			cout << "NO" << endl;
		}
	}
    return 0;
}

