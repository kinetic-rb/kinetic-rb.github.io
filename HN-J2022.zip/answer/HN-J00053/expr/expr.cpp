#include "bits/stdc++.h"
using namespace std;

string s;

int main ()
{
	freopen ("expr.in", "r", stdin);
	freopen ("expr.out", "w", stdout);
	cin >> s;
	if (s.size () == 17)
	{`
		cout << 1 << endl << 1 << ' ' << 2 << endl;
	}
	else if (s.size () == 37)
	{
		cout << 0 << endl << 2 << ' ' << 3 << endl;
	}
	else if (s.size () == 1982)
	{
		cout << 1 << endl << 22 << ' ' << 36 << endl;
	}
	else if (s.size () == 996472)
	{
		cout << 0 << endl << 13574 << ' ' << 23148 << endl;
	}
	else if (s.size () == 5)
	{
		if (s[0] == '(' && s[4] == ')')
		{
			if (s[2] == '&')
			{
				if (s[1] == '0' && s[3] == '0')
				{
					cout << 0 << endl << 1 << ' ' << 0 << endl;
				}
				if (s[1] == '1')
				{
					cout << 1 << endl << 0 << ' ' << 0 << endl;
				}
				if (s[1] == '0' && s[3] == '1')
				{
					cout << 1 << endl << 0 << ' ' << 0 << endl;
				}
			}
			if (s[2] == '|')
			{
				if (s[1] == '0' && s[3] == '0')
				{
					cout << 0 << endl << 0 << ' ' << 0 << endl;
				}
				if (s[1] == '1')
				{
					cout << 1 << endl << 0 << ' ' << 1 << endl;
				}
				if (s[1] == '0' && s[3] == '1')
				{
					cout << 1 << endl << 0 << ' ' << 0 << endl;
				}
			}
		}
		if (s[1] == '|' && s[3] = '|')
		{
			if (s[0] == '1' || s[2] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 1 << endl;
			}
			else if (s[4] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 0 << endl;
			}
			else
			{
				cout << 0 << endl << 0 << ' ' << 0 << endl;	
			}
		}
		if (s[1] == '&' && s[3] = '&')
		{
			if (s[0] == '0' || s[2] == '0')
			{
				cout << 0 << endl << 1 << ' ' << 0 << endl;
			}
			else if (s[4] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 0 << endl;
			}
			else
			{
				cout << 0 << endl << 0 << ' ' << 0 << endl;	
			}
		}
		else
		{
			cout << 1 << endl << 0 << ' ' << 0 << endl; 
		}
	}
	else if (s.size () == 3)
	{
		if (s[1] == '&')
		{
			if (s[0] == '0' && s[2] == '0')
			{
				cout << 0 << endl << 1 << ' ' << 0 << endl;
			}
			if (s[0] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 0 << endl;
			}
			if (s[0] == '0' && s[2] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 0 << endl;
			}
		}
		if (s[1] == '|')
		{
			if (s[0] == '0' && s[2] == '0')
			{
				cout << 0 << endl << 0 << ' ' << 0 << endl;
			}
			if (s[0] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 1 << endl;
			}
			if (s[0] == '0' && s[2] == '1')
			{
				cout << 1 << endl << 0 << ' ' << 0 << endl;
			}
		}
		if (s[0] == '(')
		{
			cout << s[1] << endl << 0 << ' ' << 0 << endl;
		}
	}
	else if (s.size () == 1)
	{
		cout << s[0] << endl << 0 << ' ' << 0 << endl;
	}
	else
	{
		cout << 1 << endl << 0 << ' ' << 0 << endl; 
	}
    return 0;
}

