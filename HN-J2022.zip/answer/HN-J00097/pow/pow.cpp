#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long int a,b,c;
	cin>>a>>b;
	if(pow(a,b)>2147483647) cout<<-1<<endl;
	c=pow(a,b);
	if(pow(a,b)<=2147483647) cout<<c<<endl;
	return 0;
}
