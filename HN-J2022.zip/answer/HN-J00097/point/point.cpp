#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("point1.in","r",stdin);
	freopen("point1.out","w",stdout);
	int n,k,x[510],y[510],ans=0,maxn=0;
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(x[i+1]-x[i]==1&&y[i+1]==y[i]||x[i+1]==x[i]&&y[i+1]-y[i]==1) ans++;
		}
		maxn=max(maxn,ans);
	}
	cout<<maxn+k<<endl;
	return 0;
}
