#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long int n;
	long long int k,e,d,p,q;
	bool ans;
	cin>>k;
L1:	for(int i=1;i<=k;i++)
	{
		cin>>n>>d>>e;
		ans=1;
		for(p=1;p<=n;p++)
		{
			for(q=1;q<=n;q++)
			{
				if(n==p*q&&e*d==(p-1)*(q-1)+1){
					ans=0;
				    cout<<p<<" "<<q<<endl;
				    break;
			    }
			}
			if(ans==0) break;
		}
		if(ans==1) cout<<"NO"<<endl;
	}
	return 0;
}
