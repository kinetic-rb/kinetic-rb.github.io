#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string x;
	bool a,b;
	cin>>x;
	if(x[0]=='0') a=0;
	if(x[0]=='1') a=1;
	if(x[0]=='2') a=2;
	if(x[0]=='3') a=3;
	if(x[0]=='4') a=4;
	if(x[0]=='5') a=5;
	if(x[0]=='6') a=6;
	if(x[0]=='7') a=7;
	if(x[0]=='8') a=8;
	if(x[0]=='9') a=9;
	if(x[2]=='0') b=0;
	if(x[2]=='1') b=1;
	if(x[2]=='2') b=2;
	if(x[2]=='3') b=3;
	if(x[2]=='4') b=4;
	if(x[2]=='5') b=5;
	if(x[2]=='6') b=6;
	if(x[2]=='7') b=7;
	if(x[2]=='8') b=8;
	if(x[2]=='9') b=9;
	if(x[1]=='&'&&a==1&&b==1)
	{
		cout<<1<<endl<<0<<" "<<0<<endl;
		return 0;
	}
	else if(x[1]=='&')
	{
		cout<<0<<endl<<1<<" "<<0<<endl;
		return 0;
	}
	if(x[1]=='|'&&a==1||b==1)
	{
		cout<<1<<endl<<0<<" "<<1<<endl;
		return 0;
	}
	else if(x[1]=='|')
	{
		cout<<0<<endl<<0<<" "<<0<<endl;
		return 0;
	}
	return 0;
}
