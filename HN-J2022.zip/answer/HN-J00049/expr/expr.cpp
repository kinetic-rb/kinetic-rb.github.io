#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

int a,b;
string s;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"0"<<endl;
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='|')a++;
		if(s[i]=='&')b++;
	}
	cout<<a/2<<" "<<b/2;
	return 0;
} 
