#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;

inline ull read(){
	ull s=0;char ch=getchar();
	while(ch<'0' or ch>'9'){ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return s;
}

inline void write(ull x){
	if(x>9)write(x/10);
	putchar(x%10+48);
}

int k;
ull n,e,d;

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	while(k--){
		n=read(),e=read(),d=read();
		ull b=e*d-n-2,c=n;
		double delta=b*b-4*c;
		if(delta<0){
			puts("NO");
			continue;
		}
		delta=sqrt(delta);
		if(double(floor(delta))!=delta){
			puts("NO");
			continue;
		}
		ull Delta=floor(delta);
		ull x1=-b-Delta>>1,x2=-b+Delta>>1;
		if(x1*x2!=n or x1+x2!=n+2-e*d){
			puts("NO");
			continue;
		}
		write(x1),putchar(' '),write(x2),puts("");
	}
	return 0;
} 
