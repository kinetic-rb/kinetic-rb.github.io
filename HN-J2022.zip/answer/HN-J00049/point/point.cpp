#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int N=5e2+5;
int n,k,m[N][N],ans;

struct point{
	int x,y;
}p[N];

inline void dfs(int u,int tot,int sum){
	ans=max(tot,ans);
	for(int v=1;v<=n;v++){
		if(m[u][v]==-114514 or u==v)continue;
		if(p[u].x<=p[v].x and p[u].y<=p[v].y and sum-m[u][v]>=0)
			dfs(v,tot+1,sum-m[u][v]);
	}
}

int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	memset(m,-114514,sizeof(m));
	n=read(),k=read();
	for(int i=1;i<=n;i++)
		p[i].x=read(),p[i].y=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			if(p[i].x<=p[j].x and p[i].y<=p[j].y)
				m[i][j]=p[j].x+p[j].y-p[i].x-p[i].y-1;
		}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++)
//			write(m[i][j]),putchar(' ');
//		puts("");
//	}
	for(int i=1;i<=n;i++)
		dfs(i,1,k);
	write(ans+k);
	return 0;
} 
