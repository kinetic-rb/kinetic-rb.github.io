#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read(){
	ll s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const ll inf=1e9;
ll a,b;

inline ll Qpow(ll a,ll b){
	if(b==0)return 1;
	if(b==1)return a;
	if(b&1){
		ll QwQ=Qpow(a,b>>1);
		if(QwQ>inf){
			write(-1);
			exit(0);
		}
		return QwQ*QwQ*a;
	}else{
		ll QwQ=Qpow(a,b>>1);
		if(QwQ>inf){
			write(-1);
			exit(0);
		}
		return QwQ*QwQ;
	}
}

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read(),b=read();
	ll ans=Qpow(a,b);
	write(ans);
	return 0;
} 
