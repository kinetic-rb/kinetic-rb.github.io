#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","w",stdin);
	freopen("decode.out","r",stdout);
	int k,o;
	cin>>k;
	long long n,d,e;
	for(int i=1;i<=n;i++){
		o=1;
		cin>>n>>d>>e;
		for(int j=1;j<=sqrt(n);j++){
			if(n%j==0){
				int p=j,q=n/j;
				if((p-1)*(q-1)+1==e*d){
					cout<<p<<" "<<q<<endl;
					o=0;
					break;
				}
			}
		}
		if(o==1)cout<<"NO"<<endl;
	}  
	fclose(stdin);
	fclose(stdout);
} 
