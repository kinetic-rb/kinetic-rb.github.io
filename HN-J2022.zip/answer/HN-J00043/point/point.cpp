#include<bits/stdc++.h>
using namespace std;
struct b{
	int x,y,h;
}m[5005];
bool cmp(b j,b k){
	if(j.x!=k.x)return j.x<k.x;
	if(j.x==k.x)
		if(j.y!=k.y)return j.y<k.y;
}
bool cnp(b u,b r){
	if(u.y!=r.y)return u.y<r.y;
	if(u.y==r.y)
		if(u.x!=r.x)return u.x<r.x;
}
bool cup(b q,b p){
	if(q.h!=p.h)return q.h<p.h;
	if(q.h==p.h)
		if(q.h!=p.h)return q.h<p.h;
}
int main(){
	freopen("point.in","w",stdin);
	freopen("point.out","r",stdout);
	int n,a,s;
	int ans=0,sum=0;
	cin>>n>>a;
	int sums=a;
	for(int i=1;i<=n;i++){
		cin>>m[i].x>>m[i].y; 
		m[i].h=m[i].x+m[i].y;
	}
	sort(m+1,m+n+1,cmp);
	for(int i=1;i<=n;i++){
		sums=a;
		ans=0;
		for(int j=i;j<=n;j++){
			if(m[j].x==m[j+1].x){
				if(abs(m[j].y-m[j+1].y)==1)ans++;
			}
			else if(m[j].y==m[j+1].y){
				if(abs(m[j].x-m[j+1].x)==1)ans++;
			}
			else {
				ans+=min(sums,abs(m[j+1].x-m[j].x)+abs(m[j+1].y-m[j].y)-1);
				sums=sums-abs(m[j+1].x-m[j].x)-abs(m[j+1].y-m[j].y)+1;
				if(sums>=0)ans++;
			}
			if(sums<0)break;
		} 
		sum=max(sum,ans);
	}
	sort(m+1,m+n+1,cnp);
	for(int i=1;i<=n;i++){
		sums=a;
		ans=0;
		for(int j=i;j<=n;j++){
			if(m[j].x==m[j+1].x){
				if(abs(m[j].y-m[j+1].y)==1)ans++;
			}
			else if(m[j].y==m[j+1].y){
				if(abs(m[j].x-m[j+1].x)==1)ans++;
			}
			else {
				ans+=min(sums,abs(m[j+1].x-m[j].x)+abs(m[j+1].y-m[j].y)-1);
				sums=sums-abs(m[j+1].x-m[j].x)-abs(m[j+1].y-m[j].y)+1;
				if(sums>=0)ans++;
			}
			if(sums<0)break;
		} 
		sum=max(sum,ans);
	}
	sort(m+1,m+n+1,cup);
	for(int i=1;i<=n;i++){
		sums=a;
		ans=0;
		for(int j=i;j<=n;j++){
			if(m[j].x==m[j+1].x){
				if(abs(m[j].y-m[j+1].y)==1)ans++;
			}
			else if(m[j].y==m[j+1].y){
				if(abs(m[j].x-m[j+1].x)==1)ans++;
			}
			else {
				ans+=min(sums,abs(m[j+1].x-m[j].x)+abs(m[j+1].y-m[j].y)-1);
				sums=sums-abs(m[j+1].x-m[j].x)-abs(m[j+1].y-m[j].y)+1;
				if(sums>=0)ans++;
			}
			if(sums<0)break;
		} 
		sum=max(sum,ans);
	}
	cout<<sum;
	return 0;
	fclose(stdin);
	fclose(stdout);
} 
