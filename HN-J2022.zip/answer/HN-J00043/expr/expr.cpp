#include<bits/stdc++.h>
using namespace std;
char a[10000005];
int b[10000005]; 
string hs(string d,int c){
	if(d[c]==')')return 0;
	else if(d[c]=='(')b[c]++;
	else  hs(d,c++);
	if(d[c]==')')return 0;
} 
int main(){
	freopen("expr.in","w",stdin);
	freopen("expr.out","r",stdout);
	string s;
	int ans;
	cin>>s;
	hs(s,0);
	return 0;
	fclose(stdin);
	fclose(stdout);
} 
