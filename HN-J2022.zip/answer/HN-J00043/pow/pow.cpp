#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","w",stdin);
	freopen("pow.out","r",stdout);
	int a,b,o=0;
	long n=1;
	cin>>a>>b;
	while(b){
		n=n*a;
		if(n>pow(10,9)){
			cout<<"-1";
			o=1;
			break;
		}
		b--;
	}
	if(o==0)cout<<n;
	return 0;
	fclose(stdin);
	fclose(stdout);
} 
