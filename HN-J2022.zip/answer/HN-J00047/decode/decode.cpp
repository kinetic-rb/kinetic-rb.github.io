#include<iostream>
#include<cstdio>
using namespace std;

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	for(int i=1;i<=k;i++){
		long long n,d,e;
		cin>>n>>d>>e;
		int flag=1;
		for(long long j=1;j<=n;j++){
			int y=n/(j*e*d);
			int f=j;
			if((f-1)*(f-1)+1==n){
				cout<<f<<" "<<f<<endl;
				flag=0;
			}
			if((y-1)*(f-1)+1==n){
				cout<<y<<" "<<f<<endl;
				flag=0;
			}
		}
		if(flag==1){
			cout<<"NO"<<endl;
		}
	}
} 
