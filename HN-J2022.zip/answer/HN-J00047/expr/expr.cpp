#include<iostream>
#include<cstdio>
using namespace std;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	cin>>a;
	int y;
	int len=0;
	string w=a;
	while(w[len]!='\0'){
		len++;
	}
	if(y==1){
		bool flag=0;
		for(int i=1;i<=len;i++){
			if(a[i]=='0'){
				cout<<0<<endl;
				flag=1;
				break;
			}
		}
		if(flag=0){
			cout<<1<<endl;
			cout<<0<<" "<<0;
			return 0;
		}
		for(int i=1;i<=len;i++){
			
		}
	}
	cout<<0<<endl;
	cout<<0<<" "<<0;
	return 0;
}
