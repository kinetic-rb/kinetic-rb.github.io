#include<iostream>
#include<cstdio>
using namespace std;
int x[1000001];
int y[1000001];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	scanf("%d %d", &n, &k);
	for(int i=1;i<=n;i++){
		scanf("%d %d", &x[i], &y[i]);
	}
	int cnt=0; 
	for(int i=1;i<=n;i++){
		if(x[i+1]-x[i]==1&&y[i+1]==y[i]||y[i+1]-y[i]==1&&x[i+1]==x[i]){
			cnt++;
		}
	}
	cout<<cnt+k*2+1;
	return 0;
}
