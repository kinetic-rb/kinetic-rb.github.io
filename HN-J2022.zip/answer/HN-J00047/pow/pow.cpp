#include<iostream>
#include<cstdio>
using namespace std;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int n,m;
	cin>>n>>m;
	long long cul=1;
	for(int i=1;i<=m;i++){
		cul*=n;
		if(cul>1000000000||cul<0){
			cout<<-1;
			return 0;
		}
	}
	cout<<cul;
	return 0;
} 
