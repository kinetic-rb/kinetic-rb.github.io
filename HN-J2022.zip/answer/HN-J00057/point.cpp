#include<bits/stdc++.h>
#define map pam
using namespace std;
const int M=30010;
long long int maxn=-1,n,k,x[510],y[510];
bool b[M][M],map[M][M];
int fx[4]={0,0,1,-1},fy[4]={-1,1,0,0};
void dfs(int xx,int yy,int cnt){
	if(cnt>maxn)maxn=cnt;
	for(int i=0;i<4;i++){
		int nx=xx+fx[i],ny=yy+fy[i];
		if(b[nx][ny]==0&&map[nx][ny]==1){
			b[nx][ny]=1;
			dfs(nx,ny,cnt+1);
		}
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x[i],&y[i]);
		map[x[i]][y[i]]=1;
	}
	for(int i=1;i<=n;i++)
		if(b[x[i]][y[i]]==0)b[x[i]][y[i]]=1,dfs(x[i],y[i],1);
	if(k==0)printf("%lld",maxn);
	else printf("%lld",maxn+k);
	return 0;
}
