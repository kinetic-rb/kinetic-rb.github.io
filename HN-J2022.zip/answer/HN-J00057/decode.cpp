#include<bits/stdc++.h>
#define LL long long int 
using namespace std;
LL k,n,d,e;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	while(k--){
		scanf("%lld%lld%lld",&n,&d,&e);
		LL m=n-e*d+2;
		bool flag=0;
		for(int i=1;i*i<=n;i++){
			if(n%i==0){
				if(i+n/i==m){
					printf("%lld %lld\n",i,n/i);
					flag=1;
					break;
				}
				if(i>n/i)break;
			}
		}
		if(flag==0)printf("NO\n");
	}
	return 0;
}
