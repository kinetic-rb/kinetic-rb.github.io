#include<bits/stdc++.h>
using namespace std;
long long a,b;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if((long long)pow(a,b)<0||(long long)pow(a,b)>1000000000)printf("-1");
	else printf("%lld",(long long)pow(a,b));
	return 0;
}
