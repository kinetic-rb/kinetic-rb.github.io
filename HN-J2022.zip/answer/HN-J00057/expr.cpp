#include<bits/stdc++.h>
#define LL long long int
using namespace std;
string a,ans;
int _and,_or,lena;
bool QWQ(int wei){
	if(a[wei]=='(')wei++;
	if(a[wei]==')')wei+=2;
	if(wei==lena-1)return a[wei]=='1';
	for(int i=wei;i<lena;i++){
		if(a[i]=='1'&&a[i+1]=='|'){_or++;return 1;}
		if(a[i]=='0'&&a[i+1]=='&'){_and++;return 0;}
		if(a[i]=='1'&&a[i+1]=='&'&&QWQ(i+2)==1)return 1;
		if(a[i]=='0'&&a[i+1]=='|'&&QWQ(i+2)==1)return 1;
		return 0;
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	lena=a.size();
	int t=QWQ(0);
	printf("%d\n%d %d",t,_and,_or);
	return 0;
}
