#include<bits/stdc++.h>
using namespace std;
int n, k;
int sum, ans;
struct node
{
	int a, b;
}t[600], tt[600];
bool cmp(node x, node y)
{
	return x.a < y.a;
}
bool cmp1(node x, node y)
{
	return x.b < y.b;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>t[i].a>>t[i].b;
		tt[i].a=t[i].a;
		tt[i].b=t[i].b;
	}
	sort(t+1,t+1+n,cmp);
	sort(tt+1,tt+1+n,cmp1);
	for(int i=2;i<=n;i++)
	{
		if(t[i].b>t[i-1].b) sum++;
		if(tt[i].a>t[i-1].a) ans++;
	}
	cout<<max(sum,ans)+k;
	return 0;
}
