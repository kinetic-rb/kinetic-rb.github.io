#include<bits/stdc++.h>
using namespace std;
long long a, b, c;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	c=a;
	if(a==1) 
	{
		cout<<1;
		return 0;
	}
	if(b>=31)
	{
		cout<<"-1";
		return 0;
	}
    for(int i=2;i<=b;i++)
    {
    	c*=a;
    	if(c>1e9)
    	{
    		cout<<"-1";
    		return 0;
		}
	}
	cout<<c;
	return 0;
}
