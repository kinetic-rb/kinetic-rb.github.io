#include<bits/stdc++.h>
using namespace std;
int k;
long long n, e, d, s, x, xx, y, yy;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
	{
		cin>>n>>d>>e;
		s=pow(e*d-2-n,2)-4*n;
		if(s<0) 
		{
			cout<<"NO"<<endl;
			continue;
		}
		x=(n+2-e*d+sqrt(s))/2;
		xx=(n+2-e*d-sqrt(s))/2;
		y=n/x;
		yy=n/xx;
		if(x*y-x-y+2==e*d)
		{
			cout<<min(x,y)<<" "<<max(x,y)<<endl;
			continue;
		}
		if(xx*yy-xx-yy+2==e*d)
		{
			cout<<min(xx,yy)<<" "<<max(xx,yy)<<endl;
			continue;
		}
		cout<<"NO"<<endl;
	}
	return 0;
}
