#include<bits/stdc++.h>
using namespace std;
string s;
int a,b;
int main()
{
	srand(time(0));
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.size()==1)
	{
		cout<<s[0];
		return 0;
	}
	cout<<rand()%2<<endl;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='0'&&s[i+1]=='&') a++;
		if(s[i]=='1'&&s[i+1]=='|') b++;
	}
	cout<<a<<" "<<b;
	return 0;
}
