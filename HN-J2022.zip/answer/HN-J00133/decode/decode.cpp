#include<bits/stdc++.h>
using namespace std;
int k;
long long a[100005],b[100005],c[100005],s[100005],f[100005],d[100005],e[10005];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout); 
	scanf("%d",&k);
	for(int num=1;num<=k;num++){
		scanf("%ld%ld%ld",&a[num],&b[num],&c[num]);
		for(int i=2;i<=a[num]/2+1;i++){
			if(a[num]%i==0){
				s[i]=i;
				f[i]=a[num]/i;
				if((b[i]*c[i])==s[i-1]+1||(b[i]*c[i])==f[i-1]||(b[i]*c[i])==s[i-1]||(b[i]*c[i])==f[i-1]+1){
					d[i]=s[i];
					e[i]=f[i];
				}		
			}
			
		}		
	}	
	for(int i=2;i<=k+1;i++){		
		if(d[i]==0&&e[i]==0){
			printf("NO\n");
		}
		else{
			printf("%ld %ld\n",d[i],e[i]);
		}
	}
	return 0;
} 
