#include<bits/stdc++.h>
using namespace std;
int n,m,ans,x[505],y[505];
int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x[i],&y[i]);
	}
	sort(i+1,i+n+1);
	
	
	
	return 0;
}
