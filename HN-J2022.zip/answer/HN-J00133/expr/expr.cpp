#include<bits/stdc++.h>
using namespace std;
string s;
int ans,a;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.length();i++){
		if(s[i]='&'){
			ans=s[i-1]&s[i+1];
		}
		else if(s[i]='|'&&s[i+2]!='&'){
			ans=s[i-1]|s[i+1];
		}
	}
	printf("%d\n",ans);
	printf("0 0");
	return 0;
}
