#include<bits/stdc++.h>
using namespace std;
long long a,b,ans;
int s;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%ld%ld",&a,&b);
	if(a>=10&&b>=10||(a<10&&b>=10)||(a>=10&&b<10)){
		s=-1;
		printf("-1");
		return 0;
	}
	ans=pow(a,b);
	if(ans>1000000000){
		s=-1;
		printf("-1");
	}
	else if(ans<=1000000000){
		printf("%ld",ans);
	}
	return 0;
}
