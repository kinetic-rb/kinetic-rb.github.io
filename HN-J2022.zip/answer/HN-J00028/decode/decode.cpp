#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
long long n,e,d,ans;
int p,q,k;
bool yon=false;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=0;i<k;i++)
	{
		cin>>n>>d>>e;
		ans=n-e*d+2;
		for(int j=1;j*j<n;j++){
			if(n%j==0){
				p=j;
				q=n/j;
				if(e*d==(p-1)*(q-1)+1){
					cout<<p<<' '<<q<<endl;
					yon=true;
					break;
				}
			
			}
				
		}
		if(!yon){
			cout<<"NO"<<endl;
		}
		yon=false;
	}
	return 0;
} 
