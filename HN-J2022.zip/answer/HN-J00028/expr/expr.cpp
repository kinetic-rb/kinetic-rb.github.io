#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
char a[1000001];
int yl,hl;
int pc(int i){			//�ų��ظ����� 
	for(;a[i+1]==a[i];i++){
	}
	return i;
}
int fx(int nun,int i){//���� 
	if(a[i-1]=='('){
		a[i-1]=nun;
	}
	if((a[i+2]=='1')&&(a[i+2]=='0'))
	{
		a[i+1]=nun;
		a[i+2]=nun;
		return 0;
	}
	if(a[i+2]=='('){
		a[i+2]=nun;
		for(;;i++){
			if(a[i]=='('){
				fx(nun,i+1);
			}
			if(a[i]==')'){
				a[i]=nun;
				break;
			}
			a[i]=nun;
		}
	}
}
void ss(int i){//���� 
	if((a[i]=='1')||(a[i]=='0')){
		i=pc(i);
	}
	if(a[i]=='1'&&a[i+1]){
		if(a[i+1]=='|'){
			fx(1,i);
			hl++;
			i=pc(i);
			if(a[i+1]){
				ss(i);
			}
		}else if(a[i+1]=='&'){
			if(a[i+2]=='1'){
				a[i+1]=1;
			}else if(a[i+2]=='0'){
				a[i]=0;
				a[i+1]=0;
			}
		}else if(a[i+1]=='('){
			ss(i+1);
		}
	}
	if((a[i]=='0')&&a[i+1]){
		if(a[i+1]=='&'){
			fx(0,i);
			yl++;
			i=pc(i);
			if(a[i+1]){
				ss(i);
			}
		}else if(a[i+1]=='|'){
			if(a[i+2]=='1'){
				a[i+1]=1;
				a[i]=1;
			}else if(a[i+2]=='0'){
				a[i+1]=0;
			}else if(a[i+2]=='('){
				ss(i+3);
			}
		}else if(a[i+1]=='('){
			ss(i+1);
		}
		
	}	
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	ss(0);
	cout<<a[0]<<endl;
	cout<<yl<<' '<<hl<<endl;
} 
