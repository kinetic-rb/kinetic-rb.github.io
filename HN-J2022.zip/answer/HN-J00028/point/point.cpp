#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int mx[600],my[600],n,k,nx,ny;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>mx[i]>>my[i];
	}
	cout<<n;
} 
