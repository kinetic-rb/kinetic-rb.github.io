#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
long long a,b,ans;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	ans=pow(a,b);
	if(ans>1000000000||ans<0){
		cout<<-1<<endl;
		return 0;
	}
	else{
		cout<<ans<<endl;
		return 0;
	}
	return 0;
} 
