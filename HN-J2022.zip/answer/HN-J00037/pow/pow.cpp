#include<bits/stdc++.h>
using namespace std;
const int N=1e9;
long long a,b,s=0;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout); 
	cin>>a>>b;
	s=a;
	for(int i=1;i<b;++i){
		if(a>N){
			cout<<"-1";
			return 0;
		}
		else a*=s;
	}
	cout<<a;
	return 0;
}
