#include<bits/stdc++.h>
using namespace std;
string s;
int a,b;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	for(int i=1;i<=s.size();++i){
		if(s[i]=='|'){
			a++;
		}
		else if(s[i]=='&'){
			b++;
		}
	}
	cout<<1<<endl;
	cout<<a<<" "<<b;
	return 0;
}
