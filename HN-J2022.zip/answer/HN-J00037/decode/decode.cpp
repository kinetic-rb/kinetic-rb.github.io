#include<bits/stdc++.h>
using namespace std;
const int N=1e3+5;
int k,n[N],e[N],d[N],p[N],q[N];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;++i){
		cin>>n[i]>>e[i]>>d[i];
		cout<<"No";
	}
	return 0;
} 
