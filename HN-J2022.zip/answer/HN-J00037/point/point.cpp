#include<bits/stdc++.h>
using namespace std; 
const int N=505;
int n,k;
int x[N],y[N];
int loong; 
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;++i)cin>>x[i]>>y[i];
	cout<<loong;
	return 0;
}
