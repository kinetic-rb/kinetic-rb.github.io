#include <bits/stdc++.h>
using namespace std;
//bl
bool isprime(long long n) {
	long long s = sqrt(n);
	if(n <= 2) {
		return 1;
	}
	if(n % 2 == 0) {
		return 0;
	}
	for(long long i = 3;i <= s;i += 2) {
		if(n % i == 0) {
			return 1;
		}
	}
	return 0;
}
unsigned long long pq;
int main() {
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	scanf("%d",&k);
	while(k--) {
		unsigned long long n,d,e;
		cin >> n >> e >> d;
		unsigned long long ed = d * e;
		bool find = 0;
		if(ed == 1) {
			printf("1 %d",n);
			find = 1;
		} else {
			unsigned long long left = n + 2 - ed;
			if(isprime(n)) {
				goto loop;
			}
			unsigned int bl = (left) / 2;
			for(unsigned long long p = 2,q = left - p;p <= bl;p++,q--) {
				pq = p * q;
				if(pq == n) {
					if(q > p) {
						swap(q,p);
					}
					printf("%d %d",q,p);
					find = 1;
					break;
				} else if(pq > n) {
					break;
				}
			}
		}
		loop:;
		if(!find) {
			printf("NO");
		}
		printf("\n");
	}
	return 0;
}
