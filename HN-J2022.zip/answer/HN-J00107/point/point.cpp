#include <bits/stdc++.h>
using namespace std;
int n,k;
struct point {
	int x,y;
}a[555];
bool m[111][111];
int main() {
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin >> n >> k;
	for(int i = 1;i <= n;i++) {
		cin >> a[i].x >> a[i].y;
		m[a[i].x][a[i].y] = 1;
	}
	cout << 3 << endl;
	return 0;
}
