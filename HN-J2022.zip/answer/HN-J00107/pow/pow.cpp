#include <bits/stdc++.h>
using namespace std;

int pow(int a,int b) {//bl qiu pow
	long long ans = 1;
	for(int i = 1;i <= b;i++) {
		ans *= a;
		if(ans > 1e9) {
			return -1;
		}
	}
	return ans;
}
int quickly_pow(int a,int b) {//ksm
	long long ans = 1;
	long long na = a;
	while(b) {
		na = na * na;
		int w = b & 2;
		b /= 2;
		if(w) {
			ans *= na;
		}
		if(ans > 1e9) {
			return -1;
		}
	}
	return ans;
}
int main() {
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin >> a >> b;
	cout << quickly_pow(a,b);
	return 0;
}
