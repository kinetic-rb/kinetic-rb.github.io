#include <bits/stdc++.h>
using namespace std;
int d1_,d2_;
bool cl(char c) {
	return c == '0' ? 0 : 1;
}
string cntc;
bool f(string s) {
	if(s.length() == 1) {
		return cl(s[0]);
	}
	for(int i = 0;i < s.length();i++) {
		if(s[i] == '&') {
			string ls = s.substr(0,i),rs = s.substr(i + 1,s.length() - i);
			bool lb = f(ls),rb = f(rs);
			if(!lb) {d1_++;}
			return lb && rb;
		} else if(s[i] == '|') {
			string ls = s.substr(0,i),rs = s.substr(i + 1,s.length() - i);
			bool lb = f(ls),rb = f(rs);
			if(lb) {d2_++;}
			return lb || rb;
		}
	}
}
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin >> s;
	cntc = s;
	cout << f(s) << '\n';
	cout << d1_ << ' ' <<d2_;
	return 0;
}
