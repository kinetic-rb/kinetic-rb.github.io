#include <bits/stdc++.h>
using namespace std;
int main(){
    freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
    string s;
    cin >> s;
    if (s[2] == '&'){
        if (s[1] == '0') cout << 0 << endl << "1 0";
        else{
            if (s[3] == '1') cout << 1 << endl << "0 0";
            else cout << 0 << endl << "0 0";
        }
    }
    else{
        if (s[1] == '1') cout << 1 << endl << "0 1";
        else{
            if (s[3] == '0') cout << 0 << endl << "0 0";
            else cout << 1 << endl << "0 0";
        }
    }
    return 0;
}
