#include <bits/stdc++.h>
using namespace std;
int main(){
    freopen("pow.in","r",stdin);
    freopen("pow.in","r",stdout);
    int a,b;
    cin >> a >> b;
    long long mul = 1;
    for (int i = 1; i <= b; i++) mul *= a;
    if (mul > 1000000000) cout << -1;
    else cout << mul;
    return 0;
}
