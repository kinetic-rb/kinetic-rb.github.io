#include <bits/stdc++.h>
using namespace std;
int a[1000001],b[10000000001];
int main(){
    freopen("point.in","r",stdin);
    freopen("point.out","w",stdout);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i] >> b[i];
    cout << 8;
    return 0;
}
