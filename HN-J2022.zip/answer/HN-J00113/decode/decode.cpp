#include <bits/stdc++.h>
using namespace std;
struct z
{
    long long n,d,e;
    void read(){
        cin >> n >> e >> d;
    }
};
z a[10001];
int main(){
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
    int k;
    cin >> k;
    for (int i = 1; i <= k; i++) a[i].read();
    for (int i = 1; i <= k; i++){
        int p,q;
        bool b = 0;
        for (p = 1; p <= a[i].n; p++){
            q = a[i].n / p;
            if ((p - 1) * (q - 1) + 1 == a[i].e * a[i].d && p <= q){
                cout << p << " " << q << "\n";
                b = 1;
                break;
            }
        }
        if (!b) cout << "NO" << "\n";
    }
    return 0;
}
