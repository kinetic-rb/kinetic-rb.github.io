#include<bits/stdc++.h>
using namespace std;
const long long maxn = 1e9;
long long a,b;
long long p(long long x,long long y)
{
	long long a = x;
	for(int i = 1; i < y; i++)
	{
		x *= a;
	}
	return x;
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	long long x = a;
	if(a == 1)
	{
		cout << 1;
		return 0;
	}
	if(b == 1 && a <= maxn)
	{
		cout << a;
		return 0;
	}
	for(int i = 1; i <= b; i++)
	{
		if(a > maxn)
		{
			cout << -1;
			return 0;
		}
		a *= x;
	}
	cout << p(x,b);
	return 0;
 }  
