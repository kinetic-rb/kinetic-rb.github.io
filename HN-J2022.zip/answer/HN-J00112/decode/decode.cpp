#include<bits/stdc++.h>
using namespace std;
int k;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	long long n,d,e;
	for(long long i = 1; i <= k; i++)
	{
		scanf("%lld%lld%lld",&n,&d,&e);
		long long pq = n;
		bool flag = 0;
		for(long long j = 1; j <= ceil(sqrt(pq)); j++)
		{
			if(pq % j == 0)
			{
				if(e * d == pq - j - (pq / j) + 2)
				{
					printf("%lld %lld\n",j,(pq / j));
					flag = 1;
					break;
				}
			}
		}
		if(flag == 0)
		{
			printf("%s\n","NO");
		}
	}
	return 0;
 } 
