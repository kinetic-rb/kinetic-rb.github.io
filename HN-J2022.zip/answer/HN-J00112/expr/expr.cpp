#include<bits/stdc++.h>
using namespace std;
string a;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout << 1 << endl << 1 << " " << 2;
	return 0;
 } 
