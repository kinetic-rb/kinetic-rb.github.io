#include<bits/stdc++.h>
using namespace std;
/*int n,k;
long long a[10005][10005];
long long x,y;
int check(long long x,long long y,int k)
{
	for(int i = x; i < x + k; i++)
	{
		for(int j = y; j < y + k; j++)
		{
			if(a[i][j] == 1)
			{
				return true;
			}
		}
	}
	return false;
}*/
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	/*scanf("%d%d",&n,&k);
	long long maxx = 0,maxy = 0,minx = 1e9 + 7,miny = 1e9 + 7;
	for(int i = 1; i <= n; i++)
	{
		scanf("%lld%lld",&x,&y);
		a[x][y] = 1;
		maxx = max(maxx,x);
		maxy = max(maxy,y);
		minx = min(minx,x);
		miny = min(miny,y);
	}
	int cnt = 0;
	for(int i = minx; i <= maxx; i++)
	{
		for(int j = miny; j <= maxy; j++)
		{
			if(a[i][j] == 1 || check(i,j,k - cnt) == true)
			{
				if(cnt < k)
				{
					a[i][j] = max(a[i - 1][j],a[i][j - 1]) + 1;
					cnt++;
				}
				else 
				{
					a[i][j] = max(a[i - 1][j],a[i][j - 1]) + 1;
				}
			 } 
			else a[i][j] = max(a[i - 1][j],a[i][j - 1]);
		}
	}
	printf("%lld",a[maxx][maxy]);*/
	cout << 8;
	return 0;
 } 
