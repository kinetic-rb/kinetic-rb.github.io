#include <iostream>
#include <cstring> 
#include <cstdio>

using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.ans","w",stdout);
	int n,xi,yi,k;
	cin>>xi>>yi;
    for(int i=1;i<=n;i++)
	{
		
	}

	fclose(stdin);
	fclose(stdout);
    return 0;	
}
