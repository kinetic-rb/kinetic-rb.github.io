#include <iostream>
#include <cstring> 
#include <cstdio>

using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin>>a>>b;
	for(int i=1;i<=b;i++)
	{
        a=a*a;	
	}
	        if(a>1000000000)
		{
			cout<<"-1"<<endl;
		}
		else
		{
			cout<<a;
		}
	fclose(stdin);
	fclose(stdout);
    return 0;	
}
