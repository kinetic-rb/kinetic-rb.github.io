#include <iostream>
#include <cstring> 
#include <cstdio>

using namespace std;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.ans","w",stdout);
    int k,ni,ei,di,pi,qi;
    cin>>k>>ni>>ei>>di;
    for(int i=1;i<=k;i++)
    {
    	pi<=qi;
    	if(ni==pi*qi&&ei*di==(pi-1)*(qi-1)+1)
    	{
    		cout<<pi<< " " <<qi<<endl;
		}
		else
		{
			cout<<"NO"<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
    return 0;	
}
