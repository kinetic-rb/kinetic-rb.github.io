#include <iostream>
#include <cstring> 
#include <cstdio>

using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
    float s[7];
    cin>>s;
    
    
    
    
    
	fclose(stdin);
	fclose(stdout);
    return 0;	
}