#include<bits/stdc++.h>
using namespace std;
struct node
{
	int x,y,p;
}a[505];
int cmp(node e,node f)
{
	if (e.x==f.x) return e.y<f.y;
	else return e.x<f.x;
}
int main()
{
    freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k,maxx=-1;
	cin>>n>>k;
	for (int i=1;i<=n;++i)
	{
		cin>>a[i].x>>a[i].y;	
	 } 
	sort (a+1,a+n+1,cmp);
	for (int i=1;i<=n;++i)
	{
		a[i].p=1;
	}
	for (int i=1;i<=n;++i)
	{
		int s1=a[i].x,s2=a[i].y,m=1;
		for (int j=i+1;j<=n;++j)
		{
			if (a[j].x==s1&&a[j].y==s2+1)
			{
				s1=a[j].x,s2=a[j].y;
				m++;
			}
			else if (a[j].x==s1+1&&a[j].y==s2) 
			{
				s1=a[j].x,s2=a[j].y;
				m++;
			}
		}
		if (m>maxx) maxx=m;
	}
	cout<<maxx;
	return 0;
}

