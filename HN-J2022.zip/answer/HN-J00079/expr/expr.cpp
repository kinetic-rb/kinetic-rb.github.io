#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	int n;
	cin>>s; 
	n=s.size();
	if (n<=3) 
	{
		int x=0,y=0,p=0,q=0;
		for (int i=0;i<n;++i) 
		{
		    if (s[i]=='1') x++;
			if (s[i]=='0') y++;
			if (s[i]=='&') p++;
			if (s[i]=='|') q++;
		}
		if (p==1)
		{
			if (x==2) cout<<1;
			else cout<<0;
		}
		else
		{
			if (y==2) cout<<0;
			else cout<<1;
		}
		if (p==1&&s[0]=='0') cout<<1;
		else cout<<0;
		if (q==1&&s[0]=='1') cout<<1;
		else cout<<0;
	}
	return 0;
}
