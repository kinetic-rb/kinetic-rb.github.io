#include<bits/stdc++.h>
using namespace std;
long long n[100005],e[100005],d[100005];
int main()
{
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	for (int i=1;i<=k;++i) 
	{
		int m;
		bool b=1;
		cin>>n[i]>>e[i]>>d[i];
		m=n[i]-(e[i]*d[i])+2;
		for (int j=1;j<=m/2;++j)
		{
			if (j*(m-j)==n[i])
			{
				cout<<j<<' '<<m-j<<endl;
				b=0;
				break;
			 } 
		}
		if (b==1) cout<<"NO"<<endl;
	}
	return 0;
}
