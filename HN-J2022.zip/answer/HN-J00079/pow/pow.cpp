#include<bits/stdc++.h>
using namespace std;
bool x=1;
int main()
{
    freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,n;
	cin>>a>>b;
	n=a;
	if (a==1)
	{
		cout<<1;
		return 0;
	}
	for (int i=2;i<=b;++i)
	{
		if (n*a<=1000000000)
		    n*=a;
		else 
		{
			x=0;
			break;
		}
	}
	if (x==1) cout<<n;
	else cout<<"-1"; 
	return 0;
}
