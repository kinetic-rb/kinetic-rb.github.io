#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 605;
struct node {
	int x, y;
} a[N];
int n, k, ans = 0;
map<int, int> mpx, mpy;
signed main() {
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	cin >> n >> k;
	for(int i = 1; i <= n; i++) {
		cin >> a[i].x >> a[i].y;
		mpx[a[i].x]++, mpy[a[i].y]++;
	}
	for(int i = 1; i <= n; i++) {
		ans = max(ans, max(mpx[a[i].x], mpy[a[i].y]));
	}
	cout << ans + k;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

