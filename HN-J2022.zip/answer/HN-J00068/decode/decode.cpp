#include<bits/stdc++.h>
using namespace std;
long long n, d, e;
inline long long read() {
	long long x = 0;
	bool flag = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = 1;
			ch = getchar();
		}
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + ch - '0';
		ch = getchar();
	}
	if(!flag) {
		return x;
	} else {
		return ~(x - 1);
	}
}
inline void write(long long x) {
	if(x < 0) {
		x = ~(x - 1);
		putchar('-');
	}
	if(x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
int main() {
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	int k = read();
	while(k--) {
		bool f = 0;
		n = read(), d = read(), e = read();
		long long tmp = d * e - 1;
		if(n <= tmp) {
			puts("NO");
			continue;
		}
		for(long long i = 1; i <= sqrt(n); i++) {
			if(n % i != 0) {
				continue;
			}
			long long j = n / i;
			if((i - 1) * (j - 1) == tmp) {
				write(i);
				printf(" ");
				write(j);
				puts("");
				f = 1;
				break;
			}
		}
		if(!f) {
			puts("NO");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

