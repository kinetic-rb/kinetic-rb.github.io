#include<bits/stdc++.h>
using namespace std;
long long a, b, s = 1;
int main() {
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	cin >> a >> b;
	if(a == 1) {
		puts("1");
		return 0;
	}
	if(b >= 30) {
		puts("-1");
		return 0;
	}
	for(int i = 1; i <= b; i++) {
		if(s * a > 1000000000) {
			puts("-1");
			return 0;
		}
		s *= a;
	}
	cout << s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

