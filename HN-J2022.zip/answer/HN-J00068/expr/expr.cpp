#include<bits/stdc++.h>
using namespace std;
int cnt1 = 0, cnt2 = 0;
stack<int> stk1;
stack<char> stk2;
string s;
int main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	cin >> s;
	if(s.size() == 1) {
		cout << s[0] << "\n0 0";
		return 0;
	}
	if(s.size() == 3) {
		if(s[0] == '(') {
			cout << s[1] << "\n0 0";
		} else {
			if(s[1] == '&') {
				cout << ((s[0] - '0') & (s[2] - '0'));
				if(s[0] == '0') {
					cout << "\n1 0";
				} else {
					cout << "\n0 0";
				}
			} else {
				cout << ((s[0] - '0') | (s[2] - '1'));
				if(s[0] == '1') {
					cout << "\n0 1";
				} else {
					cout << "\n0 0";
				}
			}
		}
		return 0;
	}
	if(s.size() == 5) {
		if(s[0] == '(') {
			if(s[2] == ')') {
				if(s[3] == '&') {
					cout << ((s[1] - '0') & (s[4] - '0'));
					if(s[1] == '0') {
						cout << "\n1 0";
					} else {
						cout << "\n0 0";
					}
				} else {
					cout << ((s[1] - '0') | (s[4] - '1'));
					if(s[1] == '1') {
						cout << "\n0 1";
					} else {
						cout << "\n0 0";
					}
				}
			} else {
				if(s[2] == '&') {
					cout << ((s[1] - '0') & (s[3] - '0'));
					if(s[1] == '0') {
						cout << "\n1 0";
					} else {
						cout << "\n0 0";
					}
				} else {
					cout << ((s[1] - '0') | (s[3] - '1'));
					if(s[1] == '1') {
						cout << "\n0 1";
					} else {
						cout << "\n0 0";
					}
				}
			}
		} else if(s[2] == '(') {
			if(s[1] == '&') {
				cout << ((s[0] - '0') & (s[3] - '0'));
				if(s[0] == '0') {
					cout << "\n1 0";
				} else {
					cout << "\n0 0";
				}
			} else {
				cout << ((s[0] - '0') | (s[3] - '1'));
				if(s[0] == '1') {
					cout << "\n0 1";
				} else {
					cout << "\n0 0";
				}
			}
		} else {
			if(s[1] == '&') {
				if(s[3] == '|') {
					cout << ((s[0] - '0') & (s[2] - '0') | (s[4] - '0'));
					if(s[0] == '0') {
						cout << "\n1 ";
					} else {
						cout << "\n0 ";
					}
					if(s[2] == '1') {
						cout << "1";
					} else {
						cout << "0";
					}
				} else {
					cout << ((s[0] - '0') & (s[2] - '0') & (s[4] - '0'));
					if(s[0] == '0') {
						cout << "\n1 ";
					} else {
						cout << "\n0 ";
					}
					if(s[2] == '0') {
						cout << "1";
					} else {
						cout << "0";
					}
				}
			} else {
				if(s[3] == '|') {
					cout << ((s[0] - '0') | (s[2] - '0') | (s[4] - '0'));
					if(s[0] == '1') {
						cout << "\n1 ";
					} else {
						cout << "\n0 ";
					}
					if(s[2] == '1') {
						cout << "1";
					} else {
						cout << "0";
					}
				} else {
					cout << ((s[0] - '0') | ((s[2] - '0') & (s[4] - '0')));
					if(s[0] == '1') {
						cout << "\n0 1";
					} else {
						cout << "\n";
						if(s[2] == '0') {
							cout << "1 0";
						} else {
							cout << "0 0";
						}
					}
				}
			}
		}
		return 0;
	}
	cout << "1\n0 0";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
