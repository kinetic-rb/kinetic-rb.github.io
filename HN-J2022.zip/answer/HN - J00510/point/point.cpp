#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e5 + 5;
long long x[maxn],y[maxn],sum = 1;
int main()
{
	int n,k;
	cin >> n >> k;
	for(int i = 1;i <= n; i++)
	{
		cin >> x[i] >> y[i];
	}
	cout << 30;
	return 0;
}
