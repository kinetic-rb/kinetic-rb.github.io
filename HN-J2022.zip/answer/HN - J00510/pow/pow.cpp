#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e9;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin >> a >> b;
	if(pow(a,b) > maxn)
	{
		cout << -1;
	}
	else
	{
		long long ans = pow(a,b);
		cout <<ans;
	}
	return 0;
}
