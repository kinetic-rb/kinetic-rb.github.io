#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e5 + 5;
long long n[maxn];
long long d[maxn];
long long e[maxn];
int flag = 1;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	for(int i = 1;i <= k; i++)
	{
		cin >> n[i] >> d[i] >> e[i];
	}
	for(int q = 1;q<= k; q++)
	{
		flag = 1;
		for(int i = 1;i * i <= n[q]; i++)
		{
			if(n[q] % i == 0)
			{
				int a = n[q] / i;
				if(e[q] * d[q] == (i - 1) * (a - 1) + 1)
				{
					cout << i << " " << a << endl;
					flag = 0;
					break;
				}
			}
		}
		if(flag == 1)
		{
			cout << "NO" << endl;
		}
	}
	return 0;
}
