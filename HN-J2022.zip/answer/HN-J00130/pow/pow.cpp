#include<bits/stdc++.h>
using namespace std;
int n,m,a;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>n>>m;
	a=pow(n,m);
	if(a<0){
		cout<<-1;
		return 0;
	}
	cout<<a;
	return 0;
} 
