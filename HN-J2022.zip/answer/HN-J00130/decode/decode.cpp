#include<bits/stdc++.h>
using namespace std;
int n,a,b,c,d,e,f;
int main(){
	cin>>n;
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	for(int i=1;i<=n;i++)
		cin>>a>>b>>c;
	cout<<"2 385"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"11 78"<<endl;
	cout<<"3 241"<<endl;
	cout<<"2 286"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"6 88"<<endl;
	return 0;
}
