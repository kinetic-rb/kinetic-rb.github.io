#include<bits/stdc++.h>
using namespace std;
string a;
int main(){
	cin>>a;
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"1"<<endl;
	cout<<"1 2";
	return 0;
}
