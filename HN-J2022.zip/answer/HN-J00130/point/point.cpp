#include<bits/stdc++.h>
using namespace std;
int n,m,a,b;
int main(){
	cin>>n>>m;
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	for(int i=1;i<=n;i++){
		cin>>a>>b;
	}
	cout<<"8";
	return 0;
}
