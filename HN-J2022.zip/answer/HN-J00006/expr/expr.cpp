#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen ("expr.in","r",stdin);
	freopen ("expr.out","w",stdout);
	string s;
	cin>>s;
	int a,b;
	std:
	for(int i=0;i<=2000;i++)
	{
		if(s[i]=='&'&&s[i-1]==0,s[i+1]==0||s[i+1]==1)
		{
			s[i-1]=2;s[i]=2;s[i+1]==0;
			a++;
		}
		if(s[i]=='&'&&s[i-1]==1)
		{
			if(s[i+1]=0) {s[i-1]=2;s[i]=2;s[i+1]==0;}
			if(s[i+1]=1) {s[i-1]=2;s[i]=2;s[i+1]==1;}
		 } 
	}
	for(int i=0;i<=2000;i++)
	{
	if(s[i]=='|'&&s[i-1]==1,s[i+1]==0||s[i+1]==1)
		{
			s[i-1]=2;s[i]=2;s[i+1]==1;
			b++;
		}
		if(s[i]=='&'&&s[i-1]==0)
		{
			if(s[i+1]=0) {s[i-1]=2;s[i]=2;s[i+1]==0;}
			if(s[i+1]=1) {s[i-1]=2;s[i]=2;s[i+1]==1;}
		 } 
	}
	int c=0; 
	for(int i=0;i<=2000;i++)
	{
		if(s[i]==2)
		{
			b++;
			s[i+c]=s[i];
			s[i+c]=2;
			
		}
	}
	if (s[2]==0||s[2]==1) {
		goto std;
	}
	cout<<s;
}
