#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,x;
	cin>>a>>b;
	x=a;
	
	if (b>9)
	{
		cout<<"-1"<<endl;
		return 0;
	}
	for (int i=2;i<=b;i++)
	{
		x=x*a;
	}
	cout<<x<<endl;
	return 0;
	
}
