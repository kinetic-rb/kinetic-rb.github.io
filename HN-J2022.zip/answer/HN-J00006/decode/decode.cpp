#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen ("decode.in","r",stdin);
	freopen ("decode.out","w",stdout);
	int k,n1,e1,d1;
	cin>>k;
	for (int i=1;i<=k;i++)
	{
		cin>>n1>>e1>>d1;
		cout<<"NO"<<endl; 
	}
	return 0;
}
