#include<iostream>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	int a[k][3];
	for (int i=1;i<=k;i++){
		cin >> a[i][1] >> a[i][2] >> a[i][3];
	}
	for (int i=1;i<=k;i++){
		for (int p=1;p<=a[i][1];p++){
			for (int q=p;q<=a[i][1];q++){
				if (p*q==a[i][1]&&a[i][2]*a[i][3]==(p-1)*(q-1)+1){
					cout << p << " " << q << endl;
					i++;
				}
			}
			if (p*p==a[i][1]||p*p+1==a[i][1]){
				i++;
			}
		}
		if (i<=k){
			cout << "NO" << endl;
		}
	} 
	return 0;
}
