#include<iostream>
#include<string>
using namespace std;
int main(){
	freopen("exer.in","r",stdin);
	freopen("exer.out","w",stdout);
	string s;
	cin >> s;
	int sum=0,sum1=0;
	bool x=true;
	for (int i=1;i<=s.length();i++){
		if (x==true&&s.length()>1&&i==s.length()){
			x=false;
			i=1;
		}
		if (s[i]=='('){
			for (int j=i+1;j<s.length();j++){
				if (s[j]!=')'){
					if (s[j]=='&'){
						if (s[j-1]=='0'){
							sum++;
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
						else if (s[j+1]=='0'){
							s[j-1]='0';
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
						else{
							s[j-1]='1';
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
					}
					else if (s[j]=='|'){
						if (s[j-1]=='1'){
							sum1++;
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
						else if (s[j+1]=='1'){
							s[j-1]='1';
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
						else{
							s[j-1]='0';
							for (int k=j;k<=s.length();k++){
								s[k]=s[k+2];
							}
						}
					}
				}
				else{
					for (int k=j;k<=s.length();k++){
						s[k]=s[k+1];
					}
					j=s.length();
					
				}
			}
			for (int j=i;j<=s.length();j++){
				s[j]=s[j+1];
			}
		}
		else if (s[i]=='&'&&x==false){
			if (s[i-1]=='0'){
				sum++;
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
			else if (s[i+1]=='0'){
				s[i-1]='0';
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
			else{
				s[i-1]='1';
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
		}
		else if (s[i]=='|'&&x==false){
			if (s[i-1]=='1'){
				sum1++;
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
			else if (s[i+1]=='1'){
				s[i-1]='1';
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
			else{
				s[i-1]='0';
				for (int j=i;j<=s.length();j++){
					s[j]=s[j+2];
				}
			}
		}
	}
	cout << s << endl << sum << " " << sum1;
	return 0;
}
