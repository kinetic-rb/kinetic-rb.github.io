#include<bits/stdc++.h>
using namespace std;
const long long N=1e9;
long long a,b,sum=1;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	if(b>50)
	{
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=b;i++)
	{
		if(sum*a<=N)
			sum*=a;
		else
		{
			cout<<-1;
			return 0;
		}
	}
	cout<<sum;
	return 0;
}
	
