#include<bits/stdc++.h>
using namespace std;
long long n,e,d,cnt=0;
long long ans=0,k;
queue <long long>q;
void y(int x)
{
	cnt=0;
	for(int i=1;i*i<=x;i++)
		if(x%i==0)
		{
			q.push(i);
			q.push(x/i);
			cnt++;
		}
	return ;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--)
	{
		cin>>n>>e>>d;
		y(n);
		ans=0;
		long long a=0,b=0;
		for(int i=1;i<=cnt;i++)
		{
			a=q.front();
			q.pop();
			b=q.front();
			q.pop();
			if((a-1)*(b-1)+1==e*d)
			{	
				ans++;
				cout<<a<<" "<<b<<"\n";
			}	
		}
		if(ans==0)
			cout<<"NO\n";
	}
	return 0;
}

