#include<bits/stdc++.h>
using namespace std;
long long t;
long long n,d,e;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>t;
	while(t--)
	{
		bool flag=false;
		cin>>n>>d>>e;
		for(long long i=0;i<=max(d*e,n);i++)
		{
			for(long long j=i;j<=max(d*e,n);j++)
			{
				if(i*j==n&&((i-1)*(j-1)+1)==d*e)
				{
					cout<<i<<" "<<j<<endl;
					flag=true;
					break;
				}
			}
		}
		if(!flag)
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
