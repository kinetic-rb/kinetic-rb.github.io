#include <cstdio>
#include <cmath>
using namespace std;
typedef long long ll;
inline ll qpow(ll a, ll b, ll m)
{
	ll res = 1;
	while (b > 0)
	{
		if (b % 2 == 1)res *= a;
		a *= a;
		//binnary
		b >>= 1;
		if (res > m)return -1;
	}
	return res;
}
int main()
{
    freopen("pow.out", "w", stdout);
    freopen("pow.in", "r", stdin);
    int a, b;
    scanf("%d%d", &a, &b);
    printf("%d", qpow(a, b, 2147483647));
    fclose(stdin);
    fclose(stdout);
    return 0;
}
