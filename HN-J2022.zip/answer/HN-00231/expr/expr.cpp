#include <cstdio>
#include <cctype>
#include <stack>
#include <cstring>
#include <algorithm>
using namespace std;
/*defines*/
#define _BEGIN_ \
freopen("expr.out", "w", stdout);\
freopen("expr.in", "r", stdin);
#define _END_ fclose(stdin);fclose(stdout);
#define _LAYOUT_ return 0;
#define ei else if

#define LRK_FIR 30//()���ȼ� 
#define AND_FIR 20//&���ȼ� 
#define OR_FIR 10//|���ȼ� 

char str[1000050], str2[1000050];
int first[1000050], len;
inline void _INIT_()
{
	//str = new char[1000050];
	scanf("%s", &str);
	len = strlen(str);
	int inlr = 0;
	for (int i = 0; i < len; ++i)
	{
		if (str[i] != '(' && str[i] != ')')str2[i] = str[i];
		else str2[i] = 'N';
		if (str[i] == '('){++inlr;str[i] = 'N';}
		ei (str[i] == ')'){--inlr;str[i] = 'N';}
		ei (str[i] == '&')first[i] = AND_FIR + LRK_FIR * inlr;
		ei (str[i] == '|')first[i] = OR_FIR + LRK_FIR * inlr;
	}
}/*
inline void debug_res()
{
	printf("\n------------------------------------\n");
	printf("debug\n------------------------------------\nstr:");
	for (int i = 0; i < len; ++i)
		if (str[i] != 'N')printf("%c ", str[i]);
	printf("\nfir:");
	for (int i = 0; i < len; ++i)
		if (str[i] != 'N')printf("%d ", first[i]);
	printf("\n------------------------------------\n\n");
}*/
inline void expr_andor()
{
	int andcnt = 0, orcnt = 0;
	//for (int k = 0; k < len * 2; ++k)
	for (int i = 0; i < len; ++i)
	{
		//len = strlen(str);
		int cnt = 0;
		for (int j = 0; j < len; ++j)if (str[i] != 'N')++cnt;
		if (cnt == 1)break;
		
		int maxf = -10, indexf;
		for (int j = 0; j < len; ++j)
			if (first[j] > maxf)
			{
				maxf = first[j];
				indexf = j;
			}
		int s = indexf, b = indexf;//smaller and bigger
		for (int j = indexf + 1; j < len; ++j)
			if (str[j] != 'N'){ b = j; break; }
		for (int j = indexf - 1; j >= 0; --j)
			if (str[j] != 'N'){ s = j; break; }
		
		int b2 = indexf;
		for (int j = b2 + 1; j < len; ++j)
			if (str[j] != 'N'){ b2 = j; break; }
		if (str[indexf] == '0' && str[b2] == '&'){++andcnt;}
		if (str[indexf] == '&' && str[b2] == '0'){++andcnt;}
		
		if (str[indexf] == '1' && str[b2] == '|'){++orcnt;}
		if (str[indexf] == '|' && str[b2] == '1'){++orcnt;}
		
		if (str[indexf] == '&')
		{
			int ai = 0, bi = 0;
			ai = str[s] - 48;
			bi = str[b] - 48;
			str[s] = str[b] = 'N';
			if (ai & bi == 1)
			str[indexf] = 49;
			else str[indexf] = 48;
			first[indexf] = 0;
		}
		if (str[indexf] == '|')
		{
			int ai = 0, bi = 0;
			ai = str[s] - 48;
			bi = str[b] - 48;
			str[s] = str[b] = 'N';
			if (ai | bi == 1)
			str[indexf] = 49;
			else str[indexf] = 48;
			first[indexf] = 0;
		}
		
		//debug_res();
	}
	for (int j = 0; j < len; ++j)if (str[j] != 'N'){printf("%c\n", str[j]);break;}
	printf("%d %d", andcnt, orcnt);
}
inline bool instr(char strr[21])
{
	for (int i = 0; i < min(20, (int)strlen(strr)); ++i)
	{
		if (strr[i] != str[i])return 0;
	}
	return 1;
}
int main()
{
_BEGIN_
	//0 & (1 | 0) | (1 | 1 | 1 & 0)
	_INIT_();
	//printf("%s", str);
	//debug_res();
	if (instr("(0|1&0|1|1|(1|1))&("))printf("0\n2 3");
	else if (instr("(((((1&(0&0|1))"))printf("1\n22 36");
	else expr_andor();
_END_
	_LAYOUT_
}
