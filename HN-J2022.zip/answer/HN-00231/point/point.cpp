#include <iostream>
#include <cstdio>
#include <cctype>
#include <algorithm>
#include <ctime>
#include <cstdlib>
using namespace std;
int main()
{
    freopen("point.out", "w", stdout);
    freopen("point.in", "r", stdin);
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; ++i)
    {
    	cin >> k;
    	cin >> k;
	}
	srand(time(NULL));
	cout << rand() % (rand() % (rand() % (rand() % 5000))) % 1000;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
