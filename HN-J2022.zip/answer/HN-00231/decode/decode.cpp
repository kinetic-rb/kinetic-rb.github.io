//#pragma optimize(2)
#include <cstdio>
#include <cmath>
#define ll long long
#define MAXN 100005
#define ERROR_CODE -10

ll N[MAXN], E[MAXN], D[MAXN];
ll k, p, q;

inline void init()
{
    scanf("%d", &k);
    for (ll i = 0; i < k; ++i)
    {
    	scanf("%d%d%d", &N[i], &D[i], &E[i]);
	}
}

inline ll decode(ll _i)
{
	ll n = N[_i], d = D[_i], e = E[_i];
	p = q = 0;
	int ed = e * d;
	int x = sqrt(n) + 1;
	for (ll i = 1; i <= x; ++i)
	{
		if (n % i == 0)
		{
			p = i;
			q = n / p;
			if (ed == (p - 1) * (q - 1) + 1)//e ��d = (p-1)(q-1)+1
				return 1;
		}
	}
	return ERROR_CODE;
}
int main()
{
    freopen("decode.out", "w", stdout);
    freopen("decode.in", "r", stdin);
    init();
    for (ll i = 0; i < k; ++i)
    {
    	ll res = decode(i);
    	if (res < 0)printf("NO\n");
    	else printf("%d %d\n", p, q);
	}
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
