#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int t=1000000000;
	long long s,a,b;
	cin>>a>>b;
	s=a;
	for(long long i=1;i<b;i++){
		s=s*a;
		if(s>t){
			cout<<"-1";
			break;
		}
	}
	if(s<=t){
		cout<<s;
    }
	return 0;
}
