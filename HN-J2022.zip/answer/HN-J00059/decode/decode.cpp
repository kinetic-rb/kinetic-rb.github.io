#include<bits/stdc++.h> 
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
    int a[100],c,j,t,p,q;
    int x,y,z;
    cin>>c;
    for(int i=1;i<=c;i++){
    	cin>>a[i]>>a[j]>>a[t];
    	x=a[i];
    	y=a[j];
    	z=a[t];
    	for(int i=1;i<=10000;i++){
    		p=i;
    		for(int j=1;j<=10000;j++){
    			q=j;
    			if(p*q==x && (p-1)*(q-1)+1==y*z){
    				if(p<=q){
    					cout<<p<<" "<<q;
    				    break;
					}
				}
			}
		}
		cout<<endl;
	}
	return 0;
}
