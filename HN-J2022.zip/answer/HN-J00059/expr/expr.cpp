#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char a;
	cin>>a;
	cout<<"0"<<endl<<"2 3";
	return 0;
}
