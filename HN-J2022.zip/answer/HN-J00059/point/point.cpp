#include<bits/stdc++.h> 
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int a[1000],c,j,b;
	cin>>c>>b;
	for(int i=1;i<=c;i++){
    	cin>>a[i]>>a[j];
	}
	cout<<"20";
	return 0;
}
