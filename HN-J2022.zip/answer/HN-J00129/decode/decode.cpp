#inclue<bits/stdc++.h>
using namespace std;
long long a,b,c,n;
int main(){
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++){
        cout<<"NO"<<endl;
    }
    return 0;
}
