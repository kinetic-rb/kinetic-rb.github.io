#include<bits/stdc++.h>
using namespace std;
long long a,b,c;
int main(){
    freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
    cin>>a>>b;
    c=a;
    for(int i=1;i<b;i++){
        a*=c;
        if(a>1000000000){
            cout<<-1;
            return 0;
        }
    }
    cout<<a;
    return 0;
}
