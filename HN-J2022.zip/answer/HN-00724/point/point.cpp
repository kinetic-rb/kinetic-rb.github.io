#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,c=1;
	int d=0;
	cin>>a>>b;
	if(a==1)	cout<<1;
	else	if(a>1000000000)	cout<<-1;
	else 	if(b==1&&a<=1000000000)	cout<<a;
	else
	{	for(;b>0;b-=2)
		{	if(b==1)	c*=a;
			else	c*=a*a;
			if(c>1000000000)	
			{	d=1;
				cout<<-1;
				break;	}	}
		if(d!=1)	cout<<c;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
