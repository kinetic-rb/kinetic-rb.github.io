#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n,e,a,b,d;
	int k,s,c=0;
	cin>>k;
	for(int i=0;i<k;i++)
	{	c=0;
		cin>>n>>d>>e;
		s=sqrt(n)+0.001;
		for(a=2;a<=n;a++)
		{
			if(n%a==0)
			{	b=n/a;
				if(((a-1)*(b-1)+1)==e*d)
				{	c=1;
					if(a>b)
					cout<<b<<" "<<a<<endl;
					else
					cout<<a<<" "<<b<<endl;
					break;
				}
			}
		}
		if(c!=1)	cout<<"NO"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
