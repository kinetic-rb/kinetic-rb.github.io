#include <bits/stdc++.h>
using namespace std;
int main()
{	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int i=0;
	string s;
	cin>>s;
	if((int)s[1]==38)
		if(s[0]==48)	i++;
	if((int)s[1]==124)
		if(s[0]==49)	i++;
	if(s=="0|1"||s=="1|0"||s=="1|1"||s=="1&1")
		cout<<1<<endl;
	if(s=="1&0"||s=="0&1"||s=="0&0"||s=="0|0")
		cout<<0<<endl;
	if((int)s[1]==38)
		cout<<i<<" "<<0;
	if((int)s[1]==124)	
		cout<<0<<" "<<i;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
