#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin>>a>>b;
	int c=pow(a,b);
	if(c>pow(10,9)){
		cout<<-1;
	}else{
		cout<<c;
	}
	return 0;
}
