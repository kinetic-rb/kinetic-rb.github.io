#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int x;
	int n[10001],e[10001],d[10001],p[10001],q[10001];
	cin>>x;
	for(int i=0;i<x;i++){
		cin>>n[i]>>d[i]>>e[i];
	}
	for(int i=0;i<x;i++){
		bool f=true;
		for(p[i]=0;p[i]<=n[i];p[i]++){
			for(q[i]=0;q[i]<=n[i];q[i]++){
				if(p[i]*q[i]==n[i]&&e[i]*d[i]==(p[i]-1)*(q[i]-1)+1){
					if(p[i]>q[i]){
						cout<<q[i]<<" "<<q[i]<<endl;
					}else{
						cout<<p[i]<<" "<<q[i]<<endl;
					}
					f=false;
					break;
				}
			}
			if(f==false){
				break;
			}
		}
		if(f){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
