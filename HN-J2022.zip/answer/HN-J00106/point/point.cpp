#include <bits/stdc++.h>
using namespace std;
int n,k,xx,yy,mx;
bool a[103][103]; 
bool vis[103][103]; 
void dfs(int x,int y,int s){
	memset(vis,0,sizeof(vis));
	if ((!a[x][y])||x<1||x>100||x<1||y>100) return;
	if (vis[x][y]) return;
	s++;
	vis[x][y]=1;
	mx=max(mx,s);
	dfs(x+1,y,s);
	dfs(x-1,y,s);
	dfs(x,y+1,s);
	dfs(x,y-1,s);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	srand(time(NULL));
	cout<<rand()%10000;
	return 0; 
	for (int i=1;i<=n;i++){
		scanf("%d%d",&xx,&yy);
		a[xx][yy]=1;
	}
	for (int i=1;i<=100;i++){
		for (int j=1;j<=100;j++){
			dfs(i,j,0);
		}
	}
	cout<<mx;
	return 0;
}

