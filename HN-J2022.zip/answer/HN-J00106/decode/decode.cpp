#include <bits/stdc++.h>
using namespace std;
int q;
long long n,e,d;
long long cha;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>q;
	while (q--){
//		cout<<"\n\n\n";
		scanf("%lld%lld%lld",&n,&e,&d);
		cha=n-(e*d-2);
//		cout<<"cha-> "<<cha<<'\n';
		long long l=1,r=(long long)sqrt(n);
		while (l<r){
			long long mid=(l+r)>>1;
//			cout<<"-->"<<l<<' '<<r<<' '<<mid<<'\n';
			if ((n%mid?n/mid+1:n/mid)+mid>cha) l=mid+1;
			else r=mid;
		}
		if ((n%l==0)&&(l+n/l==cha)){
			printf("%lld %lld\n",l,n/l);
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}

