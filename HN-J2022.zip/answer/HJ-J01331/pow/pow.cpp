#include<bits/stdc++.h>
using namespace std;
long long a,b,c;
long long d=1000000000;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout); 
	cin>>a>>b;
	c=pow(a,b);
	if(c<d){
		cout<<"-1";
	}
	else {
		cout<<c;
	}
	return 0;
}

