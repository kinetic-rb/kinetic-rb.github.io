#include<bits/stdc++.h>
using namespace std;
long long n[1000],d[1000],e[1000],x[1000],y[1000];
int a,ans=1;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>a;
	for(int i;i<a;i++)
	{
		cin>>n[i]>>d[i]>>e[i];
		y[i]=e[i]*d[i]*-1;
		x[i]=n[i]+2;
			for(int j=0;j<i;j++)
			{
				cout<<x[j]<<y[j]<<endl;
			 } 
			
		  
	 } 
	if(ans==1)cout<<"NO"<<endl;	 
	return 0;
}

