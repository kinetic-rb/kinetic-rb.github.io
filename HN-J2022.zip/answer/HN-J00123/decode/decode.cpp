#include<cmath>
#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	int k;
	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	scanf("%d",&k);
	
	for(int i=1;i<=k;i++)
	{
		int m=0,n,e,d;
		scanf("%d%d%d",&n,&e,&d);
		for(int j=1;j<=sqrt(n)&&m==0;j++)
			if(n%j==0)
			{
				int p=j,q=n/j;
				if((p+q)==n-e*d+2)
				{
					printf("%d %d",p,q);
					puts("");
					m++;
				}
			}
		if(m==0) {printf("NO");puts("");}
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
