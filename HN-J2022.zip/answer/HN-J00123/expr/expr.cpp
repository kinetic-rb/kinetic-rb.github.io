#include<iostream>
using namespace std;
int main()
{
	freopen("expr.out","w",stdout);
	cout<<1<<endl<<1<<" "<<2;
	fclose(stdout);
	return 0;
}
