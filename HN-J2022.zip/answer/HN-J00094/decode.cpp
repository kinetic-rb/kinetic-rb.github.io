#include <bits/stdc++.h>
using namespace std;
long long t,n,e,d,p,q,o,F;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin >> t;
	while(t--)
	{
		q=0;p=0;F=0;
		cin >> n >> e >> d;
		o=n-e*d+2;//o=q+p-2;
		for(;p<1000000000;++p)
		{
			q=o-p;
			if(n==q*p&&e*d==(p-1)*(q-1)+1)
			{
				cout << p << " " << q << "\n"; 
				F=1;
				break;
			}
		}
		if(F!=1)cout << "NO\n";
	}
	return 0;
}
