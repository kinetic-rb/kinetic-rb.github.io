#include <bits/stdc++.h>
using namespace std;
long long a,b,c;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin >> a >> b;
	if(b<=2)
	{
		if(b==1)
		{
			if(a<=1e9)cout << a << "\n";
			else cout << "-1\n";
		}
		else
		{
			if(a*a<=1e9)cout << a*a << "\n";
			else cout << "-1\n";
		}
		return 0;
	}
	c=pow(a,b);
	if(c<0||c>1e9)cout << "-1\n";
	else cout << c << "\n";
	return 0;
}
