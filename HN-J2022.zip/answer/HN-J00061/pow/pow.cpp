#include<iostream>
using namespace std;
long long sum=1,Int=1;
int a,b;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	for(int i=1;i<=9;i++)
	{
		Int=Int*10;
	}
	cin>>a>>b;
	for(int i=1;i<=b;i++)
	{
		sum=sum*a;
	}
	
	if(sum<=Int&&sum>=0&&sum!=1)
	{
		cout<<sum;
		return 0;
	}
	else
	{
		cout<<"-1";
		return 0;
	}
}
