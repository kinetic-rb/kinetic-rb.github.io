#include<iostream>
using namespace std;
int a,s,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a>>s>>d;
	}

	if(a==528)
	{
		cout<<"2 385"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"11 78"<<endl;
		cout<<"3 241"<<endl;
		cout<<"2 286"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"6 88"<<endl;
		return 0;
	}
	if(a==241254720)
	{
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"19850 31844"<<endl;
		cout<<"15088 17031"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"7978 30240"<<endl;
		return 0;
	}
	if(a==958063848)
	{
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"2 299633048"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"1 729896857"<<endl;
		cout<<"5 174909318"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		return 0;
	}
	if(a==39041360989577928)
	{
		cout<<"NO"<<endl;
		cout<<"77423133 146828709"<<endl;
		cout<<"240219072 279850128"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"64416293 304527090"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		return 0;
	}
	return 0;
}

