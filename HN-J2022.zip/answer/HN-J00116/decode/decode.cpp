#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("decode.in");
fstream fout("decode.out");

LL k, n, d, e, m, s;

LL Sqrt(LL x) {
	LL l = 0, r = 1e9;
	while (l <= r) {
		LL mid = l + r >> 1;
		if (mid * mid <= x) {
			l = mid + 1;
		} else {
			r = mid - 1;
		}
	}
	return r;
}

int main() {
  fin >> k;
  while (k--) {
  	fin >> n >> d >> e;
  	m = n - e * d + 2;
  	s = Sqrt(m * m - 4 * n);
  	if (s * s != m * m - 4 * n || (m + s & 1)) {
  		fout << "NO\n";
		} else {
			fout << (m - s) / 2 << ' ' << (m + s) / 2 << '\n';
		}
	}
  return 0;
}

