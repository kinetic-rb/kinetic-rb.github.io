#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("expr.in");
fstream fout("expr.out");

const int kMaxM = 21, kMaxN = 1e6 + 1, kInf = 1e9;
struct V {
	bool b;
	int c[2], s[2];  // c[0]:| c[1]:&
} v[kMaxN];
int n, m, k, p, a[kMaxN], lg[kMaxN], d[kMaxM][kMaxN];
string s, t = "?";

void Calc(int l, int r, int &p) {
	p = ++m;
	if (l > r) {
		return;
	} else if (l == r) {
		v[p].b = t[l] == '1';
		return;
	}
	int x = d[lg[r - l + 1]][l], y = d[lg[r - l + 1]][r - (1 << lg[r - l + 1]) + 1];
	if (a[x] >= a[y]) {
		swap(x, y);
	}
	Calc(l, x - 1, v[p].s[0]);
	v[p].c[0] += v[v[p].s[0]].c[0],	v[p].c[1] += v[v[p].s[0]].c[1];
	if (t[x] == '|') {
		if (v[v[p].s[0]].b) {
			v[p].c[0]++;
			v[p].b = 1;
		} else {
			Calc(x + 1, r, v[p].s[1]);
			v[p].c[0] += v[v[p].s[1]].c[0], v[p].c[1] += v[v[p].s[1]].c[1];
			v[p].b = v[v[p].s[1]].b;
		}
	} else if (t[x] == '&') {
		if (!v[v[p].s[0]].b) {
			v[p].c[1]++;
			v[p].b = 0;
		} else {
			Calc(x + 1, r, v[p].s[1]);
			v[p].c[0] += v[v[p].s[1]].c[0], v[p].c[1] += v[v[p].s[1]].c[1];
			v[p].b = v[v[p].s[1]].b;
		}
	}
}

int main() {
  fin >> s;
  for (char ch : s) {
  	if (ch == '(') {
  		k++;
		} else if (ch == ')') {
			k--;
		} else if (ch == '|') {
			a[t.size()] = k * 2;
			t += ch;
		} else if (ch == '&') {
			a[t.size()] = k * 2 + 1;
			t += ch;
		} else {
		  a[t.size()] = kInf;
			t += ch;
		}
	}
	n = t.size() - 1;
	for (int i = 1, j = 0; i <= n; i++) {
		d[0][i] = i, lg[i] = j;
		if (i == (1 << j + 1)) {
			j++;
		}
	}
	for (int i = 1; i < kMaxM; i++) {
		for (int j = 1; j <= n; j++) {
			if (j + (1 << i - 1) <= n) {
			  int x = d[i - 1][j], y = d[i - 1][j + (1 << i - 1)];
			  d[i][j] = a[x] < a[y] ? x : y;
			} else {
				d[i][j] = d[i - 1][j];
			}
		}
	}
	Calc(1, n, p);
	fout << v[p].b << '\n' << v[p].c[1] << ' ' << v[p].c[0];
  return 0;
}

