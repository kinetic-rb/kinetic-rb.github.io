#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("pow.in");
fstream fout("pow.out");

const LL kInf = 1e9;
LL a, b, ans = 1;

int main() {
  fin >> a >> b;
  for (LL i = 1; i <= b; i <<= 1) {
  	if (i & b) {
  		if (ans > kInf || a > kInf || ans * a > kInf) {
  			fout << -1;
  			return 0;
			}
			ans *= a;
		}
		if (a <= kInf) {
			a *= a;
		}
	}
	fout << ans;
  return 0;
}

