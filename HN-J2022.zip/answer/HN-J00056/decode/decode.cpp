#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	for(int i=0;i<k;i++){
		int n,d,e;
		cin>>n>>d>>e;
	}
	int p,q;
	for(int j=0;j<k;j++){
		cout<<"NO";
	}
	
	return 0;
}
