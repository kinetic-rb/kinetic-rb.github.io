#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s[2000];
	for(int i=0;i<2000;i++){
		cin>>s[i];
	}
	cout<<1;
	cout<<2<<2;
	return 0;
}
