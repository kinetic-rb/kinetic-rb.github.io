#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	int s[10000000],ans=1;
	cin>>a>>b;
	for(int i=0;i<b;i++){
		s[i]=a;
		ans*=s[i];		
	}
	if(ans>=1000000000){
		
		cout<<-1;
		
	}else cout<<ans;
	return 0;
}
