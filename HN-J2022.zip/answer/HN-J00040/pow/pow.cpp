#include<bits/stdc++.h>
using namespace std;
long long a,b,sum;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	sum=a;
	for(int i=2;i<=b;i++){
		sum*=a;
		if(sum>1000000000){
			cout<<-1;
			return 0;
		}
	}
	cout<<sum;
	return 0;
}
