#include<bits/stdc++.h>
using namespace std;
string s;
int sum1=0,sum2=0;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='&'){
			sum1++;
		}
		if(s[i]=='|'){
			sum2++;
		}
	}
	cout<<0<<endl<<sum1<<" "<<sum2;
	return 0;
}
