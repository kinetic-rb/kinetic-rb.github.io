#include<bits/stdc++.h>
using namespace std;
long long k,n[100001],e[100001],d[100001];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		bool flag=0;
		cin>>n[i]>>e[i]>>d[i];
		int ls=e[i]*d[i];
		for(int j=1;j<=sqrt(n[i]);j++){
			if(n[i]%j==0){
				int temp1=j,temp2=n[i]/j;
				if((temp1-1)*(temp2-1)+1==ls){
					flag=1;
					cout<<temp1<<" "<<temp2<<endl;
					break;
				}
			}
		}
		if(flag==0){
			cout<<"NO"<<endl;
			continue;
		}
	}
	return 0;
}
