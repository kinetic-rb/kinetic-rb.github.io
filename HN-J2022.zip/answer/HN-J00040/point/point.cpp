#include<bits/stdc++.h>
using namespace std;
int n,k,x[10001],y[10001],m[101][101]={0},length1=1,length2=0;
bool book[101][101]={0};
void dfs1(int x,int y){
	if(m[x][y]==0||book[x][y]==1) return ;
	book[x][y]=1;
	length+=1;
	if(m[x+1][y+1]==1&&m[x+1][y]==1)dfs1(x+1,y);
	else if(m[x][y+1]==1&&m[x+1][y+1]==1)dfs1(x,y+1);
	dfs1(x+1,y);
	dfs1(x+1,y+1);
	dfs1(x,y+1);
	if((m[x+1][y+1]==0&&m[x+1][y]==0&&m[x][y+1]==0)){
		if(k>0){
			k--;
			dfs1(x+1,y);
			dfs1(x+1,y+1);
			dfs1(x,y+1);
		}
	}
}
void dfs2(int x,int y){
	if(m[x][y]==0||book[x][y]==1) return ;
	book[x][y]=1;
	length+=1;
	if(m[x+1][y+1]==1&&m[x+1][y]==1)dfs2(x+1,y);
	else if(m[x][y+1]==1&&m[x+1][y+1]==1)dfs2(x,y+1);
	dfs1(x+1,y);
	dfs1(x+1,y+1);
	dfs1(x,y+1);
	if((m[x+1][y+1]==0&&m[x+1][y]==0&&m[x][y+1]==0)){
		if(k>0){
			k--;
			dfs2(x+1,y);
			dfs2(x+1,y+1);
			dfs2(x,y+1);
		}
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;	
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
		m[x[i]][y[i]]=1;
	}
	for(int i=1;i<=1001;i++){
		for(int j=1;j<=1001;j++){
			if(m[i][j]==1){
				dfs1(i,j);
				break;
			}
		}
	}
	for(int i=1;i<=1001;i++){
		for(int j=1;j<=1001;j++){
			if(m[j][i]==1){
				dfs2(i,j);
				break;
			}
		}
	}
	cout<<max(length1,length2);
	return 0;
}
