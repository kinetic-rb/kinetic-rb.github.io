#include <bits/stdc++.h>
using namespace std;
long long n,k,x,y,nn=0,mm=0,cnt;
long long arr[1005][1005],sum[1005][1005];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>x>>y;
		arr[x][y]=1;
		nn=max(nn,x);
		mm=max(mm,y);
	}
	long long maxn=-1e9;
//	for(int i=1;i<=nn;i++){
//		for(int j=1;j<=mm;j++){
//			if(arr[i][j]==1){
//				cnt=1;
//				int xx=i+1,yy=j;
//				int x_x=i-1,y_y=j;
//				int xxx=i,yyy=j+1;
//				int x__x=i,y__y=j-1;
//				while(arr[xx][yy]==1){
//					cnt++;
//					xx++;
//					sum[xx][yy]=1;
//				}
//				while(arr[x_x][y_y]==1){
//					cnt++;
//					xx--;
//					sum[x_x][y_y]=1;
//				}
//				while(arr[xxx][yyy]==1){
//					cnt++;
//					yyy++;
//					sum[xxx][yyy]=1;
//				}
//				while(arr[x__x][y__y]==1){
//					cnt++;
//					y__y--;
//					sum[x__x][y__y]=1;
//				}
//			}
//			maxn=max(maxn,cnt);
//		}
//	}
	cout<<n;
	return 0;
}
