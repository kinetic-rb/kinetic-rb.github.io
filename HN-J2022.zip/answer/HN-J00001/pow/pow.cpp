#include <bits/stdc++.h>
using namespace std;
long long maxn=1e9;
long long sum=1,n,m;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>n>>m;
	if(n==1){
		cout<<1;
		return 0;
	}
	if(m==1){
		if(n>maxn){
			cout<<"-1";
		}
		else{
			cout<<n;
		}
		return 0;
	}
	if(n==maxn){
		if(m>1){
			cout<<"-1";
			return 0;
		}
	}
	if(m>29||n>10000){
		cout<<"-1";
		return 0;
	}
	sum=n;
	for(int i=1;i<m;i++){
		sum*=n;
		if(n>maxn){
			cout<<"-1";
			return 0;
		}
	}
	cout<<sum;
	return 0;
}
