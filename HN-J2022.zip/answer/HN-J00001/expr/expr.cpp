#include <bits/stdc++.h>
using namespace std;
string arr;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>arr;
	long long len=arr.size();
	if(len==3){
		if(arr[1]=='&'){
			if(arr[0]=='0'){
				cout<<0<<endl<<1<<" 0";
			}else if(arr[2]=='0'&&arr[0]=='0'){
				cout<<0<<endl<<"0 0";
			}else{
				cout<<1<<endl<<"0 0";
			}
		}else{
			if(arr[0]=='1'){
				cout<<1<<endl<<"0 1";
			}else if(arr[2]=='0'&&arr[0]=='0'){
				cout<<0<<endl<<"0 0";
			}else{
				cout<<1<<endl<<"0 0";
			}
		}
	}
	return 0;
}
