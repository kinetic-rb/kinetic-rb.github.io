#include <bits/stdc++.h>
using namespace std;
long long n,a,b,c;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a>>b>>c;
		long long sum=a-b*c+2;
		bool flag=0;
		for(long long j=1;j<=sum;j++){
			for(long long k=j;j+k<=sum;k++){
				if(j*k==a&&j+k==sum){
					cout<<j<<" "<<k<<endl;
					flag=1;
					break;
				}
			}
			if(flag==1){
				break;
			}
		}
		if(flag==0){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
