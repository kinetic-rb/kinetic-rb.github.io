#include <bits/stdc++.h>

using namespace std;

const int N = 1e6 + 10;

string s;
int n, c1, c2, lc;
bool c[N], v;

int ts() {
  bool x, y, z;
  for (int i = 0; i < n; i++) {
    if (s[i] == '&') {
      x = 1;
    }
    if (s[i] == '|') {
      y = 1;
    }
    if (s[i] == '(' || s[i] == ')') {
      z = 1;
    }
  }
  if (!x) {
    return 1;
  } else if (!y) {
    return 2;
  } else if (!z) {
    return 3;
  }
  return 4;
}

int F1() {
  v = s[0] - '0';
  int i;
  for (i = 1; i < s.size() && !v; i++) {
    if (s[i] == '0' || s[i] == '1') {
      v |= (s[i] - '0');
    }
  }
  return i;
}

int F2() {
  v = s[0] - '0';
  int i;
  for (i = 1; i < s.size() && v; i++) {
    if (s[i] == '0' || s[i] == '1') {
      v &= (s[i] - '0');
    }
  }
  return i;
}

int F3() {
  char op;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '0' || s[i] == '1') {
      if (op == '&') {
        c1 += c[lc] == '0';
        c[lc] &= (s[i] - '0');
      } else {
        c[++lc] = s[i] - '0';
      }
    } else {
      op = s[i];
    }
  }
  v = c[1];
  int i;
  for (i = 2; i <= lc && !v; i++) {
    v |= c[i];
  }
  return i;
}

int main() {
  freopen("expr.in", "r", stdin);
  freopen("expr.out", "w", stdout);
  cin >> s;
  n = s.size();
  int p = ts();
  if (n == 3) {
    if (s[0] == '(') {
      cout << s[1] - '0';
    } else {
      if (s[1] == '&') {
        cout << ((s[0] - '0') & (s[2] - '0')) << '\n';
        cout << (s[0] == '0') << ' ' << 0;
      } else {
        cout << ((s[0] - '0') | (s[2] - '0')) << '\n';
        cout << 0 << ' ' << (s[0] == '1');
      }
    }
  } else {
    if (p == 1) {
      int m = F1();
      cout << v << '\n' << 0 << ' ' << (m < s.size() - 1);
    } else if (p == 2) {
      int m = F2();
      cout << v << '\n' << (m < s.size() - 1) << ' ' << 0;
    } else if (p == 3) {
      int m = F3();
      cout << v << '\n' << c1 << ' ' << (m <= lc);
    }
  }
  return 0;
}
