#include <bits/stdc++.h>

using namespace std;

int k;
long long n, d, e;

long long F() {
  for (int i = 1; i * i <= n; i++) {
    if (n % i == 0) {
      long long q = n / i;
      if (e * d == (i - 1) * (q - 1) + 1) {
        return i;
      }
    } 
  }
  return -1;
}

int main() {
  freopen("decode.in", "r", stdin);
  freopen("decode.out", "w", stdout);
  cin >> k;
  while (k--) {
    cin >> n >> d >> e;
    bool k = 0;
    if (n > int(1e9)) {
      long long m = sqrt(n);
      if (m * m == n && (m - 1) * (m - 1) + 1 == e * d) {
        cout << m << ' ' << m << '\n';
        k = 1;
      }
    }
    if (F() == -1 && !k) {
      cout << "NO\n";
    } else if (!k) {
      long long p = F();
      cout << p << ' ' << n / p << '\n';
    }
  }
  return 0;
}
