#include <bits/stdc++.h>

using namespace std;

int a, b;

long long fm(int p) {
  if (p == 1) {
    return a;
  }
  long long i = fm(p / 2), j = fm(p - p / 2);
  if (i == -1 || j == -1 || i * j > int(1e9)) {
    return -1;
  }
  return i * j;
}

int main() {
  freopen("pow.in", "r", stdin);
  freopen("pow.out", "w", stdout);
  cin >> a >> b;
  long long m = fm(b);
  cout << m;
  return 0;
}
