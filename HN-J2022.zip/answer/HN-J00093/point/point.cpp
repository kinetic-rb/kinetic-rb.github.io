#include <bits/stdc++.h>

using namespace std;

const int N = 510;

int n, k, cnt;

struct wz {
  int x, y;
} a[N];

bool cmp(const wz &i, const wz &j) {
  if (i.x == j.x) {
    return i.y < j.y;
  }
  return i.x < j.x;
}

int main() {
  freopen("point.in", "r", stdin);
  freopen("point.out", "w", stdout);
  cin >> n >> k;
  for (int i = 1; i <= n; i++) {
    cin >> a[i].x >> a[i].y;
  }
  sort(a + 1, a + n + 1, cmp);
  if (!k) {
    int lx = a[1].x, ly = a[1].y;
    cnt = 1;
    for (int i = 2; i <= n; i++) {
      if (a[i].x - lx + abs(a[i].y - ly) == 1) {
        cnt++;
        lx = a[i].x, ly = a[i].y;
      } 
    }
    cout << cnt;
  }
  return 0;
}
