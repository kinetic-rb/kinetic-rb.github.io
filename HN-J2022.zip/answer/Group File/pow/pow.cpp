#include <bits/stdc++.h>
#define int unsigned long long int
using namespace std;
int a, b;

signed main()
{
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	cin >> a >> b;
	int sum = a;
	for( int i = 1; i < b; i++ )
	{
		a *= sum;
		if(a > 1000000000)
		{
			cout << -1 << endl;
			return 0;
		}
	}
	cout << a << endl;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
