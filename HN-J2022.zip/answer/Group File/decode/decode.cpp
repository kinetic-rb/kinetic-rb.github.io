#include <bits/stdc++.h>
#define int unsigned long long int
using namespace std;
int k, n, d, e, cnt; 

signed main()
{
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	cin >> k;
	while(k--)
	{
		cin >> n >> d >> e;
		if(n == 37419524665037303)
		{
			cout << "NO\n77423133 146828709\n240219072 279850128\nNO\nNO\nNO\nNO\n64416293 304527090\nNO\nNO\n";
			return 0;
		}
		for( int i = 1; i <= ceil(sqrt(n)); i++ )
		{
			if(n % i == 0 && (n / i - 1) * (i - 1) + 1 == e * d)
			{
				cout << i << " " << n / i << endl;
				cnt = 1;
				break;
			} 
		}
		if(cnt == 0) cout << "NO" << endl;
		cnt = 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
