#include<bits/stdc++.h>
using namespace std;
unsigned long long a,b,zjc=1;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(b==0){
		cout<<0;
		return 0;
	}
	if(b==1){
		cout<<a;
		return 0;
	}
	if(a==1){
		cout<<1;
		return 0;
	}
	if(a>=16&&b>=16){
		cout<<"-1";
		return 0;
	}
	if(a>=1000000000&&b>=2){
		cout<<"-1";
		return 0;
	}
	if(a>1000000&&b>=3){
		cout<<"-1";
		return 0;
	}
	if(a*b>1000000000000000000){
		cout<<"-1";
		return 0;
	}
	for(int i=1;i<=b;i++){
		zjc*=a;
		if(zjc>1000000000000000000){
			cout<<"-1";
			return 0;
		}
	}
	
	
	
	cout<<zjc<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
