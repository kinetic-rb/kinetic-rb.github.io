#include<bits/stdc++.h>
using namespace std;
unsigned long long k;
unsigned long long n,e,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n>>e>>d;
		bool flag=false;
		unsigned long long s1,s2;
		unsigned long long m=n-e*d+2;
		for(int p=1;p<=m;p++){
			int q=m-p;
			if(n==p*q&&e*d==(p-1)*(q-1)+1){
				s1=p; s2=q;
				flag=true;
				break;
			}

		}
		if(flag==true){
			cout<<s1<<' '<<s2<<endl;
			continue;
		}else{
			cout<<"NO"<<endl;
			continue;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
