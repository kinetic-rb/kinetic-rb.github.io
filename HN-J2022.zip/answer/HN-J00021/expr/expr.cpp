#include<bits/stdc++.h>
using namespace std;
string str;
char now='0';
unsigned long long ans1=0,ans2=0;
unsigned long long yu=0,huo=0;
bool b[114514];

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>str;
	unsigned long long len=str.size();
	if(len==3){
		if(str[1]=='&'){
			if(str[0]==str[2]){
				cout<<str[0]<<endl;
				cout<<0<<' '<<0;
				return 0;
			}else{
				cout<<0<<endl;
				cout<<1<<' '<<0; 
				return 0;
			}
		}
		if(str[1]=='|'){
			if(str[0]==str[2]){
				cout<<str[0]<<endl;
				cout<<0<<' '<<0;
				return 0;
			}else{
				cout<<1<<endl;
				cout<<0<<' '<<1; 
				return 0;
			}
		}
	}
	if(len==5){
		for(int i=0;i<len;i++){
			if(str[i]=='&'){
				if(str[i-1]==str[i+1]){
					now=str[i-1];
				}else{
					now=str[i-1];
					ans1++;
				}
			}
			
			if(str[1]=='|'){
				if(str[0]==str[2]){
					now=str[i-1];
				}else{
					now='1';
					ans2++;
					return 0;
				}
			}
		}
		cout<<now<<endl;
		cout<<ans1<<' '<<ans2;
	}
	for(int i=0;i<len;i++){
		if(str[i]=='&') yu++;
		if(str[i]=='|') huo++;
	}
	for(int i=0;i<len;i++){
		if(str[i]=='&'){
			yu--;
			b[i]=true;
			now=str[i-1];
			if(now!=str[i+1]&&(now=='0'||now=='1')&&(str[i+1]=='0'||str[i+1]=='1')){
				ans1++;
			}
		}
		if(str[i]=='|'){
			huo--;
			b[i]=true;
			if(str[i-2]=='('||yu==0){
				if(str[i-1]=='0'&&now=='0'){
					now='0';
				}
				else{
					now='1';
				}
			}
			if(now!=str[i+1]&&(now=='0'||now=='1')&&(str[i+1]=='0'||str[i+1]=='1')){
				ans2++;
			}
		}
	}
	for(int i=0;i<len;i++){
		if(b[i]!=true&&(str[i]=='&'||str[i]=='|')){
			if(str[i]=='&'){
				yu--;
				b[i]=true;
				now=str[i-1];
				if(now!=str[i+1]&&(now=='0'||now=='1')&&(str[i+1]=='0'||str[i+1]=='1')){
					ans1++;
				}
			}
			if(str[i]=='|'){
				huo--;
				b[i]=true;
				if(str[i-2]=='('||yu==0){
					if(str[i-1]=='0'&&now=='0'){
						now='0';
					}
					else{
						now='1';
					}
				}
				if(now!=str[i+1]&&(now=='0'||now=='1')&&(str[i+1]=='0'||str[i+1]=='1')){
					ans2++;
				}
			}
		}
	}
	cout<<now<<endl;
	cout<<ans1<<' '<<ans2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
