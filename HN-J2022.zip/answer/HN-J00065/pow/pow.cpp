#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,c;
	cin>>a>>b;
	for(int i=1;i<=b;i++){
		c=c*a;
	}
	if(c>1000000000){
		cout<<"-1";
	}
	else{
		cout<<c;
	}
	return 0;
}
