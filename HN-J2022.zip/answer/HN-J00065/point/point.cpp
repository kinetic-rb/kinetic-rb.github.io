#include<bits/stdc++.h>
using namespace std;
int main(){
	//freopen("point.in","r",stdin);
	//freopen("point.out","w",stdout);
	int
	return 0;
}

