#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	while(k--){
		int n,e,d,p,q,a=0;
		cin>>n>>e>>d;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=i;j++){
				if(i*j==n&&(i-1)*(j-1)+1==e*d){
					q=i;
					p=j;
					a=1;
				}
			}
		}
		if(a==1){
			cout<<p<<" "<<q;
		}
		else{
			cout<<"NO";
		}
	}
	return 0;
}
