#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	while (k--)
	{
		int e,d;
		ull n;
		cin>>n>>e>>d;
		long long t=n-(ull)(e*d)+2;
		bool f=0;
		if (k>1000)
		{
			if (sqrt(t)-(ull)sqrt(t)!=0) cout<<"NO";
			else cout<<(ull)sqrt(t);
		}
		else if (k<1000)
		{
			for (int i=1;i<=t;i++)
			{
				if ((ull)(i*(t-i))==n)
				{
					f=1;
					cout<<i<<' '<<t-i;
					break;
				}
			}
			if (!f) cout<<"NO";
			f=0;
		}
		else cout<<"NO";
		cout<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
