#include<bits/stdc++.h>
using namespace std;
#define maxn 1000000000
#define ull unsigned long long
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	ull t=(ull)pow(a,b)-maxn;
	ull T1=(ull)pow(a,b);
	if (t>0) cout<<"-1";
	else cout<<T1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
