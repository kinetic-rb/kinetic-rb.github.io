#include<bits/stdc++.h>
using namespace std;
bool f[505][505];
int ansa[1000005],ansb[1000005];
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k,maxx=0,maxy=0;
	cin>>n>>k;
	for (int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x>>y;
		f[x][y]=1;
		maxx=max(maxx,x);
		maxy=max(maxy,y);
	}
	int z1=0;
	for (int i=1;i<=maxx;i++)
	{
		for (int j=1;j<=maxy;j++)
		{
			if (!f[i][j]) z1++;
			if (f[i][j]) ansa[z1]++;
		}
	}
	int z2=0;
	for (int i=1;i<=maxx;i++)
	{
		for (int j=1;j<=maxy;j++)
		{
			if (!f[j][i]) z1++;
			if (f[j][i]) ansb[z1]++;
		}
	}
	sort(ansa+1,ansa+z1+1,cmp);
	sort(ansb+1,ansb+z2+1,cmp);
	cout<<max(ansa[1],ansb[1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
