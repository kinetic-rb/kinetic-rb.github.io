#include<bits/stdc++.h>
using namespace std;
struct stu{
	char ST;
	bool f;
}s1[1000005];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	for (int i=0;i<s.length();i++) s1[i].f=0;
	int sum1=0,lens1=0;
	for (int i=0;i<s.length();i++)
	{
		if (s[i]=='&')
		{
			lens1++;
			if (s[i-1]=='0')
			{
				sum1++;
				s1[lens1].ST='0';
			}
			else if (s[i+1]=='1'&&s[i-1]=='1') s1[lens1].ST='1';
			else s1[lens1].ST='0';
		}
		else
		{
			lens1++;
			s1[lens1].ST=s[i];
		}
	}
	string s2;
	int sum2=0,lens2=0;
	for (int i=0;i<lens1;i++)
	{
		if (s1[i].ST=='|'&&!s1[i-1].f)
		{
			lens2++;
			if (s1[i-1].ST=='1')
			{
				sum2++;
				s2[lens2]='1';
			}
			else if (s1[i-1].ST=='0'&&s1[i+1].ST=='0') s2[lens2]='0';
			else s2[lens2]='1';
		}
		else
		{
			lens2++;
			s2[lens2]='|';
		}
	}
	if (s2[1]=='&')
	{
		if (s2[0]=='0')
		{
			sum1++;
			cout<<0;
		}
		else if (s2[0]=='1'&&s2[2]=='1') cout<<1;
		else cout<<0;
	}
	else
	{
		if (s2[0]=='1')
		{
			sum2++;
			cout<<1;
		}
		else if (s2[0]=='0'&&s2[2]=='0') cout<<0;
		else cout<<1;
	}
	cout<<endl<<sum1<<' '<<sum2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
