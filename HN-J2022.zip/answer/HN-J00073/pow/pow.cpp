#include <bits/stdc++.h>
using namespace std;
long long int a,b;


int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	int num=1;
	int sum;
	for(int i=1;i<=b;i++){
		sum*=a;
	}
	for(int j=1;j<=9;j++){
		num*=10;
	}
	if(sum>num){
		sum=-1;
	}
	cout<<sum;
	return 0;
}
