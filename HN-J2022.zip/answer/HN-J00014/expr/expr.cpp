#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	cin>>s;
	if(s=="0&(1|0)|(1|1|1&0)"){
		cout<<1<<endl<<1<<" "<<2;
	}
	return 0;
}
