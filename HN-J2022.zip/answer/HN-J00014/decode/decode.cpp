#include<bits/stdc++.h>
using namespace std;
int k;
int n[10001],e[10001],d[10001];
int main(){
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n[i]>>e[i]>>d[i];
	}
	for(int i=1;i<=k;i++){
		bool flag=false;
		for(int j=2;j*j<=n[i];j++){
			if(n[i]%j==0){
				if((j-1)*(n[i]/j-1)+1==e[i]*d[i]){
					cout<<j<<" "<<n[i]/j<<endl;
					flag=!flag;
				}
			}
		}
		if(flag==false){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
