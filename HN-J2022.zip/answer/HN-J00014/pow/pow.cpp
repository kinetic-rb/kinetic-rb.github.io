#include<bits/stdc++.h>
using namespace std;
int a,b;
int main(){
	//freopen("1.in","r",stdin);
	//freopen("1.out","w",stdout);
	cin>>a>>b;
	int n=a;
	for(int i=1;i<=b-1;i++){
		a*=n;
	}
	if(a>1000000000){
		cout<<"-1";
	}else{
		cout<<a;
	}
	return 0;
} 
