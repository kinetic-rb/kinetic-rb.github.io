#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen(" pow.in","r",stdin);
	freopen(" pow.out","w",stdout);
	int m,n;
	cin >> m >> n;
	int ans=1;
	int s=1;
	for(int i=1;i<=n;i++){
		m*=ans;
	}
	cout << ans<< endl;
	return 0; 
}
