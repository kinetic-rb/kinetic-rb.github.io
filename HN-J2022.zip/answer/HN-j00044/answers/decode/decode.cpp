#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode .out","w",stdout);
	int n=0;
	cin >> n; 
	int a[100][100];
	for (int i=0;i<=n;i++){
		for(int j=0;i<=3;j++){
			cin >> a[i][j];
		}
	}
	for (int i=0;i<=n;i++){
		for(int j=0;i<=3;j++){
		}
	}
	return 0; 
}
