#include<bits/stdc++.h>
using namespace std;
long long a,b,t;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	t=a;
	for(int i=b-1;i>=1;i--){
		if(t>1000000000){
			cout<<"-1";
			return 0;
		}
		t*=a;
	}
	cout<<t;
	return 0;
}
