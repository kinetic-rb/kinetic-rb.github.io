#include<bits/stdc++.h>
using namespace std;
long long k,n[10010],e[10010],d[10010],p,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n[i]>>e[i]>>d[i];
	}
	for(int i=1;i<=k;i++){
		for(int j=1;j<=sqrt(n[i]);j++){
			p=j,q=0;
			q=n[i]/p;
			if(e[i]*d[i]==(p-1)*(q-1)+1){
				cout<<p<<' '<<q<<endl;
				p=0;
				break;
			}
		}
		if(p>0){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
