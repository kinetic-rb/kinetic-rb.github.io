#include<bits/stdc++.h>

using namespace std;

typedef long long LL;

string s;
string str;
stack<char> op;
stack<int> num;

int solve(int j)
{
	char op1[100000]={};
	int num1[100000]={};
	int len=0,cnt=0;
	while(op.top()!='(')
	{
		if(op.size()&&op.top()=='&')
		{
			op.pop();
			int x=num.top(); num.pop();
			int y=num.top(); num.pop();
			int ans=x&y;
			
			num.push(ans);
		}
		else
		{
			op1[len++]=op.top(); op.pop();
			num1[cnt++]=num.top(); num.pop();
		}
	}
	
	op.pop();
	int x=0;
	for(int i=0;i<cnt;i++)
	{
		x|=num1[i];
	}
	
	while(num.size())
	{
		x|=num.top(); num.pop();
	}
	
	return x;
}

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	
	cin>>s;
	str=s;
	
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='0'||s[i]=='1')
		{
			num.push(s[i]-'0');
			if(op.size()&&op.top()=='&')
			{
				op.pop();
				int x=num.top(); num.pop();
				int y=num.top(); num.pop();
				int ans=x&y;
				
				num.push(ans);
			}
		}
		else
		{
			op.push(s[i]);
			if(s[i]==')')
			{
				op.pop();
				int x=solve(i);
				num.push(x); 
			}
		}
	}
	
	LL ans=0,ans1=0,ans2=0;

	if(num.size()==1)
	{
		cout<<num.top();
		num.pop();
		for(int i=0;i<str.size()-2;i++)
		{
			if((str[i]=='1'||str[i]=='0')&&str[i+1]=='&'&&(str[i+2]=='1'||str[i+2]=='0'))
			{
				ans1++;
			}
			if((str[i]=='1'||str[i]=='0')&&str[i+1]=='|'&&(str[i+2]=='1'||str[i+2]=='0'))
			{
				ans2++;
			}
		}
		cout<<ans1<<' '<<ans2;
		return 0;
	}
	while(op.size())
	{
		int x=num.top(); num.pop();
		int y=num.top(); num.pop();
		
		int ans=x|y;
		op.pop();
		num.push(ans);
	}
	
	cout<<num.top()<<endl;
	
	
	for(int i=0;i<str.size()-2;i++)
	{
		if((str[i]=='0'||str[i]=='1')&&str[i+1]=='&'&&(str[i+2]=='1'||str[i+2]=='0'))
		{
			ans1++;
		}
		if((str[i]=='1'||str[i]=='0')&&str[i+1]=='|'&&(str[i+2]=='1'||str[i+2]=='0'))
		{
			ans2++;
		}
	}
	
	cout<<ans1<<' '<<ans2;
	
	return 0;
}
