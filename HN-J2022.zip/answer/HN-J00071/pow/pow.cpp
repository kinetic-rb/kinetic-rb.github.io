#include<bits/stdc++.h>

using namespace std;

typedef long long LL;

const int N=1e9;
LL a,b,ans=1;

LL qmi(LL a,LL b)
{
	LL res=1;
	while(b)
	{
		if(res>N||a>N)
		{
			return -1;
		}
		if(b&1)
		{
			res=res*a;
		}
		a=a*a;
		b>>=1;
		
	}
	
	return res;
}

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	cin>>a>>b;
	
	cout<<qmi(a,b); 
	
	return 0;
}
