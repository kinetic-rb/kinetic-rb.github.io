#include<bits/stdc++.h>

using namespace std;

typedef long long LL;

int k;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	scanf("%d",&k);
	
	while(k--)
	{
		LL n,e,d,p,q;
		scanf("%lld%lld%lld",&n,&e,&d);
		
		bool flag=0;
		for(int i=1;i<=n/i;i++)
		{
			p=i,q=n/i;
			if(p*q==n&&e*d==(p-1)*(q-1)+1)
			{
				cout<<p<<' '<<q<<endl;
				flag=1;
				break;
			}
		}
		
		if(flag==0)
		{
			cout<<"NO"<<endl;
		}
	}
	
	return 0;
}
