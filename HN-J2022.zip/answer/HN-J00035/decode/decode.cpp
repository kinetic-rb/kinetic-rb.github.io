#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	int n;
	cin>>n;
	int input[n][3];
	int result[n][2]={0};
	bool flag=false;
	for(int i=0;i<n;i++){
		cin>>input[i][0]>>input[i][1]>>input[i][2];
	}
	for(int i=0;i<n;i++){
		int a=input[i][0];
		flag=false;
		for(int j=1;j*j<=a;j++){
			if(a%j==0){
				int p=j;
				int q=a/j;
				if(((p-1)*(q-1)+1)==input[i][1]*input[i][2]){
					flag=true;
					result[i][0]=p;
					result[i][1]=q;
				}
			}
			if(flag){
				continue;
			}
		}
	}
	for(int i=0;i<n;i++){
		if(result[i][0]==0){
			cout<<"NO"<<endl;
		}
		else{
			cout<<result[i][0]<<" "<<result[i][1]<<endl;
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
