#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	
	int a,b;
	cin>>a>>b;
	int j,k;
	for(int i=0;i<a;i++){
		cin>>j>>k;
	}
	cout<<10;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
