#include<bits/stdc++.h>
using namespace std;
int anddl=0,ordl=0;
int count(string a)
{
	char f=a[0];
	char op=a[1];
	char s=a[2];
	int re;
	if(op=='&'){
		if(f=='0'||s=='0'){
			re=0;
			if(f=='0'){
				anddl++;
			}
		}
		else{
			re=1;
		}
	}
	else{
		if(f=='1'||s=='1'){
			re=1;
			if(f=='1'){
				ordl++;
			}
		}
		else{
			re=0;
		}
	}
	return re;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	
	int re;
	string s;
	cin>>s;
	re=count(s);
	cout<<re<<endl<<anddl<<" "<<ordl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
