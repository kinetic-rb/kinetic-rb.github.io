#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	int a,b;
	cin>>a>>b;
	int s=1;
	for(int i=1;i<=b;i++){
		s*=a;
		if(s%a!=0||s<0){
			cout<<-1;
			return 0;
		}
	}
	cout<<s;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
