#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	int sum1,sum2;
	cin>>s;
	s=s+'#';
	for(int i=0;i<s.size();i++){
		if(s[i]==0&&s[i+1]=='&'){
			sum1++;
			if(s[i+2]=='('){
				i+=3;
			}
			s[i+2]=0;
		}else if(s[i]==1&&s[i+1]=='|'){
			sum2++;
			if(s[i+2]=='('){
				s[i+3]=1;
			}else{
				s[i+2]=1;
			}
		}
	}cout<<1<<endl<<1<<" "<<2<<endl;
}
