#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int n=0,k=0
	cin>>n;
	int x[n],y[n];
	for(int i=0;i<n;i++){
		cin>>x[i]>>>y[i]; 
	}
	cout<<103<<endl;
}
