#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k=0;
	cin>>k;
	int e,d,b;
	long long n,p,q,c;
	for(int i=1;i<=k;i++){
		q=n;
		p=1;
		cin>>n>>d>>e;
		for(int j=2;j<n/2+1;j++){
			if(n%j==0){
				if(e==d&&e==1){
					cout<<p<<" "<<q<<endl;
					p=0;
				}
				c=n%j;
			}else{
				p=c;
				q=n/c;
				if((p-1)*(q-1)+1==e*d){
					cout<<p<<" "<<q<<endl;
					p=0;
				}
			}
		}if(p){
			cout<<"NO"<<endl;
		}
	}
}
