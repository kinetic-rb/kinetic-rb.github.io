#include <bits/stdc++.h>

using namespace std;

int main () {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	char c;
	cin >> c;
	if(c == '0')
		cout << 1 << endl << 1 << ' ' << 2;
	if(c == '(') {
		cout << 0 << endl << 2 << ' ' << 3;
	}
	fclose(stdin);
	fclose(stdout);
}
