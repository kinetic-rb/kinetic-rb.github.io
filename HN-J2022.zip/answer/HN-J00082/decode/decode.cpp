#include<bits/stdc++.h>

using namespace std;

int k;

int main () {
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	cin >> k;
	while(k--) {
		bool f = 0;
		int n, e, d;
		cin >> n >> e >> d;
		if(n == 0 || e == 0 || d == 0) {
			cout << "NO" << endl;
			continue;
		}
		int tmp = e * d - 1;
		for (int i = 2; i <= sqrt(n); ++i) {
			if(n % i != 0) {
				continue;
			}
			int temp = n / i;
			if((i - 1) * (temp - 1) == tmp) {
				f = 1;
				cout << i << ' ' << temp << endl;
				break; 
			}
		}
		if(f == 0) {
			cout << "NO" << endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
