#include<bits/stdc++.h>
#define int unsigned long long

using namespace std;

int a, b, ans = 1;

signed main() {
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	cin >> a >> b;
	if((a == 1 && b > 0) || (b == 0)) {
		cout << '1';
		return 0;
	}
	int temp = 1000000000;
	for (int i = 1; i <= b; ++i) {
		ans *= a;
		if(ans > temp) {
			cout << "-1";
			return 0;
		}
	}
	cout << ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
