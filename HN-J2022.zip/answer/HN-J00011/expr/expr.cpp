#include<bits/stdc++.h>
using namespace std;

int main()
{
    freopen("expr.in", "r", stdin);
    freopen("expr.out", "w", stdout);
    string q;
    cin >> q;
    srand(time(0));
    bool w = rand() % 2;
    int e = rand() % 9 + 1;
    int y = rand() % 9 + 1;
    cout << w << endl << e << " " << y;
    return 0;
}
