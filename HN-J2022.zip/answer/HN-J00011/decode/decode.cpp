#include<iostream>
using namespace std;

int main()
{
    freopen("decode.in", "r", stdin);
    freopen("decode.out", "w", stdout);
    int k, n, e, d;
    cin >> k;
    for (int i = 1; i <= k; i++)
    {
        cin >> n >> e >> d;
    int cnt = 0, a[1000], b[1000];
    bool cnl = 0;
        for (int i = 1; i <= n / 2; i++)
        {
          if (n % i == 0)
          {
            cnt++;
            a[cnt] = i;
            b[cnt] = n / i;
          }
        }
        for (int i = 1; i <= cnt; i++)
        {
            if ((a[i] - 1) * (b[i] - 1) + 1 == e * d)
            {
                cout << min(a[i], b[i]) << " " << max(a[i], b[i]);
                cnl++;
                break;
            }
        }
        if (cnl == 0)
        {
            cout << "NO";
        }
        cout << endl;
    }
}
