#include<iostream>
#include<ctime>
using namespace std;

int main()
{
    freopen("point.in", "r", stdin);
    freopen("point.out", "w", stdout);
    int n, k, t[1000];
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
    {
        cin >> t[i];
    }
    srand(time(0));
    cout << rand() % 1000 + 12;
    return 0;
}
