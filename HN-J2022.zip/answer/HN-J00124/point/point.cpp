#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin >> n >> k;
	int a[n][2];
	for(int i=0; i<n; i++){
		for(int j=0; j<2; j++){
			cin >> a;
		}
	}
	if()
	return 0;
}
