#include <bits/stdc++.h>
using namespace std;
int i; string s1;
void kh(string s){
	string s2;
	while(s[i]!=')'){
		if(s[i]=='|'&& (s[i-1]=='1' || s[i+1]=='1')){
			s2="1"; while(s[i]!=')')i++; i++; s1+=s2; return ;
		}else s2+=s[i];
		i++;
		if(s[i]=='(')kh(s);
	}
	if(s2!="1") s2+=')';
	s1+=s2;
	return ;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s,s3,s0=" "; int ans1=0,ans2=0;
	cin >> s;
	for(i=0; i<s.size(); i++){
		if(s[i]!='1' && s[i]!='0'){
			s0+=s[i];
		}
	}
	s0+=' ';
	for(i=1; i<s0.size(); i++){
		if(s0[i-1]!='(' && s0[i+1]!=')'){
			if(s0[i]=='&')ans1++;
			else if(s0[i]=='|')ans2++;
		}
	}
	for(i=0; i<s.size(); i++){
		string s2;
		if(s[i]=='('){
			kh(s);
		}
		s1+=s2;
		s1+=s[i];
	}
	for(i=0; i<s1.size(); i++){
		string s2;
		if(s1[i+1]=='&'){
			if(s1[i]=='0' || s1[i+2]=='0'){
				s2='0';i+=3;
			}
		}
		s3+=s2;
		s3+=s1[i];
	}
	for(i=0; i<s3.size(); i++){
		if(s3[i]=='1'){
			cout << 1 << endl << ans1 << ' ' << ans2; return 0;
		}
	}
	cout <<0 << endl << ans1 << ' ' << ans2;
	return 0;
}
//0  1 0   1 1 1 0
// &( | )|( | | & )
//0&1|(1|1|0)
