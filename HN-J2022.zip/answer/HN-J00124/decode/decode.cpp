#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k,n,c,d; bool bo=1;
	cin >> k >> n >> c >> d;
	if(c*d>=n/2){
		for(long long i=1; i<sqrt(n); i++){
			if(n%i==0){
				long long x=n/i;
				if(c*d==n-i-x+2 && i<=x){
					cout << i << ' ' << x;
					bo=0; break;
				}
			}
		}
	}else cout << "NO";
	if(bo)cout << "NO";
	for(long long j=1; j<k; j++){
		cin >> n >> c >> d; bo=1;
		if(c*d>=n/2){
			for(long long i=1; i<sqrt(n); i++){
				if(n%i==0){
					long long x=n/i;
					if(c*d==n-i-x+2 && i<=x){
						cout << endl << i << ' ' << x;
						bo=0; break;
					}
				}
			}
		}else cout << endl << "NO";
		if(bo)cout << endl << "NO";
	}
	return 0;
}
//c*d=q*p-(p+q)+2=n-(p-1)-(q-1)=n-p-q+2
//n=q*p
// 858 3 257      11 78
//n-(p+1)-(q+1)=c*d n=c*d+p+q-2 n+2-c*d=p+n/p 
//n-cd+2=p+n/p (n-cd+2)p=p*p+n
//387 = 385+2     424p=p*p+633
