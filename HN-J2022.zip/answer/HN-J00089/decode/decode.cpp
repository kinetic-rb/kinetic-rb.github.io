#include<bits/stdc++.h>
using namespace std;
int k;
long long a,b,c,m;
long long l,r,mid,ans;
long long read(){
	long long s=0;
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout); 
	cin>>k;
	for(int i=1;i<=k;i++){
		a=read();
		b=read();
		c=read();  
		m=a-b*c+2;
		l=1;
		r=m/2;
		ans=0;
		while(l<=r){
			mid=(l+r)/2;
			if(mid*(m-mid)<a)l=mid+1;
			if(mid*(m-mid)==a){
				ans=mid;
				break;
			}
			if(mid*(m-mid)>a)r=mid-1;
		}
		if(ans==0)cout<<"NO"<<endl;
		else cout<<ans<<" "<<m-ans<<endl; 
	}
}
