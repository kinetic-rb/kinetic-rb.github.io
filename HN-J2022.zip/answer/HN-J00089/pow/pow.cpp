#include<bits/stdc++.h>
using namespace std;
int a,b;
long long s=1;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=b;i++){
		s*=a;
		if(s>1000000000){
			cout<<-1;
			return 0;
		}
	}
	cout<<s;
	return 0;
}
