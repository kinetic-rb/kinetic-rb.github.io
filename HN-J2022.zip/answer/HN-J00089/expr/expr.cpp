#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.size()<=3){
		if(s[0]=='('){
			cout<<s[1]<<endl<<"0 0";
			return 0;
		}
		if(s[1]=='&'){
			int x=s[0]-'0';
			int y=s[2]-'0';
			x=x&y;
			cout<<x<<endl<<"1 0";
		}
		if(s[1]=='|'){
			int x=s[0]-'0';
			int y=s[2]-'0';
			x=x|y;
			cout<<x<<endl<<"0 1";
		}
		return 0;
	}
	cout<<1<<endl<<"1 1";
}
