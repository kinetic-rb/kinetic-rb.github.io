#include<bits/stdc++.h>
using namespace std;
int n,k,x[510],y[510],ans,v[510];
int check(int i,int j){
	if(x[j]==x[i]+1&&y[i]==y[j])return 1;
	if(y[j]==y[i]+1&&x[i]==x[j])return 1;
	return 0;
}
int dfs(int z,int s){
	v[z]=1;
	for(int i=1;i<=n;i++)
	if(v[i]==0&&check(z,i))
	dfs(i,s+1);
	v[z]=0;
	return ans=max(ans,s);
}
int dfs2(int z,int s,int kk){
	v[z]=1;
	for(int i=1;i<=n;i++){
		if(i==z)continue;
		if(v[i]==1)continue;
		if(x[i]<x[z])continue;
		if(y[i]<y[z])continue;
		if(x[i]==x[z]&&y[i]==y[z])continue;
		int k2=(x[i]-x[z])+(y[i]-y[z])-1;
		if(k2>kk)continue;
		dfs2(i,s+k2+1,kk-k2);
	}
	v[z]=0;
	ans=max(ans,s+kk);
	return 0;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout); 
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	cin>>x[i]>>y[i];
	if(k==0){
	for(int i=1;i<=n;i++)
	dfs(i,1);
	cout<<ans;
	return 0;
	}
	for(int i=1;i<=n;i++)
	dfs2(i,1,k);
	cout<<ans;
}
