#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	cout<<"0"<<endl;
	cout<<"0"<<" "<<"0";
	return 0;
}
