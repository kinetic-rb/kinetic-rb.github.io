#include<bits/stdc++.h>
using namespace std;
long long k;
long long n,e,d;
long long p[100010],q[100010],maxx;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(long long i=1;i<=k;i++)
	{
		cin>>n>>e>>d;
		long long num1=(n-(e*d-2))-sqrt((n-(e*d-2))*(n-(e*d-2))-4*n);
		num1=num1/2;
		if(n%num1!=0)
		{
			cout<<"NO"<<endl;
			continue;
		}
		long long num2=(n-(e*d-2))+sqrt((n-(e*d-2))*(n-(e*d-2))-4*n);
		num2=num2/2;
		if(((num1-1)*(num2-1)+1)!=e*d)
		{
			cout<<"NO"<<endl;
			continue;
		}
		cout<<min(num1,num2)<<" "<<max(num1,num2)<<endl;
	}
	return 0;
}
