#include<bits/stdc++.h>
using namespace std;
int n,k,ans;
struct edge
{
	int x,y;
}e[1010];
bool cmp(edge a,edge b)
{
	if(a.x==b.x)
	{
		return a.y<=b.y;
	}
	return a.x<b.x;
}
int vis[1010];
void dfs(int bh,int cd,int cs)
{
	ans=max(cd+cs,ans);
	if(cs<0)
	{
		ans=max(cd,ans);
		return;
	}
	for(int i=bh+1;i<=n;i++)
	{
		if(e[i].y<e[bh].y)
		{
			continue;
		}
		if(e[i].x==e[bh].x)
		{
			if(e[i].y-e[bh].y==1)
			{
				ans=max(cd,ans);
				dfs(i,cd+1,cs);
			}
		}
		if(e[i].y==e[bh].y)
		{
			if(e[i].x-e[bh].x==1)
			{
				ans=max(cd,ans);
				dfs(i,cd+1,cs);
			}
		}
		int xx=e[i].x-e[bh].x;
		int yy=e[i].y-e[bh].y;
		if(xx+yy>cs+1)
		{
			continue;
		}
		ans=max(cd,ans);
		dfs(i,cd+xx+yy,cs-xx-yy+1);
	}
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>e[i].x>>e[i].y;
	}
	sort(e+1,e+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		dfs(i,1,k);
	}
	cout<<ans;
	return 0;
}
