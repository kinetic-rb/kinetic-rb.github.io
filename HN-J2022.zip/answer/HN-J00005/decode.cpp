#include<bits/stdc++.h>
using namespace std;

int k;
long long n,e,d,p,q,ed,add,sq,sqr;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>e>>d;
		ed=e*d;
		add=n+2-ed;
		sq=add*add-4*n;
		if(sq<0){
			cout<<"NO"<<endl;
			continue;
		}sqr=sqrt(sq);
		if(sqr*sqr!=sq){
			cout<<"NO"<<endl;
			continue;
		}p=(add+sqr)/2;
		q=abs(add-sqr)/2;
		if(p<0||q<0){
			cout<<"NO"<<endl;
			continue;
		}if(p>q)swap(p,q);
		cout<<p<<' '<<q<<endl;
	}
	return 0;
}


