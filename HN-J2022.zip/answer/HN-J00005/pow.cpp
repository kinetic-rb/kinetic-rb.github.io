#include<bits/stdc++.h>
using namespace std;

int a,b;
unsigned long long ans=1;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1){
		cout<<1<<endl;
		return 0;
	}if(b>30){
		cout<<-1<<endl;
		return 0;
	}for(int i=1;i<=b;i++){
		ans*=a;
		if(ans>1000000000){
			cout<<-1<<endl;
			return 0;
		}
	}cout<<ans;
	return 0;
}

