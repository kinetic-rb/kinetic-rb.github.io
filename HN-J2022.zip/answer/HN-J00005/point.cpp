#include<bits/stdc++.h>
using namespace std;

struct node{
	int x,y;
}T[550];

int n,k,X,Y,now,ans;

bool cmp(node A,node B){
	return A.x<B.x;
}

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>X>>Y;
		T[i].x=X;
		T[i].y=Y;
	}sort(T,T+n,cmp);
	now=1;
	for(int i=1;i<n;i++){
		if(T[i].x-T[i-1].x==1&&T[i].y-T[i-1].y)now++;
		else{
			ans=max(ans,now);
			now=1;
		}
	}cout<<ans;
	return 0;
}

