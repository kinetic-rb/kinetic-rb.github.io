#include<bits/stdc++.h>
using namespace std;

string T[1000050];
int ans1,ans2;

void build(int no){
	if(T[no].size()==1)return;
	int i,e,end=-1,kh=0,l,r;
	for(e=T[no].size()-1;e>=0;e--){
		if(T[no][e]==')'){
			kh++;
		}if(T[no][e]=='('){
			kh--;
		}if(T[no][e]=='&'&&kh==0){
			end=e;
		}if(T[no][e]=='|'&&kh==0){
			end=e;
			break;
		}
	}for(i=0;i<end;i++){
		T[no*2]+=T[no][i];
	}for(i=end+1;i<T[no].size();i++){
		T[no*2+1]+=T[no][i];
	}T[no]=T[no][end];
	build(no*2);
	build(no*2+1);
}

int check(int no){
	if(T[no][0]=='0')return 0;
	if(T[no][0]=='1')return 1;
	if(T[no][0]=='|'){
		if(check(no*2)==1){
			ans2++;
			return 1;
		}else{
			if(check(no*2+1)==0)return 0;
		}
	}if(T[no][0]=='&'){
		if(check(no*2)==0){
			ans1++;
			return 0;
		}else{
			if(check(no*2+1)==1)return 1;
		}
	}
}

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>T[1];
	build(1);
	cout<<check(1)<<endl;
	cout<<ans1<<' '<<ans2;
	return 0;
}

//0|(1|0)&(1|1|1&0)
//0&(1|0)|(1|1|1&0)
