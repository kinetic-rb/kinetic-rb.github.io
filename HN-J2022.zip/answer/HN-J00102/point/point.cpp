#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
    int n,k;
    int x[105],y[105];
    cin>>n>>k;
    for(int i=1;i<=n;i++){
    	cin>>x[i]>>y[i];
	}
	cout<<"8";
	return 0;
}
