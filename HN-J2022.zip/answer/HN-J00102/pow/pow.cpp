#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
    int a,b;
    cin>>a>>b;
    long long c=pow(a,b);
    if(pow(a,b)<=1000000000){
    	cout<<c;
	}else{
		cout<<"-1";
	}
	return 0;
}
