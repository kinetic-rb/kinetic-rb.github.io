#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
    string s;
    int t=0,c=0,x=0,y=0;
    cin>>s;
    for(int i=0;i<=s.size();i++){
    	if(s[i]=='0' && s[i+1]=='&'){
    		s[i]=s[i+1]='\0';
    		if(s[i+2]=='('){
    			while(s[i+2+t]!=')'){
    				s[i+2+t]='\0';
    				++t;
				}
				s[i+2+t]='0';
				++x;
				break;
			}
		}
		if(s[i]=='1' && s[i+1]=='|'){
    		s[i]=s[i+1]='\0';
    		if(s[i+2]=='('){
    			while(s[i+2+c]!=')'){
    				s[i+2+c]='\0';
    				++c;
				}
				s[i+2+c]='0';
				++y;
			}
		}
	}
	cout<<"0"<<endl;
	cout<<x<<" "<<y;
	return 0;
}
