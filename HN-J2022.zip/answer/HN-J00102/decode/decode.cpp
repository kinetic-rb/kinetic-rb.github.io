#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
    int k;
    bool flag=0;
    int n,e,d,ans=0,x=0;
    cin>>k;
    for(int i=0;i<k;i++){
    	cin>>n>>d>>e;
    	ans=d*e;
    	for(int j=1;j<=n/2;j++){
    		x=n/j;
    		if(((j-1)*(x-1)+1)==ans){
    			cout<<j<<" "<<x<<endl;
    			flag=1;
    			break;
			}
		}
		if(flag==0){
			cout<<"NO"<<endl;
		}
		flag=0;
		ans=0;
		x=0;
	}
	return 0;
}
