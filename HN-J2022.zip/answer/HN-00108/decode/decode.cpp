#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k,n,e,d,p,q;
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n>>e>>d;
		long long s=n-e*d+2,flag=0;
		for(int i=1;i<=s/2;i++){
			p=i,q=s-i;
			if(n=p*q&&e*d=p*q-p-q+2){
				cout<<p<<" "<<q<<endl;
				flag=1;
				break;
			}
		}
		if(flag==0){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
