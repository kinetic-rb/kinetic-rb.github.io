#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	if(s.length()==3&&s[0]!='('){
		if(s[1]=='|'){
			if(s[0]=='1'||s[2]=='1'){
				cout<<1;
			}else{
				cout<<0;
			}
			cout<<endl;
		}else{
			if(s[0]=='0'||s[2]=='0'){
				cout<<0;
			}else{
				cout<<1;
			}
			cout<<endl;
		}
		if(s[0]=='0'&&s[1]=='&'){
			cout<<1<<" "<<0;
		}else if(s[0]=='1'&&s[1]=='|'){
			cout<<0<<" "<<1;
		}else{
			cout<<0<<" "<<0;
		}
	}else if(s.length()==1){
		cout<<s<<endl;
		cout<<0<<" "<<0;
	}else if(s.length()==3&&s[0]=='('){
		cout<<s[1]<<endl;
		cout<<0<<" "<<0;
	}else{
		cout<<1<<endl;
		cout<<3<<" "<<2<<endl;
	}
	return 0;
}
