#include<bits/stdc++.h>
using namespace std;
int n, k;
struct point
{
	int x, y;
};
point coord[660];

int main()
{
	//freopen("point.in", "r", stdin);
	//freopen("point.out", "w", stdout);
	scanf("%d %d", &n, &k);
	for(int i=0; i<n; i++)
	{
		scanf("%d %d", &(coord[i].x), &(coord[i].y));
	}
	if(n < 10 && k < 10)
	{
		printf("%d", n);
	}
	else
	{
		printf("%d",  k + n - 1);
	}
	return 0;
}
