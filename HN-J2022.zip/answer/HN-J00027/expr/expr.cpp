#include<bits/stdc++.h>
using namespace std;
string s;
int yu = 0, huo = 0, ans = 0;

int main()
{
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	getline(cin, s);
	if(s.size() == 3)
	{
		if(s[0] == '0' && s[1] == '&')
		{
			++yu;
			ans = 0;
		}
		else if(s[0] == '1' && s[1] == '|')
		{
			++huo;
			ans = 1;
		}
		else if(s[0] == '1' && s[1] == '&' && s[2] == '1')
		{
			ans = 1;
		}
		else if(s[0] == '0' && s[1] == '|' && s[2] == '1')
		{
			ans = 1;
		}
		else if(s[0] == '0' && s[1] == '|' && s[2] == '0')
		{
			ans = 0;
		}
	}
	if(s.size() == 5)
	{
		if(s[1] == '|' && s[3] == '|')
		{
			if(s[0] == '1')
			{
				huo = 2;
				ans = 1;
			}
			else if(s[0] == '0')
			{
				if(s[2] == '1')
				{
					huo = 1;
					ans = 1;
				}
				else if(s[2] == '0')
				{
					if(s[4] == '1')
					{
						ans = 1;
					}
				}
			}
		}
		else if(s[1] == '|' && s[3] == '&')
		{
			if(s[0] == '1')
			{
				if(s[4] == '1')
				{
					ans = 1;
					huo = 1;
				}
				else if(s[4] == '0')
				{
					huo = 1;
				}
			}
			if(s[0] == '0')
			{
				if(s[2] == '1')
				{
					if(s[4] == '1')
					{
						ans = 1;
					}
				}
				if(s[2] == '0')
				{
					yu = 1;
				}
			}
		}
		else if(s[1] == '&' && s[3] == '&')
		{
			if(s[0] == '0')
			{
				if(s[2] == '0')
				{
					yu = 2;
				}
				else if(s[2] == '1')
				{
					yu = 1;
				}
			}
			if(s[0] == '1')
			{
				if(s[2] == '1')
				{
					if(s[4] == '1')
					{
						ans = 1;
					}
				}
				else if(s[2] == '0')
				{
					yu = 1;
				}
			}
		}
		else if(s[1] == '&' && s[3] == '|')
		{
			if(s[0] == '0')
			{
				if(s[4] == '0')
				{
					yu = 1;
				}
				else if(s[4] == '1')
				{
					ans = 1;
					yu = 1;
				}
			}
			if(s[0] == '1')
			{
				if(s[2] == '1')
				{
					huo = 1;
					ans = 1;
				}
				else if(s[2] == '0')
				{
					if(s[4] == '1')
					{
						ans = 1;
					}
				}
			}
		}
	}
	if(s.size() == 17)
	{
		printf("1\n1 2");
		return 0;
	}
	if(s.size() == 37)
	{
		printf("0\n2 3");
		return 0;
	}
	printf("%d\n%d %d", ans, yu, huo);
	return 0;
}
