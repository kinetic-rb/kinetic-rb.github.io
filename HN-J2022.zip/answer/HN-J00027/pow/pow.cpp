#include<bits/stdc++.h>
using namespace std;
long long int a, b;

long long int mi(long long int a, long long int b)
{
	int c = a, sum = 2;
	for(int i=1; i<b; i++)
	{
		sum *= c;
	}
	return sum;
}

int main()
{
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	scanf("%d %d", &a, &b);
	if((a > 10 && b > 9) || a + b > 30)
	{
		printf("-1");
		return 0;
	}
	unsigned long long int c = mi(a, b);
	
	printf("%lld", c);
	return 0;
}
