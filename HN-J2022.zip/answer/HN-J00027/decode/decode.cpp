#include<bits/stdc++.h>
using namespace std;
int k;

int main()
{
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	scanf("%d", &k);
	for(int i=0; i<k; i++)
	{
		start:long long int n, d, e;
		bool flag = false;
		scanf("%lld %lld %lld", &n, &d, &e);
		for(long long int p=2; p<=sqrt(n); p++)
		{
			for(long long int q=n/2; q>=sqrt(n); q--)
			{
				if(p * q == n)
				{
					printf("%lld %lld\n", p, q);
					flag = true;
					goto start;
				}
			}
		}
		if(!flag)
		{
			printf("NO\n");
		}
	}
	return 0;
}
