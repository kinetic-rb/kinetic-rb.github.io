#include<bits/stdc++.h>
using namespace std;
long long a,b;
long long qpow(long long a,long long b){
	long long ans=1;
	while(b){
		if(b&1)
			ans*=a;
		if(a>1e9||ans>1e9)
			return -1;
		a*=a;
		b>>=1;
	}
	return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	cout<<qpow(a,b);
	return 0;
}
