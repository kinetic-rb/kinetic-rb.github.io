#include<bits/stdc++.h>
using namespace std;
const int N=505;
int n,k;
struct node{
	int x,y;
}q[N];
int dp[N][N],ans;
bool cmp(node x,node y){
	return (x.x+x.y)<(y.x+y.y);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;++i)
		cin>>q[i].x>>q[i].y;
	sort(q+1,q+n+1,cmp);
	for(int i=1;i<=n;++i){
		for(int j=0;j<=k;++j){
			dp[i][j]=1;
			for(int l=1;l<=n;++l){
				if(q[l].x>q[i].x||q[l].y>q[i].y||i==l)
					continue;
				int t=q[i].x-q[l].x+q[i].y-q[l].y-1;
				if(t<=j)
					dp[i][j]=max(dp[i][j],1+dp[l][j-t]);
			}
		}
	}
	for(int i=1;i<=n;++i)
		ans=max(ans,k+dp[i][k]);
	cout<<ans;
	return 0;
}
