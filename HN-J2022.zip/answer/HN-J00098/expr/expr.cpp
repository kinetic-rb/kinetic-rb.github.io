#include<bits/stdc++.h>
using namespace std;
string a;
int ansy,ansh;
int flag;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	int n=a.length();
	for(int i=0;i<n;++i){
		if(a[i]=='(')
			++flag;
		if(a[i]==')')
			a[i]=a[i-1],--flag;
		if(a[i]=='|'&&a[i-1]=='1'){
			int t=flag;
			while(1){
				if(a[i+1]=='|'&&flag==t||flag<t)
					break;
				else if(a[i+1]=='(')
					++flag;
				else if(a[i+1]==')')
					--flag;
				if(i==n-1)
					break;
				++i;
			}
			a[i]='1';
			++ansh;
		} 
		if(a[i]=='|'&&a[i-1]!='1'){
			if(a[i+1]=='1')
				a[++i]='1';
			else
				a[++i]='0';
		}
		if(a[i]=='&'&&a[i-1]=='0'){
			int t=flag;
			while(1){
				if(a[i+1]=='|'&&flag==t||flag<t)
					break;
				if(a[i+1]=='&'&&flag==t)
					++ansy;
				else if(a[i+1]=='(')
					++flag;
				else if(a[i+1]==')')
					--flag;
				if(i==n-1)
					break;
				++i;
			}
			a[i]='0';
			++ansy;
		}
		if(a[i]=='&'&&a[i-1]!='0'){
			if(a[i+1]=='1')
				a[++i]='1';
			else
				a[++i]='0';
		}
	}
	cout<<a[n-1]<<'\n';
	cout<<ansy<<' '<<ansh;
	return 0;
}
