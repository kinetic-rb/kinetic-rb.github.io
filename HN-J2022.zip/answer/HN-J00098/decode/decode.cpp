#include<bits/stdc++.h>
#define ll long long
using namespace std;
int k;
ll n,d,e;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>d>>e;
		ll m=n-d*e+2;
		ll l=1,r=m,mid;
		while(l<=r){
			mid=(l+r)>>1;
			if(mid*(m-mid)<n)
				l=mid+1;
			else
				r=mid-1;
		}
		if(l*(m-l)!=n)
			puts("NO");
		else
			cout<<l<<' '<<m-l<<'\n';
	}
	return 0;
}
