#include<bits/stdc++.h>
using namespace std;
char a,b;
int main()
{
	
	return 0;
}
