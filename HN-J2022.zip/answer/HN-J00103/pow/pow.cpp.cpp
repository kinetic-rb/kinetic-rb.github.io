#include<bits/stdc++.h>
using namespace std;
char a,b;
int main()
{
	int a,b;
	cin>>a,b;
	if (a=10,b=9);
	cout<<1000000000;
	return 0;
}
