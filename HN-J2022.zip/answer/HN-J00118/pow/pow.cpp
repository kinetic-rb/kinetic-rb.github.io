#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
//	//������ų�
//	if(a==10 && b<=9){
//		cout<<1000000000<<endl;
//	} 
//	if(a=10 && b>9) cout<<-1<<endl;
//	int n[20],m[20],j[20];
//	string r;
    if(a>1000000000){cout<<-1<<endl;return 0;}
    if(b>1000000000){cout<<-1<<endl;return 0;}
	if(a*b>1000000000) cout<<-1<<endl;
	else cout<<a*b<<endl;
	return 0;
}
