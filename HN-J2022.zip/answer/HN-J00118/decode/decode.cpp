#include<iostream>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	long long n[k],d[k],e[k];
	for(int i=0;i<k;i++){
		cin>>n[i]>>d[i]>>e[i];
	}
//	int p[k],q[k];
    bool flag=true,no=true;
	for(int i=0;i<k;i++){
		no=true;
		//n=p*q e*d=(p-1)*(q-1)+1
		for(long long p=1;p<=n[i];p++){
			if(flag==false){flag=true;break;}
//			cout<<p<<endl; 
			for(long long q=1;q<=n[i];q++){
				if(flag==false) break; 
//				cout<<q<<endl;
				if(p*q==n[i]){
					if(e[i]*d[i]==((p-1)*(q-1)+1)){
						if(p<=q){cout<<p<<" "<<q<<endl;flag=false;no=false;continue;}
//					}else{
//						cout<<"NO"<<endl;
//						flag=false;
//					}	
				}
				
				}
			}
		}
		if(no) cout<<"NO"<<endl;
		}
	
	return 0;
}
