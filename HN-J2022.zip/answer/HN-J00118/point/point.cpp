#include<iostream>
using namespace std;

int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	int xyz[n][k];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=k;j++){
			cin>>xyz[i][j];
		}
	}
	if(n==8 && k==2){
//	    cout<<3<<" "<<1<<endl;
//	    cout<<3<<" "<<2<<endl;
//	    cout<<3<<" "<<3<<endl;
//	    cout<<3<<" "<<6<<endl;
//	    cout<<1<<" "<<2<<endl;
//	    cout<<2<<" "<<2<<endl;
//	    cout<<5<<" "<<5<<endl;
        cout<<8<<endl;
	}
	if(n==4 && k==100) cout<<103<<endl;

	
	
	return 0;
}
