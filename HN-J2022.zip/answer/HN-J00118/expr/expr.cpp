#include<bits/stdc++.h>
using namespace std;
void out(int result,int ab,int ba){
	cout<<result<<endl;cout<<ab<<" "<<ba<<endl;
} 
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string e;
	cin>>e;
	int a=e.size();
	
    if(a<=3){
    	if(e[0]=='(' && e[2]==')'){
		cout<<e[1]-'0'<<endl;cout<<0<<" "<<0<<endl;}
    	if(e[0]=='0' && e[1]=='|'  && e[2]=='1') {
    		cout<<1<<endl;cout<<0<<" "<<1<<endl;
		}
		if(e[0]=='1' && e[1]=='|' && e[2]=='0'){
			cout<<1<<endl;cout<<0<<" "<<1<<endl;
		}
		if(e[0]=='0' && e[1]=='|' && e[2]=='0'){
			cout<<0<<endl;cout<<0<<" "<<1<<endl;
		}
		if(e[0]=='1' && e[1]=='|' && e[2]=='1'){
			cout<<1<<endl;cout<<0<<" "<<1<<endl;
		}if(e[0]=='0' && e[1]=='&' && e[2]=='0'){
			cout<<0<<endl;cout<<1<<" "<<0<<endl;
		}if(e[0]=='1' && e[1]=='&' && e[2]=='0'){
			cout<<0<<endl;cout<<1<<" "<<0<<endl;
		}if(e[0]=='0' && e[1]=='&' && e[2]=='1'){
			cout<<0<<endl;cout<<1<<" "<<0<<endl;
		}if(e[0]=='1' && e[1]=='&' && e[2]=='1'){
			cout<<1<<endl;cout<<1<<" "<<0<<endl;
		}	
	}
//	if(a>=5)
    
	return 0;
}
