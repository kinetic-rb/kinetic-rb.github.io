#include<bits/stdc++.h>
using namespace std;
stack<char> a;//fuhao
stack<char> b;//kuohao
string s;
int p=0,q=0;
void jishuan(int ak){
	for(int i=1;i<=ak/3;i++){
		int num2=a.top()-48;
		a.pop();
		char c=a.top();
		a.pop();
		int num1=b.top()-48;
		a.pop();
		if(c=='&'){
			a.push(num1&num2);
			if(num1==0){
				p++;
			}
		}else if(c=='|'){
			a.push(num1|num2);
			if(num1==1){
				q++;
			}
		}
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int len=s.length();
	if(len<=3){
		if(s[1]=='|'&&s[0]=='1'){//1|
			cout<<1<<endl;
			cout<<0<<" "<<1;
		}
		if(s[1]=='&'&&s[0]=='0'){//0&
			cout<<0<<endl;
			cout<<1<<" "<<0;
		}
		if(s=="1&1"){
			cout<<1<<endl<<0<<" "<<0;
		}
		if(s=="1&0"){
			cout<<0<<endl<<0<<" "<<0;
		}
		if(s=="0|1"){
			cout<<1<<endl<<0<<" "<<0;
		}
		if(s=="0|0"){
			cout<<0<<endl<<0<<" "<<0;
		}
	}/*else{
		int flag=0,ak=0;
		for(int i=0;i<len;i++){
			if(s[i]=='('){
				b.push(s[i]);
				flag=1;
				ak=0;
			}
			if(s[i]=='&'||s[i]=='|'||(s[i]>='0'&&s[i]<='9')){
				a.push(s[i]);
				if(flag){
					ak++;
				}
			}
			if(s[i]==')'){
				while(b.top()!='('&&!b.empty()){
					b.pop();
				}
				jishuan(ak);
			}
		}
	}
	if(!a.empty()){
		while(a.size()!=1){
			int num2=a.top()-48;
			a.pop();
			char c=a.top();
			a.pop();
			int num1=b.top()-48;
			a.pop();
			if(c=='&'){
				a.push(num1&num2);
				if(num1==0){
					p++;
				}
			}else if(c=='|'){
				a.push(num1|num2);
				if(num1==1){
					q++;
				}
			}
		}
	}
	cout<<a.top()<<endl<<p<<" "<<q;*/
	fclose(stdin);
	fclose(stdout);
	return 0;
}
