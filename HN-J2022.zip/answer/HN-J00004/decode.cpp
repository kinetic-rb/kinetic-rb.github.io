#include<bits/stdc++.h>
using namespace std;
int k,n,e,d,head;
long long a[10000000];
void fenjie(int n){
	head=1;
	for(int i=1;i<=sqrt(n);i++){
		if(n%i==0){
			a[head]=i;
			head++;
		}
	}
	head--;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>e>>d;
		fenjie(n);
		int flag=0;
		for(int i=1;i<=head;i++){
			int p=a[i],q=n/a[i];
			if(e*d==(p-1)*(q-1)+1){
				cout<<p<<" "<<q<<endl;
				flag=1;
			}
		}
		if(flag==0){
			cout<<"NO"<<endl;	
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
10
770 77 5
633 1 211
545 1 499
683 3 227
858 3 257
723 37 13
572 26 11
867 17 17
829 3 263
528 4 109
*/
