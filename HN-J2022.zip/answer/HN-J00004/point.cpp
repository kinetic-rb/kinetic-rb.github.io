#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","w",stdin);
	freopen("point.out","r",stdout);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
