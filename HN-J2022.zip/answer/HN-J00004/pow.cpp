#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b,c=1;
	cin>>a>>b;
	for(int i=1;i<=b;i++){
		c=c*a;
		if(c>1e9){
			cout<<-1;
			return 0;
		}
	}
	cout<<c;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

