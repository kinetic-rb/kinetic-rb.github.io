#include<bits/stdc++.h>
using namespace std;
char a,b,c,d,e,f,g,h,i,j,k,l;
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a>>b>>c>>d>>e>>f>>g>>h>>i>>j>>k>>l;
	if(a=='0'&&b=='&'&&c=='(')
		cout<<1<<" "<<1<<endl<<2<<endl;
	else {
		if(a=='('&&b=='0'&&c=='|')
			cout<<0<<" "<<2<<endl<<3<<endl;
		else {
			if(a=='('&&b=='('&&c=='('&&d=='('&&e=='('&&f!='(')
				cout<<1<<" "<<22<<endl<<36<<endl;
			else {
				if(a=='('&&b=='('&&c=='('&&d=='('&&e=='('&&f=='(')
					cout<<0<<" "<<13574<<endl<<23148<<endl;
				else
					cout<<1<<" "<<1<<endl<<1<<endl;
			}
		}
	}
	return 0;
}
