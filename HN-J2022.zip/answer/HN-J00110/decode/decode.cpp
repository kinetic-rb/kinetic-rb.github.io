#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,p,q,dt1,dt2,pop=0;
int main() {
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(long long i=1; i<=k; i++) {
		pop=0;
		cin>>n>>e>>d;
		dt1=n-e*d+2;//he
		dt2=n;//ji
		if(dt1%2==1&&dt2%2==1) {
			pop=1;
			cout<<"NO"<<endl;
		}
		if(pop==0) {
			for(long long j=1; j*j<=n; j++) {
				if(dt2%j==0&&j<dt1&&pop==0&&dt2/j==dt1-j) {
					cout<<j<<" "<<dt1-j<<endl;
					pop=1;
				}
			}
		}
		if(pop==0)
			cout<<"NO"<<endl;
	}
	return 0;
}
