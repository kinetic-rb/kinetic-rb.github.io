#include<bits/stdc++.h>
using namespace std;
int a,b;
int cnt=0;
int main(){
	cin>>a>>b;
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	for(int i=1;i<=b;i++){
		cnt=a;
		for(int i=2;i<=b;i++){
			cnt=a*a;
		}
		for(int i=3;i<=b;i++){
			cnt=a*a*a;
		}
		for(int i=4;i<=b;i++){
			cnt=a*a*a*a;
		}
		for(int i=5;i<=b;i++){
			cnt=a*a*a*a*a;
		}
		for(int i=6;i<=b;i++){
			cnt=a*a*a*a*a*a;
		}
		for(int i=7;i<=b;i++){
			cnt=a*a*a*a*a*a*a;
		}
		for(int i=8;i<=b;i++){
			cnt=a*a*a*a*a*a*a*a;
		}
		for(int i=9;i<=b;i++){
			cnt=a*a*a*a*a*a*a*a*a;
		}
		if(cnt>1000000000){
			cout<<"-1";
			return 0;
		}
	}
		cout<<cnt;
	return 0;
}
