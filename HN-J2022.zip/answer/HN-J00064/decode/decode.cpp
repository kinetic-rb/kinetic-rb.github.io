#include<bits/stdc++.h>
using namespace std;
long long n[10000],e[10000],d[100000];
int p[10000],q[10000];
int k;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>> n[10000]>>e[10000]>>d[100000];
	for(int i=1;i<=k;i++){
		p[i]==n[i]%q[i]&&p[i]==(e[i]*d[i]-1)%(q[i]-1)-1;
		q[i]==n[i]%p[i]&&q[i]==(e[i]*d[i]-1)%(p[i]-1)-1;
		if(p[i]>q[i]){
			cout<<"No";
		}
		else cout<<p[i]<<" "<<q[i]<<endl;
	}
	return 0;
}

