#include<bits/stdc++.h>
using namespace std;

int a, b;
int ab = 1;

int main()
{
	cin >> a >> b;
	for(int i = 1; i <= b; i++)
	{
		ab = a * ab;
		if(ab % 1000000001 != ab)
		{
			cout << "-1";
			return 0;
		}
	 } 
	cout << ab;
	return 0;	
}

