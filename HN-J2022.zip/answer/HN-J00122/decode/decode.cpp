#include<bits/stdc++.h>
using namespace std;
int k;
int n[100005],q[100005],p[100005],e[100005],d[100005],m[100005];
int main()
{
	cin >> k;
	for(int i = 1; i <= k; i++)
	{
		cin >> n[i] >> e[i] >> d[i];
		m[i] = n[i] - e[i] * d[i] + 2;
	}
	for(int i = 1; i <= k; i++)
	{
		for(int j = 1; j <= m[i]/2 ; j++)
		{
			double x = n[i]/j;
			double y = m[i] - j;
			if(x == y)
			{
				p[i] = j;
				q[i] = m[i] - j;
				continue; 
			}			
		}
	
	}
	for(int i = 1; i <= k; i++)
	{
		if(p[i] > 0 && p[i] <= q[i] && p[i] * q[i] == n[i])
			cout << p[i] << " "<< q[i] << endl;
		else
			cout << "NO"<< endl;
	}
	return 0;
}
