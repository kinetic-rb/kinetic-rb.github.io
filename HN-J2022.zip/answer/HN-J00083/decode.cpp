#include<bits/stdc++.h>
using namespace std;
int main()
{
	int k,p[100],q[100];
	cin>>k;
	for(int i1=1;i1<=k;i1+1)
	{
		int n,d,e;
		cin>>n>>d>>e;
		if(q[i1]*p[i1]==n)
		{
			q[i1]=q[i1]-1;
			p[i1]=p[i1]-1;
			if(q[i1]*p[i1]+1==e*d)
			{
				cout<<q[i1]+1<<p[i1]+1;
			}
			else
			{
				cout<<"NO"<<endl;
			}
		}
		else
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
