#include<bits/stdc++.h>
using namespace std;
int n,k,ans=0,za=1;
long long a[455][570];
void df(int q,int p){
	if(a[q][p]>0){
    if(a[q+1][p]>0){
    	za++;
    	a[q][p]=0;
    	df(q+1,p);
	} 
    if(a[q][p+1]>0){
    	za++;
    	a[q][p]=0;
    	df(q,p+1);
	}
	if(a[q-1][p]>0){
    	za++;
    	a[q][p]=0;
    	df(q-1,p);
	} 
    if(a[q][p-1]>0){
    	za++;
    	a[q][p]=0;
    	df(q,p-1);
	}
    }
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	int x=0,y=0,z1,z2;
	for(int i=1;i<=n;i++){
		cin>>z1>>z2;
		a[z1][z2]++;
		if(z1>x) x=z1;
		if(z2>y) y=z2;
	}
    for(int i=1;i<=x+1;i++){
    	for(int j=1;j<=y+1;j++){
    		df(i,j);
    		if(za>ans) ans=za;
    		za=1;
		}
	}
	cout<<ans+k;
	return 0;
}
