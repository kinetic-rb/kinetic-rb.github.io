#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	long long n[100001],d,e,m[100001];
	for(int i=1;i<=k;i++){
		cin>>n[i]>>d>>e;
		m[i]=n[i]-(d*e)+2;
	}
	int v=1;
	for(int i=1;i<=k;i++){
		for(int j=1;j<=m[i]/2;j++){
			if(n[i]==j*(m[i]-j)){
				cout<<j<<" "<<(m[i]-j);
				v=0;
			}
		}
		if(v==1){
			cout<<"NO";
		}
		cout<<endl;
		v=1;
	}
	return 0;
}
