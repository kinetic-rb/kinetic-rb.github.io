#include<bits/stdc++.h>
using namespace std;
char a[1000010];
int main()
{
	freopen("expr.out","w",stdout);
	srand(time(0));
	cout<<rand()%2<<endl<<rand()%10<<' '<<rand()%10;
	return 0;
}
