#include<bits/stdc++.h>
using namespace std;
map<int,int> p;
void run(int l)
{
	long long n,d,e;
	scanf("%lld%lld%lld",&n,&d,&e);
	long long k=n-e*d+2;
	int t=sqrt(n);
	vector<int> prime;
	for(int i=1;i<=t;i++)
	{
		if(n%i==0)
		{ 
			p[n/i]=l;
			prime.push_back(i);
		}
	}
	for(int i=0;i<prime.size();i++)
	{
		if(p[k-prime[i]]==l)
		{
			printf("%d %d\n",prime[i],k-prime[i]);
		}
	}
	printf("NO\n"); 
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	while(k--)
		run(k+1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
