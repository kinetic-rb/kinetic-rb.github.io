#include<bits/stdc++.h>
using namespace std;
void run()
{
	long long n,d,e;
	scanf("%lld%lld%lld",&n,&d,&e);
	long long k=n-e*d+2;
	long long l=1,r=k-1;
	while(l<=r)
	{
		long long p=(l+r)/2;
		if(abs(p-n*1.0/(k-p))<=1e-6) 
		{
			if(p<n/p)
				printf("%d %d\n",p,n/p);
			else
				printf("%d %d\n",n/p,p);
			return ;
		}
		else if(p>n*1.0/(k-p))
			r=p-1;
		else if(p<n*1.0/(k-p))
			l=p+1;
	}
	printf("NO\n");
}
int main()
{           
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;        
	cin>>k;
	while(k--)
		run();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
