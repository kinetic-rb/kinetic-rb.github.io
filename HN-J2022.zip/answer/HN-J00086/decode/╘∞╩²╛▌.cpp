#include<bits/stdc++.h>
using namespace std;
int main()
{           
	freopen("decode.in","w",stdout);
	cout<<1000<<endl;
	srand(time(0));
	
	for(int i=1;i<=100;i++)
	{
		int p=rand()%100000000,q=rand()%100000000;
		cout<<p*q<<' ';
		int k=sqrt((p-1)*(q-1)+1);
		bool flag=1;
		for(int i=1;i<=k;i++)
		{
			if(((p-1)*(q-1)+1)%i==0)
			{
				cout<<i<<' '<<((p-1)*(q-1)+1)/i<<endl;
				flag=0;
				break;
			}
		}
		if(flag)
			cout<<1<<' '<<1<<endl;
	} 
	fclose(stdout);
	return 0;
}
