#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,c=1;
	cin>>a>>b;
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	while(b&&c<=1e9)
	{
		c*=a;
		b--;
	}
	if(c<=1e9)
		cout<<c;
	else
		cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
