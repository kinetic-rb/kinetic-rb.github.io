#include<bits/stdc++.h>
using namespace std;

int a,b;
long long ans1,ans2;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	cin>>a>>b;
	ans2=1;
	ans1=1;
	int zt=1;
	if(a==1){
	cout<<1;}
	else{
	while(b--){
		ans1*=a;
		ans1%=1000000001ll;
		if(ans1<ans2){
			cout<<-1;zt=0;break;
		}
		ans2=ans1;
		
	}
	if(zt)cout<<ans1;
	
	
	
}
	
	
	
	return 0;
	
}
