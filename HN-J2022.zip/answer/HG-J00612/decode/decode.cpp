#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
ll n, m, d, e ;
int k;
int main(){
	freopen("decode1.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	cin>>k;
	while(k--){
		cin>>n>>d>>e;
		//n=q*p;
		//q<=p
		//d*e=n-q-p+2
		m=-1ll*(d*e-n-2);
		ll l=1ll;
		ll p=1ll;
		while(p>0ll){
			if((n/(p+l))+l+p<=m)l+=p,p*=2;
			else {
				p/=2;
			}
			//if(n*1.0/(l+p)<l+p)break;
		}
		if((n%l)==0)cout<<l+p<<" "<<n/(l+p);
		else cout<<"No";
		cout<<endl;
		
	}
	
	return 0;
	
}
