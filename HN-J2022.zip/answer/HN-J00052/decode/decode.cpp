#include<bits/stdc++.h>
using namespace std;
int k;
unsigned long long n,e,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n>>e>>d;
		unsigned long long m=n+2-e*d;
		if(e*d>n){
			cout<<"NO";
			continue;
		}
		bool flag=0;
		for(unsigned long long i=1;i<=m/4+3;i++){
			if(n==i*(m-i)){
				cout<<i<<" "<<m-i<<endl;
				flag=1;
				break;
			}
		}
		if(!flag)cout<<"NO"<<endl;
	}
	return 0;
}
