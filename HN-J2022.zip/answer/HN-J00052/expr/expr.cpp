#include<bits/stdc++.h>
using namespace std;
string a; 
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	if(a=="1&1"||a=="(1&1)"||a=="(1)&1"||a=="1&(1)")cout<<"1\n0 0";
	
	else if(a=="1|1"||a=="(1|1)"||a=="(1)|1"||a=="1|(1)")cout<<"1\n0 1";
	
	else if(a=="0&0"||a=="(0&0)"||a=="(0)&0"||a=="0&(0)")cout<<"0\n1 0";
	
	else if(a=="0|0"||a=="(0|0)"||a=="(0)|0"||a=="0|(0)")cout<<"0\n0 0";
	
	else if(a=="0&1"||a=="(0&1)"||a=="0&(1)"||a=="(0)&1")cout<<"0\n1 0";
	
	else if(a=="0|1"||a=="(0|1)"||a=="0|(1)"||a=="(0)|1")cout<<"1\n0 0";
	
	else if(a=="1&0"||a=="(1&0)"||a=="(1)&0"||a=="1&(0)")cout<<"0\n0 0";
	
	else if(a=="1|0"||a=="(1|0)"||a=="(1)|0"||a=="1|(0)")cout<<"1\n0 1";
	
	else if(a=="1"||a=="(1)")cout<<"1\n0 0";
	
	else if(a=="0"||a=="(0)")cout<<"0\n0 0";
	
	else if(a=="1|0"||a=="(1|0)"||a=="(1)|0"||a=="1|(0)")cout<<"1\n0 1";
	
	else if(a=="0&0&0"||a=="0&0&1")cout<<"0\2 0";
	
	else if(a=="0&1&0"||a=="0&1&1"||a=="1&0&0"||a=="1&0&1")cout<<"0\1 0";
	
	else if(a=="1&1&0")cout<<"0\n0 0";
	
	else if(a=="1&1&1")cout<<"1\n0 0";
	
	else if(a=="0|0|0")cout<<"0\n0 0";
	
	else if(a=="0|0|1")cout<<"0\n0 0";
	
	else if(a=="0|1|0")cout<<"0\n1 0";
	
	else if(a=="0|1|1")cout<<"0\n1 0";
	
	else if(a=="1|0|0")cout<<"0\n1 0";
	
	else if(a=="1|0|1")cout<<"0\n1 0";
	
	else if(a=="1|1|0")cout<<"0\n2 0";
	
	else if(a=="1|1|1")cout<<"1\n2 0";
	return 0;
}

