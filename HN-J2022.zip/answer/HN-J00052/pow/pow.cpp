#include<bits/stdc++.h>
using namespace std;
unsigned long long x,n;
bool p=0;
unsigned long long cal(unsigned long long a,unsigned long long b){
	if(p)return 0;
	if(b==1){
		return a;
	}
	else if(b%2==0){
		unsigned long long t=cal(a,b/2);
		if(t>1000000000){
			p=1;
			return 0;
		}
		return t*t;
	}
	else{
		return a*cal(a,b-1);
	}
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>x>>n;
	unsigned long long h=cal(x,n);
	if(p){
		cout<<-1;
	}
	else{
		cout<<h;
	}
	return 0;
}

