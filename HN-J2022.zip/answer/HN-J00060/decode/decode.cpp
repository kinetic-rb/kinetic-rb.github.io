#include<bits/stdc++.h>
using namespace std;
int k;
long long n,e,d;
bool flag;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
	{
		flag=0;
		scanf("%lld%lld%lld",&n,&e,&d);
		for(int j=1;j<=sqrt(n);j++)
			if(n%j==0)
				if((j-1)*(n/j-1)+1==e*d)
				{
					flag=1;
					printf("%d %lld\n",j,n/j);
					break;
				}
		if(!flag)
			printf("NO\n"); 
	}
	return 0;
}
