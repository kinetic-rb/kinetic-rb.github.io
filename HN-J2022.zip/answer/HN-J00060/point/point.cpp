#include<bits/stdc++.h>
using namespace std;
int n,k;
int x[501],y[501];
int maxx,maxy;
struct node
{
	int f;
	int cnt;
}dp[10001][10001];
int ans;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		dp[x[i]][y[i]].f=1;
		maxx=max(maxx,x[i]);
		maxy=max(maxy,y[i]);
	}
	for(int i=1;i<=maxx;i++)
		for(int j=1;j<=maxy;j++)
		{
			if(!dp[i][j].f)
				dp[i][j].cnt++;
			if(dp[i][j-1].f>dp[i-1][j].f)
			{
				dp[i][j].f+=dp[i][j-1].f;
				dp[i][j].cnt+=dp[i][j-1].cnt;
			}
			else
			{
				dp[i][j].f+=dp[i-1][j].f;
				dp[i][j].cnt+=dp[i-1][j].cnt;
			}
		}
	for(int i=1;i<=n;i++)
	{
		if(dp[x[i]][y[i]].cnt<=k)
			ans=max(ans,dp[x[i]][y[i]].f+k);
		else
			ans=max(ans,dp[x[i]][y[i]].f);
	}
	printf("%d\n",ans); 
	return 0;
}
