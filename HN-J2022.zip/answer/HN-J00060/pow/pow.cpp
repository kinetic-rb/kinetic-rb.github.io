#include<cstdio>
using namespace std;
int a,b;
long long sum=1;
long long pow1(int x,int y)
{
	for(int i=1;i<=y;i++)
	{
		sum*=x;
		if(sum>1e9)
			return -1;
	}
	return sum;
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%d%d",&a,&b);
	printf("%lld\n",pow1(a,b));
	return 0;
}
