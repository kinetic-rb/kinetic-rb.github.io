#include<bits/stdc++.h>
using namespace std;
int k;
long long n,e,d;
int main()
{
	froepen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>n>>e>>d;
		cout<<"NO";
	}
	return 0;
}

