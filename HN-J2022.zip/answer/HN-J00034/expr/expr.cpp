#include<bits/stdc++.h>
using namespace std;
char a[100010];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	cout<<"0"<<endl<<"2"<<" "<<"3";
	return 0;
}

