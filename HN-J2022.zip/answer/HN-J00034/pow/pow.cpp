#include<bits/stdc++.h>
using namespace std;
long long a,b,sum1;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1)
	{
		cout<<"1";
		return 0;
	}
	sum1=1;
	for(int i=1;i<=b;i++)
	{
		sum1=sum1*a;
		if(sum1>1000000000)
		{
			cout<<"-1";
			return 0;
		}
	}
	if(sum1<=1000000000)
	{
		cout<<sum1;
		return 0;
	}
	return 0;
}
