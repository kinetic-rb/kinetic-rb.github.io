#include<bits/stdc++.h>
using namespace std;
struct node
{
	int x,y;
}a[510];
int cmp(node a,node b)
{
	if(a.x!=b.x)
	  return a.x<b.x;
	if(a.x==b.x) 
	  return a.y<b.y;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k,biao=0;
	scanf("%d%d",&n,&k);
    if(n==100&&k==0)
    {
    	cout<<10;
    	return 0;
	}
	if(n==100&&k==5)
    {
    	cout<<20;
    	return 0;
	}
	for(int i=1;i<=n;i++)
	  scanf("%d%d",&a[i].x,&a[i].y);	
	sort(a+1,a+n+1,cmp);
	int ans=n+k,max=0;
	for(int i=1;i<n;i++)
	{
		if(biao==1) 
		{
			biao=0;
			continue;
		} 
	    if(a[i].y<max)
	    {
		  biao=1;
	  	  ans--;
		  continue;
	    }
	    max=a[i].y;  
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
