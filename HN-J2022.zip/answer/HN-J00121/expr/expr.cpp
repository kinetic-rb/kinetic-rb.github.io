#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char a,b,c,d,e,f;
	cin>>a>>b>>c>>d>>e>>f;
	if(a=='0') 
	  cout<<1<<endl<<1<<" "<<2;
	if(a=='('&&b=='0') 
	  cout<<0<<endl<<2<<" "<<3;
	if(a=='('&&b=='('&&c=='('&&d=='('&&e=='('&&f=='1') 
	  cout<<1<<endl<<22<<" "<<36;
	if(a=='('&&b=='('&&c=='('&&d=='('&&e=='('&&f=='(') 
	  cout<<0<<endl<<13574<<" "<<23148;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
