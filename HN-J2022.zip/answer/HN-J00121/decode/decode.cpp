#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int k;
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
	{
		long long n,d,e,cun,he,pan=1;
		scanf("%lld%lld%lld",&n,&d,&e);
		cun=d*e;
		he=n-cun+2;
		for(int i=1;i<=he;i++)
		{
			if(n%i==0)
			{
				long long a=i,b=n/i;
				if(a+b==he)
				{
					if(a<b)
					  cout<<a<<" "<<b<<endl;
					else 
					  cout<<b<<" "<<a<<endl;
					pan=0;
				    break;
				}
			}
		}
		if(pan)
		  cout<<"NO"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
