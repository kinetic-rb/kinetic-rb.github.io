#include<bits/stdc++.h>
using namespace std;
int kuai(long long x,long long z)
{
	long long sum=1;
	while(z!=0)
	{
		if(z%2==1)
		  sum*=x;
		x*=x;
		z/=2;
	}
	return sum;
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long x,z,ans;
    scanf("%lld%lld",&x,&z);
	ans=kuai(x,z);
	if(ans>1000000000)
		cout<<"-1";
	else
	    cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
