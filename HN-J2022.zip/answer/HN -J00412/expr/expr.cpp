#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin >> s;
		if(s[0]=='0'&&s[1]=='&'){
			cout << '0' << endl;
			cout << '0' << " "<< '0';
		}else if(s[0]=='1'&&s[1]=='&'&&s[2]=='1'){
			cout << '1' << endl;
			cout << '0'<<" " << '0';
		}else if(s[0]=='1'&&s[1]=='|'){
			cout << '1' << endl;
			cout << '0' <<" "<< '1';
		}else if(s[0]=='0'&&s[1]=='|'&&s[2]=='0'){
			cout << '0' << endl;
			cout << '0' <<" "<< '0';
		}else if(s[0]=='0'&&s[1]=='|'&&s[2]=='1'){
			cout << '1' << endl;
			cout << '0' <<" "<< '0';
		}
	return 0;
}
