#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin >> a >> b;
	long long c=pow(a,b);
	if(pow(a,b)>pow(10,9)){
		cout << "-1";
	}else{
		cout << c;
	}
	return 0;
}
