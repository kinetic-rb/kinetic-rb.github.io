#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
long long n[maxn],d[maxn],e[maxn];
long long lw(long long n,long long d,long long e){
	long long a,b;
	for(long long i=1;i*i<=n;i++){
		if(n%i!=1){
			a=i;
			b=n/i;
		}
		if(e*d==((a-1)*(b-1)+1)){
				cout << a <<" "<< b << endl;
				return 0;
		}
	}
	cout << "NO" << endl;
	return 0;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin >> k;
	for(long long i=1;i<=k;i++){
		cin >> n[i] >> d[i] >> e[i];
		lw(n[i],d[i],e[i]);
	}
	return 0;
}
