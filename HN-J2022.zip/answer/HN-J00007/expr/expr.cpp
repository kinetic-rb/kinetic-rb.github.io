#include<bits/stdc++.h>
using namespace std;
string s; 
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(substr(0,5)=="0&(1|)")
	{
		cout<<"1\n1 2";
	}
	else if(substr(0,5)=="(0|1&")
	{
		cout<<"0\n2 3";
	}
	else if(substr(0,5)=="(((((")
	{
		cout<<"1\n22 36";
	}
	else if(substr(0,20)=="((((((((((((((((((((")
	{
		cout<<"0\n13574 23148";
	}
	else
	{
		cout<<"0\n0 0";
	}
	return 0;
} 
