#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,ans;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>k;
	while(k--)
	{
		cin>>n>>e>>d;
		ans=n+2-e*d;
//		for(int i=1;i<=ans/2+1;i++)
//		{
//			if(i*(ans-i)==n)
//			{
//				cout<<i<<" "<<ans-i<<endl;
//				f=1;
//				break;
//			}
//		}
        long long l=1,r=ans/2;
		bool f=0; 
		while(l<r-1)
		{
			long long m=(l+r)>>1;
			//cout<<l<<" "<<r<<" "<<m<<" "<<ans<<endl;
			if(m*(ans-m)<n)
			{
				l=m;
			}
			else if(m*(ans-m)>n)
			{
				r=m;
			}
			else
			{
				cout<<m<<" "<<ans-m<<endl;
				f=1;
				break;
			}
		}
		if(!f)
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
} 
