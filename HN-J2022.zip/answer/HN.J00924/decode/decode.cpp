#include<bits/stdc++.h>
using namespace std;
long long n,e,d,p,q,k;
bool check(double x){
	long long g=x;
	if(1.0*g!=x)return 0;
	return 1;
}
int main(){	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(long long g=1;g<=k;g++){
		cin>>n>>d>>e;
		long long c=n-e*d+2;
		long long deta=-4*n*1+(-c)*(-c);
		if(deta<0||!check(sqrt(1.0*deta))){
			cout<<"NO"<<endl;
			continue;
		}
		double xb=(1.0*sqrt(1.0*deta)+c)/2; 
		double xc=(1.0*(-sqrt(1.0*deta))+c)/2;
	
		if(xb<=0||xc<=0||!check(xc)||!check(xb)){
			cout<<"NO"<<endl;
			continue;
		}
		long long xs=min(xc,xb);
		long long xy=max(xc,xb);
		cout<<xs<<" "<<xy<<endl;
	}
	
	return 0;
} 
