#include<bits/stdc++.h>
using namespace std;
string s;
int t,r;
bool check(string z){
	int o=z.size();
	if(z[0]!='(')return 0;
	int q=1;
	for(int i=1;i<o-1;i++){
		if(z[i]=='(')q++;
		if(z[i]==')')q--;
		if(q==0)return 0;
	}
	return 1;
}
bool f(string z){
	string xs,xl;
	char x;
		if(z.empty())return 0;
	
	int n=z.size();
	bool a=0;
	
				
	if(check(z)){
	n--,a++;
	}
	
	if(n==1){
		if(z[0]=='1')return 1;
		else return 0;
	}
				

	//
	int p=0;bool flag=0;
	for(int i=a;i<n;i++){
		if(z[i]=='('){
			while(z[i]!=')')i++;
		}
		if(z[i]=='&'&&flag==0)p=i;
		if(z[i]=='|')p=i,flag=1;
	}
	x=z[p];
	for(int i=a;i<p;i++)xs+=z[i];
	for(int i=p+1;i<n;i++)xl+=z[i];
	if(x=='&'){	
	int v=f(xs);	
		if(v==0){
			t++;return 0;
		}
		else{
			if(f(xl)==1&&v==1)return 1;
			return 0;
		}
	}
	else{  ;
		if(f(xs)==1){
			r++;
			return 1;
		}
		else{
			if(f(xl)==1)return 1;
			return 0;
		} 
	}
}

int main(){	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	bool fla=1,flb=0,flc=1,fld=0;
	int g=s.size();
	for(int i=0;i<g;i++){
		if(s[i]=='&'){
		fla=0;
		}
		if(s[i]=='|'){
		flc=0;
		}
		if(s[i]=='1')flb=1;
		if(s[i]=='0')fld=1;
	}
	
	if(fla==1&&flb==1){
		f(s);
		cout<<1<<endl;
		cout<<t<<" "<<r;
		return 0;
	}
	if(fld==1&&flc==1){
		f(s);
		cout<<0<<endl;
		cout<<t<<" "<<r;
		return 0;
	}
	
	
	cout<<f(s)<<endl;
	cout<<t<<" "<<r;
	
	return 0;
} 

