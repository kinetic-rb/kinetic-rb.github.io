#include<bits/stdc++.h>
using namespace std;
int n,k,v[10000];




struct node{
	int x,y;
	bool operator <(const node &b)const{
		if(x!=b.x)return x<b.x;
		else return y<b.y;
	}
}a[1000];

struct node2{
	int x,p;
	bool operator <(const node2 &b)const{
		return x<b.x;
	}
}f[1000];
void dfs(int k,int p){
	
	for(int i=p;i<=n;i++){
		if(a[i].x-a[p].x>1||a[i].x-a[p].x>1)break;
		if(v[i]==0&&((a[i].x-a[p].x==1&&a[i].y==a[p].y)||((a[i].y-a[p].y==1)&&a[i].x==a[p].x))){
			v[i]=1;
			dfs(k+1,i);
			v[i]=0; 
		}
	}
	f[p].x=max(f[p].x,k);
}
int main(){	
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
	cin>>a[i].x>>a[i].y;f[i].p=i;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++){
		dfs(1,i);
	}
	int ans=0,ansx=0;
	for(int i=1;i<=n;i++){
		if(f[i].x>ans){
			ans=f[i].x;
			ansx=i;
		}		//cout<<f[i]<<" ";
	}
	sort(f+1,f+n+1);
	int s=0;
	for(int i=1;i<=n;i++){
		if((a[f[i].x].x-a[ansx].x==1&&a[f[i].x].y==a[ansx].y)||((a[f[i].x].y-a[ansx].y==1)&&a[f[i].x].x==a[ansx].x)){
			ans=ans+f[i].x;
			s++;
		}
		if(s==k)break;
	}
	cout<<ans+k;
	return 0;
} 

