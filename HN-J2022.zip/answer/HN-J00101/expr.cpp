#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<0<<endl;
	cout<<"2"<<"3"<<endl;
	return 0;
}
