#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	long long sum=pow(a,b);
	long long big=pow(10,9);
	if(sum>big){
		cout<<"-1";
	}else{
		if(a!=1&&b>31){
			cout<<"-1";
		}else{
			cout<<sum;
		}
	}
	return 0;
}
