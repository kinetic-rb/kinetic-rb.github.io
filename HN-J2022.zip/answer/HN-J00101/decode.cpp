#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	for(int i=1;i<=k;i++){
		cout<<"NO";
    }
	return 0;
}
