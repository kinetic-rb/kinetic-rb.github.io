# include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	int x=0,y=0;
	cin >> a;
	for(int i=0;i<=a.length();i++){
		if(a[i]=='&') x++;
		if(a[i]=='|') y++;
	}
	cout << 0 << endl;
	cout << x/2 << " " << y/2;
	return 0;
}

