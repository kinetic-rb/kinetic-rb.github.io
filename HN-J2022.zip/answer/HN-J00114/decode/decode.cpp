# include <bits/stdc++.h>
using namespace std;
void decode(long long n,long long c,long long d){
	long long x=n-c*d+2;
	for(int i=1;i<=x/2;++i){
		if(i*(x-i)==n){
			cout << i << " " << x-i << endl;
			return;
		} 
	}
	cout << "NO" << endl;
	return;
}
long long r,s,t;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	for(int i=1;i<=k;++i){
		cin >> r >> s >> t;
		decode(r,s,t);
	}
	return 0;
}

