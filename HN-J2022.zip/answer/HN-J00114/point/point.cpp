# include <bits/stdc++.h>
using namespace std;
int a[10005][10005],vis[10005][10005];
int x,y;
int dfs(int x,int y,int maxx,int maxy){
	int love=1;
	vis[x][y]=1;
	if(a[x+1][y]==0&&a[x-1][y]==0&&a[x][y+1]==0&&a[x][y-1]==0) return 1;
	if(a[x+1][y]==1&&vis[x+1][y]!=1&&x+1<=maxx){
		love+=dfs(x+1,y,maxx,maxy);
	}
	if(a[x-1][y]==1&&vis[x-1][y]!=1&&x-1>=1){
		love+=dfs(x-1,y,maxx,maxy);
	}
	if(a[x][y+1]==1&&vis[x][y+1]!=1&&y+1<=maxy){
		love+=dfs(x,y+1,maxx,maxy);
	}
	if(a[x][y-1]==1&&vis[x][y-1]!=1&&y-1>=1){
		love+=dfs(x,y-1,maxx,maxy);
	}
	return love;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin >> n >> k;
	int maxx=0,maxy=0;
	for(int i=1;i<=n;i++){
		cin >> x >> y;
		a[x][y]=1;
		maxx=max(x,maxx);
		maxy=max(y,maxy);
	}
	
	int ans=0;
		/*for(int i=1;i<=maxx;i++){
			int m=0,j=1;
		 	while(a[i][j]==1&&j<=maxy){
				j++;
				m++;
			}
			ans=max(ans,m);
		}
		for(int i=1;i<=maxy;i++){
			int m=0,j=1;
			while(a[j][i]==1&&j<=maxx){
				j++;
				m++;
			}
			ans=max(ans,m);
		}*/
	int love;
	for(int i=1;i<=maxx;i++){
		for(int j=1;j<=maxy;j++){
			if(a[i][j]==1&&vis[i][j]!=1){
				ans=max(ans,dfs(i,j,maxx,maxy)/4);
			} 
		}
	}
	cout << ans+k;
	return 0;
}

