# include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin >> a >> b;
	int x=0;
	long long q=1;
	long long r=a;
	for(int i=1;i<=b;++i){
		while(a>=10){
			a=a/10;
			x++;
		}
		a*=r;
		q*=r;
	}
	if(x>9) cout << "-1";
	else cout << q;
	return 0;
}

