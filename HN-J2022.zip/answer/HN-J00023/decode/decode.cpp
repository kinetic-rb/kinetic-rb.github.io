#include<bits/stdc++.h>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<fstream>
using namespace std;
int k;
long long n,e,d;
int a[100001],b[100001];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=0;i<k;i++){
		bool flag=1;
		cin>>n>>e>>d;
		int s=n-e*d+2;
		long long l=0,r=n;
		if(s<2*sqrt(n)){
			cout<<"NO"<<endl;
			continue;
		}
		/*while(l<r){
			long long mid=(l+r)/2;
			while(mid%n!=0)mid++;
			if(n%mid==0&&mid+n/mid==s){
				cout<<mid<<" "<<n/mid<<endl;
				flag=0;
				break;
			}
			else if(mid+n/mid<s)l=mid;
			else if(mid+n/mid>s)r=mid;
		}*/
		for(long long j=1;j<sqrt(n);j++){
			if(n%j==0&&j+n/j==s){
				cout<<j<<" "<<n/j<<endl;
				flag=0;
				break;
			}
		}
		if(flag)cout<<"NO"<<endl;
	}
	return 0;
}




