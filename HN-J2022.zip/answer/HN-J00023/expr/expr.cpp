#include<bits/stdc++.h>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<fstream>
using namespace std;
string s;
int siz,khs=0,sum=0,as=0,bs=0;
struct kh{
	int l,r;
}q[1000001];
int qz(string x){
	for(int i=0;i<x.size();i++){
		if(x[i]=='&'){
			int a=x[i-1]-'0',b=x[i+1]-'0';
			char ss='0';
			if(a==0)as++;
			if(a==1&&b==1)ss='1';
			x[i-1]=ss;	
			x.erase(i,2);
		}
	}
	for(int i=0;i<x.size();i++){
		if(x[i]=='|'){
			int a=x[i-1]-'0',b=x[i+1]-'0';
			char ss='0';
			if(a==1)bs++;
			if(a==1||b==1)ss='1';
			x[i-1]=ss;	
			x.erase(i,2);
		}
	}
	int kk=x[0]-'0';
	return kk;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='('){
			q[sum].l=i;
			khs++;
			sum++;
		}
		if(s[i]==')'){
			q[khs].r=i;
			khs--;
		}
	}
	for(int i=sum-1;i>=0;i--){
		int l=q[i].l,r=q[i].r;
		int sizz=l-r-1;
		string a=s.substr(l+1,l+sizz);
		char sd=qz(a)+'0';
		s[l]=sd;
		s.erase(l+1,l+sizz);
		if(s[l+1]==')')s.erase(l+1,1);
		for(int j=0;j<i;j++){
			if(q[j].l>l){
				q[j].r-=sizz;
				q[j].l-=sizz;
			}
		}
	}
	int anss=qz(s);
	cout<<anss<<endl<<as<<" "<<bs;
	return 0;
}

