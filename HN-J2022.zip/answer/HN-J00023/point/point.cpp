#include<iostream>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<fstream>
using namespace std;
int n,k,x,y;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++)cin>>x>>y;
	cout<<n;
	return 0;
}

