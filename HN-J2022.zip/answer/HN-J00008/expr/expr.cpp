#include<bits/stdc++.h>
using namespace std;
char a[1000001];
int c[1000001],b[1000001],t1=0,t2=0;int ans1=0,ans2=0;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int ans;
	cin>>a;
	int len=strlen(a);
	for(int i=0;i<len;++i)
	{
		if(a[i]=='&')c[++t1]=i;
		if(a[i]=='|')b[++t2]=i;
	}
	int fl=0;
	for(int i=fl;i<len;++i)
	{
		for(int j=1;j<=t1;++j)
		{
			if(a[c[j]+1]=='0')
			{
				ans1++;
				int fll=0,x=0;
				while(1)
				{
					fll++;
					fl++;
					if(a[fll]=='(')x++;
					if(a[fll]==')')x--;
					if(x==0)break;
				}
				a[fl]='0';
			}
			else if(a[c[j]-1]=='0')
			{
				int fll=c[j],x=0;
				while(1)
				{
					fll--;
					if(a[fll]==')')x++;
					if(a[fll]=='(')x--;
					if(x==0)break;
				}
				ans1++;
				a[c[j]]='0';
			}
		}
		for(int j=1;j<=t2;++j)
		{
			if(a[b[j]+1]=='1')
			{
				ans2++;
				int fll=0,x=0;
				while(1)
				{
					fll++;
					fl++;
					if(a[fll]=='(')x++;
					if(a[fll]==')')x--;
					if(x==0)break;
				}
				a[fl]='0';
			}
			else if(a[b[j]-1]=='1')
			{
				int fll=b[j],x=0;
				while(1)
				{
					fll--;
					if(a[fll]==')')x++;
					if(a[fll]=='(')x--;
					if(x==0)break;
				}
				ans2++;
				a[c[j]]='0';
			}
		}
	}
	cout<<a[len-1]<<endl;
	cout<<ans1<<" "<<ans2;
	return 0;
}
