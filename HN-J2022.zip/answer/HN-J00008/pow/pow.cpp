#include<bits/stdc++.h>
using namespace std;
long long a,b,ans=1;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%d%d",&a,&b);
	long long i;
	for(i=1;i<=b;++i)
	{
		ans*=a;
		if(ans>1000000000)
		{
			printf("-1");
			return 0;
		}
	}
	printf("%lld",ans);
	return 0;
}
