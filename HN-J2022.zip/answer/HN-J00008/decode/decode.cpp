#include<bits/stdc++.h>
using namespace std;
int k;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int az=1;az<=k;++az)
	{
		long long n,e,d;
		scanf("%lld%lld%lld",&n,&e,&d);
		long long pd=e*d;
		bool a=true;
		for(long long i=n/2;i>=1;--i)
		{
			for(long long j=2;j<=i;++j)
			{
				if(i*j==n)
				{
					long long qs=(i-1)*(j-1)+1;
					if(qs==pd)
					{
						cout<<j<<" "<<i<<endl;
						a=false;
						break;
					}
				}
				if(i*j>n)break;
			}
			if(!a)break;
		}
		if(a)
			printf("NO\n");
	}
	return 0;
}
