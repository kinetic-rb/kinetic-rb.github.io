#include<bits/stdc++.h>
using namespace std;
int n,k,xb,ans=0,zc=-1,f[50001];
struct nuxus{
	int x,y,ls;
}a[50001];
int ffd(int x)
{
	if(a[x].ls==x)return a[x].ls;
	else return ffd(a[x].ls);
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a[i].x,&a[i].y);
		a[i].ls=i;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;++j)
		{
			if(a[i].x==a[j].x && a[i].y==a[j].y+1)
				a[j].ls=i;
			if(a[i].x==a[j].x && a[i].y==a[j].y-1)
				a[i].ls=j;
			if(a[i].y==a[j].y && a[i].x==a[j].x+1)
				a[j].ls=i;
			if(a[i].y==a[j].y && a[i].x==a[j].x-1)
				a[i].ls=j;
		}
	}
	for(int i=1;i<=n;++i)
	{
		int c=0;
		if(a[i].ls==i)
		{
			for(int j=1;j<=n;++j)
			{
				if(ffd(a[j].ls)==i)
					++c;
			}
			if(c>=zc)
			{
				xb=i;
				zc=c;
			}
		}	
	}
	if(k==0)
	{
		cout<<zc;
	}
	cout<<zc+k;
	return 0;
}
