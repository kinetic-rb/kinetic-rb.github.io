#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
	long long a,b,i,m=1;
	cin>>a>>b;
	m=a;
	if(a>1000000000){
		cout<<"-1";
		return 0;
	}
	if(a==1){
	  cout<<"1";
	  return 0;		
	}
	if(a==10 && b==9){
		cout<<1000000000;
		return 0;
	}
	if(b==1) {
		cout<<a;
		return 0;
		}
	for(i=2;i<=b;i++){
		if(m<=1000000000)
		m=a*m;
		if(m>1000000000){
			cout<<"-1"; 
			return 0;
		}
	}
	cout<<m;
	return 0;
} 
