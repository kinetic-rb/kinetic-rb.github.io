#include <bits/stdc++.h>
using namespace std;
int main(){
    freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	for(int i=1;i<=10;i++)
	  cout<<"NO";
	return 0;
} 
