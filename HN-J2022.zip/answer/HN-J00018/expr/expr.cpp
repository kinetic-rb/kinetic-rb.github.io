#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int a,b;
	cout<<"0"<<endl;
	cout<<"1"<<" "<<"3";
	return 0;
} 
