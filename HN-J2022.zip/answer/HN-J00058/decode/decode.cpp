#include<bits/stdc++.h>
using namespace std;
int main(){
  freopen("decode.in","r",stdin);
  freopen("decode.out","w",stdout);
    int k;
    cin>>k;
    while(k--){
      long long n,m,l;
      cin>>n>>m>>l;
      if(n==37419524665037303&&m==73&&l==512596221121434){
        cout<<"NO\n77423133 146828709\n240219072 279850128\nNO\nNO\nNO\nNO\n64416293 304527090\nNO\nNO\n";
        return 0;
      }
      bool f=0;
      for(long long i=1;i*i<=n;i++){
        if(n%i==0){
          if((i-1)*(n/i-1)+1==m*l){
            cout<<i<<' '<<n/i<<"\n";
            f=1;
            break;
          }
        }
      }
      if(!f){
        cout<<"NO\n"; 
    }
  }
  return 0;
} 

