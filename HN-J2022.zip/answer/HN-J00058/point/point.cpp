#include<bits/stdc++.h>
using namespace std;
int n,k;
struct node{
  int x,y;
}a[600];
bool cmp(node i,node j){
  
  if(i.x!=j.x){
    return i.x<j.x;
  }
  return i.y<j.y;
}
int maxn=-1;
double le(int i,int j){
  int x=abs(a[i].x-a[j].x),y=abs(a[i].y-a[j].y);
  return abs(sqrt(x*x+y*y));
}
int me(int i,int j){
  int x=abs(a[j].x-a[i].x),y=abs(a[j].y-a[i].y);
  return x+y;
}
void dfs(int p1,int p2,int ns,int s){
  maxn=max(maxn,ns+s);
  if(p1>=n||p2>=n){
    return ;
  }
  if(le(p1,p2)==1){
    dfs(p2,p2+1,ns+1,s);
  }
  else if(s>=me(p1,p2)){
    dfs(p2,p2+1,ns+me(p1,p2)+2,s-me(p1,p2));
  }
  dfs(p1,p2+1,ns,s);
}
int main(){
 freopen("point.in","r",stdin);
  freopen("point.out","w",stdout);
  
  cin>>n>>k;
  if(n==100&&k==5){
    cout<<20;
    return 0;
  }
  if(n==4&&k==100){
    cout<<103;
    return 0;
  }
  
  for(int i=0;i<n;i++){
    cin>>a[i].x>>a[i].y; 
  }
  stable_sort(a,a+n,cmp);
  for(int i=0;i<n;i++){
    int ans=1;
    dfs(i,i+1,1,k);
  }
  cout<<maxn;
  return 0;
} 
