#include<bits/stdc++.h>
using namespace std;
int a,b,c,d,l=1,n,m,o=0;
int qwe(int n){
	for(int i=o+1;i<=n/2;i++){
		o++;
		if(n%i==0){
			return i;
		}
	}
	return -1;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++){
		l=1;
		o=0;
		cin>>b>>c>>d;
		while(l){
			n=qwe(b);
			m=b/n;
			if(n==-1){
				cout<<"NO"<<endl;
				l=l-1;
			}
			if(c*d==(n-1)*(m-1)+1){
				cout<<n<<' '<<m<<endl;
				l=l-1;
			}
		}
	}
	return 0;
}
