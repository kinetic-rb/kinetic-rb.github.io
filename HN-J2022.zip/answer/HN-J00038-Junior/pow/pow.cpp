#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","r",stdout);
	int a,b;
	cin>>a>>b;
	double c=pow(a,b);
	for(int i=1;i<=9;i++){
		c/=10;
	}
	if(c>1){
		cout<<-1;
	}else if(c=1){
		cout<<10*10*10*10*10*10*10*10*10;
	}else{
		cout<<pow(a,b);
	}
	return 0;
}
