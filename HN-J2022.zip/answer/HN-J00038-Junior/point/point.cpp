#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","r",stdout);
	int n,k,ans=0;
	cin>>n>>k;
	int x[1001],y[1001];
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
	}
	for(int i=1;i<=n;i++){
		if(x[i+1]-x[i]==1&&y[i]==y[i+1]||y[i+1]-y[i]==1&&x[i]==x[i+1]){
			ans+=2;
		}
	}
	cout<<ans+k;
	return 0;
}
