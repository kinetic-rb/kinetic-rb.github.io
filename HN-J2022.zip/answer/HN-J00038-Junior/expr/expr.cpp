#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","r",stdout);
	string s="";
	cin>>s;
	int l=s.length();
	int a=0,b=0,c=0;
	for(int i=0;i<l;i++){
		if(s[i]=='0'&&s[i+1]=='&'){
			a=0;
			b++;
			if(s[i+2]=='1'||s[i+2]=='0'){
				continue;
			}
			if(s[i+2]=='('){
				while(s[i]!=')'){
					i++;
				}
			}
		}else if(s[i]=='1'&&s[i+1]=='|'){
			a=1;
			c++;
			if(s[i+2]=='1'||s[i+2]=='0'){
				continue;
			}
			if(s[i+2]=='('){
				while(s[i]!=')'){
					i++;
				}
			}
		}else if(s[i]=='0'&&s[i+1]=='|'){
			if(s[i+2]=='0'){
				a=0;
			}else{
				a=1;
			}
		}else if(s[i]=='1'&&s[i+1]=='&'){
			if(s[i+2]=='0'){
				a=0;
			}else{
				a=1;
			}
		}
	}
	cout<<a<<endl;
	cout<<b<<" "<<c;
	return 0;
}
