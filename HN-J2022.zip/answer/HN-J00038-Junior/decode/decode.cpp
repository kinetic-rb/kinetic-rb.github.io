#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","r",stdout);
	int k,ni,di,ei,pi,qi;          
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>ni>>di>>ei;
		int a=ni+2-ei*di;
		int b=a*a;
		int c=b-4*ni;
		int d=0;
		for(int i=0;i<c;i++){
			if(i*i==c){
				d=i;
				break;
			}
		}
		int e=a+d;
		if(e%2!=0||d==0){
			cout<<"NO";
		}else{
			qi=e/2;
			pi=ni/qi;
			if(pi<=qi){
				cout<<pi<<" "<<qi<<endl;
			}
		}
	}
	return 0;
}
