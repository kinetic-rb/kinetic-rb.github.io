#include <bits/stdc++.h>
using namespace std;
string s;
int i=-1;
int a1=0,o1=0;
struct OZ{
	int v;
	int a,o;
	OZ(int v,int a,int o):v(v),a(a),o(o){};
};
OZ solve(){
	deque<OZ>num;
	deque<char>ch;
	i++;
	for(;i<s.size();i++){
		if(s[i]=='('){
			num.push_back(solve());
			if(!ch.empty()&&ch.back()=='&'){
				int a=num.back().v;
				int aa=num.back().a,oo=num.back().o;
				num.pop_back();
				int b=num.back().v;
				num.pop_back();
				if(b==0){
					a1-=aa,o1-=oo;
					a1++;
				}
				num.push_back(OZ(a&b,aa+(b==0),oo));
				ch.pop_back();
			}
		} else if(s[i]==')'){
			break;
		} else if(s[i]=='&'||s[i]=='|'){
			ch.push_back(s[i]);
		} else{
			num.push_back(OZ(s[i]-'0',0,0));
			if(!ch.empty()&&ch.back()=='&'){
				int a=num.back().v;
				num.pop_back();
				int b=num.back().v;
				int aa=num.back().a,oo=num.back().o;
				num.pop_back();
				if(b==0){
					a1++;
				}
				num.push_back(OZ(a&b,aa+(b==0),oo));
				ch.pop_back();
			}
		}
	}
	while(!ch.empty()){
		int a=num.front().v;
		num.pop_front();
		int b=num.front().v;
		int aa=num.front().a,oo=num.front().o;
		num.pop_front();
		if(a==1){
			a1-=aa,o1-=oo;
			o1++;
		}
		num.push_back(OZ(a|b,0,(a==0)));
		ch.pop_back();
	}
	return num.front();
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	cout<<solve().v;
	cout<<endl<<a1<<" "<<o1;
	return 0;
}

