#include <bits/stdc++.h>
using namespace std;
int a,b;
unsigned long long Qpow(int a,int x){
	if(x==0) return 1;
	if(x&1){
		unsigned long long tmp=Qpow(a,x-1)*a;
		if(tmp>1e9){
			cout<<-1;
			exit(0);
		}
		return tmp;
	} else{
		unsigned long long tmp=Qpow(a,x/2);
		if(tmp*tmp>1e9){
			cout<<-1;
			exit(0);
		}
		return tmp*tmp;
	}
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b; 
	unsigned long long ans=Qpow(a,b);
	cout<<ans;
	return 0;
} 
