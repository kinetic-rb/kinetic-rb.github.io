#include <bits/stdc++.h>
using namespace std;
namespace io{
	inline long long read(){
		long long x=0;
		bool flag=true;
		char c=getchar();
		while(c<'0'||'9'<c){
			if(c=='-'){
				flag=false;
			}
			c=getchar();
		}
		while('0'<=c&&c<='9'){
			x=(x<<1)+(x<<3)+c-'0';
			c=getchar();
		}
		return (flag?x:~(x-1));
	}
	void print(int x){
		if(x>=10) print(x/10);
		putchar(x%10+'0');
	}
}
using namespace io;
int k;
long long n,e,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	while(k--){
		n=read(),e=read(),d=read();
		long long sum=e*d;
		if(sum>n){
			cout<<"NO\n";
			continue;
		}
		if(n&1){			//Ϊ���� 
			if(sum%2==0){
				cout<<"NO\n";
				continue;
			}
			else{
				bool flag=false;
				for(long long i=1;i<=sqrt(n)+1;i+=2){
					if(n%i==0&&e*d==(i-1)*(n/i-1)+1){
						print(i);
						putchar(' ');
						print(n/i);
						putchar('\n'); 
						flag=true;
						break;
					}
				}
				if(!flag) cout<<"NO\n";
			}
		}
		else{
			bool flag=false;
			for(long long i=2;i<=sqrt(n)+1;i+=2){
				if(n%i==0&&e*d==(i-1)*(n/i-1)+1){
					print(i);
					putchar(' ');
					print(n/i);
					putchar('\n'); 
					flag=true;
					break;
				}
			}
			if(!flag){
				for(long long i=1;i<=sqrt(n)+1;i+=2){
					if(n%i==0&&e*d==(i-1)*(n/i-1)+1){
						print(i);
						putchar(' ');
						print(n/i);
						putchar('\n'); 
						flag=true;
						break;
					}
				}
				if(!flag) cout<<"NO\n";
			}
		}
	}
	return 0;
}
