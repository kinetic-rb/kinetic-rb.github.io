#include <bits/stdc++.h>
using namespace std;
namespace io{
	inline long long read(){
		long long x=0;
		bool flag=true;
		char c=getchar();
		while(c<'0'||'9'<c){
			if(c=='-'){
				flag=false;
			}
			c=getchar();
		}
		while('0'<=c&&c<='9'){
			x=(x<<1)+(x<<3)+c-'0';
			c=getchar();
		}
		return (flag?x:~(x-1));
	}
	void print(int x){
		if(x>=10) print(x/10);
		putchar(x%10+'0');
	}
}
using namespace io;
const int N=210;
int n,k;
int f[N][N][N];		//f[i][j][k] for the best answer when x=i,y=j and other node=k
bool Node[N][N];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	n=read(),k=read();
	memset(f,0xcf,sizeof(f));
	for(int i=1;i<N;i++){
		for(int j=0;j<=k;j++)
			f[0][N][j]=f[N][0][j]=0;
	}
	for(int i=1;i<=n;i++){
		int x=read(),y=read();
		Node[x][y]=true;
		f[x][y][k]=1;
	}
	for(int i=1;i<N;i++){
		for(int j=1;j<N;j++){
			if(Node[i][j])
				for(int l=0;l<=k;l++)
					f[i][j][l]=max(f[i][j][l],max(f[i-1][j][l],f[i][j-1][l])+1);
			else
				for(int l=0;l<k;l++)
					f[i][j][l]=max(f[i][j][l],max(f[i-1][j][l+1],f[i][j-1][l+1])+1);
		}
	}
	int ans=0;
	for(int i=1;i<N;i++){
		for(int j=1;j<N;j++){
			for(int l=0;l<=k;l++){
				ans=max(ans,f[i][j][l]);
			}
		}
	}
	cout<<ans;
	return 0;
}
