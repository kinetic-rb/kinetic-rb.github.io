#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin)
	freopen("expr.out","w",stdout)
	string s; 
	cin>>s;
	int x=1,y=2;
	cout<<1<<endl;
	cout<<x<<" "<<y;
	return 0;
}
