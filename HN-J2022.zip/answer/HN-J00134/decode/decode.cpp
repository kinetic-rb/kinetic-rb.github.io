#include<bits/stdc++.h>
using namespace std;
long long int n[10005],e[10005],d[10005],p,q;
int main()
{
	freopen("decode.in","r",stdin)
	freopen("decode.out","w",stdout)
	int k,x;
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n[i]>>e[i]>>d[i];
		long long zq=e[i]*d[i];
		x=0;
		for(int j=2;j<=sqrt(n[i]);j++){
			if(n[i]%j==0){
				p=j;
				q=n[i]/j;
				if((e[i]*d[i]-2+q+p==n[i]||n[i]-q-p+2==e[i]*d[i])&&p<=q){
					cout<<p<<" "<<q<<endl;
					x=1;
					break; 
				}
			}
		}
		if(x!=1)
			cout<<"NO"<<endl;
	} 
	return 0;
}
