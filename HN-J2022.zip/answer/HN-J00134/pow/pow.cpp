#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin)
	freopen("pow.out","w",stdout)
	long long a,b,sum=1,q=1000000000;
	cin>>a>>b;
	if(a*b>q){
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=b;i++){
		sum=sum*a;
		if(sum>q){
			cout<<-1;
			return 0;
		}
	}
	if(sum>q)
		cout<<-1;
	else
		cout<<sum;
	return 0;
}
