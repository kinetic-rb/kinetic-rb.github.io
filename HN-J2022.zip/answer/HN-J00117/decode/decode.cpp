#include <bits/stdc++.h>
using namespace std;
int k , n[1000005] , e[1000005] , d[1000005] , x[1000005] , y[1000005];
bool sum ;
int main()
{
    freopen("decode.in" , "r" , stdin);
    freopen("decode.out" , "w" , stdout);
    cin >> k ;
    for(int i = 1 ; i <= k ; i++)
    {
        cin >> n[i] >> e[i] >> d[i] ;
    }
    for(int i = 1 ; i <= k ; i ++)
    {
        for(int j = 1; j <= n[i] / 2; j++)
        {
            for(int g = n[i] / 2 ; j * g <= n[i] ; g++)
            {
                if( j * g == n[i] && e[i] * d[i] == (j - 1) * (g - 1) + 1)
                {
                	cout << j << " " << g << endl ;
                    sum = 1 ;
                }
                break;
            }
        }
        if(sum == 0)
        {
            cout << "NO" << endl ;
        }
        sum = 0 ;
    }
    return 0 ;
}
