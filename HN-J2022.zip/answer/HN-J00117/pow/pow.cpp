#include <bits/stdc++.h>
using namespace std;
long long a , m , sum = 1;
int main()
{
    freopen("pow.in" , "r" , stdin);
    freopen("pow.out" , "w" , stdout);
    cin >> a >> m ;
    for(int i = 1 ; i <= m ; i++)
    {
        sum *= a ;
    }
    if(sum <= 1000000000)
    {
        cout << sum ;
    }
    else
    {
        cout << -1 ;
    }
    return 0;
}
