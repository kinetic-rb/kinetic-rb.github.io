#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("point.in" , "r" , stdin);
    freopen("point.out" , "w" , stdout);
    int n , k , x[505] , y[505];
    cin >> n >> k ;
    for(int i = 1; i <= k ; i++)
    {
        cin >> x[i] >> y[i] ;
    }
    return 0 ;
}
