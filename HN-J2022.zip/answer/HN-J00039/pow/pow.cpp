#include<bits/stdc++.h>
#define MAXN 10001;
#define ll long long int
using namespace std; 

ll a,b;
ll num(ll m,ll n)
{
	ll i;
	ll j=m;
	for(i=0;i<n-1;i++)	
	{
		m=m*j;
		if(m>1000000000)
			return -1;
	}
	return m;
	
} 
int main()
{
	freopen("pow.in","r",stdin); 
	freopen("pow.out","w",stdout);
	
	cin>>a>>b;
	ll ans=num(a,b);
	cout<<ans;
	
	
	return 0;
}


 
