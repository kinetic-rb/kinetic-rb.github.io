#include<bits/stdc++.h>
#define ll long long int;
using namespace std; 
long long int x[10001],y[10001],z[10001];
vector <int>g[100101];
int i,num=0,ans=0;
bool ttt[10011];
void link(long long int a,long long int b)
{
	if(a==b) return;
	g[a].push_back(b);
	
}
/*void dfs(long long int a)
{
	ttt[a]=true;
	ans++; 
	dfs(g[b]);
	
}*/
int n,k,j;

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout); 
	cin>>n>>k;
	for(i=0;i<n;i++)
	{
		cin>>x[i]>>y[i];
		z[i]=i;
	
	}
	for(i=0;i<n;i++)
	{
		for(j=1;j<n;j++)
		{
		 	if( (x[i]-x[j]==1)&&(y[i]==y[j]) || (x[i]==x[j])&&(y[i]-y[j]==1) )
			{
			 	link(z[j],z[i]);
			 	num++;
			 	
			 	
			 	
			} 
		
		
		
		} 
		
	}
	for(i=0;i<num;i++)
	{
		ans++;
	}
	cout<<ans;
	
	return 0;
}


 
