#include<bits/stdc++.h>
#define MAXN 10001;
#define ll long long int 
using namespace std; 
int a,i,j;
int n,c,d;
int ans[10001];
int qqq,num1,num2;
void nan(int n)
{
	int t=0;
	for(i=1;i<=n;i++)
	{
		if(n%i==0)
		{
			ans[t]=i;
			t++;
		}
	
	}
	qqq=t;
}
int num(int n,int c,int d)
{
	for(i=0;i<qqq;i++) 
	{
		for(j=qqq;j>i;j--)
		{
			if(ans[i]*ans[j]==n)
			{
				if(c*d==n-ans[i]-ans[j]+2)
				{
				
					num1=ans[i];
					num2=ans[j];
					return 1;
				}
			}
		}	
	}
	return 0;
	
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	cin>>a;
	while(a)
	{
		a--;
		cin>>n>>c>>d;
		nan(n);
		int anns=num(n,c,d);
		if(anns)
		{ 
			cout<<num1<<" "<<num2<<endl;
		}	
		else
		{ 
			cout<<"NO"<<endl;	
		}
		 
	}
	
	
	
	
	
	return 0;
}


 
