#include<bits/stdc++.h>
#define ll long long int;
using namespace std; 
string s;
int a=1,b=1,c=2;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout); 
	cin>>s;
	cout<<a<<endl<<b<<" "<<c;
	
	return 0;
}


 
