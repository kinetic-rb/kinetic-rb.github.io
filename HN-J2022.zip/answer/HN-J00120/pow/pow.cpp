#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	unsigned long long s;
	cin>>a>>b;
	s=1;
	while(b--){
		s*=a;
	}
	if(s>1e9)cout<<-1;
	else cout<<s;
	return 0;
}

