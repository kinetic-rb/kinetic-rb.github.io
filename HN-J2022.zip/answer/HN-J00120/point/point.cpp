#include<bits/stdc++.h>
using namespace std;
const int N=1e9+5;
int n,k,cnt=1,maxi=-1e9;
struct node{
	int x,y;
}a[505];
bool cmp1(node x,node y){
	if(x.x!=y.x)return x.x<y.x;
	return x.y<y.y;
}
bool cmp2(node x,node y){
	if(x.y!=y.y)return x.y<y.y;
	return x.x<y.x;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y;
	}
	sort(a+1,a+1+n,cmp1);
	for(int i=2;i<=n;i++){
		if(a[i].x==a[i-1].x&&a[i-1].y+1==a[i].y){
			cnt++;
		}
		else{
			maxi=max(maxi,cnt);
			cnt=1;
		}
	}
	sort(a+1,a+1+n,cmp2);
	for(int i=2;i<=n;i++){
		if(a[i].y==a[i-1].y&&a[i-1].x+1==a[i].x){
			cnt++;
		}
		else{
			maxi=max(maxi,cnt);
			cnt=1;
		}
	}
	cout<<maxi;
	return 0;
}

