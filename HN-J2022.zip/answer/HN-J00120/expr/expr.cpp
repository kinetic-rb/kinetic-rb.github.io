#include<bits/stdc++.h>
using namespace std;
stack<char> s,q;
char c; 
int d1,d2;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	while(cin>>c)q.push(c);
	while(true){
		if(s.size()==1&&q.empty()==true){
			cout<<s.top()<<endl<<d1<<" "<<d2;
			return 0;
		}
		if(q.empty()==true){
			while(s.empty()==false){
				q.push(s.top()),s.pop();
			}
			s.push(q.top()),q.pop();
		}
		if(q.top()=='&'&&s.top()=='0'){
			d1++;
			q.pop();
			if(q.top()!='(')q.pop();
			else{
				while(q.top()!='(')q.pop();
				q.pop();
			}
		} 
		if(q.top()=='|'&&s.top()=='1'){
			d2++;
			q.pop();
			if(q.top()!='(')q.pop();
			else{
				while(q.top()!=')')q.pop();
				q.pop();
			}
		}
		else{
			q.pop();
		}
	}
	return 0;
}

