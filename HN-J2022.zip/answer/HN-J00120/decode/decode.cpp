#include<bits/stdc++.h>
using namespace std;
unsigned long long cnt=1,k,n,e,d;
bool flag;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>e>>d;
		cnt=n-e*d+2;
		if(cnt<=0){
			cout<<"NO"<<endl;
			continue;
		}	
		flag=true;	 
		for(unsigned long long i=1,j=cnt-i;i<=cnt/2;i++,j--){
			if(i*j==n){
				cout<<i<<" "<<j<<endl;
				flag=false;
				break; 
			}
		}
		if(flag==true)cout<<"NO"<<endl;
	}
	return 0;
}

