#include<bits/stdc++.h>
using namespace std;
long long n,e,d,p,q,t,num;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n>>e>>d;
		num=n+2-e*d;
		p=0;
		q=num;
		for(int i=1;i<=num;i++){
			p++;
			q--;
			if(p*q==n){
				break;
			}
			if(p>q){
				break;
			}
		}
		if(p>q){
			cout<<"NO"<<endl;
		}
		else{
			cout<<p<<" "<<q<<endl;
		}
	}
	return 0;
}

