#include<bits/stdc++.h>
using namespace std;
int main()
{
	int RLGD;
	cin>>RLGD;
	cout<<RLGD;
}
