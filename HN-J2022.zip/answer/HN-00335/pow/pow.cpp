#include <bits/stdc++.h>
using namespace std;
unsigned long long a , b;
int main ()
{
	freopen ("pow.in" , "r" , stdin);
	freopen ("pow.out" , "w" , stdout);
	cin >> a >> b;
	if (a > 10 && b > 9)
	{
		cout << -1;
		return 0;
	}
	if ( (long long) (pow (a , b)) >  (long long) (pow (10 , 9))) cout << -1;
	else cout << (long long) (pow (a , b));
	return 0;
}
