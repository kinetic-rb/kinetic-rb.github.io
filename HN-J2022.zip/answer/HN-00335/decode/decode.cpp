#include <bits/stdc++.h>
using namespace std;
inline long long read ()
{
	long long s = 0 , f = 1;
	char c = getchar ();
	while (c < '0' || c > '9')
	{
		if (c == '-') f = -1;
		c = getchar ();
	}
	while (c >= '0' && c <= '9')
	{
		s = (s << 1) + (s << 3) + (c ^ 48);
		c = getchar ();
	}
	return s * f;
}
long long p , q , he , ji , l , r , ans;
inline int check (long long mid)
{
	if (mid * (he - mid) < ji) return 1; 
	else if (mid * (he - mid) == ji) return 2;
	return 0; 
}
int main ()
{
	freopen ("decode.in" , "r" , stdin);
	freopen ("decode.out" , "w" , stdout);
	long long k = read () , n , e , d;
	for (int ii = 1; ii <= k; ii++)
	{
		n = read () , e = read () , d = read ();
		/*
		    n - e * d + 2 = p + q
		    n = p * q;
		    n + 2 = e * d + p + q; 
		    
		    he = n - e * d + 2;
			ji = n;
			
			he * p - p * p = ji;
			q = he - he * p + p * p;
			q = ji / (he * p - p * p);
		    
		    633 1 211
		    633 - 1 * 211 + 2 = p + q
		    633 = p * q;
		*/
		he = n - e * d + 2;
		ji = n;
		l = 1 , r = he;
		while (l <= r)
		{
			long long mid = (l + r) >> 1;
			int opt = check (mid);
			if (opt == 1)
			{
				l = mid + 1;
				ans = mid;
			}
			else if (opt == 2) 
			{
				ans = mid;
				break;
			}
			else r = mid - 1;
			if (l > he) break;
		}
		if (ans * (he - ans) != n || (ans) + (he - ans) != he) puts ("NO");
		else 
		{
			cout << min (ans , he - ans) << " " << max (ans , he - ans) << "\n";
		}
	}
	return 0;
}/*

10
770 77 5
633 1 211
545 1 499
683 3 227
858 3 257
723 37 13
572 26 11
867 17 17
829 3 263
528 4 109

*/
