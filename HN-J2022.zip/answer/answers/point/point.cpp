#include<bits/stdc++.h>
using namespace std;
const int maxn=2147483647;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	if(n==8) cout<<"8";
	if(n==4) cout<<"103";
	return 0;	
} 
