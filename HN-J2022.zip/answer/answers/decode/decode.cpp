#include<bits/stdc++.h>
using namespace std;
int k;
long long n[100005]; 
int e[100005],d[100005],p[100005],q[100005];
int sum=0;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);	
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>n[i]>>d[i]>>e[i];
		for(int j=k;j>=1;j--)
		{
			if(n[i]%j==0)
			{
				int ans=j;
				int ans2=n[i]/j;
				if(ans+ans2+d[i]*e[i]==n[i]+2&&sum==0)
				{
					cout << ans<<" "<<ans2<<endl;
					sum++;
					continue;
				}
			}
		}
		if(sum==0)
		cout<<"NO"<<endl;
		sum=0;
	}
	return 0;
} 
