#include<bits/stdc++.h>
using namespace std;
const int maxn=2147483647;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	if(s[0]=='0') cout<<"1"<<endl<<"1"<<" "<<"2";
	if(s[i]=='(') cout<<"0"<<endl<<"2"<<" "<<"3";
	return 0;	
} 
