#include<bits/stdc++.h>
using namespace std;
const int maxn=2147483647;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long ans=1;
	int b;
	int a;
	scanf("%d%d",&a,&b);
	for(int i=1;i<=b;i++)
	{
		ans*=a;
		if(ans>maxn)
		{
			cout<<-1;
			return 0;
		}	
	}
	cout<<ans;
	return 0;	
} 
