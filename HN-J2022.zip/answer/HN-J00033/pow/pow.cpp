//God by me
//i think i will get a low mark
#include<bits/stdc++.h>
using namespace std;
long long qmi(long long a,long long b){//fast pow
	if(b==1) return a;
	long long ans=1;
	if(b&1){
		ans*=a;
	}
	ans*=qmi(a,b>>1)*qmi(a,b>>1);
	return ans;
}
long long a,b;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(b==1){
		cout<<a;
		return 0;
	}
	if(qmi(a,b)>1e9) puts("-1");//more than 1e9
	else cout<<qmi(a,b)<<endl;
	return 0;
}
//I love CCF
