//if i don't get 1=,i will AFO :(
#include<bits/stdc++.h>
#define INF 0x3f3f3f
using namespace std;
struct P{
	int X,Y;
}x[1005];
long long n,k;
int ans=-INF;
bool cmp(P A,P B){
	if(A.X==B.X) return A.Y<B.Y;
	return A.X<B.X;
}
int dx[4]={1,0,0,-1};
int dy[4]={0,1,-1,0};
bool init(P xx){//is xx in x?
	for(int i=0;i<n;i++){
		if(xx.X==x[i].X&&xx.Y==x[i].Y){
			return true;
		}
	}
	return false;
}
int dfs(P a,int ktemp,int CHY){// a:now note,ktemp:how many note can use,CHY:the ans
	if(!init(a)){
		if(ktemp==0){
			return CHY;//can not forward
		}
		else{
			ktemp--;
		}
	}
	CHY++;
	for(int i=0;i<4;i++){
		int xx=a.X+dx[i];//x
		int yy=a.Y+dy[i];//y
		P temp;//new note
		temp.X=xx;
		temp.Y=yy;
		return dfs(temp,ktemp,CHY);//seach
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>x[i].X>>x[i].Y;
	}
	sort(x,x+n,cmp);//sort this 
	for(int i=0;i<n;i++){
		ans=max(ans,dfs(x[i],k,0));//get the maxxer
	}
	cout<<ans;//print maxxer
	return 0;
} 
//I love CCF
