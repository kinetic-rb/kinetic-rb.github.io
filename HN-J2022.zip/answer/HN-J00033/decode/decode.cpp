#include<bits/stdc++.h>
using namespace std;
const long long N=1e6+5;
struct K{
	long long x,y;
};
long long k;
K p[N];
long long t=0;
bool is_prime(long long n){//is it prime?
	if(n<2) return false;
	for(long long i=2;i*i<=n;i++){
		if(n%i==0){
			return false;//nope
		}
	}
	return true;//yes
}
void ILoveCcf(long long n){//i love ccf!
	for(long long i=2;i*i<=n;i++){
		if(n%i==0){
			p[t].x=i,p[t++].y=n/i;//get the num
		}
	}
	if(n>1){
		p[t].x=1,p[t++].y=n;//if n>1,n is prime! 
	}
}
void ILoveCCF(long long ED){//i love ccf
	for(long long i=0;i<t;i++){
		if((p[i].x-1)*(p[i].y-1)==ED-1){
			cout<<p[i].x<<" "<<p[i].y<<"\n";//p_i<=q_i
			return ;
		}
	}
	cout<<"NO"<<'\n';
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		long long n,d,e,ed;
		cin>>n>>d>>e;//input n,d,e
		ed=e*d;
		if(ed==1){
			cout<<1<<" "<<n<<'\n';
		}
		if(is_prime(n)){
			if(e*d!=1){
				cout<<"NO"<<'\n';
				continue;
			}
		}
		ILoveCcf(n);
		ILoveCCF(ed);
	}
	return 0;
} 
//I love CCF
