#include<bits/stdc++.h>
using namespace std;
string x;
stack<char> stk;//stack?
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>x;
	for(int i=x.size()-1;i>=0;i--){
		stk.push(x[i]);
	}
	int ans=stk.top(),a,b;//a:& b:|
	stk.pop();
	while(!stk.empty()){//all right, i do not think about ( and )
		if(stk.top()=='|'){//i do not know what is this doing!
			if(ans=='1'){
				b++;
				ans=1;
				stk.pop();
				stk.pop();//why need two pop?
			}else{
				stk.pop();
				ans=((stk.top()=='1')?(1):(0));
				stk.pop();
			}
		}else if(stk.top()=='&'){//i do not know what is this doing!
			if(ans=='0'){
				a++;
				ans=0;
				stk.pop();
				stk.pop();
			}else{
				stk.pop();
				ans=((stk.top()=='1')?(1):(0));
				stk.pop();
			}
		}else{
			stk.pop();//need this?
		}
	}
	cout<<ans<<'\n';
	cout<<a<<' '<<b<<'\n';
	return 0;//finish
} 
//I love CCF
