#include<iostream>
#include<cstdio>
using namespace std;

long long pow(long long a,long long b)
{
	if(b==1)
	return a;
	long long c=pow(a,b/2);
	if(c>1000000000||c==-1)
	return -1;
	if(b%2==1)
	return c*c*a;
	return c*c;
}

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	cout<<pow(a,b)<<endl;
	return 0;
}
