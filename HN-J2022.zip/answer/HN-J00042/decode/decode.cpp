#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n,m,j,q,p,k,e,d,x,y;
	bool b;
	scanf("%lld",&k);
	for(int i=1;i<=k;i++)
	{
		scanf("%lld%lld%lld",&n,&e,&d);
		m=n-e*d+2;
		x=m>>1;
		y=sqrt(n);
		b=false;
		if(x>y)x=y;
		if(m-1<=n)
		{
			for(int t=x;t>=1;t--)
			{
				q=t;
				p=m-t;
				j=q*p;
				if(j==n)
				{
					printf("%lld %lld\n",q,p);
					b=true;
					break;
				}
				if(j<n)break;
			}
		}
		if(b==false)
		printf("NO\n");
	}
	return 0;
}
