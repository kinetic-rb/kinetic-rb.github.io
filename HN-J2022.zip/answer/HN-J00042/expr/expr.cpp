#include<iostream>
#include<cstdio>
using namespace std;
int a,h,l;
string s;

bool expr(int w,int r)
{
	if(w==l)
	return s[w]-48;
	int j=w+2,b;
	if(s[j]=='(')
	{
		j=l;
		for(int i=w+3;i<=r;i++)
		{
			if(s[i]==')')
			{
				j=i;
				break;
			}
		}
	}
	if(s[w+1]=='&')
	{
		if(s[w]=='0')
		{
			b=0;
			a++;
			if(j==l)
			return b;
			s[j]='0';
			return expr(j,r);
		}
		else b=1;
		if(s[w+2]=='(')
		b=b&expr(w+3,j-1);
		s[j]=b+48;
		b=expr(j,l);
	}
	if(s[w+1]=='|')
	{
		for(int i=j;i<=l;i++)
		if(s[i]=='|')
		{
			if(j<i)
			j=i;
		}
		if(s[w]=='1')
		{
			b=1;
			h++;
			if(j==l)
			return b;
			s[j]='1';
			return expr(j,r);
		}
		else b=0;
		b=b|expr(w+2,j);
		s[j]=b+48;
		b=expr(j,l);
	}
	if(s[w]=='(')
	{
		j=l;
		for(int i=w+1;i<=r;i++)
		{
			if(s[i]==')')
			{
				j=i;
				break;
			}
		}
		b=expr(w+1,j-1);
		s[j]=b;
		b=expr(j,l);
	}
}

int main()
{
	getline(cin,s);
	l=s.size();
	bool b=expr(0,l-1);
	printf("%d\n%d %d",b,a,h);
	return 0;
}
