#include <bits/stdc++.h>

using namespace std;

const int N = 1e6 + 110;
int n, top, topp, ans1, ans2, idx;
char p[N];
int t[N], so[N], st[N], id[N], fr[N];
char ch[N];

int main ()
{
	
	freopen ("expr.in", "r", stdin);
	freopen ("expr.out", "w", stdout);
	cin >> ch + 1;
	n = strlen (ch + 1);
	ch[0] = '(', ch[n + 1] = ')'; 
	//0|0|0|1
	memset (fr, 0x3f, sizeof fr);
	for (int i = 0; i <= n + 1; i ++)
    {
    	if (ch[i] == ')')
    	{
    		++ idx;
    		fr[i] = min (fr[i], idx);
    		while (p[top] != '(') 
    		{
    			fr[id[top]] = min (fr[id[top]], idx);
    			top --;
			}
			fr[id[top]] = min (fr[id[top]], idx);
			top --;
		}
		else p[++ top] = ch[i], id[top] = i;
	}
	top = 0;
	for (int i = 0; i <= n + 1; i ++)
    {
    	if (ch[i] == ')')
    	{
    		int x, s1 = 0, s2 = 0;
    		while (p[top] != '(')
    		{
    			x = p[top --] - '0';
    			if (p[top] == '|')
    			{
    				top --;
    				if (x == 1)
    				{
    					ans2 ++;
    					s2 ++;
					}
					t[++ topp] = x;
				}
    			else if (p[top] == '&') 
    			{
    				int y = p[-- top] - '0';
    				if (x == 0)
    				{
    					ans1 ++;
    					s1 ++;
					}
    				p[top] = (x & y) + '0';
				}
			}
			if (x == 1 && p[top + 2] == '|')
			{
				ans2 ++;
				s2 ++;
			}
			if (x == 0 && p[top + 2] == '&')
			{
				ans1 ++;
				s1 ++;
			}
			so[fr[id[top] - 1]] = s1;
			st[fr[id[top] - 1]] = s2;
			ans1 -= so[fr[i]];
			ans2 -= st[fr[i]];
			int s = x;
			for (int j = 1; j <= topp; j ++) s |= t[j];
			topp = 0;
			p[top] = s + '0';
		}
		else p[++ top] = ch[i], id[top] = i;
	}
	printf ("%d\n", p[1] - '0');
	printf ("%d %d\n", ans1, ans2);
	return 0;
	
}
