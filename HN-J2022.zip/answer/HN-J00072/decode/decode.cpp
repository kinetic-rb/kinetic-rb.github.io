#include <bits/stdc++.h>

using namespace std;

int k;
long long n, e, d;

int main ()
{
	
	freopen ("decode.in", "r", stdin);
	freopen ("decode.out", "w", stdout);
	scanf ("%d", &k);
	while (k --)
	{
		scanf ("%lld %lld %lld", &n, &e, &d);
		if (n / e < d)
		{
			puts ("NO");
			continue;
		}
		long long m = n - e * d + 2, ans = LONG_LONG_MAX - 1; //p + q = m, p * q = n
		long long l = 1, r = sqrt (n);
		while (l <= r)
		{
			long long mid = l + r >> 1;
			if (mid + n / mid >= m) l = mid + 1, ans = mid;
			else r = mid - 1;
		}
		if (n % ans == 0 && ans + n / ans == m) printf ("%lld %lld\n", ans, n / ans);
		else puts ("NO");
	}
	return 0;
	
}

