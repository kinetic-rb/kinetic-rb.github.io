#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 110;
int n, k, tot, ans, maxn;
int fa[N], x[N], y[N];

int main ()
{
	
	freopen ("point.in", "r", stdin);
	freopen ("point.out", "w", stdout);
	scanf ("%d %d", &n, &k);
	for (int i = 1; i <= n; i ++) scanf ("%d %d", &x[i], &y[i]);
	printf ("%d\n", n + k - 1);
	return 0;
	
}
