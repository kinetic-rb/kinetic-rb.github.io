#include <bits/stdc++.h>

using namespace std;

int n, m;

int solve ()
{
	
	int t = n, ans = 1;
	for (; m; m /= 2)
	{
		if (m % 2 == 1) 
		{
			if (t > 1000000000 / ans) return -1;
			ans *= t;
		}
		if (m > 1 && t > 1000000000 / t) return -1;
		t = t * t;
	}
	return ans;
	
}

int main ()
{
	
	freopen ("pow.in", "r", stdin);
	freopen ("pow.out", "w", stdout);
	scanf ("%d %d", &n, &m);
	printf ("%d\n", solve ());
	return 0;
	
}
