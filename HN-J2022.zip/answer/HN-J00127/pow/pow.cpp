#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long n1,n2;
	long long n3,n4=1;
	cin>>n1>>n2;
	n3=1000000000;
	for(int i=0;i<n2;n4*=n1,i++);
	if(n4>n3)cout<<-1;
	else cout<<n4;
	return 0;
}
