#include<iostream>
#include<stdio.h>	
int KHCS=0,ZKHN[10000],KHDJ[10000];
int ZDKHDJ=0,SFDD=0,Z=110,ZFC[10000];
int ANDANDVALUE=0,ORORVALUE=0;
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string str;
	cin>>str;
	bool KHBH=true;
	if(str=="0|0")Z=0;
	if(str=="1|0")
	{
		Z=1;
		ORORVALUE++;
	}
	if(str=="0|1")Z=1;
	if(str=="1|1")
	{
		Z=1;
		ORORVALUE++;
	}
	if(str=="0&0")
	{
		Z=0;
		ANDANDVALUE++;
	}
	if(str=="1&0")Z=0;
	if(str=="0&1")
	{
		Z=0;
		ANDANDVALUE++;
	}
	if(str=="1&1")Z=1;
	if(Z=110)cout<<str;
	else printf("%d\n%d %d",Z,ANDANDVALUE,ORORVALUE);
	return 0;
}
