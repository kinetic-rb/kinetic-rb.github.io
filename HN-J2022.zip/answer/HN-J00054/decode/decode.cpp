#include <bits/stdc++.h>

using namespace std;

const int N = 1e4 + 5;

int k;
long long n, d, e;

int main(){
  freopen("decode.in", "r", stdin);
  freopen("decode.out", "w", stdout);
  cin >> k;
  while (k--){
    cin >> n >> d >> e;
    if (d * e > n){
      cout << "NO\n";
      continue;
    }
    long long c = n - d * e + 2;
    bool flag = 0;
    for (int i = 2; i <= c / 2; i++){
      long long x = i, y = c - i;
      if (x * y == n && (x - 1) * (y - 1) + 1 == d * e){
        flag = 1;
        cout << x << " " << y << '\n';
        break;
      } else if (x * y > n || (x - 1) * (y - 1) + 1 > d * e){
        break;
      }
    }
    if (!flag){
      cout << "NO\n";
    }
  }
  return 0;
}
