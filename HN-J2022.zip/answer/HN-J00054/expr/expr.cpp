#include <bits/stdc++.h>

using namespace std;

int n;
string s;

int main(){
  freopen("expr.in", "r", stdin);
  freopen("expr.out", "w", stdout);
  cin >> s;
  n = s.size();
  if (n == 3){
    if (s[0] == '0' && s[1] == '&'){
      cout << "0\n" << "1 0";
    } else if (s[0] == '1' && s[1] == '|'){
      cout << "0\n" << "0 1";
    } else {
      cout << "1\n" << "0 0";
    }
  }
  return 0;
}
