#include <bits/stdc++.h>

using namespace std;

const int INF = 1e9;

int a, b;
long long x = 1;

int main(){
  freopen("pow.in", "r", stdin);
  freopen("pow.out", "w", stdout);
  cin >> a >> b;
  for (int i = 1; i <= b; i++){
    x *= a;
    if (x > INF){
      cout << "-1";
      return 0;
    }
  }
  cout << x;
  return 0;
}
