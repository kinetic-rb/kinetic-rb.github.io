#include <bits/stdc++.h>

using namespace std;

const int N = 505;

struct Node{
  int x, y;
} a[N];

int n, k, ans, l[N], p[N][N];

bool cmp(const Node &i, const Node &j){
  if (i.x != j.x){
    return i.x < j.x;
  }
  return i.y < j.y;
}

int main(){
  freopen("point.in", "r", stdin);
  freopen("point.out", "w", stdout);
  cin >> n >> k;
  for (int i = 1; i <= n; i++){
    cin >> a[i].x >> a[i].y;
  }
  sort(a + 1, a + n + 1, cmp);
  if (!k){
    for (int i = 1; i <= n; i++){
      for (int j = 0; j < i; j++){
        if (!j || ((a[i].x - a[j].x == 1 && a[j].y == a[i].y || a[i].y - a[j].y == 1 && a[j].x == a[i].x) && l[j] + 1 >= l[i])){
          l[i] = l[j] + 1;
        }
      }
      ans = max(ans, l[i]);
    }
    cout << ans;
  } else {
    cout << n + k;
  }
  return 0;
}
