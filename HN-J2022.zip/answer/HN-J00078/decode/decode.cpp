#pragma comment(linker, "\stack:200000000")
#include<bits/stdc++.h>
using namespace std;

unsigned long long int k, n, e, d;
map<unsigned long long int, pair<unsigned long long int, unsigned long long int> > ma;

inline unsigned long long int read(){
	register unsigned long long int x=0, f=1;
	register char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

inline void putout(unsigned long long int x){
	if(x<0) x=-x, putchar('-');
	if(x>9) putout(x/10), x%=10;
	putchar(x+'0');
}

int main(){
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	k=read();
	while(k--){
		n=read(), d=read();
		e=read();
		bool fll=0;
		int cnt=0;
		for(int i=2;i*i<=n;i++){
			cnt++;
			if(cnt==10000000) break;
			if(n%i==0){fll=1;break;}
		}
		cnt=0;
		if(!fll){putchar('N'), putchar('O'), putchar('\n');continue;} 
		unsigned long long int x=n-e*d+2;
		bool f=0;
		if(ma[n].first){
			putout(ma[n].first);
			putchar(' ');
			putout(ma[n].second);
			putchar('\n');
			continue;
		}
		for(unsigned long long int i=1;i<=x/2;i++){
			unsigned long long int ano=x-i;
			cnt++;
			if(cnt==10000000) break;
			if(ano*i==n){
				ma[n]=make_pair(i, ano);
				f=1;
				putout(i);
				putchar(' ');
				putout(n/i);
				putchar('\n');
				break;
			}
		}
		if(!f) putchar('N'), putchar('O'), putchar('\n'); 
	}
	return 0;
}
