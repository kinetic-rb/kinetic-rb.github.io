#include<bits/stdc++.h>
using namespace std;

map<char, int> ma;
string s;
int huo, he;

inline int read(){
	register int x=0, f=1;
	register char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

inline void putout(int x){
	if(x<0) x=-x, putchar('-');
	if(x>9) putout(x/10), x%=10;
	putchar(x+'0');
}

int main(){
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	ma['&']=0;
	ma['|']=1;
	cin>>s;
	int len=s.size();
	int x=0;
	for(int i=0;i<len;i++){
		if(isdigit(s[i])) x=s[i]-'0';
		else{
			char ch=s[i];
			if(ch=='(' || ch==')') continue;
			if(ma[ch]==x){
				if(x) huo++;
				else he++;
			}
			x=0;
		}
	}
	putout(he);
	putchar(' ');
	putout(huo);
	return 0;
}
