#include<bits/stdc++.h>
using namespace std;

unsigned long long base, power;
unsigned long long c[30];
unsigned long long len=1;
bool f;

inline unsigned long long read(){
	register unsigned long long x=0, f=1;
	register char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

inline void putout(unsigned long long x){
	if(x<0) x=-x, putchar('-');
	if(x>9) putout(x/10), x%=10;
	putchar(x+'0');
}

unsigned long long cheng(unsigned long long base){
	unsigned long long tex=0;
	for(unsigned long long i=1;i<=len;i++){
		c[i]=c[i]*base+tex;
		tex=c[i]/10;
		c[i]%=10;
	}
	while(tex){
		c[++len]=tex%10;
		tex/=10;
	}
	if(len>10){f=1;return 114514;}
	len=10;
}

int main(){
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	base=read();
	power=read();
	c[1]=1;
	while(power--){
		cheng(base);
		if(f){putout(-1);return 0;}
	}
	if(len>10){putout(-1);return 0;}
	else if(len==10){
		if(c[len]>1){putout(-1);return 0;}
		for(unsigned long long i=len-1;i>0;i--) if(c[i]>0){putout(-1);return 0;}
	}
	for(unsigned long long i=len;i>=1;i--) putout(c[i]);
	return 0;
}
