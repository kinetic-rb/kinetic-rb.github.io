#include<bits/stdc++.h>
using namespace std;

int n, k;
struct node{
	int x;
	int y;
}a[505];
int dp[505];
int maxi;
int maxii;

inline int read(){
	register int x=0, f=1;
	register char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

inline void putout(int x){
	if(x<0) x=-x, putchar('-');
	if(x>9) putout(x/10), x%=10;
	putchar(x+'0');
}

bool cmp(node x, node y){
	if(x.x!=y.x) return x.x<y.x;
	else x.y<y.y;
}

int main(){
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	n=read(), k=read();
	for(int i=1;i<=n;i++) a[i].x=read(), a[i].y=read();
	sort(a+1, a+1+n, cmp);
	for(int i=1;i<=n;i++){
		if(a[i].x==a[i-1].x) dp[i]=dp[i-1]+1;
		else if(a[i].y==a[i-1].y) dp[i]=dp[i-1]+1;
		else dp[i]=1;
	}
	for(int i=1;i<=n;i++) maxi=max(maxi, dp[i]);
	memset(dp, 0, sizeof(dp));
	for(int i=1;i<=n;i++){
		if(a[i].x==a[i-1].x) dp[i]=dp[i-1]+1;
		if(a[i].y==a[i-1].y) dp[i]=dp[i-1]+1;
		else dp[i]=1;
	}
	for(int i=1;i<=n;i++) maxii=max(maxii, dp[i]);
	putout(maxi-maxii-1);
	return 0;
}
