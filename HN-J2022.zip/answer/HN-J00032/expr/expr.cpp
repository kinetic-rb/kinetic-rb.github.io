#include<bits/stdc++.h> 
using namespace std;
char a[1000005];
int s1,s2;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	for(int i=0;i<strlen(a);i++)
	{
		if(a[i]=='|') s2++;
		if(a[i]=='&') s1++; 
	}
	cout<<"1"<<endl<<s1<<" "<<s2;
	return 0;
}
