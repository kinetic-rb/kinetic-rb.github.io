#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,s=1;
	cin>>a>>b; 
	while(b!=0)
	{
		if(b%2==1) s*=a;
		a=a*a;
		b=b/2;
		if(s>1e9)
		{
			cout<<-1;
			return 0;
		}
	}
	cout<<s;
	return 0;
}
