#include<bits/stdc++.h> 
using namespace std;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,m,x,y;
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>x>>y;
	cout<<n+m;
	return 0;
}
