#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long n,e,d,p,q,k;
	bool f=0;
	cin>>k;
    for(int i=1;i<=k;i++)
    {
    	f=0;
	    cin>>n>>e>>d;
	    int s=n-e*d+2;
	    p=0;
	    while(p<=s/2)
	    {
	    	p++; 
		    q=s-p;
		    if(q*p==n)
		    {
			    cout<<p<<" "<<q<<endl;
			    f=1;
		    }
	    }
	    if(f==0)
	    cout<<"NO"<<endl; 
    }
	return 0;
}

