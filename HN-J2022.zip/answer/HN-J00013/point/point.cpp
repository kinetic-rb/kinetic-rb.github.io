#include <bits/stdc++.h>
using namespace std;

long long n, k;

struct qq
    {long long l, r;}
    e[100100];

bool cmp (qq a, qq b)
    {return a. l + a. r < b. l + b. r;}

signed main () {
    scanf ("%lld %lld", &n, &k);

    for (long long i = 1; i <= n; ++ i)
        scanf ("%lld %lld", &e[i]. l, &e[i]. r);
    
    sort (e + 1, e + n + 1, cmp);
    
    cout << endl;
    for (long long i = 1; i <= n; ++ i)
    	cout << e[i]. l << " " << e[i]. r << endl;
    
    long long ans = 0, ma = 0;
    for (long long i = 2; i <= n; ++ i) {
        if ((e[i]. l - e[i - 1]. l) + (e[i]. r - e[i - 1]. r) == 1 && e[i]. l >= e[i - 1]. l && e[i]. r >= e[i - 1]. r)
            ans ++,
            ma = max (ma, ans);
        
        else ans = 0;
    }    
	
    cout << ma;

    return 0;
}