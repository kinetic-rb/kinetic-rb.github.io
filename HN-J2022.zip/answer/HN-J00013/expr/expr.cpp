#include <bits/stdc++.h>
using  namespace std;

long long a, b;
string str;

long long cl (long long l, long long r) {
    if (l == r)
        return str[l] - '0';
    
    long long num = -1, kkk = 0, lkb = -1, rkb = -1;
    for (long long i = l; i <= r; ++ i) {
        if (str[i] >= '0' && str[i] <= '1')
            num = str[i] - '0';
        
        if (str[i] == '&') {
            long long bj = i;
            
            kkk = 0;
            lkb = -1;

            i += 1;

            if (str[i] == '(') {
                kkk ++, lkb = (lkb == -1) ? i : lkb;

                while (kkk != 0) {
                    i ++;

                    if (str[i] == '(')
                        kkk ++, lkb = (lkb == -1) ? i : lkb;
                    
                    if (str[i] == ')')
                        kkk --, rkb = i;
                }
            }

            if (str[bj] == '&') {
                if (num == 0)
                    b ++;
                
                else {
                    if (lkb != -1) {
                        num &= cl (lkb + 1, rkb - 1);
                    }
                    
                    else {num &= str[i] - '0';}
                }
            }
        }
    }

    kkk = 0, lkb = -1, rkb = -1;

    for (long long i = l; i <= r; ++ i) {
        if (str[i] >= '0' && str[i] <= '1')
            num = str[i] - '0';
        
        if (str[i] == '|') {
            long long bj = i;
            
            kkk = 0;
            lkb = -1;

            i += 1;

            if (str[i] == '(') {
                kkk ++, lkb = (lkb == -1) ? i : lkb;

                while (kkk != 0) {
                    i ++;

                    if (str[i] == '(')
                        kkk ++, lkb = (lkb == -1) ? i : lkb;
                    
                    if (str[i] == ')')
                        kkk --, rkb = i;
                }
            }

            if (str[bj] == '|') {
                if (num == 1) {
                    a ++,
                    num = 1;
                }
                
                else {
                    if (lkb != -1) {
                        num |= cl (lkb, rkb);
                    }
                    
                    else {num |=  str[i] - '0';}
                }
            }
        }
    }
    
    return num;
}

signed main () {
    freopen ("expr.in", "r", stdin);
    freopen ("expr.out", "w", stdout);

    cin >> str;
    
    cout << cl (0, str. length ()) << "\n";

    cout << a << " " << b;
    
    return 0;
}