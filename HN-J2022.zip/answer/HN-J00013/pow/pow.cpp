#include <bits/stdc++.h>
using namespace std;

long long a, b, flag;

long long ksm (long long x, long long y) {
    long long number = 0, number1 = 0, number2 = 1;
    
    if (y == 1)
        return x;

    number += ksm (x, y / 2);
    number1 += ksm (x, y / 2);
    
    if (y % 2 == 1)
        number2 = x;
    
    if (number * number1 * number2 > 1e9) {
        printf ("-1");
        exit (0);
    }

    return number * number1 * number2;
}

signed main () {
    freopen ("pow.in", "r", stdin);
    freopen ("pow.out", "w", stdout);

    scanf ("%lld %lld", &a, &b);
    
    printf ("%lld", ksm (a, b));

    return 0;
}