#include <bits/stdc++.h>
using namespace std;

long long k;

signed main () {
    freopen ("decode.in", "r", stdin);
    freopen ("decode.out", "w", stdout);

    scanf ("%lld", &k);
    while (k --) {
        long long n, d, e;
        scanf ("%lld %lld %lld", &n, &e, &d);

        long long number = n - e * d + 2, p;
        
        bool flag = 0;
        for (p = 1; p <= n / 2; ++ p) {
            if (number - p == n / p && number - p >= p) {
                printf ("%lld %lld\n", p, number - p);
                flag = 1;
                break;
            }
        }
        
        if (flag == 0)
            printf ("NO\n");
    }
    return 0;
}