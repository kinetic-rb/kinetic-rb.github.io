#include<bits/stdc++.h>
using namespace std;
const long long t=INT_MAX;
long long a,b,s,c;
int main(){
  freopen("pow.in","r",stdin);
  freopen("pow.out","w",stdout);
  cin>>a>>b;
  if(a==1){
    cout<<1;
    return 0;
  } 
  s=1;
  c=0;
  while(s<=t){
    s*=a;
    c++;
  }
  if(b>=c){
    cout<<-1;
    return 0;
  }
  s=1;
  for(int i=1;i<=b;i++){
    s*=a;
  }
  cout<<s;
  return 0;
}
