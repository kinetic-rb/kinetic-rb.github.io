#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,s,t;
bool f;
int main(){
  freopen("decode.in","r",stdin);
  freopen("decode.out","w",stdout);
  cin>>k;
  for(int i=1;i<=k;i++){
    cin>>n>>e>>d;
    s=e*d-1;
    t=n-s;
    t++;
    f=0;
    for(long long j=1;j<=t/2;j++){
      if(j*(t-j)==n&&(j-1)*(t-j-1)+1==e*d){
        cout<<j<<" "<<(t-j)<<"\n";
        f=1;
        break;
      }
    }
    if(f==0){
      cout<<"NO\n";
    }
  }
  return 0;
}
