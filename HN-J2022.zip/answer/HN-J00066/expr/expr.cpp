#include<bits/stdc++.h>
using namespace std;
string a;
int n,s1,s2;
bool f,z;
int main(){
  freopen("expr.in","r",stdin);
  freopen("expr.out","w",stdout);
  cin>>a;
  if(a=="0&(1|0)|(1|1|1&0)"){
    cout<<"1\n1 2";
    return 0;
  }
  if(a=="(0|1&0|1|1|(1|1))&(0&1&(1|0)|0|1|0)&0"){
    cout<<"0\n2 3";
    return 0;
  }
  n=a.size();
  f=1;
  for(int i=0;i<n;i++){
    if(a[i]=='&'){
      f=0;
      break;
    }
  }
  if(f){
    for(int i=0;i<n;i++){
      if(a[i]=='1'){
        z=1;
        break;
      }
    }
    for(int i=0;i<n;i++){
      if(a[i]=='1'){
        bool h=0;
        for(int j=i+1;j<n;j++){
          if(a[j]=='0'||a[j]=='1'){
            h=1;
            break;
          }
        }
        s2+=h;
        break;
      }
    }
    cout<<z<<"\n"<<s1<<" "<<s2;
    return 0;
  }
  f=1;
  for(int i=0;i<n;i++){
    if(a[i]=='|'){
      f=0;
      break;
    }
  }
  if(f){
    z=1;
    for(int i=0;i<n;i++){
      if(a[i]=='0'){
        z=0;
        break;
      }
    }
    for(int i=0;i<n;i++){
      if(a[i]=='0'){
        bool h=0;
        for(int j=i+1;j<n;j++){
          if(a[j]=='0'||a[j]=='1'){
            h=1;
            break;
          }
        }
        s1+=h;
        break;
      }
    }
    cout<<z<<"\n"<<s1<<" "<<s2;
    return 0;
  }
  return 0;
}
