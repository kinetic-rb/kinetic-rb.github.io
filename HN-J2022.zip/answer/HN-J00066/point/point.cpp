#include<bits/stdc++.h>
using namespace std;
struct no{
  int x,y;
}a[505];
int n,k,dp[505],ma;
bool cmp(no a,no b){
  if(a.x==b.x){
    return a.y<b.y;
  }
  return a.x<b.x;
}
int main(){
  freopen("point.in","r",stdin);
  freopen("point.out","w",stdout);
  cin>>n>>k;
  for(int i=1;i<=n;i++){
    cin>>a[i].x>>a[i].y;
  }
  sort(a+1,a+n+1,cmp);
  for(int i=1;i<=n;i++){
    dp[i]=1;
    for(int j=1;j<i;j++){
      if(a[j].x<=a[i].x&&a[j].y<=a[i].y&&(a[i].x-a[j].x+a[i].y-a[j].y)==1){
        dp[i]=max(dp[i],dp[j]+1);
      }
    }
    ma=max(ma,dp[i]);
  }
  cout<<ma;
  return 0;
}
