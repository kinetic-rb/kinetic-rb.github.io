#include<bits/stdc++.h>
using namespace std;
int dp[505][105], n, k, ans;
struct A{
	int x, y;
}a[505];
bool cmp(A x, A y){
	if(x.x + x.y == y.x + y.y)return x.x < y.x;
	return x.x + x.y < y.x + y.y;
}
int ojld(int p, int q){
	return abs(a[p].x - a[q].x) + abs(a[p].y - a[q].y);
}
int main(){
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	cin >> n >> k;
	for(int i = 1; i <= n; i++){
		cin >> a[i].x >> a[i].y;
	}
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1; i <= n; i++){
		dp[i][0] = 1;
	}
	for(int i = 2; i <= n; i++){
		for(int j = 0; j <= k; j++){
			for(int o = 1; o < i; o++){
				if(a[i].x >= a[o].x && a[i].y >= a[o].y && ojld(i, o) - 1 <= j){
					dp[i][j] = max(dp[i][j], dp[o][j - ojld(i, o) + 1] + ojld(i, o));
				}
				if(j > 0)dp[i][j] = max(dp[i][j], dp[i][j - 1] + 1);
			}
		}
	}
	for(int i = 1; i <= n; i++){
		ans = max(ans, dp[i][k]);
	}
	cout << ans;
	return 0;
}
