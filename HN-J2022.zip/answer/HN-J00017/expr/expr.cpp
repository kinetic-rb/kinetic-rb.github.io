#include<bits/stdc++.h>
using namespace std; 
const int maxs = 1e6 + 5;
string a;
int ans = 2, p, q;
bool fy, fh, fkh, yp, hp; 
int main(){
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	cin.tie(0), cout.tie(0);
	cin >> a;
	for(int i = 0; i < a.size(); i++){
		if(a[i] == '|'){
			fh = 1;
		}
		if(a[i] == '&'){
			fy = 1;
		}
		if(a[i] == '('){
			fkh = 1;
		}
	}
	if(fh == 0){
		for(int i = 0; i < a.size(); i++){
			if(a[i] == '0' && i != a.size()){
				cout << 0 << endl << 1 << " " << 0;
				return 0;
			}else if(a[i] == '0' && i == a.size()){
				cout << 0 << endl << 0 << " " << 0;
			}
		}
		cout << 1 << endl << 0 << " " << 0;
		return 0;
	}
	if(fy == 0){
		for(int i = 0; i < a.size(); i++){
			if(a[i] == '1' && i != a.size()){
				cout << 1 << endl << 0 << " " << 1;
				return 0;
			}else if(a[i] == '1' && i == a.size()){
				cout << 1 << endl << 0 << " " << 0;
			}
		}
		cout << 0 << endl << 0 << " " << 0;
		return 0;
	}
	if(fkh == 0){
		for(int i = 0; i < a.size(); i++){
			if(a[i] == '&'){
				if(a[i - 1] == '0'){
					p++;
				}else if(a[i - 1] == '1' && a[i + 1] == '1'){
					yp = 1;
				}
			}else if(a[i] == '1'){
				if(a[i - 1] == '|' && a[i + 1] == '|' || i == a.size()){
					hp = 1;
				}
			}
		}
		if(yp || hp){
			cout << 1 << endl << p << " " << 1;
		}else{
			cout << 0 << endl << 0 << " " << 0;
		}
		return 0;
	}
	cout << "1\n1 2";
	return 0;
}
