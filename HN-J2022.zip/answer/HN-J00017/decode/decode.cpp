#include<bits/stdc++.h>
using namespace std; 
long long k, n, d, e, x/*n - ed + 2 = p + q*/, y/*n = pq*/, l;
int main(){
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	cin.tie(0), cout.tie(0);
	cin >> k;
	while(k--){
		cin >> n >> d >> e;
		x = n - e * d + 2, y = x;
		x = x * x - 4 * n;
		l = sqrt(x);
		if(l * l == x && (y - l) / 2 > 0 && (l + y) / 2 > 0){
			cout << (y - l) / 2 << " " << (l + y) / 2 << endl;
		}else{
			cout << "NO\n";
		}
	}
	return 0;
}
 
