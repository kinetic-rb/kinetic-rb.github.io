#include<bits/stdc++.h>
using namespace std; 
long long a, b, ans, c = 1, d;
int main(){
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	cin >> a >> b;
	d = b;
	if(a == 1){
		cout << 1;
		return 0;
	}
	while(c <= 1000000000){
		c *= a;
		b--;
	}
	if(b >= 0){
		cout << -1;
	}else{
		c = 1;
		for(int i = 1; i <= d; i++){
			c *= a;
		}
		cout << c;
	}
	return 0;
}
