#include<bits/stdc++.h>

using namespace std;
struct Node{
	long long x,y;
}w[505];
long long n,k;
long long ans,f[505];

void bfs(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if((w[j].x==w[i].x && w[j].y+1==w[i].y) || (w[j].x+1==w[i].x && w[j].y==w[i].y)){
				f[i]=max(f[i],f[j]+1);
			}
		}	
	} 
	return ;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>w[i].x>>w[i].y;
	}

	for(int i=1;i<=n;i++){
		f[i]=1;
	}
	for(int i=1;i<=n;i++){
		bfs();
	}
	
	long long ans=0;
	for(int i=1;i<=n;i++){
		ans=max(ans,f[i]);
	}
	cout<<ans+k;
	return 0;
}

