#include<bits/stdc++.h>

using namespace std;
string s;
char ch;
int ans,ans1,ans2;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int lens=s.length();
	for(int i=0;i<lens;i++){
		if(s[i]=='&'){
			ans1++;
		}else if(s[i]=='|'){
			ans2++;
		}
	}
	cout<<1<<endl<<ans1<<" "<<ans2;
	return 0;
}
