#include<bits/stdc++.h>

using namespace std;
long long k,n,e,d;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>d>>e;
		long long w=n-d*e+2;
		long long l=1,r=sqrt(n);
		bool f=0;
		for(long long i=l;i<=r;i++){
			if(n%i==0 && n/i+i==w){
				printf("%lld %lld\n",i,n/i);
				f=1;
				break;
			}
		}
		if(f==0){
			printf("NO\n");
		}
	}
	return 0;
}
/*
10
770 77 5
633 1 211
545 1 499
683 3 227
858 3 257
723 37 13
572 26 11
867 17 17
829 3 263
528 4 109
*/
