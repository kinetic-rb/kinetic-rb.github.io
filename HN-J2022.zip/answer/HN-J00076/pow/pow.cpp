#include<bits/stdc++.h>

using namespace std;
long long a,b; 
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(pow(a,b)>INT_MAX){
		cout<<-1;
		return 0;
	}
	cout<<(long long)pow(a,b);
	return 0;
}
