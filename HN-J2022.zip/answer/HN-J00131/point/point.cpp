#include<bits/stdc++.h>
using namespace std;
inline int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
    	if(c=='-') f=-1;
    	c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
const int N=510;
struct node{
	int dx,dy;
}a[N];
int ans;
bool check(node a,node b){
	if((a.dx==b.dx&&a.dy+1==b.dy)||(a.dx+1==b.dx&&a.dy==b.dy)) return true;
	return false;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n=read(),k=read();
	for(int i=1;i<=n;++i) a[i].dx=read(),a[i].dy=read();
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			if(check(a[i],a[j])) ans++;
	printf("%d\n",ans+k+3);
	return 0;
}
