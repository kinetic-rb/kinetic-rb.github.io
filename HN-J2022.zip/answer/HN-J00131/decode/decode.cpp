#include<bits/stdc++.h>
using namespace std;
inline long long read(){
    long long x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
    	if(c=='-') f=-1;
    	c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int T=read();
	while(T--){
		long long n=read(),e=read(),d=read();
		long long m=n+2-(e*d);
		bool flag=false;
		if(n==e&&n==d&&n==1){
			printf("1 1\n");
			continue;
		}
		if(n<=1e9){
			for(long long i=2;i<=sqrt(n);++i){
			    if(n%i==0){
				long long yz=n/i;
				    if(yz+i==m){
					  printf("%lld %lld\n",i,yz);	
					  flag=1;
					  break;
				    }     
			    }
		    }
		}
		else{
			if(m/2*m/2==n){
				printf("%lld %lld\n",m/2,m/2);
				continue;
			}
			for(long long i=2;i<=1000;++i){
			if(n%i==0){
				long long yz=n/i;
				if(yz+i==m){
					printf("%lld %lld\n",i,yz);	
					flag=1;
					break;
				}  
			}
		    }
		}
		if(flag==false) printf("NO\n");
	}
	return 0;
}
