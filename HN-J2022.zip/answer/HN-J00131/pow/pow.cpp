#include<bits/stdc++.h>
using namespace std;
inline int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
    	if(c=='-') f=-1;
    	c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
int mypow(int a,int b){
	long long ans=1;
	for(int i=1;i<=b;i++){
		ans*=a;
		if(ans>1e9) return -1;
	}
    return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a=read(),b=read();
	if(a==1) printf("1");
	else if(b>=35) printf("-1");
	else printf("%d",mypow(a,b));
	return 0;
}
