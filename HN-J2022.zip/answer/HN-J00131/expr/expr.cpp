#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	printf("1\n");
	int f=0,fp=0;
	for(int i=0;i<s.length();++i){
		if(s[i]=='|') f++;
		else if(s[i]=='&') fp++;
	}
	printf("%d %d",f/2,fp/2);
	return 0;
}
