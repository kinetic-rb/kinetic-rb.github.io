#include <bits/stdc++.h>
using namespace std;
string s;
bool ll[1000005];
int sum, a[1000005], first1, first2, num, minsum = 1e9;
int dg( int i )
{
    if( s[i] == '|' && s[i - 1] != ')' && s[i + 1] != '(' ) return ( ( bool( s[i - 1] - '0' ) ) | ( bool( s[i + 1] - '0' ) ) );
    if( s[i] == '&' && s[i - 1] != ')' && s[i + 1] != '(' ) return ( ( bool( s[i - 1] - '0' ) ) & ( bool( s[i + 1] - '0' ) ) );
    int l = 0, r = 0;
    for( int j = i + 1; j < s.size(); j ++ )
    {
        if( ll[j] ) r = j;
    }
    for( int j = i - 1; j >= 1; j -- )
    {
        if( ll[j] ) l = j;
    }
    int ansl;
    if( l != 0 ) ansl = dg( l );
    if( s[i] == '|' && ansl == 1 )
    {
        first2 ++;
        return 1;
    }
    if( l == 0 ) return s[i - 1] - '0';
    if( s[i] == '&' && ansl == 0 )
    {
        first1 ++;
        return 0;
    }
    int ansr;
    if( r != 0 ) ansr = dg( r );
    if( r == 0 ) return s[i + 1] - '0';
    if( s[i] == '&' ) return ansl & ansr;
    else return ansl | ansr;
}
int main()
{
    freopen( "expr.in", "r", stdin );
    freopen( "expr.out", "w", stdout );
    cin >> s;
    if( s.size() == 1 )
    {
        cout << s[0] - '0';
        return 0;
    }
    for( int i = 0; i < s.size(); i ++ )
    {
        if( s[i] == '|' || s[i] == '&' ) ll[i] = 1;
        if( s[i] == '&' ) a[i] ++;
        if( s[i] == '(' ) sum ++;
        if( s[i] == ')' ) sum --;
        if( s[i] == '&' || s[i] == '|' ) a[i] += sum;
    }
    for( int i = 0; i < s.size(); i ++ )
    {
        if( s[i] == '&' || s[i] == '|' )
        {
            if( minsum >= a[i] ) num = i;
            minsum = min( minsum, a[i] );
        }
    }
    int ans = dg( num );
    cout << ans << endl << first1 << " " << first2;
}
