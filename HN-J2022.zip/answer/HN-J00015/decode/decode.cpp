#include <bits/stdc++.h>
using namespace std;
#define int unsigned long long
int k, p, q, n, e, d;
bool b;
signed main()
{
    freopen( "decode.in", "r", stdin );
    freopen( "decode.out", "r", stdout );
    cin >> k;
    while( k -- )
    {
        scanf( "%u%u%u", &n, &e, &d );
        b = 0;
        int mm = e * d;
        for( int x = 2; x <= n; x ++ )
        {
            int xx = ( n - 1 ) / ( x - 1 );
            if( ( xx - 1 ) * ( x - 1 ) + 1 == mm && x * xx == n )
            {
                printf( "%u %u\n", min( xx, x ), max( xx, x ) );
                b = 1;
                break;
            }
        }
        if( b ) continue;
        cout << "No" <<"\n";
    }
    return 0;
}
