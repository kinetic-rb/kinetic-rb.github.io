#include <bits/stdc++.h>
using namespace std;
#define int unsigned long long
int a, b;
signed main()
{
    freopen( "pow.in", "r", stdin );
    freopen( "pow.out", "w", stdout );
    cin >> a >> b;
    int sum = 1;
    if( a == 1 )
    {
        cout << 1;
        return 0;
    }
    if( a == 0 )
    {
        cout << 0;
        return 0;
    }
    for( int i = 1; i <= b; i ++ )
    {
        sum = sum * a;
        if( sum > 1e9 )
        {
            cout << -1;
            return 0;
        }
    }
    cout << sum;
    return 0;
}
