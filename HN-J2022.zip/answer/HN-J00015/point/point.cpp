#include <bits/stdc++.h>
using namespace std;
#define int long long
int n, k, ans;
struct node
{
    int x, y;
}type[505];
bool cmp( node a, node b )
{
    if( a.x < b.x ) return true;
    if( a.x > b.x ) return false;
    if( a.x == b.x )
    {
        if( a.y < b.y ) return 1;
        return 0;
    }
    return true;
}
void dfs( int step, int nowk, node pre, int sum )
{
    ans = max( ans, sum );
    if( sum + n - step + k - nowk <= ans ) return ;
    if( nowk > k ) return ;
    if( step > n || k == nowk )
    {
        ans = max( ans, sum );
        return ;
    }
    if( step <= n ) dfs( step + 1, nowk, pre, sum );
    if( ( type[step].x - pre.x == 0 && type[step].y - pre.y == 1 ) || sum == 0 || ( type[step].x - pre.x == 1 && type[step].y - pre.y == 0 ) )
    {
        if( step <= n ) dfs( step + 1, nowk, type[step], sum + 1 );
        return ;
    }

    dfs( step, nowk + 1, {pre.x + 1, pre.y}, sum + 1 );
    dfs( step , nowk + 1, {pre.x, pre.y + 1}, sum + 1 );
}
signed main()
{
    freopen( "point.in", "r", stdin );
    freopen( "point.out", "w", stdout );
    cin >> n >> k;
    for( int i = 1; i <= n; i ++ )
    {
        cin >> type[i].x >> type[i].y;
    }
    sort( type + 1, type+ n + 1, cmp );
    dfs( 1, 0, {0, 0}, 0 );
    cout << ans;
}
