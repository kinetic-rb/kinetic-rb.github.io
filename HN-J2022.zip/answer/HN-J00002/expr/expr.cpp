#include <bits/stdc++.h>

using namespace std;

int a=0,b=0,index1,index2;
char s[1000000],counter[10]="&|() ";

void f_and(int a,int b,int j);
void f_or(int a,int b,int j);
void f_kuohao(int pos);
void f_main(int pos,int poe);

void f_and(int a,int b,int j){
	if(a==0){
		s[j]='1';
	}else if(a==1&&b==0){
		return 0;
	}else{
		return 1;
	}
	return;
}

void f_or(int a,int b){
	if(a==1){
		b++;
		return 1;
	}else if(a==0&&b==1){
		return 1;
	}else{
		return 0;
	}
}

void f_kuohao(int pos){
	for(int i=pos+1;i<=strlen(s);i++){
		if((s[i]+0)==(counter[2]+0)){
			f_kuohao(i);
		}else if((s[i]+0)==(counter[3]+0)){
			int poe=i;
			f_main(pos+1,poe-1);
			}
		return;
	}
}

void f_main(int pos,int poe){
	for(int i=pos;i<=poe;i++){
		if((s[i]+0)==(counter[0]+0)){
			for(int j=i-1;;j--){
				if((s[j]+0)!=(counter[4]+0)){
					a=(int)s[j];
					index1=j;
				}
			}
			for(int j=i+1;;j++){
				if((s[j]+0)!=(counter[4]+0)){
					b=(int)s[j];
					index2=j;
				}
			}
			s[index1]=f_and(a,b);
			s[i]=counter[4];
			s[index2]=counter[4];
		}
	}
	for(int i=pos;i<=poe;i++){
		if((s[i]+0)==(counter[1]+0)){
			for(int j=i-1;;j--){
				if((s[j]+0)!=(counter[4]+0)){
					a=(int)s[j];
					index1=j;
				}
			}
			for(int j=i+1;;j++){
				if((s[j]+0)!=(counter[4]+0)){
					b=(int)s[j];
					index2=j;
				}
			}
			s[index1]=f_or(a,b,j);
			s[i]=counter[4];
			s[index2]=counter[4];
		}
	}
	return;
}

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);

	cin>>s;
	for(int i=0;i<=strlen(s);i++){
		if(s[i]+0==counter[2]+0){
			f_kuohao(i);
		}
	}
	f_main(0,strlen(s));
	
	for(int i=0;;i++){
		if((s[i]+0)!=(counter[4]+0)){
			cout<<s[i]<<endl;
			cout<<a<<' '<<b;
			return 0;
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
};

