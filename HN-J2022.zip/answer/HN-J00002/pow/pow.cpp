#include <bits/stdc++.h>

using namespace std;

int under,up,sum=1;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	cin>>under>>up;

	if(!(under>=1&&under<=1000000000)){
		cout<<-1<<endl;
		
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	
	for(int i=1;i<=up;i++){
		sum*=under;
		if(sum>=1&&sum<=1000000000){
			continue;
		}
		cout<<-1<<endl;
		
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	cout<<sum<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}

