#include <bits/stdc++.h>

using namespace std;

int k;
int n[10000000],e[10000000],d[10000000],p[10000000],q[10000000];

void f(int index){
	for(int i=1;i*i<=n[index];i++){
		if(n[index]%i==0){
			p[index]=i;
			q[index]=n[index]/i;
		}
		if((p[index]-1)*(q[index]-1)+1==e[index]*d[index]){
			cout<<p[index]<<' '<<q[index]<<endl;
			return;
		}
	}
	cout<<"NO"<<endl;
	return;
}

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n[i]>>e[i]>>d[i];
	}
	for(int i=1;i<=k;i++){
		f(i);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}

