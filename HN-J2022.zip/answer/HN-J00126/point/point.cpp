#include<bits/stdc++.h>
using namespace std;
int x[1111000],y[1111000];
int main()
{
  freopen("point,in","r",stdin);	
  freopen("point,out","w",stdout);
  int n,k;
  cin>>n>>k;
  for(int i=1;i<=n;i++)
  {
  	for(int j=1;j<=k;j++)
    {
    	cin>>x[i]>>y[i];
	}
  }
  cout<<"127";
  return 0;	
} 
