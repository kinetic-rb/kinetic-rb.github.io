#include<bits/stdc++.h>
using namespace std;
int n[1000000],p[1000000],q[1000000],d[10000000],e[1000000];
int main()
{
  freopen("decode,in","r",stdin);	
  freopen("decode,out","w",stdout);
  int k;
  cin>>k;
  for(int i=1;i<=k;i++)
  {
  	cin>>n[i]>>e[i]>>d[i]; 
  }
  for(int i=1;i<=k;i++)
  {
  	if(n[i]=p[i]*q[i]&&e[i]*d[i]==(p[i]-1)*(q[i]-1)+1)
  	{
  		cout<<p[i]<<" "<<q[i]<<endl;	
	}
  	else cout<<"NO"<<endl;
  }
  return 0;	 
} 
 
