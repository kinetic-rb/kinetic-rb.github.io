#include<bits/stdc++.h>
using namespace std;
int main()
{
  freopen("pow,in","r",stdin);	
  freopen("pow,out","w",stdout);
  int a,b,x=0;
  long long s=0;
  cin>>a>>b;
  x=a;
  for(int i=1;i<=b-1;i++)
  {
  	s=x*a;
	a=a*10;
  	if(s>1000000000||s<-1)
    {
  	  cout<<"-1";
      return 0;
    }
  }
  cout<<s;
  return 0;	
} 
