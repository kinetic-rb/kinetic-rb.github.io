#include<bits/stdc++.h>
using namespace std;
char s[1111000];
int main()
{
  freopen("expr,in","r",stdin);	
  freopen("expr,out","w",stdout);
  cin>>s;
  cout<<"1"<<endl;
  cout<<"4"<<" "<<"5";
  return 0;	
} 
