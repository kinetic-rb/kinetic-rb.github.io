// pow.cpp
#include<bits/stdc++.h>
using namespace std;
long long a, b, ans = 1;
const long long N = 1000000000;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
    cin >> a >> b;
    for(int i = 0; i < b; i++)
    {
        ans *= a;
        if(ans > N)
        {
            ans = 0-1;
            break;
        }
    }
    cout << ans << endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
