// decode.cpp
#include<bits/stdc++.h>
using namespace std;
long long k, n, e, d, p, q;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
    cin >> k;
    for(int i = 1; i <= k; i++)
    {
        cin >> n >> d >> e;
        long long de = d * e - 2;
        p = sqrt(n);
        q = p;
        if(n - p - q != de)
            cout << "NO" << endl;
        else
        	cout << p << " " << q << endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
