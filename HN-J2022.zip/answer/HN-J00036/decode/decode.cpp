#include<bits/stdc++.h>
using namespace std;
int m()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
}
long long n[100000],e[100000],d[100000];
int main()
{
	m();
	bool s=false;
	long long k; 
	cin>>k;
	for(int i=1;i<=k;i++)
		cin>>n[i]>>e[i]>>d[i];
	for(long long i=1;i<=k;i++)
	{
		for(long long j=1;j<=n[i];j++)
		{
			for(long long m=1;m<=j;m++)
			{
				if(j*m==n[i]&&e[i]*d[i]==(j-1)*(m-1)+1)
				{
					cout<<m<<" "<<j<<endl;
					s=true;
				}
			}
		}
		if(s==false) cout<<"NO"<<endl;
		s=false;
	}	
	return 0;
} 
