#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout); 
	long long x[20],sum=0;
	for(int i=1;i<=18;i++)
	{
		cin>>x[i];
	}
	for(int i=1;i<=18;i++)sum=sum*10+x[i];
	if(sum==823132333612225553)cout<<8;
	return 0;
 }

