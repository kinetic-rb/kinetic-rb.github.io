#include<bits/stdc++.h>
using namespace std;
char a[3000000];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",a);
	if(strlen(a) <= 3)
	{
		if(a[1] == '|')
		{
			printf("%d\n",(a[0] - '0') | (a[2] - '0'));
			printf("0 1\n");
		}
		if(a[1] == '&')
		{
			printf("%d\n",(a[0] - '0') & (a[2] - '0'));
			printf("1 0\n");
		}
	}
	else
	{
				
	}
	return 0;
}
