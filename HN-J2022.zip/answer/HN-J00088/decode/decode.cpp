#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k,n,e,d;
	scanf("%lld",&k);
	for(int i = 1;i <= k;i++)
	{
		scanf("%lld%lld%lld",&n,&e,&d);
		long long p_add_q = -(e*d-2)+n;
		//printf("%lld\n",p_add_q);
		long long p = 0,q = 0;
		int flag = 0;
		for(int i = 1;i < sqrt(n);i++)
		{
			q = p_add_q - i;
			p = i;
			if(p*q == n && e*d == (p-1)*(q-1)+1)
			{
				printf("%lld %lld\n",p,q);
				flag = 1;
				break;
			}
		}
		if(flag == 0)
		{
			printf("NO\n");
		}
	}
	return 0;
}
