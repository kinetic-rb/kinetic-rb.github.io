#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	long long ret = 0;
	for(int i = 1;i <= m;i++)
	{
		ret += n;
		if(ret > 1000000000 || n*m >= 1000000000)
		{
			printf("-1");
			return 0;
		}
	}
	printf("%lld\n",ret);
	return 0;
}
