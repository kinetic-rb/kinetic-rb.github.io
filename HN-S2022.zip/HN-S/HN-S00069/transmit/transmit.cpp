#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int n,q,K,fa[202020],dep[202020],V[201010],h[202020],nxt[404040],var[404040],cnt,P[202][202],G[202][202],Q[202][202];
int f[202020][22],g[202020][22];
void add(int x,int y){
	nxt[++cnt]=h[x],h[x]=cnt,var[cnt]=y;
}
void dfs(int x,int de){
	dep[x]=de;g[x][0]=V[fa[x]];
	for(int i=1;i<=18;i++)f[x][i]=f[f[x][i-1]][i-1],g[x][i]=g[x][i-1]+g[f[x][i-1]][i-1];
	for(int i=h[x];i;i=nxt[i]){
		int v=var[i];if(v==fa[x])continue;
		f[v][0]=x;fa[v]=x;dfs(v,de+1);
	}
}
main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),q=read(),K=read();
	for(int i=1;i<=n;i++)V[i]=read();
	for(int i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y),add(y,x);
		if(n<=200)P[x][y]=1,P[y][x]=1,G[y][x]=1,G[x][y]=1;
	}dfs(1,1);
	if(n<=200){
		for(int i=1;i<=n;i++)P[i][i]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(i!=j&&!G[i][j])G[i][j]=1e18;
				Q[i][j]=1e18;
			}
		}
		for(int k=1;k<=n;k++){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++)G[i][j]=min(G[i][j],G[i][k]+G[k][j]);
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(G[i][j]<=K)P[i][j]=1;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)if(P[i][j]&&i!=j)Q[i][j]=V[i]+V[j];
		}
		for(int i=1;i<=n;i++)Q[i][i]=V[i];
		for(int k=1;k<=n;k++){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					if(k!=i&&k!=j)Q[i][j]=min(Q[i][j],Q[i][k]+Q[k][j]-V[k]);
				}
			}
		}
	}
	while(q--){
		int x=read(),y=read();
		if(K==1){
			int ans=V[x]+V[y];
			if(dep[x]<dep[y])swap(x,y);
			for(int i=18;i>=0;i--){
				if(dep[f[x][i]]>dep[y])ans+=g[x][i],x=f[x][i];
			}
			for(int i=18;i>=0;i--){
				if(f[x][i]!=f[y][i])ans+=g[x][i]+g[y][i],x=f[x][i],y=f[y][i];
			}
			printf("%lld\n",ans-V[x]);
		}
		else if(n<=200){
			printf("%lld\n",Q[x][y]);
		}
	}
}
