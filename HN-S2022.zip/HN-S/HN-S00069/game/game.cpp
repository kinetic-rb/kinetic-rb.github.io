#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int n,m,q,L1,L2,R1,R2;
int a[101010],b[101010],ST[2][3][101010][18];
//(1)[]:0.a 1.b
//(2)[]:0.+ 1.0 2.-
int st[2][2][101010][18];
//(1)[]:0.a 1.b
//(2)[]:0:+ 1.-
int qmax(int x,int y,int l,int r){
	int G=log2(r-l+1);
	return max(ST[x][y][l][G],ST[x][y][r-(int)pow(2,G)+1][G]);
}
int qmin(int x,int y,int l,int r){
	int G=log2(r-l+1);
	return min(st[x][y][l][G],st[x][y][r-(int)pow(2,G)+1][G]);
}
main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int j=1;j<=m;j++)b[j]=read();
	for(int i=1;i<=n;i++){
		if(a[i]>0)ST[0][0][i][0]=a[i],ST[0][2][i][0]=-1,st[0][0][i][0]=a[i],st[0][1][i][0]=2e9,ST[0][1][i][0]=0;
		if(a[i]<0)ST[0][2][i][0]=-a[i],ST[0][0][i][0]=-1,st[0][1][i][0]=-a[i],st[0][0][i][0]=2e9,ST[0][1][i][0]=0;
		if(a[i]==0)ST[0][1][i][0]=1,ST[0][0][i][0]=-1,ST[0][2][i][0]=-1,st[0][1][i][0]=st[0][0][i][0]=2e9;
	}
	for(int i=1;i<=m;i++){
		if(b[i]>0)ST[1][0][i][0]=b[i],ST[1][2][i][0]=-1,st[1][0][i][0]=b[i],st[1][1][i][0]=2e9,ST[1][1][i][0]=0;
		if(b[i]<0)ST[1][2][i][0]=-b[i],ST[1][0][i][0]=-1,st[1][1][i][0]=-b[i],st[1][0][i][0]=2e9,ST[1][1][i][0]=0;
		if(b[i]==0)ST[1][1][i][0]=1,ST[1][0][i][0]=-1,ST[1][2][i][0]=-1,st[1][1][i][0]=st[1][0][i][0]=2e9;
	}
	for(int i=1;i<18;i++){
		for(int j=1;j+pow(2,i)-1<=n;j++){
			for(int k=0;k<3;k++)ST[0][k][j][i]=max(ST[0][k][j][i-1],ST[0][k][j+(int)(pow(2,i-1))][i-1]);
			for(int k=0;k<2;k++)st[0][k][j][i]=min(st[0][k][j][i-1],st[0][k][j+(int)(pow(2,i-1))][i-1]);
		}
		for(int j=1;j+pow(2,i)-1<=m;j++){
			for(int k=0;k<3;k++)ST[1][k][j][i]=max(ST[1][k][j][i-1],ST[1][k][j+(int)(pow(2,i-1))][i-1]);
			for(int k=0;k<2;k++)st[1][k][j][i]=min(st[1][k][j][i-1],st[1][k][j+(int)(pow(2,i-1))][i-1]);
		}
	}
//	cout<<qmin(1,0,2,2)<<endl;
	while(q--){
		L1=read(),R1=read(),L2=read(),R2=read();
		int Aplu=qmax(1,0,L2,R2),zer=qmax(1,1,L2,R2),Aneg=qmax(1,2,L2,R2),Bplu=qmin(1,0,L2,R2),Bneg=qmin(1,1,L2,R2);
		int Aplu1=qmax(0,0,L1,R1),zer1=qmax(0,1,L1,R1),Aneg1=qmax(0,2,L1,R1),Bplu1=qmin(0,0,L1,R1),Bneg1=qmin(0,1,L1,R1);
//		cout<<Aplu<<" "<<Bplu<<"   "<<Aneg<<" "<<Bneg<<"   "<<zer<<endl;
//		cout<<Aplu1<<" "<<Bplu1<<"   "<<Aneg1<<" "<<Bneg1<<"   "<<zer1<<endl;
		long long maxn=-1e18;
		if(zer1==1)maxn=0;
		if(Aplu>0&&Aneg>0){
			if(Aplu1>0)maxn=max(maxn,-(long long)(Aneg)*Bplu1);
			if(Aneg1>0)maxn=max(maxn,-(long long)(Aplu)*Bneg1);
		}
		else if(Aplu>0){
			if(Aplu1>0)maxn=max(maxn,(long long)(Bplu)*Aplu1);
			if(Aneg1>0)maxn=max(maxn,-(long long)(Aplu)*Bneg1);
		}
		else if(Aneg>0){
			if(Aplu1>0)maxn=max(maxn,-(long long)(Aneg)*Bplu1);
			if(Aneg1>0)maxn=max(maxn,(long long)(Bneg)*Aneg1);
		}printf("%lld\n",maxn);
	}
}
