#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int n,m,q;
int O[201010],P[202020];
main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		O[x]++,P[x]++;
	}
	q=read();
	int flag=0;
	for(int i=1;i<=n;i++)if(P[i]!=1)flag++;
	while(q--){
		int t=read();
		if(t==1){
			int x=read(),y=read();P[x]--;if(P[x]==1)flag--;if(P[x]+1==1)flag++;
		}
		else if(t==2){
			int x=read();if(P[x]==1)flag++;P[x]=0;
		}
		else if(t==3){
			int x=read(),y=read();
			P[x]++;if(P[x]==1)flag--;if(P[x]-1==1)flag++;
		}
		else{
			int x=read();if(P[x]==1)flag++;P[x]=O[x];if(P[x]==1)flag--;
		}
		if(flag<=0)puts("YES");
		else puts("NO");
	}
}
