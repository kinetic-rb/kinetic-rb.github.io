#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int n,m,k;
int f[2525],vis[2525],h[2505],A,B,C,D,nxt[12601000],var[12600000],cnt,s[2505],G[2505][2505];
vector<int>Q[2555];
int fi[2550],se[2550],th[2550];
int Fi[2550],Se[2550],Th[2550];
int maxn=0;
void add(int x,int y){
	nxt[++cnt]=h[x],h[x]=cnt,var[cnt]=y;
	G[x][y]=1;
}
void bfs(int I){
	queue<pair<int,int> >q;
	q.push(make_pair(I,-1));//vis[I]=1;
	while(q.size()){
		int g=q.front().first,o=q.front().second;q.pop();
//		cout<<I<<"    "<<g<<endl;
		if(o>k)break;if(vis[g])continue;
		vis[g]=1;Q[I].push_back(g);
		for(int i=h[g];i;i=nxt[i]){
			int v=var[i];if(vis[v])continue;
			q.push(make_pair(v,o+1));
		}
	}
}
int _G(int x,int y){
	if(y==1)return Fi[x];
	if(y==2)return Se[x];
	if(y==3)return Th[x];
	if(y>3)return -1;
}
main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++)G[i][i]=1;
	for(int i=2;i<=n;i++)s[i]=read();
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
//		cout<<x<<" "<<y<<endl;
		add(x,y),add(y,x); 
	}
	for(int i=1;i<=n;i++){
		memset(vis,0,sizeof(vis));
		bfs(i);
	}
	for(int i=1;i<=n;i++){
		for(int j=0;j<Q[i].size();j++)add(i,Q[i][j]);
	}
	for(int p=h[1];p;p=nxt[p]){
		int V=var[p];if(V==1)continue;
		f[V]=s[V];//cout<<V<<endl;
	}
//	cout<<G[139][189]<<endl;
	for(int i=1;i<=n;i++)Fi[i]=Se[i]=Th[i]=fi[i]=se[i]=th[i]=-1;
	for(int i=1;i<=n;i++){
		for(int v=1;v<=n;v++){
			if(!G[i][v]||v==i)continue;//cout<<i<<" "<<v<<" "<<f[i]<<"???\n";
			if(f[i]>fi[v]){
				Th[v]=Se[v],Se[v]=Fi[v],th[v]=se[v],se[v]=fi[v];
				fi[v]=f[i],Fi[v]=i;
			}
			else if(f[i]>se[v]){
				Th[v]=Se[v],th[v]=se[v];
				Se[v]=i,se[v]=f[i];
			}
			else if(f[i]>th[v]){
				Th[v]=i,th[v]=f[i];
			}
		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<G[i][j];
//		}puts("");
//	}
//	for(int i=2;i<=n;i++){
//		for(int j=2;j<=n;j++){
//			for(int p=2;p<=n;p++){
//				for(int q=2;q<=n;q++){
//					if(i==j||i==p||i==q||j==p||j==q||p==q)continue;
//					if(!G[1][i]||!G[i][j]||!G[j][p]||!G[p][q]||!G[q][1])continue;
//					if(s[i]+s[j]+s[p]+s[q]>maxn)maxn=s[i]+s[j]+s[p]+s[q],A=i,B=j,C=p,D=q;
//				}
//			}
//		}
//	}
//	cout<<maxn<<" "<<A<<" "<<B<<" "<<C<<" "<<D<<endl;system("pause");
//	for(int i=1;i<=n;i++){
//		if(i==143||i==189)cout<<Fi[i]<<" "<<Se[i]<<" "<<Th[i]<<endl;
//	}
	for(int i=2;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(!G[i][j])continue;
			int C1=1,C2=1,ans=s[i]+s[j];
			if(_G(i,C1)==j)C1++;
			if(_G(j,C2)==i)C2++;
			if(_G(i,C1)==-1||_G(j,C2)==-1)continue;
			if(_G(i,C1)!=_G(j,C2)){ans+=s[_G(i,C1)]+s[_G(j,C2)];}
			else{
				int flag=0;
				if(_G(i,C1+1)!=-1&&(_G(i,C1+1)!=j||_G(i,C1+2)!=-1)){flag=1;ans=max(ans,s[i]+s[j]+s[_G(i,C1+1+(_G(i,C1+1)==j))]+s[_G(j,C2)]);}
				if(_G(j,C2+1)!=-1&&(_G(j,C2+1)!=i||_G(j,C2+2)!=-1)){flag=1;ans=max(ans,s[i]+s[j]+s[_G(i,C1)]+s[_G(j,C2+1+(_G(j,C2+1==i)))]);}
				if(flag==0)continue;
			}//if(i==143&&j==189)cout<<i<<" "<<j<<" "<<C1<<" "<<C2<<" "<<ans<<endl;
			maxn=max(maxn,ans);
		}
	}cout<<maxn;
}
