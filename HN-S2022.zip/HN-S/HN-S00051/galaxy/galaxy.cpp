#include <bits/stdc++.h>

using namespace std;

const int N = 5e5 + 5;
int n, m, q, u[N], v[N];
bool del[N], vis[N];
vector<int> in[N], out[N];
map<pair<int, int>, int> mp;

int main() {
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);
    scanf("%d%d", &n, &m);

    for (int i = 1; i <= m; i++) {
        scanf("%d%d", &u[i], &v[i]);
        mp[{u[i], v[i]}] = i;
        out[u[i]].emplace_back(i), in[v[i]].emplace_back(i);
    }

    scanf("%d", &q);

    while (q--) {
        int op, u, v;
        scanf("%d%d", &op, &u);

        if (op == 1)
            scanf("%d", &v), del[mp[{u, v}]] = true;
        else if (op == 2)
            for (int i : in[u]) del[i] = true;
        else if (op == 3)
            scanf("%d", &v), del[mp[{u, v}]] = false;
        else
            for (int i : in[u]) del[i] = false;

        bool ok = true;

        for (int i = 1; i <= n && ok; i++) {
            bool f = false;

            for (int j : in[i])
                if (!del[j]) {
                    f = true;
                    break;
                }

            vis[i] = f;
        }

        for (int i = 1; i <= n && ok; i++) {
            if (vis[i]) {
                int cnt = 0;

                for (int j : out[i])
                    if (!del[j] && vis[::v[j]]) cnt++;

                ok &= (cnt == 1);
            }
        }

        puts(ok ? "YES" : "NO");
    }

    return 0;
}