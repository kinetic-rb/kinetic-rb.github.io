#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int N = 1e5 + 5, LOG = 17, INF = 0x3f3f3f3f;
int n, m, q, a[N], b[N], c[N];

struct Node {
    int mn, mx;
};

struct SparseTable {
    int mn[N][LOG], mx[N][LOG];

    void init(int n, int *a) {
        for (int i = n; i >= 1; i--) {
            mn[i][0] = (a[i] == INF ? INF : a[i]);
            mx[i][0] = (a[i] == INF ? -INF : a[i]);

            for (int j = 1; i + (1 << j) - 1 <= n; j++) {
                mn[i][j] = min(mn[i][j - 1], mn[i + (1 << (j - 1))][j - 1]);
                mx[i][j] = max(mx[i][j - 1], mx[i + (1 << (j - 1))][j - 1]);
            }
        }
    }

    Node query(int l, int r) {
        int e = __lg(r - l + 1);

        return {min(mn[l][e], mn[r - (1 << e) + 1][e]),
                max(mx[l][e], mx[r - (1 << e) + 1][e])};
    }
} A, B, C;

ll query(int l1, int r1, int l2, int r2) {
    Node x = A.query(l1, r1), y = B.query(l1, r1), z = C.query(l2, r2);
    ll ans = -1e18;
    if (x.mn < INF) ans = max(ans, ll(z.mn) * (z.mn <= 0 ? x.mn : x.mx));
    if (y.mn < INF) ans = max(ans, ll(z.mx) * (z.mx >= 0 ? y.mx : y.mn));
    return ans;
}

int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);

    scanf("%d%d%d", &n, &m, &q);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    for (int i = 1; i <= m; i++) scanf("%d", &b[i]);
    C.init(m, b);

    for (int i = 1; i <= n; i++) c[i] = (a[i] >= 0 ? a[i] : INF);
    A.init(n, c);

    for (int i = 1; i <= n; i++) c[i] = (a[i] <= 0 ? a[i] : INF);
    B.init(n, c);

    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
        printf("%lld\n", query(l1, r1, l2, r2));
    }

    return 0;
}