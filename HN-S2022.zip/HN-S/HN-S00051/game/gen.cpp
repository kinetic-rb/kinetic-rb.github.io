#include <bits/stdc++.h>

using namespace std;

const int N = 5;
mt19937 eng(chrono::system_clock().now().time_since_epoch().count());

int rand(int l, int r) {
    return uniform_int_distribution<>(l, r)(eng);
}

void gen() {
    FILE *s = fopen("game.in", "w");
    fprintf(s, "%d %d %d\n", N, N, N);

    for (int i = 1; i <= N; i++) fprintf(s, "%d ", rand(-N, N));
    fprintf(s, "\n");

    for (int i = 1; i <= N; i++) fprintf(s, "%d ", rand(-N, N));
    fprintf(s, "\n");

    for (int i = 1; i <= N; i++) {
        int l = rand(1, N), r = rand(1, N);
        if (l > r) swap(l, r);
        fprintf(s, "%d %d ", l, r);
        l = rand(1, N), r = rand(1, N);
        if (l > r) swap(l, r);
        fprintf(s, "%d %d\n", l, r);
    }

    fclose(s);
}

void judge(int t) {
    system("./my"), system("./std");

    if (system("diff game.out game.ans")) {
        printf("Case #%d: Wrong Answer.\n", t);
        return;
    }

    if (t % 100 == 0) printf("Case #%d: Accepted.\n", t);
}

int main() {
    int lim;
    scanf("%d", &lim);
    for (int i = 1; i <= lim; i++) gen(), judge(i);
    return 0;
}