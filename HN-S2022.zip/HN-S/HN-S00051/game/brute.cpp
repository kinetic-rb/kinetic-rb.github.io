#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int N = 1e5 + 5;
int n, m, q, a[N], b[N];

int main() {
    freopen("game.in", "r", stdin);
    freopen("game.ans", "w", stdout);

    scanf("%d%d%d", &n, &m, &q);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    for (int i = 1; i <= m; i++) scanf("%d", &b[i]);

    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
        ll ans = -1e18;

        for (int i = l1; i <= r1; i++) {
            ll res = 1e18;
            for (int j = l2; j <= r2; j++) res = min(res, ll(a[i]) * b[j]);
            ans = max(ans, res);
        }

        printf("%lld\n", ans);
    }

    return 0;
}