#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int N = 2e5 + 5, M = 3, LOG = 18;
const ll INF = 0x3f3f3f3f3f3f3f3f;
int n, q, K, t, v[N], dep[N], dfn[N], mn[N], Fa[N][LOG];
ll f[N][2];
vector<int> g[N];

struct Matrix {
    ll a[M][M];

    Matrix() { memset(a, 0x3f, sizeof(a)); }

    Matrix operator*(const Matrix &rhs) const {
        Matrix ans;

        for (int i = 0; i < K; i++)
            for (int j = 0; j < K; j++)
                for (int k = 0; k < K; k++)
                    ans.a[i][k] = min(ans.a[i][k], a[i][j] + rhs.a[j][k]);

        return ans;
    }
} ppk[N][LOG], kkp[N][LOG];

void dfs(int cur, int fa) {
    dep[cur] = dep[fa] + 1, dfn[cur] = ++t, Fa[cur][0] = fa;
    Matrix &T = ppk[cur][0];

    if (K == 1)
        T.a[0][0] = v[cur];
    else
        T.a[1][0] = 0, T.a[0][1] = T.a[1][1] = v[cur];

    kkp[cur][0] = ppk[cur][0];

    for (int i = 1; (1 << i) < dep[cur]; i++) {
        Fa[cur][i] = Fa[Fa[cur][i - 1]][i - 1];
        ppk[cur][i] = ppk[cur][i - 1] * ppk[Fa[cur][i - 1]][i - 1];
        kkp[cur][i] = kkp[Fa[cur][i - 1]][i - 1] * kkp[cur][i - 1];
    }

    mn[cur] = 1e9;

    for (int to : g[cur])
        if (to != fa) dfs(to, cur), mn[cur] = min(mn[cur], v[to]);
}

int lca(int x, int y) {
    if (dfn[x] < dfn[y]) swap(x, y);

    for (int i = __lg(dep[x] - 1); i >= 0; i--)
        if (dfn[Fa[x][i]] > dfn[y]) x = Fa[x][i];

    return Fa[x][0];
}

ll query12(int x, int y) {
    if (x == y) return v[x];
    if (dep[x] < dep[y]) swap(x, y);
    int l = lca(x, y);

    Matrix ax, ay;
    ax.a[0][K - 1] = v[x], x = Fa[x][0];
    for (int i = 0; i < K; i++) ay.a[i][i] = 0;

    if (x != l)
        for (int i = __lg(dep[x] - dep[l]); i >= 0; i--)
            if (dep[x] - (1 << i) >= dep[l]) ax = ax * ppk[x][i], x = Fa[x][i];

    if (y != l)
        for (int i = __lg(dep[y] - dep[l]); i >= 0; i--)
            if (dep[y] - (1 << i) >= dep[l]) ay = kkp[y][i] * ay, y = Fa[y][i];

    return (ax * ppk[l][0] * ay).a[0][K - 1];
}

ll query3(int x, int y) {
    int X = x, Y = y;
    vector<int> p, q;

    while (x != y) {
        if (dep[x] < dep[y])
            q.emplace_back(y), y = Fa[y][0];
        else
            p.emplace_back(x), x = Fa[x][0];
    }

    p.emplace_back(Fa[x][0]);
    reverse(q.begin(), q.end());
    p.insert(p.end(), q.begin(), q.end());
    int s = p.size();
    if (s <= 4) return v[X] + v[Y];

    f[0][0] = v[X], f[0][1] = INF;

    for (int i = 1; i < s; i++) {
        f[i][0] = f[i][1] = INF;
        for (int j = max(0, i - 3); j < i; j++) f[i][0] = min(f[i][0], f[j][0]);
        for (int j = max(0, i - 2); j < i; j++) f[i][0] = min(f[i][0], f[j][1]);
        for (int j = max(0, i - 2); j < i; j++) f[i][1] = min(f[i][1], f[j][0]);
        for (int j = max(0, i - 1); j < i; j++) f[i][1] = min(f[i][1], f[j][1]);
        f[i][0] += v[p[i]], f[i][1] += mn[p[i]];
    }

    return f[s - 1][0];
}

ll query(int x, int y) {
    return K <= 2 ? query12(x, y) : query3(x, y);
}

int main() {
    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);
    scanf("%d%d%d", &n, &q, &K);
    for (int i = 1; i <= n; i++) scanf("%d", &v[i]);

    for (int i = 1; i < n; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        g[x].emplace_back(y), g[y].emplace_back(x);
    }

    dfs(1, 1);

    while (q--) {
        int x, y;
        scanf("%d%d", &x, &y);
        printf("%lld\n", query(x, y));
    }

    return 0;
}