#include <bits/stdc++.h>

using namespace std;

const int N = 2505, INF = 0x3f3f3f3f;
int n, m, K, s[N], dis[N][N];
vector<int> g[N];
queue<int> q;

template <typename T>
void clear(queue<T> &q) {
    queue<T> tmp;
    swap(q, tmp);
}

void bfs(int u) {
    memset(dis[u] + 1, 0x3f, n * 4), dis[u][u] = 0;
    clear(q), q.emplace(u);

    while (!q.empty()) {
        int cur = q.front();
        q.pop();

        for (int to : g[cur])
            if (dis[u][to] == INF)
                dis[u][to] = dis[u][cur] + 1, q.emplace(to);
    }
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.ans", "w", stdout);

    scanf("%d%d%d", &n, &m, &K), K++;
    for (int i = 2; i <= n; i++) scanf("%d", &s[i]);

    while (m--) {
        int x, y;
        scanf("%d%d", &x, &y);
        g[x].emplace_back(y), g[y].emplace_back(x);
    }

    for (int i = 1; i <= n; i++) bfs(i);
    int ans = 0;

    for (int i = 2; i <= n; i++)
        for (int j = 2; j <= n; j++)
            for (int k = 2; k <= n; k++)
                for (int l = 2; l <= n; l++) {
                    if (i == j || i == k || i == l || j == k || j == l || k == l)
                        continue;

                    if (dis[1][i] > K || dis[i][j] > K || dis[j][k] > K ||
                        dis[k][l] > K || dis[l][1] > K)
                        continue;

                    ans = max(ans, s[i] + s[j] + s[k] + s[l]);
                }

    printf("%d\n", ans);
    return 0;
}