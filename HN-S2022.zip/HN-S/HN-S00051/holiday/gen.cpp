#include <bits/stdc++.h>

using namespace std;

const int N = 10, M = 30, K = 5;
mt19937 eng(chrono::system_clock().now().time_since_epoch().count());

int rand(int l, int r) {
    return uniform_int_distribution<>(l, r)(eng);
}

void gen() {
    FILE *s = fopen("holiday.in", "w");
    fprintf(s, "%d %d %d\n", N, M, K);

    for (int i = 2; i <= N; i++) fprintf(s, "%d ", rand(1, N));
    fprintf(s, "\n");

    for (int i = 1; i <= M; i++) {
        int a = rand(1, N * (N - 1) / 2);

        for (int j = 1; j <= N; j++) {
            if (a <= N - j) {
                fprintf(s, "%d %d\n", j, a + j);
                break;
            }

            a -= N - j;
        }
    }

    fclose(s);
}

void judge(int t) {
    system("./my"), system("./std");

    if (system("diff holiday.out holiday.ans")) {
        printf("Case #%d: Wrong Answer.\n", t);
        return;
    }

    if (t % 100 == 0) printf("Case #%d: Accepted.\n", t);
}

int main() {
    int lim;
    scanf("%d", &lim);
    for (int i = 1; i <= lim; i++) gen(), judge(i);
    return 0;
}