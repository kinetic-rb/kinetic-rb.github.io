#include <bits/stdc++.h>
#define val first
#define id second

using namespace std;
using ull = unsigned long long;
using pui = pair<ull, int>;

const int N = 2505, INF = 0x3f3f3f3f;
int n, m, k, dis[N][N];
ull s[N];
vector<int> g[N];
queue<int> q;
pui mx[N], smx[N], tmx[N];

template <typename T>
void clear(queue<T> &q) {
    queue<T> tmp;
    swap(q, tmp);
}

void bfs(int u) {
    memset(dis[u] + 1, 0x3f, n * 4), dis[u][u] = 0;
    clear(q), q.emplace(u);

    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        if (dis[u][cur] >= k) break;

        for (int to : g[cur])
            if (dis[u][to] == INF)
                dis[u][to] = dis[u][cur] + 1, q.emplace(to);
    }
}

void init() {
    for (int i = 2; i <= n; i++) {
        if (dis[1][i] > k) continue;
        pui cur(s[i], i);

        for (int j = 2; j <= n; j++) {
            if (i == j || dis[i][j] > k) continue;

            if (cur > mx[j])
                tmx[j] = smx[j], smx[j] = mx[j], mx[j] = cur;
            else if (cur > smx[j])
                tmx[j] = smx[j], smx[j] = cur;
            else
                tmx[j] = max(tmx[j], cur);
        }
    }
}

void solve() {
    ull ans = 0;

    for (int i = 2; i <= n; i++) {
        if (mx[i].val == 0) continue;

        for (int j = 2; j <= n; j++) {
            if (i == j || dis[i][j] > k || mx[j].val == 0) continue;
            pui x = (mx[i].id == j ? smx[i] : mx[i]), y;

            if (mx[j].id != i && mx[j].id != x.id)
                y = mx[j];
            else if (smx[j].id != i && smx[j].id != x.id)
                y = smx[j];
            else
                y = tmx[j];

            ans = max(ans, x.val + y.val + s[i] + s[j]);
        }
    }

    printf("%llu\n", ans);
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);

    scanf("%d%d%d", &n, &m, &k), k++;
    for (int i = 2; i <= n; i++) scanf("%llu", &s[i]);

    while (m--) {
        int x, y;
        scanf("%d%d", &x, &y);
        g[x].emplace_back(y), g[y].emplace_back(x);
    }

    for (int i = 1; i <= n; i++) bfs(i);
    init(), solve();
    return 0;
}