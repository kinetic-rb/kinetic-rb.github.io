#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 10;

int n, q, k, v[N], c[N], ans;

vector<int> f[N];

void dfs(int t, int p, int l) {
  if (v[t]) {
    return ;
  }
  if (t == p) {
    if (l - 1 <= k) {
      ans = min(ans, v[c[1]] + v[t]);
    }   
  }
  v[t] = 1;
  for (int i = 0; i < f[t].size(); i++) {
    c[l] = t;
    dfs(f[t][i], p, l + 1);
  }
}

int main() {
  freopen("transmit.in", "r", stdin);
  freopen("transmit.out", "w", stdout);
  cin >> n >> q >> k;
  for (int i = 1; i <= n; i++) {
    cin >> v[i];
  }
  for (int i = 1; i < n; i++) {
    int a, b;
    cin >> a >> b;
    f[a].push_back(b), f[b].push_back(a);
  }
  while (q--) {
    int a, b;
    cin >> a >> b;
    fill(v + 1, v + n + 1, 0);
    ans = INT_MAX;
  }
  return 0;
}
