#include <bits/stdc++.h>

using namespace std;

const int N = 25;

int n, m, k, minl, len[N][N], ch[5];
long long num[N], answ;
bool v[N];

vector<int> f[N];

void dfs(int t, int l, int m) {
  if (v[t]) {
    return ;
  }
  if (t == m) {
    minl = min(minl, l - 1);
    return ;
  }
  v[t] = 1;
  for (int i = 0; i < f[t].size(); i++) {
    dfs(f[t][i], l + 1, m);
  }
  v[t] = 0;
}

void S(int t, int c) {
  if (c > 5) {
    return ;
  }
  if (t == n + 1) {
    if (c == 5) {
      ch[0] = ch[c] = 1;
      bool h = 0;
      long long sum = 0;
      for (int i = 0; i < c; i++) {
        if (len[ch[i]][ch[i + 1]] <= k) {
          sum += num[ch[i]];
        } else {
          h = 1;
          break;
        }
      }
      if (!h) {
        answ = max(answ, sum);
      }
    }
    return ;
  }
  S(t + 1, c);
  ch[c] = t;
  S(t + 1, c + 1);
}

int main() {
  freopen("holiday.in", "r", stdin);
  freopen("holiday.out", "w", stdout);
  cin >> n >> m >> k;
  for (int i = 2; i <= n; i++) {
    cin >> num[i];
  }
  while (m--) {
    int x, y;
    cin >> x >> y;
    f[x].push_back(y), f[y].push_back(x);
  }
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= n; j++) {
      fill(v + 1, v + n + 1, 0);
      minl = INT_MAX;
      dfs(i, 0, j);
      len[i][j] = minl;
    }
  }
  S(2, 1);
  cout << answ;
  return 0;
}
