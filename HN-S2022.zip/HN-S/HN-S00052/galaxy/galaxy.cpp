#include <bits/stdc++.h>

using namespace std;

const int N = 1e3 + 10, M = 1e4 + 10;

int n, m, q, u[M], v[M];
bool f[N][N], h[N], p[M];

int main() {
  freopen("galaxy.in", "r", stdin);
  freopen("galaxy.out", "w", stdout);
  cin >> n >> m;
  for (int i = 1; i <= m; i++) {
    cin >> u[i] >> v[i];
    f[u[i]][v[i]] = 1;
  }
  cin >> q;
  while (q--) {
    int t, a, b;
    cin >> t;
    if (t % 2) {
      cin >> a >> b;
      bool k = t == 3;
      f[a][b] = k && !h[a];
      for (int i = 1; i <= m; i++) {
        if (u[i] == a && v[i] == b) {
          p[i] = !k;
          break;
        }
      }
    } else {
      cin >> a;
      bool k = t == 2;
      for (int i = 1; i <= m; i++) {
        if (v[i] == a) {
          p[i] = k;
        }
        if (!h[u[i]] && !p[i]) {
          f[u[i]][v[i]] = 1;
        } else {
          f[u[i]][v[i]] = 0;
        }
      }
      h[a] = k;
    }
    bool flag = 1;
    for (int i = 1; i <= n; i++) {
      int o = 0;
      for (int j = 1; j <= n; j++) {
        o += f[i][j];
      }
      flag &= o == 1;
    }
    cout << (flag ? "YES\n" : "NO\n");
  }
  return 0;
}
