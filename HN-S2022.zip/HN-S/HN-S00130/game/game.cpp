#include<bits/stdc++.h>
using namespace std;
long long a[900000],b[999999],l1[9000000],r1[9000000],l2[9000000],r2[999999];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    #define int long long 
    #define break continue
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	for(int i=1;i<=q;i++){
		cin>>l1[i]>>r1[i]>>l2[i]>>r2[i];
	}
	for(int i=1;i<=q;i++){	
	    int sigh11=1,sigh12=1;
		int sigh21=1,sigh22=1;
	    int max1=-999999999,min1=999999999,max2=-999999999,min2=999999999;
		if(l1[i]==r1[i]&&l2[i]==r2[i]){cout<<a[l1[i]]*b[l2[i]]<<endl;break;}
		for(int j=l1[i];j<=r1[i];j++){
			if(a[j]<0) sigh11=-1;
			if(a[j]==0) sigh12=0;
			if(a[j]>max1) max1=a[j];
			if(a[j]<min1) min1=a[j];
		}
		for(int k=l2[i];k<=r2[i];k++){
			if(b[k]<0) sigh21=-1;
			if(b[k]==0) sigh22=0;
			if(b[k]>max2) max2=b[k];
			if(b[k]<min2) min2=b[k];
		}
	    if(sigh11==1&&sigh21==1){
	    	if(sigh22==1) {cout<<max1*min2<<endl;break;}
	    	else if(sigh22==0) {cout<<"0"<<endl;break;}
		}	
		if(sigh11==1&&sigh21==-1){
			if(sigh12==1) {cout<<min1*min2<<endl;break;}
			else if(sigh12==0) {cout<<"0"<<endl;break;}
		}	
		if(sigh11==-1&&sigh21==1){
			if(sigh12==1) {cout<<max1*max2<<endl;break;}
			else if(sigh12==0) {cout<<"0"<<endl;break;}
		}
		if(sigh11==-1&&sigh21==-1){
			if(sigh22==1) {cout<<min1*max2<<endl;break;}
			else if(sigh22==0) {cout<<"0"<<endl;break;}
		}
	}
	return 0;
}
