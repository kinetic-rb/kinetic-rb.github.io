#include<bits/stdc++.h>

using namespace std;
int fen[90000],x[99999],y[99999];
int s[999999];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	#define int long long 
	int n,m,k;//dian shuangzhi max
	cin>>n>>m>>k;
	for(int i=2;i<=n-1;i++){
		cin>>fen[i];
	}
	for(int i=1;i<=m;i++){
		cin>>x[i]>>y[i];
	}
	
	return 0;
}
