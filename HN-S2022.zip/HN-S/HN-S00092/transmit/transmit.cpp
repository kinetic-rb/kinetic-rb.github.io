#include<bits/stdc++.h>
#define int long long
#define re register int
using namespace std;
int n,q,k,v[200010],a,b,ans;
vector<int> u[200010];
void dfs(int m,int s,int w,int last){
	if(m==b){
		ans=min(w,ans);
		return;
	}
	if(w>=ans){
		return;
	}
	for(re i=0;i<u[m].size();++i){
		if(u[m][i]!=last&&s>=1){
			dfs(u[m][i],s-1,w+v[u[m][i]],m);
		}
	}
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(re i=1;i<=n;++i){
		cin>>v[i];
	}
	for(re i=1;i<n;++i){
		cin>>a>>b;
		u[a].push_back(b),u[b].push_back(a);
	}
	while(q--){
		cin>>a>>b;
		ans=1e18;
		dfs(a,k,v[a],a);
		cout<<ans<<endl;
	}
	return 0;
}

