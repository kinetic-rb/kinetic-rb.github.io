#include<bits/stdc++.h>
#define int long long
#define re register int
using namespace std;
int n,m,k,w[2510],f[2510],ans;
vector<int> v[10010];
void dfs(int a,int s,int u){
	if(a==1&&f[a]==1){
		ans=max(ans,u);
		return;
	}
	f[a]=1;
	for(re i=0;i<v[a].size();++i){
		if(f[v[a][i]]==0&&v[a][i]!=1&&s<=4){
			dfs(v[a][i],s+1,u+w[v[a][i]]);
		}
		if(v[a][i]==1&&s==4){
			dfs(v[a][i],s,u);
		}
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(re i=2;i<=n;++i){
		cin>>w[i];
	}
	for(re i=1;i<=m;++i){
		int x,y;
		cin>>x>>y;
		v[x].push_back(y),v[y].push_back(x);
	}
	dfs(1,0,0);
	cout<<ans;
	return 0;
}
//
//7 9 0
//1 1 1 2 3 4
//1 2
//2 3
//3 4
//1 5
//1 6
//1 7
//5 4
//6 4
//7 4
