#include<bits/stdc++.h>
#define int long long
#define re register int
using namespace std;
int n,m,q,a[100010],b[100010];
inline int lmax(int x,int y){
	if(x>y){
		return x;
	}
	return y;
}
inline int lmin(int x,int y){
	if(x<y){
		return x;
	}
	return y;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(re i=1;i<=n;++i){
		cin>>a[i]; 
	}
	for(re i=1;i<=m;++i){
		cin>>b[i];
	}
	while(q--){
		int l1,r1,l2,r2,ans=-1e18,c;
		cin>>l1>>r1>>l2>>r2;
		for(re i=l1;i<=r1;++i){
			c=1e18;
			for(re j=l2;j<=r2;++j){
				c=lmin(c,a[i]*b[j]);
			}
			ans=lmax(ans,c);
		}
		cout<<ans<<endl;
	}
	return 0;
}

