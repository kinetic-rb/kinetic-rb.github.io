#include <bits/stdc++.h>
#define ll long long

using namespace std;

inline int read() {
	int s(0);
	int f(1);
	char ch(getchar());
	while (ch < '0' || ch > '9') {
		if (ch == '-') {
			f = -1;
		}
		ch = getchar();
	}
	while (ch > '/' && ch < ':') {
		s = (s << 3) + (s << 1) + ch - '0';
		ch = getchar();
	}
	return s * f;
}

inline void write(ll x) {
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

int n, q, k, s, t;
int cnt;
long long ff[2010];
bool flag;
int val[200010];
int father[200010];
int a[2010];
int deep[200010];
long long f[200010];
int root[200010][20];

vector<int> son[200010];

void Dfs(int x, int fa, int y, long long sum) {
	father[x] = fa;
	root[x][0] = fa;
	f[x] = sum;
	deep[x] = y;
	for (int i = 0; i < son[x].size(); ++i) {
		int v = son[x][i];
		if (v != fa) {
			Dfs(v, x, y + 1, sum + val[v]);
		}
	}
}

int LCA(int x, int y) {
	if (deep[x] > deep[y]) {
		swap(x, y);
	}
	for (int i = 19; i > -1; --i) {
		if (deep[root[y][i]] >= deep[x]) {
			y = root[y][i];
		}
	}
	for (int i = 19; i > -1; --i) {
		if (root[x][i] != root[y][i]) {
			y = root[y][i], x = root[x][i];
		}
	}
	return x == y ? x : father[x];
}

void W(int x, int y, int fa) {
	if (x == t) {
		a[y] = x;
		cnt = y;
		flag = true;
		return;
	}
	for (int i = 0; i < son[x].size(); ++i) {
		int v = son[x][i];
		if (v != fa) {
			W(v, y + 1, x);
			if (flag) {
				a[y] = x;
				return;
			}
		}
	}
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	
	n = read(), q = read(), k = read();
	for (int i = 1; i <= n; ++i) {
		val[i] = read();
	}
	for (int i = 1, x, y; i < n; ++i) {
		x = read(), y = read();
		son[x].push_back(y);
		son[y].push_back(x);
	}
	if (k == 1) {
		Dfs(1, 0, 1, val[1]);
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j < 20; ++j) {
				if (root[i][j - 1]) {
					root[i][j] = root[root[i][j - 1]][j - 1];
				}
			}
		}
		while (q--) {
			s = read(), t = read();
			int l = LCA(s, t);
			write(f[s] + f[t] - f[father[l]] - f[father[l]] - f[l]);
			puts("");
		}
	} else {
		while (q--) {
			flag = 0;
			s = read(), t = read();
			W(s, 1, 0);
			for (int i = 1; i <= cnt; ++i) {
				ff[i] = 1e18;
			}
			ff[1] = val[a[1]];
			for (int i = 2; i <= cnt; ++i) {
				for (int j = 1; j <= k && i - j > 0; ++j) {
					ff[i] = min(ff[i], ff[i - j] + val[a[i]]);
				}
			}
			cout << ff[cnt] << "\n";
		}
	}
	return 0;
} 
