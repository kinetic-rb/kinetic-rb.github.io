#include <bits/stdc++.h>
#define ull unsigned long long

using namespace std;

inline ull read() {
	ull s(0);
	char ch(getchar());
	while (ch < '0' || ch > '9') {
		ch = getchar();
	}
	while (ch > '/' && ch < ':') {
		s = (s << 3) + (s << 1) + ch - '0';
		ch = getchar();
	}
	return s;
}

int n, m, k;
ull ans;
ull v[2501];
int dis[2501][2501];
ull f[2501][3];
int f2[2501][3];
bool vis[2501];

vector<int> son[2501];
vector<int> TrueSon[2501];

queue<int> q;

void Add(int x, int y) {
	ull sum = v[x] + v[y];
	for (int i = 0; i < 3; ++i) {
		if (sum > f[y][i]) {
			swap(f[y][i], sum);
			swap(f2[y][i], x);
		}
	}
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	n = read(), m = read(), k = read();
	for (int i = 2; i <= n; ++i) {
		v[i] = read();
	}
	for (int i = 1, x, y; i <= m; ++i) {
		x = read(), y = read();
		son[x].push_back(y);
		son[y].push_back(x);
	}
	for (int i = 1; i <= n; ++i) {
		while (q.size()) {
			q.pop();
		}
		memset(vis, 0, sizeof(vis));
		vis[i] = 1;
		dis[i][i] = -1;
		q.push(i);
		while (!q.empty()) {
			int x(q.front());
			q.pop();
			for (int j = 0; j < son[x].size(); ++j) {
				int v = son[x][j];
				if (!vis[v]) {
					vis[v] = 1;
					dis[i][v] = dis[i][x] + 1;
					q.push(v);
				}
			}
		}
	}
	for (int i = 1; i < n; ++i) {
		for (int j = i + 1; j <= n; ++j) {
			if (dis[i][j] <= k) {
				TrueSon[i].push_back(j);
				TrueSon[j].push_back(i);
			}
		}
	}
	for (int i = 0; i < TrueSon[1].size(); ++i) {
		int u = TrueSon[1][i];
		for (int j = 0; j < TrueSon[u].size(); ++j) {
			int v = TrueSon[u][j];
			if (v != 1) {
				Add(u, v);
			}
		}
	}
	for (int i = 2; i <= n; ++i) {
		for (int k1 = 0; k1 < 3; ++k1) {
			int u = f2[i][k1];
			for (int j = 0; j < TrueSon[i].size(); ++j) {
				int v = TrueSon[i][j];
				if (u == v) {
					continue;
				}
				for (int k2 = 0; k2 < 3; ++k2) {
					int u2 = f2[v][k2];
					if (u != u2 && u2 != i) {
						ans = max(ans, f[i][k1] + f[v][k2]);
					}
				}
			}
		}
	}
	cout << ans;
	return 0;
} 
