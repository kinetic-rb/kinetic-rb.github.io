#include <bits/stdc++.h>
#define ll long long
#define lx p << 1
#define rx p << 1 | 1

using namespace std;

inline ll read() {
	ll s(0);
	int f(1);
	char ch(getchar());
	while (ch < '0' || ch > '9') {
		if (ch == '-') {
			f = -1;
		}
		ch = getchar();
	}
	while (ch > '/' && ch < ':') {
		s = (s << 3) + (s << 1) + ch - '0';
		ch = getchar();
	}
	return s * f;
}

inline void write(ll x) {
	if (x < 0) {
		putchar('-');
		x = -x;
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

int n, m, q;
ll ans;
int l1, r1, l2, r2;
int a[100010], b[100010];

struct E {
	int x1 = 1e9 + 1, x01 = -1e9 - 1, x1e9, x01e9;
	bool Zero;
} e[100010 << 3];

struct V {
	int x1 = 1e9 + 1, x01 = -1e9 - 1, x1e9, x01e9;
	bool Zero;
} v[100010 << 3];

void BuildA(int x, int y, int p) {
	if (x == y) {
		if (a[x] > 0) {
			e[p].x1 = e[p].x1e9 = a[x];
		} else if (a[x] < 0) {
			e[p].x01 = e[p].x01e9 = a[x];
		} else {
			e[p].Zero = 1;
		}
		return;
	}
	int mid((x + y) >> 1);
	BuildA(x, mid, lx), BuildA(mid + 1, y, rx);
	e[p].Zero = e[lx].Zero | e[rx].Zero;
	if (e[lx].x1e9 != 0) {
		if (e[rx].x1e9 != 0) {
			e[p].x1 = min(e[lx].x1, e[rx].x1);
			e[p].x1e9 = max(e[lx].x1e9, e[rx].x1e9);
		} else {
			e[p].x1 = e[lx].x1;
			e[p].x1e9 = e[lx].x1e9;
		}
	} else if (e[rx].x1e9 != 0) {
		e[p].x1 = e[rx].x1;
		e[p].x1e9 = e[rx].x1e9;
	}
	if (e[lx].x01e9 != 0) {
		if (e[rx].x01e9 != 0) {
			e[p].x01 = max(e[lx].x01, e[rx].x01);
			e[p].x01e9 = min(e[lx].x01e9, e[rx].x01e9);
		} else {
			e[p].x01 = e[lx].x01;
			e[p].x01e9 = e[lx].x01e9;
		}
	} else if (e[rx].x01e9 != 0) {
		e[p].x01 = e[rx].x01;
		e[p].x01e9 = e[rx].x01e9;
	}
}

void BuildB(int x, int y, int p) {
	if (x == y) {
		if (b[x] > 0) {
			v[p].x1 = v[p].x1e9 = b[x];
		} else if (b[x] < 0) {
			v[p].x01 = v[p].x01e9 = b[x];
		} else {
			v[p].Zero = 1;
		}
		return;
	}
	int mid((x + y) >> 1);
	BuildB(x, mid, lx), BuildB(mid + 1, y, rx);
	v[p].Zero = v[lx].Zero | v[rx].Zero;
	if (v[lx].x1e9 != 0) {
		if (v[rx].x1e9 != 0) {
			v[p].x1 = min(v[lx].x1, v[rx].x1);
			v[p].x1e9 = max(v[lx].x1e9, v[rx].x1e9);
		} else {
			v[p].x1 = v[lx].x1;
			v[p].x1e9 = v[lx].x1e9;
		}
	} else if (v[rx].x1e9 != 0) {
		v[p].x1 = v[rx].x1;
		v[p].x1e9 = v[rx].x1e9;
	}
	if (v[lx].x01e9 != 0) {
		if (v[rx].x01e9 != 0) {
			v[p].x01 = max(v[lx].x01, v[rx].x01);
			v[p].x01e9 = min(v[lx].x01e9, v[rx].x01e9);
		} else {
			v[p].x01 = v[lx].x01;
			v[p].x01e9 = v[lx].x01e9;
		}
	} else if (v[rx].x01e9 != 0) {
		v[p].x01 = v[rx].x01;
		v[p].x01e9 = v[rx].x01e9;
	}
}

int FindA1(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return 1e9 + 1;
	}
	if (l1 <= x && y <= r1) {
		return e[p].x1;
	} else {
		int mid((x + y) >> 1);
		return min(FindA1(x, mid, lx), FindA1(mid + 1, y, rx));
	}
}

int FindA1e9(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return 0;
	}
	if (l1 <= x && y <= r1) {
		return e[p].x1e9;
	} else {
		int mid((x + y) >> 1);
		return max(FindA1e9(x, mid, lx), FindA1e9(mid + 1, y, rx));
	}
}

int FindA01(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return -1e9 - 1;
	}
	if (l1 <= x && y <= r1) {
		return e[p].x01;
	} else {
		int mid((x + y) >> 1);
		return max(FindA01(x, mid, lx), FindA01(mid + 1, y, rx));
	}
}

int FindA01e9(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return 0;
	}
	if (l1 <= x && y <= r1) {
		return e[p].x01e9;
	} else {
		int mid((x + y) >> 1);
		return min(FindA01e9(x, mid, lx), FindA01e9(mid + 1, y, rx));
	}
}

bool FindA0(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return 0;
	}
	if (l1 <= x && y <= r1) {
		return e[p].Zero;
	} else {
		int mid((x + y) >> 1);
		return FindA0(x, mid, lx) | FindA0(mid + 1, y, rx);
	}
}

int FindB1(int x, int y, int p) {
	if (x > r2 || y < l2) {
		return 1e9 + 1;
	}
	if (l2 <= x && y <= r2) {
		return v[p].x1;
	} else {
		int mid((x + y) >> 1);
		return min(FindB1(x, mid, lx), FindB1(mid + 1, y, rx));
	}
}

int FindB1e9(int x, int y, int p) {
	if (x > r2 || y < l2) {
		return 0;
	}
	if (l2 <= x && y <= r2) {
		return v[p].x1e9;
	} else {
		int mid((x + y) >> 1);
		return max(FindB1e9(x, mid, lx), FindB1e9(mid + 1, y, rx));
	}
}

int FindB01(int x, int y, int p) {
	if (x > r2 || y < l2) {
		return -1e9 - 1;
	}
	if (l2 <= x && y <= r2) {
		return v[p].x01;
	} else {
		int mid((x + y) >> 1);
		return max(FindB01(x, mid, lx), FindB01(mid + 1, y, rx));
	}
}

int FindB01e9(int x, int y, int p) {
	if (x > r2 || y < l2) {
		return 0;
	}
	if (l2 <= x && y <= r2) {
		return v[p].x01e9;
	} else {
		int mid((x + y) >> 1);
		return min(FindB01e9(x, mid, lx), FindB01e9(mid + 1, y, rx));
	}
}

bool FindB0(int x, int y, int p) {
	if (x > r1 || y < l1) {
		return 0;
	}
	if (l1 <= x && y <= r1) {
		return v[p].Zero;
	} else {
		int mid((x + y) >> 1);
		return FindB0(x, mid, lx) | FindB0(mid + 1, y, rx);
	}
}

void Deal() {
	int A01, A01e9, A1, A1e9;
	int B01, B01e9, B1, B1e9;
	bool A0, B0;
	A01 = FindA01(1, n, 1);
	A01e9 = FindA01e9(1, n, 1);
	A1 = FindA1(1, n, 1);
	A1e9 = FindA1e9(1, n, 1);
	A0 = FindA0(1, n, 1);
	B01 = FindB01(1, n, 1);
	B01e9 = FindB01e9(1, n, 1);
	B1 = FindB1(1, n, 1);
	B1e9 = FindB1e9(1, n, 1);
	B0 = FindB0(1, n, 1);
	if (B1e9 != 0) {
		if (B01e9 != 0) {
			if (A0) {
				ans = 0;
			} else if (A1e9 != 0) {
				if (A01e9 != 0) {
					ans = max((ll)A01 * B1e9, (ll)A1 * B01e9);
				} else {
					ans = (ll)A1 * B01e9;
				}
			} else if (A01e9 != 0) {
				ans = (ll)A01 * B1e9;
			} else {
				ans = 0;
			}
		} else {
			if (A1e9 != 0) {
				ans = (ll)A1e9 * B1;
			} else if (A01e9 != 0) {
				if (A0) {
					ans = 0;
				} else {
					ans = (ll)A01 * B1e9;
				}
			} else {
				ans = 0;
			}
		}
	} else if (B01e9 != 0) {
		if (A01e9 != 0) {
			ans = (ll)A01e9 * B01;
		} else if (A1e9 != 0) {
			if (A0) {
				ans = 0;
			} else {
				ans = (ll)A1 * B01e9;
			}
		} else {
			ans = 0;
		}
	} else {
		ans = 0;
	}
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	n = read(), m = read(), q = read();
	for (int i = 1; i <= n; ++i) {
		a[i] = read();
	}
	for (int i = 1; i <= m; ++i) {
		b[i] = read();
	}
	BuildA(1, n, 1);
	BuildB(1, n, 1);
	while (q--) {
		l1 = read(), r1 = read(), l2 = read(), r2 = read();
		Deal();
		write(ans);
		putchar('\n');
	}
	return 0;
} 
