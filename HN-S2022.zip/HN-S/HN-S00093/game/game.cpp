#include<bits/stdc++.h>
#define int long long
using namespace std;
struct T{
    int mi,ma,zmi,fma,z,f;
}t[2][400005];
int n,m,k,a[2][100005];
T merge(T x,T y){
    T qwq;
    qwq.mi=min(x.mi,y.mi);
    qwq.ma=max(x.ma,y.ma);
    qwq.z=x.z|y.z;
    if(x.z&&y.z)qwq.zmi=min(x.zmi,y.zmi);
    else if(x.z)qwq.zmi=x.zmi;
    else if(y.z)qwq.zmi=y.zmi;
    qwq.f=x.f|y.f;
    if(x.f&&y.f)qwq.fma=max(x.fma,y.fma);
    else if(x.f)qwq.fma=x.fma;
    else if(y.f)qwq.fma=y.fma;
    return qwq;
}
void pushup(int bh,int x){
    t[bh][x]=merge(t[bh][x<<1],t[bh][x<<1|1]);
}
void build(int bh,int x,int l,int r){
    if(l==r){
        t[bh][x].mi=t[bh][x].ma=a[bh][l];
        if(a[bh][l]>=0)t[bh][x].z=1,t[bh][x].zmi=a[bh][l];
        if(a[bh][l]<=0)t[bh][x].f=1,t[bh][x].fma=a[bh][l];
        return;
    }
    int mid=l+r>>1;
    build(bh,x<<1,l,mid);
    build(bh,x<<1|1,mid+1,r);
    pushup(bh,x);
}
T query(int bh,int x,int l,int r,int ll,int rr){
    if(ll<=l&&r<=rr)return t[bh][x];
    int mid=l+r>>1;
    if(rr<=mid)return query(bh,x<<1,l,mid,ll,rr);
    if(mid<ll)return query(bh,x<<1|1,mid+1,r,ll,rr);
    return merge(query(bh,x<<1,l,mid,ll,rr),query(bh,x<<1|1,mid+1,r,ll,rr));
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%lld%lld%lld",&n,&m,&k);
    for(int i=1;i<=n;i++)
        scanf("%lld",&a[0][i]);
    for(int i=1;i<=m;i++)
        scanf("%lld",&a[1][i]);
    build(0,1,1,n);
    build(1,1,1,m);
    int l1,r1,l2,r2;
    for(int i=1;i<=k;i++){
        scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
        T x=query(0,1,1,n,l1,r1),y=query(1,1,1,m,l2,r2);
        int ans=0;
        if(y.f==0){
            if(x.z)ans=x.ma*y.mi;
            else ans=x.fma*y.ma;
        }
        else if(y.z==0){
            if(x.f)ans=x.mi*y.ma;
            else ans=x.zmi*y.mi;
        }
        else {
            if(x.f&&x.z)ans=max(x.fma*y.ma,x.zmi*y.mi);
            else if(x.f)ans=x.fma*y.ma;
            else ans=x.zmi*y.mi;
        }
        printf("%lld\n",ans);
    }
    return 0;
}
