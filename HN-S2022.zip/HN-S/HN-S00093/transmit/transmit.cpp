#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,e,d[200005],fa[200005],beg[400005],nex[400005],to[400005],a[200005],dp[200005];
vector<int>p,q;
void add(int x,int y){
    to[++e]=y;
    nex[e]=beg[x];
    beg[x]=e;
}
void dfs(int x,int f){
    d[x]=d[f]+1;
    fa[x]=f;
    for(int i=beg[x];i;i=nex[i])
        if(to[i]!=f)dfs(to[i],x);
}
void getxl(int x,int y){
    vector<int>().swap(p);
    vector<int>().swap(q);
    while(d[x]>d[y])p.push_back(x),x=fa[x];
    while(d[y]>d[x])q.push_back(y),y=fa[y];
    while(x!=y)p.push_back(x),x=fa[x],q.push_back(y),y=fa[y];
    p.push_back(x);
    int l=q.size();
    for(int i=l-1;i>=0;i--)
        p.push_back(q[i]);
}
signed main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    srand(time(0));
    scanf("%lld%lld%lld",&n,&m,&k);
    for(int i=1;i<=n;i++)
        scanf("%lld",&a[i]);
    int x,y;
    for(int i=1;i<n;i++)
        scanf("%lld%lld",&x,&y),add(x,y),add(y,x);
    int rt=rand()%n+1;
    dfs(rt,0);
    while(m--){
        scanf("%lld%lld",&x,&y);
        getxl(x,y);
        int l=p.size();
        dp[0]=a[p[0]];
        for(int i=1;i<l;i++){
            dp[i]=dp[max(0ll,i-k)]+a[p[i]];
            for(int j=max(0ll,i-k+1);j<=i;j++)
                dp[i]=min(dp[i],dp[j]+a[p[i]]);
        }
        printf("%lld\n",dp[l-1]);
    }
    return 0;
}
/*
样例2是啥玩意啊 看都没看懂 自闭了 939363946 怎么来的啊
*/
