#include<bits/stdc++.h>
using namespace std;
int n,m,q,ans;
set<int>in[500005],out[500005],iin[500005],oout[500005];
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    scanf("%d%d",&n,&m);
    int op,x,y,f;
    for(int i=1;i<=m;i++)
        scanf("%d%d",&x,&y),iin[y].insert(x),oout[x].insert(y),in[y].insert(x),out[x].insert(y);
    for(int i=1;i<=n;i++)
        if(out[i].size()==1)ans++;
    scanf("%d",&q);
    while(q--){
        scanf("%d",&op);
        if(op==1){
            scanf("%d%d",&y,&x);
            in[x].erase(y);
            f=out[y].size();
            if(f==1)ans--;
            else if(f==2)ans++;
            out[y].erase(x);
        }
        if(op==2){
            scanf("%d",&x);
            for(auto y:in[x]){
                f=out[y].size();
                if(f==1)ans--;
                else if(f==2)ans++;
                out[y].erase(x);
            }
            set<int>().swap(in[x]);
        }
        if(op==3){
            scanf("%d%d",&y,&x);
            in[x].insert(y);
            f=out[y].size();
            if(f==1)ans--;
            else if(f==0)ans++;
            out[y].insert(x);
        }
        if(op==4){
            scanf("%d",&x);
            in[x]=iin[x];
            for(auto y:in[x]){
                f=out[y].size();
                if(f==1)ans--;
                else if(f==0)ans++;
                out[y].insert(x);
            }
        }
        if(ans==n)puts("YES");
        else puts("NO");
    }
    return 0;
}
/*
大样例 1.5s
*/
