#include<bits/stdc++.h>
using namespace std;
int n,m,k,e,ans,a[2505],dp[2505][2505],f[2505][4],to[1000005],nex[1000005],beg[1000005];
queue<pair<int,int> >q;
void add(int x,int y){
    to[++e]=y;
    nex[e]=beg[x];
    beg[x]=e;
}
void bfs(int n){
    q.push(make_pair(n,0));
    dp[n][n]=1;
    while(!q.empty()){
        int x=q.front().first,y=q.front().second;
        q.pop();
        for(int i=beg[x];i;i=nex[i])
            if(dp[n][to[i]]==0&&y!=k)
                dp[n][to[i]]=1,q.push(make_pair(to[i],y+1));
    }
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    k++;
    for(int i=2;i<=n;i++)
        scanf("%d",&a[i]);
    int x,y;
    for(int i=1;i<=m;i++)
        scanf("%d%d",&x,&y),add(x,y),add(y,x);
    for(int i=1;i<=n;i++)
        bfs(i);
    for(int i=2;i<=n;i++)
        if(dp[1][i])
            for(int j=2;j<=n;j++)
                if(dp[i][j]&&i!=j){
                    if(a[f[j][3]]<a[i])f[j][3]=i;
                    if(a[f[j][2]]<a[f[j][3]])swap(f[j][2],f[j][3]);
                    if(a[f[j][1]]<a[f[j][2]])swap(f[j][1],f[j][2]);
                }
    for(int i=2;i<=n;i++)
        if(f[i][1])
            for(int j=2;j<=n;j++)
                if(f[j][1]&&dp[i][j]&&i!=j)
                    for(int ii=1;ii<=3;ii++)
                        if(f[i][ii]&&f[i][ii]!=j)
                            for(int jj=1;jj<=3;jj++)
                                if(f[j][jj]&&f[j][jj]!=i&&f[i][ii]!=f[j][jj])
                                    ans=max(ans,a[i]+a[j]+a[f[i][ii]]+a[f[j][jj]]);
    printf("%d\n",ans);
    return 0;
}
