#include<bits/stdc++.h>
using namespace std;
long long n,m,p,a[100001],b[100001];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>p;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int j=1;j<=m;j++)
		cin>>b[j];
	for(long long az=1;az<=p;az++)
	{
		long long l1,l2,r1,r2;
		cin>>l1>>r1>>l2>>r2;
		long long f=-1000000000000000000;
		for(long long i=l1;i<=r1;++i)
		{
			long long z=1000000000000000000;
			for(long long j=l2;j<=r2;++j)
			{
				long long x=a[i]*b[j];
				z=min(z,x);
			}
			f=max(f,z);
		}
		cout<<f<<endl;
	}
	return 0;
}
