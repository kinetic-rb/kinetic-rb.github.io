#include<bits/stdc++.h>
using namespace std;
int n,m,k,ans=-1,f[10001];
struct Node{
	int v,to,back;
}a[10001];
void dfs(int i,int x,int sum)
{
	if(x==3)
	{
		ans=sum;
		return;
	}
	int a1=0,a2=a[i].to,j,flag1,flag2;
	for(int kk=1;kk<=k+1;kk++)
	{
		if(f[a2]==0 && a[a2].v>a1)
		{
			a1=a[a2].v;
			flag1=a2;
		}
		a2=a[a2].to;
	}
	int a3=a[i].back;
	for(int kk=1;kk<=k+1;kk++)
	{
		if(f[a3]==0 && a[a3].v>a1)
		{
			a1=a[a3].v;
			flag2=a3;
		}
		a3=a[a3].back;
	}
	if(a[flag2].v>a[flag1].v)j=flag2;
	else j=flag1;
	f[j]=1;
	dfs(j,++x,sum+=a[j].v);
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n-1;++i)
		cin>>a[i].v;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		a[x].to=y;
		a[y].back=x;
	}
	f[1]=1;
	dfs(1,1,a[1].v);
	cout<<ans;
	return 0;
}
