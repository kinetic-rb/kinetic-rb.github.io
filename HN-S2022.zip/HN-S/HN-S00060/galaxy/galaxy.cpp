#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	return 0;
}

