#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,q,zmax=-9999,mmin=9999,x=-9999,y=-9999;
	cin>>n>>m>>q;
	long long a[n+5]={0},b[m+5]={0},c[n+5][m+5]={0},d[q+5][50]={0};
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&d[i][1],&d[i][2],&d[i][3],&d[i][4]);
	}
	if(d[1][1]==d[1][2]){
		for(int i=1;i<=q;i++){
			for(int k=1;k<=m;k++){
				c[d[i][1]][k]=a[d[i][1]]*b[k];
			}
		}
		for(int i=1;i<=q;i++){
			mmin=9999;
			for(int k=d[i][3];k<=d[i][4];k++){
				if(c[d[i][1]][k]<mmin){
					mmin=c[d[i][1]][k];
				}
			}
			cout<<mmin;
		}
	}else if(d[1][3]==d[1][4]){
		for(int i=1;i<=q;i++){
			for(int k=1;k<=n;k++){
				c[k][d[i][1]]=a[k]*b[d[i][1]];
			}
		}
		for(int i=1;i<=q;i++){
			mmin=-9999;
			for(int k=d[i][1];k<=d[i][2];k++){
				if(c[k][d[i][3]]>mmin){
					mmin=c[k][d[i][3]];
				}
			}
			cout<<mmin;
		}
	}else{
		for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;i++){
		zmax=-9999,mmin=9999;
		for(int j=d[i][1];j<=d[i][2];j++){
			mmin=9999;
			for(int k=d[i][3];k<=d[i][4];k++){
				if(c[j][k]<mmin){
					mmin=c[j][k];
				}
			}
			if(mmin>zmax){
				zmax=mmin;
			}
		}
		cout<<zmax;
		cout<<endl;
	}
	
	}
	
	return 0;
}

