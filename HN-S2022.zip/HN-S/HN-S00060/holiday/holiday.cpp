#include <bits/stdc++.h>
using namespace std;
void ss(int x,int c);
int s[506],cs;
int n,m,k,bmax=0,i,j,q1,q2,f,g,cc,maxx=-1,mx,la=0;
long long q=0;
long long fs[2500]={0};
bool a[2505][2505]={0};
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	bmax=5*k+4;
	for(i=2;i<n+1;i++){
		scanf("%d",&f);
		fs[i]=f;
	}
	for(i=0;i<m;i++){
		scanf("%d %d",&q1,&q2);
		a[q1][q2]=1;
		if(q1==1){
			cs++;
		}
	}
	ss(1,0);
	for(int i=0;i<=3;i++){
		maxx=-1;
		la=mx;
		mx=0;
		for(int j=1;j<=bmax;j++){
			if(s[j]>maxx&&mx-la<=k+1){
				maxx=s[j];
				mx=j;
			}
		}
		cc+=maxx;
		s[mx]=0;
	}
	cout<<cc+1; 
	
	return 0;
}

void ss(int x,int c){
	int li[2000]={0},cnt=0;
	if(x==1&&c!=0){
		return ;
	}
	for(int i=2;i<=n;i++){
		if(a[x][i]==1){
			li[cnt]=i;
			cnt++;
		}
	}
	if(fs[x]>=s[c]){
		s[c]=fs[x];
	}
	c++;
	if(c>=bmax){
		s[c]=0;
		c--;
	}else{
		for(int i=0;i<=cnt;i++){
			ss(li[cnt-i],c);
		}
	}
	c--;
}

