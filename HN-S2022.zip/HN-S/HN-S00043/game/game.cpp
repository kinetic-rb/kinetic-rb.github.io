#include<bits/stdc++.h>
#define int long long
using namespace std;
bool Begin;
const int max_n=100005,inf=LONG_LONG_MAX;
inline int read(){
    int x=0;bool w=0;char c=getchar();
    while(c<'0' || c>'9') w|=c=='-',c=getchar();
    while(c>='0' && c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return w?-x:x;
}
inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10^48);
}

int n,m,N,Q,a[max_n],b[max_n];

int lg[max_n];
struct ST{
    int mx[20][max_n],mn[20][max_n],zhmn[20][max_n],fumx[20][max_n];
    bool fu[20][max_n],zh[20][max_n],zr[20][max_n];
    inline void init(int n,int *a){
        for(int i=1;i<=n;++i){
            mx[0][i]=mn[0][i]=a[i];
            fu[0][i]=(a[i]<0),zh[0][i]=(a[i]>=0),zr[0][i]=(a[i]==0);
            zhmn[0][i]=(a[i]>0?a[i]:inf),
            fumx[0][i]=(a[i]<0?a[i]:-inf);
        }
        for(int j=1;j<=lg[n];++j)
            for(int i=1;i+(1<<j)-1<=n;++i){
                mx[j][i]=max(mx[j-1][i],mx[j-1][i+(1<<(j-1))]),
                mn[j][i]=min(mn[j-1][i],mn[j-1][i+(1<<(j-1))]);
                fu[j][i]=(fu[j-1][i]|fu[j-1][i+(1<<(j-1))]),
                zh[j][i]=(zh[j-1][i]|zh[j-1][i+(1<<(j-1))]),
                zr[j][i]=(zr[j-1][i]|zr[j-1][i+(1<<(j-1))]);
                fumx[j][i]=max(fumx[j-1][i],fumx[j-1][i+(1<<(j-1))]),
                zhmn[j][i]=min(zhmn[j-1][i],zhmn[j-1][i+(1<<(j-1))]);
            }
    }
    inline int Askmax(int l,int r){
        int k=lg[r-l+1];
        return max(mx[k][l],mx[k][r-(1<<k)+1]);
    }
    inline int Askmin(int l,int r){
        int k=lg[r-l+1];
        return min(mn[k][l],mn[k][r-(1<<k)+1]);
    }
    inline bool Askneg(int l,int r){
        int k=lg[r-l+1];
        return (fu[k][l]|fu[k][r-(1<<k)+1]);
    }
    inline bool Askpos(int l,int r){
        int k=lg[r-l+1];
        return (zh[k][l]|zh[k][r-(1<<k)+1]);
    }
    inline bool Askzer(int l,int r){
        int k=lg[r-l+1];
        return (zr[k][l]|zr[k][r-(1<<k)+1]);
    }
    inline int Askposmin(int l,int r){
        int k=lg[r-l+1];
        return min(zhmn[k][l],zhmn[k][r-(1<<k)+1]);
    }
    inline int Asknegmax(int l,int r){
        int k=lg[r-l+1];
        return max(fumx[k][l],fumx[k][r-(1<<k)+1]);
    }
}sta,stb;

bool End;
#define File "game"
signed main(){
    freopen(File ".in","r",stdin),
    freopen(File ".out","w",stdout);
    // cerr<<"Memory : "<<(&Begin-&End)/1024.0/1024<<'\n';
    n=read(),m=read(),Q=read(),N=max(n,m);
    for(int i=1;i<=n;++i)
        a[i]=read();
    for(int i=1;i<=m;++i)
        b[i]=read();
    for(int i=2;i<=N;++i)
        lg[i]=lg[i>>1]+1;
    sta.init(n,a),stb.init(m,b);
    while(Q--){
        int l1=read(),r1=read(),l2=read(),r2=read(),x,y;
        bool fn=sta.Askneg(l1,r1),fm=stb.Askneg(l2,r2);
        bool zn=sta.Askpos(l1,r1),zm=stb.Askpos(l2,r2);
        bool on=sta.Askzer(l1,r1),om=stb.Askzer(l2,r2);
        if(!fn && !fm){
            x=sta.Askmax(l1,r1),y=stb.Askmin(l2,r2);
            // cerr<<"sol1 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(!zn && !zm){
            x=sta.Askmin(l1,r1),y=stb.Askmax(l2,r2);
            // cerr<<"sol2 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(!fn){
            x=sta.Askmin(l1,r1),y=stb.Askmin(l2,r2);
            // cerr<<"sol3 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(!zn){
            x=sta.Askmax(l1,r1),y=stb.Askmax(l2,r2);
            // cerr<<"sol4 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(!fm){
            x=sta.Askmax(l1,r1),y=stb.Askmin(l2,r2);
            // cerr<<"sol5 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(!zm){
            x=sta.Askmin(l1,r1),y=stb.Askmax(l2,r2);
            // cerr<<"sol6 "<<x<<" "<<y<<"\n";
            write(x*y),putchar('\n');
            continue;
        }
        if(on){
            // cerr<<"sol7 "<<"\n";
            puts("0");
            continue;
        }
        else{
            int xa=sta.Askposmin(l1,r1),xb=sta.Asknegmax(l1,r1);
            int ya=stb.Askmin(l2,r2),yb=stb.Askmax(l2,r2);
            // cerr<<"sol8 "<<xa<<" "<<ya<<" | "<<xb<<" "<<yb<<"\n";
            write(max(xa*ya,xb*yb)),putchar('\n');
        }
    }
    return 0;
}
/*

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

0
-2
3
2
-1

3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

0
4

*/