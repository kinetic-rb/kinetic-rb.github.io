#include<bits/stdc++.h>
// #define int long long
using namespace std;
bool Begin;
const int max_n=500005;
inline int read(){
    int x=0;bool w=0;char c=getchar();
    while(c<'0' || c>'9') w|=c=='-',c=getchar();
    while(c>='0' && c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return w?-x:x;
}
inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10^48);
}
struct Graph{
    int hd[max_n],to[max_n<<1],nx[max_n<<1],ln[max_n<<1],ct;
    Graph(){ct=1;}
    inline void add(int u,int v,int w){
        nx[++ct]=hd[u],hd[u]=ct,to[ct]=v,ln[ct]=w;
    }
}e;

int n,m,Q;
struct Oper{
    int tp,x,y;
    Oper(int Tp=0,int X=0,int Y=0):tp(Tp),x(X),y(Y){}
}q[max_n];

struct Edge{
    int u,v;
    Edge(int U=0,int V=0):u(U),v(V){}
}g[max_n];
vector< pair<int,int> > in[max_n];
map< pair<int,int>,int > mp;

int deg[max_n];
bool del[max_n],vis[max_n];

namespace Data1_8{
    int dog[max_n],to[max_n];
    stack<int> st;
    bool tor[max_n];
    inline void dfs(int u){
        st.emplace(u);
        vis[u]=1;
        int v=to[u];
        if(vis[v]){
            if(tor[v]) return void(tor[u]=1);
            while(st.top()!=v){
                int tp=st.top();st.pop();
                tor[tp]=1;
            }
            tor[v]=tor[u]=1;
            st.pop();
            return;
        }
        dfs(v);
        tor[u]=tor[v];
    }
    inline bool Check(){
        for(int i=1;i<=n;++i){
            deg[i]=dog[i]=0;
            vis[i]=tor[i]=0;
        }
        for(int i=1;i<=m;++i) if(!del[i]){
            to[g[i].u]=g[i].v;
            ++deg[g[i].u],++dog[g[i].v];
        }
        for(int i=1;i<=n;++i) if(deg[i]!=1)
            return 0;
        for(int i=1;i<=n;++i) if(!dog[i] && !vis[i]){
            while(!st.empty()) st.pop();
            dfs(i);
        }
        while(!st.empty()) st.pop();
        for(int i=1;i<=n;++i) if(!vis[i]){
            dfs(i);
            if(!st.empty()) return 0;
        }
        for(int i=1;i<=n;++i) if(!tor[i])
            return 0;
        return 1;
    }
    inline void sol(){
        for(int i=1;i<=Q;++i){
            int tp=q[i].tp,x=q[i].x,y=q[i].y;
            if(tp==1){
                int id=mp[make_pair(x,y)];
                del[id]=1;
            }
            if(tp==2){
                for(auto p:in[x])
                    del[p.second]=1;
            }
            if(tp==3){
                int id=mp[make_pair(x,y)];
                del[id]=0;
            }
            if(tp==4){
                for(auto p:in[x])
                    del[p.second]=0;
            }
            puts(Check()?"YES":"NO");
        }
    }
}

bool SPop24=1,SPop123=1;

struct SegmentTree{
    int L[max_n<<2],R[max_n<<2];
    int mn[max_n<<2],mx[max_n<<2];
    #define ls(x) (x<<1)
    #define rs(x) (x<<1|1)
    inline void pushup(int x){
        mn[x]=min(mn[ls(x)],mn[rs(x)]),
        mx[x]=max(mx[ls(x)],mx[rs(x)]);
    }
    inline void build(int x,int l,int r){
        L[x]=l,R[x]=r;
        if(l==r) return void(mn[x]=mx[x]=deg[l]);
        int mid=(l+r)>>1;
        build(ls(x),l,mid),build(rs(x),mid+1,r);
        pushup(x);
    }
    inline void update(int x,int pos,int val){
        if(L[x]==R[x]){
            mn[x]+=val,mx[x]+=val;
            return;
        }
        int mid=(L[x]+R[x])>>1;
        update(pos<=mid?ls(x):rs(x),pos,val);
        pushup(x);
    }
}seg;

set<int> s[max_n],t[max_n];
namespace Data9_10{
    inline void sol(){
        seg.build(1,1,n);
        for(int i=1;i<=m;++i)
            s[g[i].v].emplace(g[i].u);
        for(int i=1;i<=Q;++i){
            int tp=q[i].tp,x=q[i].x,y=q[i].y;
            if(tp==1){
                seg.update(1,x,-1);
                s[y].erase(x),t[y].emplace(x);
            }
            if(tp==2){
                for(auto y:s[x]){
                    seg.update(1,y,-1);
                    t[x].emplace(y);
                }
                s[x].clear();
            }
            if(tp==3){
                seg.update(1,x,1);
                s[y].emplace(x),t[y].erase(x);
            }
            if(tp==4){
                for(auto y:t[x]){
                    seg.update(1,y,1);
                    s[x].emplace(y);
                }
                t[y].clear();
            }
            puts((seg.mx[1]==1 && seg.mn[1]==1)?"YES":"NO");
        }
    }
}

bool End;
#define File "galaxy"
signed main(){
    freopen(File ".in","r",stdin),
    freopen(File ".out","w",stdout);
    // cerr<<"Memory : "<<(&Begin-&End)/1024.0/1024<<'\n';
    n=read(),m=read();
    for(int i=1;i<=m;++i){
        int u=read(),v=read();
        e.add(u,v,i),e.add(v,u,-i);
        g[i]=Edge(u,v),mp[make_pair(u,v)]=i;
        in[v].emplace_back(u,i),++deg[u];
    }
    Q=read();
    for(int i=1;i<=Q;++i){
        q[i].tp=read(),q[i].x=read();
        if(q[i].tp&1) q[i].y=read();
        else{
            q[i].y=0;
            SPop24=0;
            if(q[i].tp==4) SPop123=0;
        }
    }
    if(n<=1000 && m<=10000 && Q<=1000)
        return Data1_8::sol(),0;
    // if(SPop24 || SPop123)
        return Data9_10::sol(),0;
    return 0;
}