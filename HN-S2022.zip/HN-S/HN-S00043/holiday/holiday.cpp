#include<bits/stdc++.h>
#define int long long
using namespace std;
bool Begin;
const int max_n=2503,max_m=10004;
inline int read(){
    int x=0;bool w=0;char c=getchar();
    while(c<'0' || c>'9') w|=c=='-',c=getchar();
    while(c>='0' && c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return w?-x:x;
}
inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10^48);
}
struct Graph{
    int hd[max_n],to[max_m<<1],nx[max_m<<1],ct;
    Graph(){ct=1;}
    inline void add(int u,int v){
        nx[++ct]=hd[u],hd[u]=ct,to[ct]=v;
    }
}e;

int n,m,K,ans,a[max_n];

int dis[max_n][max_n];
queue<int> q;
inline void bfs(int rt){
    q.emplace(rt);
    dis[rt][rt]=0;
    while(!q.empty()){
        int u=q.front();q.pop();
        if(dis[rt][u]==K+1) continue;
        for(int i=e.hd[u];i;i=e.nx[i]){
            int v=e.to[i];
            if(dis[rt][v]>dis[rt][u]+1){
                dis[rt][v]=dis[rt][u]+1;
                q.emplace(v);
            }
        }
    }
}

vector<int> g[max_n],vec;

int vit[max_n],fr[4][max_n];

inline bool Check(int a,int b,int c,int d){
    return (c && d && a!=c && a!=d && b!=c && b!=d && c!=d);
}

bool End;
#define File "holiday"
signed main(){
    freopen(File ".in","r",stdin),
    freopen(File ".out","w",stdout);
    // cerr<<"Memory : "<<(&Begin-&End)/1024.0/1024<<'\n';
    n=read(),m=read(),K=read();
    for(int i=2;i<=n;++i)
        a[i]=read();
    for(int i=1;i<=m;++i){
        int u=read(),v=read();
        e.add(u,v),e.add(v,u);
    }
    memset(dis,0x3f,sizeof(dis));
    int inf=**dis;
    for(int i=1;i<=n;++i)
        bfs(i);
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j) if(i!=j)
            if(dis[i][j]<inf)
                g[i].emplace_back(j);
    }
    for(auto u:g[1])
        for(auto v:g[u]) if(u!=v && v!=1){
            ++vit[v];
            if(a[u]>a[fr[0][v]])
                fr[3][v]=fr[2][v],fr[2][v]=fr[1][v],fr[1][v]=fr[0][v],fr[0][v]=u;
            else if(a[u]>a[fr[1][v]])
                fr[3][v]=fr[2][v],fr[2][v]=fr[1][v],fr[1][v]=u;
            else if(a[u]>a[fr[2][v]])
                fr[3][v]=fr[2][v],fr[2][v]=u;
            else if(a[u]>a[fr[3][v]])
                fr[3][v]=u;
        }
    for(int i=2;i<=n;++i) if(vit[i])
        vec.emplace_back(i);
    int _n=vec.size();
    for(int x=0,u=vec[x];x<_n;u=vec[++x])
        for(int y=x+1,v=vec[y];y<_n;v=vec[++y]) if(dis[u][v]<inf)
            for(int i=0;i<4;++i)
                for(int j=0;j<4;++j) if(Check(u,v,fr[i][u],fr[j][v]))
                    ans=max(ans,a[u]+a[v]+a[fr[i][u]]+a[fr[j][v]]);
    write(ans),putchar('\n');
    return 0;
}
/*

8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

27

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

7

*/