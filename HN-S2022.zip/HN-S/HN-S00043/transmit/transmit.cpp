#include<bits/stdc++.h>
#define int long long
using namespace std;
bool Begin;
const int max_n=200005,inf=1000000000000015LL;
inline int read(){
    int x=0;bool w=0;char c=getchar();
    while(c<'0' || c>'9') w|=c=='-',c=getchar();
    while(c>='0' && c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return w?-x:x;
}
inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10^48);
}
struct Graph{
    int hd[max_n],to[max_n<<1],nx[max_n<<1],ct;
    Graph(){ct=1;}
    inline void add(int u,int v){
        nx[++ct]=hd[u],hd[u]=ct,to[ct]=v;
    }
}e;

int n,Q,K,a[max_n];

vector<int> son[max_n];
int fa[max_n],sz[max_n],hs[max_n],dep[max_n],dis[max_n];
inline void dfs1(int u,int F=0){
    fa[u]=F,sz[u]=1,dep[u]=dep[F]+1,dis[u]=dis[F]+a[u];
    for(int i=e.hd[u];i;i=e.nx[i]){
        int v=e.to[i];
        if(v==F) continue;
        son[u].emplace_back(v);
        dfs1(v,u);
        sz[u]+=sz[v];
        if(sz[v]>sz[hs[u]])
            hs[u]=v;
    }
}
int dfn[max_n],pos[max_n],cntd,top[max_n];
inline void dfs2(int u,int tp){
    top[u]=tp,dfn[u]=++cntd,pos[cntd]=u;
    if(hs[u]) dfs2(hs[u],tp);
    for(int i=e.hd[u];i;i=e.nx[i]){
        int v=e.to[i];
        if(v==fa[u] || v==hs[u]) continue;
        dfs2(v,v);
    }
}
inline int LCA(int x,int y){
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        x=fa[top[x]];
    }
    return dep[x]>dep[y]?y:x;
}

namespace Data12_13{
    inline void sol(){
        while(Q--){
            int s=read(),t=read(),lca=LCA(s,t);
            write(dis[s]+dis[t]-dis[lca]-dis[fa[lca]]),putchar('\n');
        }
    }
}
int val[max_n],f[max_n],gt[max_n];
namespace Data1_11{
    int m;
    inline void sol(){
        while(Q--){
            int x=read(),y=read(),lca=LCA(x,y),ls=-1;
            m=0;
            while(x!=lca){
                ++m;
                val[m]=a[x],gt[m]=inf;
                for(auto v:son[x]) if(v!=ls)
                    gt[m]=min(gt[m],a[v]);
                ls=x,x=fa[x];
            }
            int tmpx=ls,tmp=m;
            ls=-1;
            while(y!=lca){
                ++m;
                val[m]=a[y],gt[m]=inf;
                for(auto v:son[y]) if(v!=ls)
                    gt[m]=min(gt[m],a[v]);
                ls=y,y=fa[y];
            }
            int tmpy=ls;
            ++m;
            val[m]=a[lca],gt[m]=inf;
            for(auto v:son[lca]) if(v!=tmpx && v!=tmpy)
                gt[m]=min(gt[m],a[v]);
            for(int i=tmp+1,j=m;i<j;++i,--j)
                swap(val[i],val[j]);

            // for(int i=1;i<=m;++i) cerr<<val[i]<<" ";cerr<<"\n";
        
            f[1]=val[1],f[2]=val[1]+val[2];
            for(int i=2;i<=m;++i){
                f[i]=f[i-1]+val[i];
                if(K>=2 && i>=3) f[i]=min(f[i],f[i-2]+val[i]);
                if(K>=3 && i>=4) f[i]=min(f[i],f[i-3]+val[i]);
                if(K>=3 && i>=5) f[i]=min(f[i],f[i-4]+val[i]+gt[i-2]);
            }
            write(f[m]),putchar('\n');
        }
    }
}

bool End;
#define File "transmit"
signed main(){
    freopen(File ".in","r",stdin),
    freopen(File ".out","w",stdout);
    // cerr<<"Memory : "<<(&Begin-&End)/1024.0/1024<<'\n';
    n=read(),Q=read(),K=read();
    for(int i=1;i<=n;++i)
        a[i]=read();
    for(int i=1;i<n;++i){
        int u=read(),v=read();
        e.add(u,v),e.add(v,u);
    }
    dfs1(1),dfs2(1,1);
    if(K==1) return Data12_13::sol(),0;
    // if(n<=2000 && Q<=2000)
        return Data1_11::sol(),0;
    return 0;
}
/*

7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

12
12
3


10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7

1221097936
1086947276
1748274667
887646183
939363946
900059971
964517506
1392379601
992068897
541763489


*/