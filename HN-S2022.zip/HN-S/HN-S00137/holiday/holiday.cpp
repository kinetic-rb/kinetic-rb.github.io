#include <algorithm>
#include <cstdio>

const int maxn = 2.5e3 + 5;
const int maxm = 1e4 + 5;

struct node
{
	int nxt, to;
}edge[ maxm << 1 ];

int head[ maxn ], cnt;

void add_edge( int u, int v )
{
	edge[ ++ cnt ].nxt = head[ u ];
	edge[ cnt ].to = v;
	head[ u ] = cnt;
}

struct Node
{
	int f;
	unsigned long long val;
}aha[ maxn ][ 2 ];

unsigned long long a[ maxn ][ maxn ], ans;
int n, m, k, tcnt;
unsigned long long val[ maxn ];
bool vis[ maxn ];

void dfs( int now, int t, unsigned long long sum, int first )
{
	if( t == k + 1 )
	{
		return;
	}
	
	for( int i = head[ now ]; i; i = edge[ i ].nxt )
	{
		int to = edge[ i ].to;
		
		dfs( to, t + 1, sum, first );
		
		if( !vis[ to ] )
		{
			if( first != - 1 )
			{
				a[ to ][ first ] = std::max( sum + val[ to ], a[ first ][ to ] );
				
				continue;
			}
			
			vis[ to ] = true;
			
			dfs( to, 0, val[ to ], to );
		
			vis[ to ] = false;
		}
	}
}

void dfs2( int now, int t, int top )
{
	if( t <= k )
	{
		if( now != top )
		{
			if( aha[ now ][ 0 ].f != top && aha[ top ][ 0 ].f != now && aha[ now ][ 0 ].f != aha[ top ][ 0 ].f )
			{
				ans = std::max( ans, aha[ now ][ 0 ].val + aha[ top ][ 0 ].val );
			}
			else
			{
				if( aha[ now ][ 0 ].f != top && aha[ top ][ 1 ].f != now && aha[ top ][ 1 ].f != aha[ now ][ 0 ].f )
				{
					ans = std::max( ans, aha[ now ][ 0 ].val + aha[ top ][ 1 ].val );
				}
				if( aha[ now ][ 1 ].f != top && aha[ top ][ 0 ].f != now && aha[ top ][ 0 ].f != aha[ now ][ 1 ].f )
				{
					ans = std::max( ans, aha[ now ][ 1 ].val + aha[ top ][ 0 ].val );
				}
				if( aha[ now ][ 1 ].f != top && aha[ top ][ 1 ].f != now && aha[ top ][ 1 ].f != aha[ now ][ 1 ].f )
				{
					ans = std::max( ans, aha[ now ][ 1 ].val + aha[ top ][ 1 ].val );
				}
			}
		}
	}
	
	if( t >= k )
	{
		return;
	}
	
	for( int i = head[ now ]; i; i = edge[ i ].nxt )
	{
		int to = edge[ i ].to;
		
		dfs2( to, t + 1, top );
	}
}

int main()
{
	freopen( "holiday.in", "r", stdin );
	freopen( "holiday.out", "w", stdout );
	
	scanf( "%d%d%d", &n, &m, &k );
	
	for( int i = 2; i <= n; ++ i )
	{
		scanf( "%llu", val + i );
	}
	
	for( int i = 1; i <= m; ++ i )
	{
		int x, y;
		
		scanf( "%d%d", &x, &y );
		
		add_edge( x, y );
		add_edge( y, x );
	}
	
	vis[ 1 ] = true;
	
	dfs( 1, 0, 0, -1 );
	
	for( int i = 1; i <= n; ++ i )
	{
		for( int j = 1; j <= n; ++ j )
		{
			if( aha[ i ][ 0 ].val < a[ i ][ j ] && i != j )
			{
				aha[ i ][ 1 ] = aha[ i ][ 0 ];
				
				aha[ i ][ 0 ] = { j, a[ i ][ j ] };
			}
			else if( aha[ i ][ 1 ].val < a[ i ][ j ] && i != j )
			{
				aha[ i ][ 1 ] = { j, a[ i ][ j ] };
			}
		}
	}
	
	for( int i = 2; i <= n; ++ i )
	{
		dfs2( i, -1, i );
	}
	
	printf( "%llu\n", ans );
	
	return 0;
}
