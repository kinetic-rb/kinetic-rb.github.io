#include <algorithm>
#include <cstdio>

const int maxn = 2e5 + 5;

int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	
	while( ch < '0' || '9' < ch )
	{
		if( ch == '-' )
		{
			f = -1;
		}
		ch = getchar();
	}
	
	while( '0' <= ch && ch <= '9' )
	{
		x = ( x << 1 ) + ( x << 3 ) + ch - 48;
		ch = getchar();
	}
	
	return x * f;
}

struct node
{
	int nxt, to;
}edge[ maxn << 1 ];

int head[ maxn ], cnt;

void add_edge( int u, int v )
{
	edge[ ++ cnt ].nxt = head[ u ];
	edge[ cnt ].to = v;
	head[ u ] = cnt;
}

int n, q, k, s, t;
long long v[ maxn ];
long long ans;

void dfs( int now, int fa, long long sum, int cnt )
{
	if( cnt > k || sum > ans )
	{
		return;
	}
	
	if( now == t )
	{
		ans = std::min( ans, sum );
		
		return;
	}
	
	for( int i = head[ now ]; i; i = edge[ i ].nxt )
	{
		int to = edge[ i ].to;
		
		if( to == fa )
		{
			continue;
		}
		
		if( cnt != 0 )
		dfs( to, now, sum + v[ now ], 1 );
		dfs( to, now, sum, cnt + 1 );
	}
}

int main()
{
	freopen( "transmit.in", "r", stdin );
	freopen( "transmit.out", "w", stdout );
	
	n = read(), q = read(), k = read();
	
	for( int i = 1; i <= n; ++ i )
	{
		v[ i ] = read();
	}
	for( int i = 1; i < n; ++ i )
	{
		int x, y;
		
		x = read(), y = read();
		
		add_edge( x, y );
		add_edge( y, x );
	}
	
	while( q -- )
	{
		ans = 0x3fffffffffffffff;
		
		s = read(), t = read();
		
		dfs( s, -1, 0, 0 );
		
		printf( "%lld\n", ans + v[ t ] + v[ s ] );
	}
	
	return 0;
}
