#include <algorithm>
#include <cstdio>

const int maxn = 1e3 + 5;

template< class T >
inline T abs( T x )
{
	if( x < 0 )
	{
		return -x;
	}
	return x;
}

int n, m, q;
int a[ 2 ][ maxn ];

struct node
{
	int max, min, bclose, mclose;
};

namespace Tree
{
#define ls rt << 1
#define rs rt << 1 | 1
	
	int max[ 2 ][ maxn << 2 ], min[ 2 ][ maxn << 2 ],
		bclose[ 2 ][ maxn << 2 ], mclose[ 2 ][ maxn << 2 ];
	
	void Push_up( int rt, int k )
	{
		max[ k ][ rt ] = std::max( max[ k ][ ls ], max[ k ][ rs ] );
		min[ k ][ rt ] = std::min( min[ k ][ ls ], min[ k ][ rs ] );
		bclose[ k ][ rt ] = std::min( bclose[ k ][ ls ], bclose[ k ][ rs ] );
		mclose[ k ][ rt ] = std::max( mclose[ k ][ ls ], mclose[ k ][ rs ] );
	}
		
	void Build( int l, int r, int rt, int k )
	{
		if( l == r )
		{
			max[ k ][ rt ] = min[ k ][ rt ] = a[ k ][ l ];
			if( a[ k ][ l ] >= 0 )
			{
				bclose[ k ][ rt ] = a[ k ][ l ];
			}
			if( a[ k ][ l ] <= 0 )
			{
				mclose[ k ][ rt ] = a[ k ][ l ];
			}
			
			return ;
		}
		
		int mid = ( l + r ) >> 1;
		
		Build( l, mid, ls, k );
		Build( mid + 1, r, rs, k );
		
		Push_up( rt, k );
	}
	
	node Query( int l, int r, int rt, int L, int R, int k )
	{
		if( L <= l && r <= R )
		{
			return { max[ k ][ rt ], min[ k ][ rt ], bclose[ k ][ rt ], mclose[ k ][ rt ] };
		}
		
		int mid = ( l + r ) >> 1, tmp = 0;
		node res, res1, res2;
		
		if( L <= mid )
		{
			res1 = Query( l, mid, ls, L, R, k );
			tmp += 1;
		}
		if( R > mid )
		{
			res2 = Query( mid + 1, r, rs, L, R, k );
			tmp += 2;
		}
		
		if( tmp == 1 )
		{
			return res1;
		}
		if( tmp == 2 )
		{
			return res2;
		}
		
		res.max = std::max( res1.max, res2.max );
		res.min = std::min( res1.min, res2.min );
		res.bclose = std::min( res1.bclose, res2.bclose );
		res.mclose = std::max( res1.mclose, res2.mclose );
		
		return res;
	}
	
#undef ls
#undef rs
}

int main()
{
	freopen( "game.in", "r", stdin );
	freopen( "game.out", "w", stdout );
	
	int l1, r1, l2, r2;
	
	scanf( "%d%d%d", &n, &m, &q );
	
	for( int i = 1; i <= n; ++ i )
	{
		scanf( "%d", a[ 0 ] + i );
	}
	for( int i = 1; i <= m; ++ i )
	{
		scanf( "%d", a[ 1 ] + i );
	}
	
	std::fill( Tree::max[ 0 ], Tree::max[ 0 ] + 8 * maxn, -0x3fffffff );
	std::fill( Tree::min[ 0 ], Tree::min[ 0 ] + 8 * maxn, 0x3fffffff );
	std::fill( Tree::mclose[ 0 ], Tree::mclose[ 0 ] + 8 * maxn, -0x3fffffff );
	std::fill( Tree::bclose[ 0 ], Tree::bclose[ 0 ] + 8 * maxn, 0x3fffffff );
	
	Tree::Build( 1, n, 1, 0 );
	Tree::Build( 1, m, 1, 1 );
	
	for( int i = 1; i <= q; ++ i )
	{
		scanf( "%d%d%d%d", &l1, &r1, &l2, &r2 );
		
		node tmp1 = Tree::Query( 1, n, 1, l1, r1, 0 ),
			 tmp2 = Tree::Query( 1, m, 1, l2, r2, 1 );
		
		if( tmp2.min < 0 )
		{
			if( tmp1.min < 0 )
			{
				if( tmp2.max > 0 )
				{
					long long ans = -0x3fffffffffffffff;
					
					if( tmp1.bclose != 0x3fffffff )
					{
						ans = std::max( ans, 1ll * tmp1.bclose * tmp2.min );
					}
					if( tmp1.mclose != -0x3fffffff )
					{
						ans = std::max( ans, 1ll * tmp1.mclose * tmp2.max );
					}
					
					printf( "%lld\n", ans );
				}
				else
				{
					printf( "%lld\n", 1ll * tmp2.max * tmp1.min );
				}
			}
			else
			{
				printf( "%lld\n", 1ll * tmp2.min * tmp1.bclose );
			}
		}
		else
		{
			if( tmp1.max < 0 )
			{
				printf( "%lld\n", 1ll * tmp2.max * tmp1.max );
			}
			else
			{
				printf( "%lld\n", 1ll * tmp2.min * tmp1.max );
			}
		}
	}
	
	return 0;
}
