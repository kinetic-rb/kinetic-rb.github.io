#include <cstdio>

const int maxn = 5e5 + 5;

int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	
	while( ch < '0' || '9' < ch )
	{
		if( ch == '-' )
		{
			f = -1;
		}
		ch = getchar();
	}
	
	while( '0' <= ch && ch <= '9' )
	{
		x = ( x << 1 ) + ( x << 3 ) + ch - 48;
		ch = getchar();
	}
	
	return x * f;
}

struct node
{
	int nxt, to;
}edge[ maxn << 1 ];

int head[ maxn ], cnt;

void add_edge( int u, int v )
{
	edge[ ++ cnt ].nxt = head[ u ];
	edge[ cnt ].to = v;
	head[ u ] = cnt;
}

int n, m, q, k, u, v;

int main()
{
	freopen( "galaxy.in", "r", stdin );
	freopen( "galaxy.out", "w", stdout );
	
	n = read(), m = read();
	
	for( int i = 1; i <= m; ++ i )
	{
		u = read(), v = read();
		
		add_edge( u, v );
	}
	
	q = read();
	
	for( int i = 1; i <= q; ++ i )
	{
		k = read();
		
		if( k == 1 )
		{
			u = read(), v = read();
		}
		if( k == 2 )
		{
			u = read();
		}
		if( k == 3 )
		{
			u = read(), v = read();
		}
		if( k == 4 )
		{
			u = read();
		}
		
		puts( "NO" );
	}
	
	return 0;
}
