#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=10010;
const int M=10010;
ll sou[N],sum,mmax,n,m,k,a[N][N],flag[N],sc[N];
int ab(int xxx){
	if(xxx<=1)return 2;
	else return xxx;
}
int dfs(int q,int last){
	if(sou[q]!=0)return sou[q];
	if(sum>=4){
		mmax=max(mmax,sou[last]+sc[q]);
		return 0;
	}
	for(int i=2;i<=m;i++){
		if(a[q][i]!=1 || i==q ||flag[i]!=0)continue;
		else{
			sum++;
			flag[i]=1;
			sou[q]=sc[q]+sou[last];
			dfs(i,q);
			flag[i]=0;
			sum--;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)cin>>sc[i];
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		if(x>y)swap(x,y);
		a[x][y]=1;
		for(int j=1;j<=k;j++){
			if(x+j<=m)a[x+j][y]=1;
			if(x-j>0)a[x-j][y]=1;
			if(y+j<=m)a[x][y+j]=1;
			if(y-j>0)a[x][y-j]=1;
		}
	}
	dfs(1,0);
	cout<<mmax;
	return 0;
}
