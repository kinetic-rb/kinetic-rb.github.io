#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,q,a[100010],b[100010],c[10010][10010],l1,r1,l2,r2,mmin=1000000001,mmax=-10000000001;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int j=1;j<=m;j++)cin>>b[j];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(int x=1;x<=q;x++){
		cin>>l1>>r1>>l2>>r2;
		mmax=-10000000001;
		for(int i=l1;i<=r1;i++){
			mmin=1000000001;
			for(int j=l2;j<=r2;j++){
				mmin=min(mmin,c[i][j]);
			}
			mmax=max(mmax,mmin);
		}
		cout<<mmax<<"\n";
	}
	return 0;
}
