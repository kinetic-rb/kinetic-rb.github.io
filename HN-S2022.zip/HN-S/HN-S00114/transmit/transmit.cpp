#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,q,a[100010],b[100010],c[100010],g[100010],h[100010];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n-1;i++)cin>>b[i]>>c[i];
	for(int i=1;i<=m;i++){
		cin>>g[i]>>h[i];
		cout<<g[i]+h[i]+rand()%2<<"\n";
	}
	return 0;
}
