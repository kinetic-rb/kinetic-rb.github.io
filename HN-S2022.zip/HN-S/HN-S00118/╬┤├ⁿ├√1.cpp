#include<iostream>
using namespace std;
struct iamakingioi{
	int v,next;
}_[1000005];
int tail[1000005],tot=1;
void add(int u,int v){
	_[tail[u]].v=v;
	_[tail[u]].next=tot;
	tail[u]=tot;
	tot++;
}
int main(){
	freopen("0.in","r",stdin);
	freopen("0.out","w",stdout);
	int n,m,i,u,v;
	cin>>n>>m;
	for(i=1;i<=n;i++){
		head[i]=1;
	}
	for(i=0;i<m;i++){
		scanf("%d %d",&u,&v);
		add(u,v);
		add(v,u);
	}
	
	return 0;
}
