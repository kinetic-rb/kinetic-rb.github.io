#include<iostream>
#include<cstdlib>
using namespace std;
int main(){
	srand(362363);
	freopen("holiday.in","w",stdout);
	int n=300,m=1000,i;
	cout<<n<<" "<<m<<" "<<1<<endl;
	for(i=1;i<n;i++){
		cout<<10000000000000000ll-rand()<<" ";
	}
	cout<<endl;
	for(i=0;i<m;i++){
		cout<<rand()%n+1<<" "<<rand()%n+1<<endl;
	}
	return 0;
}
