#include<iostream>
using namespace std;
struct iamakingioi{
	int v,next;
}_[1000005];
int tail[1000005],tot=1;
void add(int u,int v){
//	cout<<"u="<<u<<",v="<<v<<endl;
	_[tail[u]].v=v;
	_[tail[u]].next=tot;
	tail[u]=tot;
	tot++;
}
int a[1000005],mark[1000005],nowid,maxdis; //nowid��ʾ��ǰö�ٵ���ʼ�㡣
bool can[5005][5005]; 
void dfs(int ceng,int asdf){
	if(ceng>maxdis+1){
		return;
	}
//	cout<<"��"<<ceng<<"��,asdf="<<asdf<<endl; 
	mark[asdf]=nowid;
	can[nowid][asdf]=1;
	int i;
	for(i=asdf;i!=tail[asdf];i=_[i].next){
//		cout<<"v="<<_[i].v<<endl;
		if(mark[_[i].v]!=nowid){
			dfs(ceng+1,_[i].v);
		}
	}
}
int max0[1000005],max1[1000005],max2[1000005]; //��¼��š� 
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,i,j,u,v,maxid=0,Max=0,ykb;
	cin>>n>>m>>maxdis;
	for(i=1;i<=n;i++){
		tail[i]=i;
		max0[i]=max1[i]=max2[i]=n+1;
	}
//	for(i=2;i<=n;i++){
//		cout<<i<<" ";
//	}
//	cout<<endl;
	for(i=2;i<=n;i++){
		scanf("%d",a+i);
//		cout<<a[i]<<" ";
	}
//	cout<<endl;
	tot=n+1;
	for(i=0;i<m;i++){
		scanf("%d %d",&u,&v);
		add(u,v);
		add(v,u);
	}
//	for(i=1;i<=n;i++){
//		cout<<i<<"|";
//		for(j=i;j!=tail[i];j=_[j].next){
//			cout<<_[j].v<<" ";
//		}
//		cout<<endl;
//	}
	for(nowid=1;nowid<=n;nowid++){
//		cout<<"------nowid="<<nowid<<"----------"<<endl;
		dfs(0,nowid);
		can[nowid][nowid]=0;
	}
//	for(i=1;i<=n;i++){
//		for(j=1;j<=n;j++){
//			cout<<can[i][j];
//		}
//		cout<<endl;
//	}
	for(i=2;i<=n;i++){ //1->i->j 
		if(can[1][i]){
			for(j=2;j<=n;j++){
				if(can[i][j]){
					if(a[i]>a[max0[j]]){
						max2[j]=max1[j];
						max1[j]=max0[j];
						max0[j]=i;
					}else if(a[i]>a[max1[j]]){
						max2[j]=max1[j];
						max1[j]=i;
					}else{
						max2[j]=i;
					}
				}
			}
		}
	}
//	for(i=2;i<=n;i++){
//		cout<<"i="<<i<<",max:"<<max0[i]<<" "<<max1[i]<<" "<<max2[i]<<endl;
//	}
	for(i=2;i<=n;i++){
		if(max0[i]!=n+1){
			for(j=2;j<=n;j++){
				if(i!=j&&max0[i]!=j&&can[i][j]){
					cout<<"i="<<i<<",j="<<j<<endl;
					if(max0[j]!=n+1&&max0[j]!=max0[i]&&max0[j]!=i){
						cout<<"|	[0]1->"<<max0[i]<<"->"<<i<<"->"<<j<<"->"<<max0[j]<<"->1,ֵ:"<<a[max0[i]]+a[i]+a[max0[j]]+a[j]<<endl;
						Max=max(Max,a[max0[i]]+a[i]+a[j]+a[max0[j]]);
					}else if(max1[j]!=n+1&&max1[j]!=max0[i]&&max1[j]!=i){
						cout<<"|	[1]1->"<<max0[i]<<"->"<<i<<"->"<<j<<"->"<<max1[j]<<"->1,ֵ:"<<a[max0[i]]+a[i]+a[max1[j]]+a[j]<<endl;
						Max=max(Max,a[max0[i]]+a[i]+a[j]+a[max1[j]]);
					}else if(max2[j]!=n+1&&max2[j]!=max0[i]&&max2[j]!=i){
						cout<<"|	[2]1->"<<max0[i]<<"->"<<i<<"->"<<j<<"->"<<max2[j]<<"->1,ֵ:"<<a[max0[i]]+a[i]+a[max2[j]]+a[j]<<endl;
						Max=max(Max,a[max0[i]]+a[i]+a[j]+a[max2[j]]);
					}
				}
			}
		}
	}
	cout<<Max;
	return 0;
}
/*
����1: 
i=2,max:3 8 9
i=3,max:2 9 9
i=4,max:2 3 9
i=5,max:3 7 9
i=6,max:8 7 9
i=7,max:8 9 9
i=8,max:2 7 9
*/
