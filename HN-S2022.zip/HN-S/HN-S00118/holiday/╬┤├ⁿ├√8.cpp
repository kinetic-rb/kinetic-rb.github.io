#include<iostream>
using namespace std;
struct iamakingioi{
	int v,next;
}_[1000005];
int tail[1000005],tot=1;
void add(int u,int v){
//	cout<<"u="<<u<<",v="<<v<<endl;
	_[tail[u]].v=v;
	_[tail[u]].next=tot;
	tail[u]=tot;
	tot++;
}
long long a[1000005];
int mark[1000005],nowid,maxdis,qid[1000005],qdis[1000005],l=0,r=1; //nowid��ʾ��ǰö�ٵ���ʼ�㡣
bool can[5005][5005]; 
//#define I if(nowid==91)
//void dfs(int ceng,int asdf){
//	if(ceng>maxdis+1){
//		return;
//	}
//	cout<<"��"<<ceng<<"��,asdf="<<asdf<<endl; 
//	mark[asdf]=nowid;
//	can[nowid][asdf]=1;
//	int i;
//	for(i=asdf;i!=tail[asdf];i=_[i].next){
//		cout<<"asdf="<<asdf<<",v="<<_[i].v<<",mark="<<mark[_[i].v]<<endl;
//		if(mark[_[i].v]!=nowid){
//			cout<<"iakioi"<<endl;
//			dfs(ceng+1,_[i].v);
//		}
//	}
//}
void bfs(){
	qid[0]=nowid;
	qdis[0]=0;
	l=0;
	r=1;
	int i;
	mark[nowid]=nowid;
	while(l<r){
//		cout<<"��չ"<<qid[l]<<endl; 
		if(qdis[l]<=maxdis){
			for(i=qid[l];i!=tail[qid[l]];i=_[i].next){
				if(mark[_[i].v]!=nowid){
//					cout<<"v="<<_[i].v<<endl;
					qdis[r]=qdis[l]+1;
					qid[r]=_[i].v;
					r++;
					can[nowid][_[i].v]=1;
					mark[_[i].v]=nowid;
				}
			}
		}
		l++;
	}
}
int max0[1000005],max1[1000005],max2[1000005]; //��¼��š� 
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,i,j,k,u,v;
	long long Max=0;
	cin>>n>>m>>maxdis;
	for(i=1;i<=n;i++){
		tail[i]=i;
		mark[i]=0;
		max0[i]=max1[i]=max2[i]=n+1;
	}
//	for(i=2;i<=n;i++){
//		cout<<i<<" ";
//	}
//	cout<<endl;
	for(i=2;i<=n;i++){
		scanf("%lld",a+i);
//		cout<<a[i]<<" ";
	}
//	cout<<endl;
	tot=n+1;
	for(i=0;i<m;i++){
		scanf("%d %d",&u,&v);
		add(u,v);
		add(v,u);
	}
//	for(i=1;i<=n;i++){
//		cout<<i<<"|";
//		for(j=i;j!=tail[i];j=_[j].next){
//			cout<<_[j].v<<" ";
//		}
//		cout<<endl;
//	}
	for(nowid=1;nowid<=n;nowid++){
//		cout<<"------nowid="<<nowid<<"----------"<<endl;
		bfs();
		can[nowid][nowid]=0;
	}
//	for(i=1;i<=n;i++){
//		for(j=1;j<=n;j++){
//			if(can[i][j]!=can[j][i]){
//				cout<<"i="<<i<<",j="<<j<<","<<can[i][j]<<can[j][i]<<endl;
//			}
//		}
//	}
//	for(i=1;i<=n;i++){
//		for(j=1;j<=n;j++){
//			cout<<can[i][j];
//		}
//		cout<<endl;
//	}
	for(i=2;i<=n;i++){ //1->i->j 
		if(can[1][i]){
			for(j=2;j<=n;j++){
				if(can[i][j]){
					if(a[i]>a[max0[j]]){
						max2[j]=max1[j];
						max1[j]=max0[j];
						max0[j]=i;
					}else if(a[i]>a[max1[j]]){
						max2[j]=max1[j];
						max1[j]=i;
					}else{
						max2[j]=i;
					}
				}
			}
		}
	}
//	for(i=2;i<=n;i++){
//		cout<<"i="<<i<<",max:"<<max0[i]<<" "<<max1[i]<<" "<<max2[i]<<endl;
//	}
	for(i=2;i<=n;i++){
		if(can[1][i]){
			for(j=2;j<=n;j++){
				if(i!=j&&can[i][j]){
					for(k=2;k<=n;k++){
						if(i!=k&&j!=k&&can[j][k]){
							for(l=2;l<=n;l++){
								if(i!=l&&j!=l&&k!=l&&can[k][l]&&can[l][1]){
//									if(i==139&&j==205&&k==143&&l==95){
//										cout<<i<<","<<j<<","<<k<<","<<l<<","<<a[i]+a[j]+a[k]+a[l]<<endl;
//									}
									Max=max(Max,a[i]+a[j]+a[k]+a[l]);
								}
							}
						}
					}
				}
			}
		}
	}
	cout<<Max;
	return 0;
}
/*
����1: 
i=2,max:3 8 9
i=3,max:2 9 9
i=4,max:2 3 9
i=5,max:3 7 9
i=6,max:8 7 9
i=7,max:8 9 9
i=8,max:2 7 9

in:
7 10 1
4 4 2 5 1 5 
3 7
4 1
2 1
6 6
6 3
6 1
1 6
3 6
5 3
5 6
����:
can[5][1]��ӦΪ1,����⵽0�� 
*/
