#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long a[1000005],b[1000005];
long long query_min(long long *ar,int l,int r,int hao){ //hao:����,0��1�� 
	int i;
//	cout<<"l="<<l<<",r="<<r<<endl;
	long long Min=1234567890;
	for(i=l;i<=r;i++){
//		cout<<"i="<<i<<endl;
		if(hao==2||((ar[i]>0)^hao)){
//			cout<<"i="<<i<<endl;
			Min=min(Min,(long long)abs(ar[i]));
		}
	}
	return Min;
}
long long query_max(long long *ar,int l,int r,int hao){
	int i;
	long long Max=0;
	for(i=l;i<=r;i++){
		if(hao==2||((ar[i]>0)^hao)){
			Max=max(Max,(long long)abs(ar[i]));
		}
	}
	return Max;
}
int sa[1000005],sb[1000005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,i,j,la,lb,ra,rb,ykb;
	cin>>n>>m>>q;
	for(i=1;i<=n;i++){
		scanf("%lld",a+i);
	}
	for(i=1;i<=m;i++){
		scanf("%lld",b+i);
	}
	for(i=1;i<=n;i++){
		sa[i]=sa[i-1]+(a[i]>0);
	}
	for(i=1;i<=m;i++){
		sb[i]=sb[i-1]+(b[i]>0);
	}
	for(i=0;i<q;i++){
		scanf("%d %d %d %d",&la,&ra,&lb,&rb);
//		cout<<"la="<<la<<",ra="<<ra<<",lb="<<lb<<",rb="<<rb<<endl;
		if(sb[rb]-sb[lb-1]==rb-lb+1){ //bȫ��������
//			cout<<"iakioi"<<endl; 
			if(sa[ra]-sa[la-1]==0){ //aȫ�Ǹ����� 
				cout<<-query_min(a,la,ra,0)*query_max(b,lb,rb,1)<<endl;
			}else{
//				cout<<"iakioi"<<endl;
				cout<<query_max(a,la,ra,1)*query_min(b,lb,rb,1)<<endl;
			}
		}else if(sb[rb]-sb[lb-1]==0){ //bȫ�Ǹ��� 
			if(sa[ra]-sa[la-1]==ra-la+1){ //aȫ������ 
				cout<<-query_min(a,la,ra,1)*query_max(b,lb,rb,0)<<endl;
			}else{
				cout<<-query_min(a,la,ra,0)*query_max(b,lb,rb,0)<<endl;
			}
		}else{ //b�����и� 
			cout<<-min(query_min(a,la,ra,0)*query_max(b,lb,rb,1),query_min(a,la,ra,1)*query_max(b,lb,rb,0))<<endl;
		}
	}
	return 0;
}
