#include<bits/stdc++.h>
using namespace std;
inline int read() {
    int x = 0;
    char c = getchar();
    bool f = 0;
    while(!isdigit(c)) f |= (c == '-'), c = getchar();
    while(isdigit(c)) x = (x * 10) + (c ^ 48), c = getchar();
    return f ? -x : x;
}
const int maxn = 5 * 1e5 + 5, maxm = 5 * 1e5 + 5;
int n, m, q;
struct node {
    int u, v, nex, id;
}edge[maxm << 1];
int head[maxn], len, Break[maxm], Du[maxn], tot, Vst[maxn];
vector <int> Vec[maxn];
map < pair<int, int>, int> mapp;
inline void make_map(int u, int v, int id) {
    len++;
    edge[len].nex = head[u];
    edge[len].u = u;
    edge[len].v = v;
    edge[len].id = id;
    head[u] = len;
}
int main() {
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);
    n = read(), m = read();
    for(register int i = 1; i <= m; ++i) {
        int u = read(), v = read();
        make_map(u, v, i), Du[u]++, mapp[make_pair(u, v)] = i;
        Vec[v].push_back(i);
    }
    q = read();
    int Cnt = q;
    while(q--) {
        int op = read(), u = read(), v;
        if(op == 1) v = read(), Break[mapp[make_pair(u, v)]] = 1, Du[u]--;
        if(op == 2) {
            for(register int i = 0; i < Vec[u].size(); ++i) 
                if(!Break[Vec[u][i]]) Break[Vec[u][i]] = 1, Du[edge[Vec[u][i]].u]--;
            if(Cnt >= 1e5) Vec[u].clear();
        }
        if(op == 3) {
            v = read(), Break[mapp[make_pair(u, v)]] = 0, Du[u]++;
            if(Cnt >= 1e5) Vec[v].push_back(mapp[make_pair(u, v)]);
        }
        if(op == 4) {
            for(register int i = 0; i < Vec[u].size(); ++i) 
                if(Break[Vec[u][i]]) Break[Vec[u][i]] = 0, Du[edge[Vec[u][i]].u]++;
        }
        int flag = 0;
        for(register int i = 1; i <= n; ++i)
            if(Du[i] != 1) { printf("NO\n"), flag = 1; break; }
        if(!flag) printf("YES\n");
    }
    return 0;
}

