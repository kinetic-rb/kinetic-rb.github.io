#include<bits/stdc++.h>
using namespace std;
inline int read() {
    int x = 0;
    char c = getchar();
    bool f = 0;
    while(!isdigit(c)) f |= (c == '-'), c = getchar();
    while(isdigit(c)) x = (x * 10) + (c ^ 48), c = getchar();
    return f ? -x : x;
}
const int maxn = 1e5 + 5, INF = 1e9 + 7;
const long long L_INF = 1e18 + 7;
int n, m, q;
int A[maxn], B[maxn];
struct Sigment_Tree {
    struct node {
        int l, r;
        int maxx, minn;
    }Tree[maxn << 2];
    #define lc i << 1
    #define rc i << 1 | 1
    inline void Push_UP(int i) { 
        Tree[i].maxx = max(Tree[lc].maxx, Tree[rc].maxx); 
        Tree[i].minn = min(Tree[lc].minn, Tree[rc].minn);
    }
    inline void Build(int i, int l, int r) {
        Tree[i].l = l, Tree[i].r = r;
        if(l == r) { Tree[i].maxx = -INF, Tree[i].minn = INF; return ; }
        int mid = (l + r) >> 1;
        Build(lc, l, mid), Build(rc, mid + 1, r);
        Push_UP(i);
    }
    inline void Update(int i, int x, int num) {
        if(Tree[i].l == Tree[i].r) { Tree[i].maxx = num, Tree[i].minn = num; return ; }
        if(x <= Tree[lc].r) Update(lc, x, num);
        else Update(rc, x, num);
        Push_UP(i);
    }
    inline int Query(int i, int l, int r, int op) {
        if(Tree[i].l >= l && Tree[i].r <= r) return op ? Tree[i].minn : Tree[i].maxx;
        int Cnt = (op ? INF : -INF);
        if(l <= Tree[lc].r) {
            if(!op) Cnt = max(Cnt, Query(lc, l, r, op));
            else Cnt = min(Cnt, Query(lc, l, r, op));
        }
        if(r >= Tree[rc].l) {
            if(!op) Cnt = max(Cnt, Query(rc, l, r, op));
            else Cnt = min(Cnt, Query(rc, l, r, op));
        }
        return Cnt;
    }
}Maxx_A_Z, Maxx_A_F, Minn_A_Z, Minn_A_F, Maxx_B, Minn_B;
int Zero[maxn];
int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    n = read(), m = read(), q = read();
    Maxx_A_Z.Build(1, 1, n), Maxx_A_F.Build(1, 1, n), Minn_A_Z.Build(1, 1, n), Minn_A_F.Build(1, 1, n), Maxx_B.Build(1, 1, m), Minn_B.Build(1, 1, m);
    for(register int i = 1; i <= n; ++i) {
        A[i] = read();
        if(A[i] > 0) Maxx_A_Z.Update(1, i, A[i]), Minn_A_Z.Update(1, i, A[i]);
        else if(A[i] < 0) Maxx_A_F.Update(1, i, A[i]), Minn_A_F.Update(1, i, A[i]);
        Zero[i] = Zero[i - 1] + (A[i] == 0);
    }
    for(register int i = 1; i <= m; ++i) {
        B[i] = read();
        Maxx_B.Update(1, i, B[i]);
        Minn_B.Update(1, i, B[i]);
    }
    while(q--) {
        int l1 = read(), r1 = read(), l2 = read(), r2 = read();
        long long Cnt1 = 1ll * Maxx_B.Query(1, l2, r2, 0), Cnt2 = 1ll * Minn_B.Query(1, l2, r2, 1), Answer = -L_INF;
        if(Cnt2 < 0) {
            long long Cnt = 1ll * Minn_A_Z.Query(1, l1, r1, 1);
            if(Cnt != INF) Answer = max(Answer, Cnt * Cnt2);
        }
        else {
            long long Cnt = 1ll * Maxx_A_Z.Query(1, l1, r1, 0);
            if(Cnt != -INF) Answer = max(Answer, Cnt * Cnt2);
        }
        if(Cnt1 > 0) {
            long long Cnt = 1ll * Maxx_A_F.Query(1, l1, r1, 0);
            if(Cnt != -INF) Answer = max(Answer, Cnt * Cnt1);
        }
        else {
            long long Cnt = 1ll * Minn_A_F.Query(1, l1, r1, 1);
            if(Cnt != INF) Answer = max(Answer, Cnt * Cnt1);
        }
        if(Zero[r1] - Zero[l1 - 1] > 0) Answer = max(Answer, 0ll);
        printf("%lld\n", Answer);
    }
    return 0;
}

