#include<bits/stdc++.h>
using namespace std;
inline int read() {
    int x = 0;
    char c = getchar();
    bool f = 0;
    while(!isdigit(c)) f |= (c == '-'), c = getchar();
    while(isdigit(c)) x = (x * 10) + (c ^ 48), c = getchar();
    return f ? -x : x;
}
const int maxn = 2505, maxm = 1e4 + 5, INF = 1e9 + 7;
int n, m, k;
long long Val[maxn], Answer;
struct node {
    int v, nex;
}edge[maxm << 1];
int head[maxn], len, Dis[maxn], Vst[maxn], mapp[maxn][maxn];
queue <int> Que;
vector <int> Vec[maxn];
inline void make_map(int u, int v) {
    len++;
    edge[len].nex = head[u];
    edge[len].v = v;
    head[u] = len;
}
inline void Search(int s) {
    while(!Que.empty()) Que.pop();
    memset(Vst, 0, sizeof(Vst)), memset(Dis, 0, sizeof(Dis));
    Que.push(s), Dis[s] = 0, Vst[s] = 1;
    while(!Que.empty()) {
        int x = Que.front(); Que.pop();
        if(Dis[x] == k + 1) continue;
        for(register int i = head[x]; i; i = edge[i].nex) {
            int y = edge[i].v;
            if(Vst[y]) continue;
            Dis[y] = Dis[x] + 1, mapp[s][y] = mapp[y][s] = 1;
            if(s != 1 && mapp[1][y]) Vec[s].push_back(y);
            Vst[y] = 1, Que.push(y);
        }
    }
}
inline bool cmp(int x, int y) { return Val[x] > Val[y]; }
int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
    n = read(), m = read(), k = read();
    for(register int i = 2; i <= n; ++i) Val[i] = read();
    for(register int i = 1; i <= m; ++i) {
        int u = read(), v = read();
        make_map(u, v), make_map(v, u);
    }
    for(register int i = 1; i <= n; ++i) Search(i);
    for(register int i = 1; i <= n; ++i) sort(Vec[i].begin(), Vec[i].end(), cmp);
/*    for(register int i = 1; i <= n; ++i) {
        printf("%d\n", Vec[i].size());
        for(register int j = 0; j < Vec[i].size(); ++j) printf("%d ", Vec[i][j]);
        printf("\n");
    }*/
    for(register int i = 1; i <= n; ++i)
        for(register int j = i + 1; j <= n; ++j) {
            if(!mapp[i][j]) continue;
            int Cnt1 = 0, Cnt2 = 0;
            while(Cnt1 < Vec[i].size() && Vec[i][Cnt1] == j) Cnt1++;
            if(Cnt1 == Vec[i].size()) continue; 
            Cnt1 = Vec[i][Cnt1];
            while(Cnt2 < Vec[j].size() && (Vec[j][Cnt2] == i || Vec[j][Cnt2] == Cnt1)) Cnt2++;
            if(Cnt2 == Vec[j].size()) continue;
            Cnt2 = Vec[j][Cnt2];
            Answer = max(Answer, Val[i] + Val[j] + Val[Cnt1] + Val[Cnt2]);
//            printf("%d %d %d %d\n", i, j, Cnt1, Cnt2);
        }
    printf("%lld\n", Answer);
    return 0;
}

