#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read() {
    int x = 0;
    char c = getchar();
    bool f = 0;
    while(!isdigit(c)) f |= (c == '-'), c = getchar();
    while(isdigit(c)) x = (x * 10) + (c ^ 48), c = getchar();
    return f ? -x : x;
}
const int maxn = 2 * 1e5 + 5, maxm = 2 * 1e5 + 5;
int n, Q, k;
int V[maxn];
struct node {
    int v, nex;
}edge[maxm << 1];
int head[maxn], len;
int Dep[maxn], f[maxn][25], Dis[maxn];
inline void make_map(int u, int v) {
    len++;
    edge[len].nex = head[u];
    edge[len].v = v;
    head[u] = len;
}
inline void Deal_First(int x, int fa) {
    Dep[x] = Dep[fa] + 1, Dis[x] = Dis[fa] + V[x];
    for(register int i = 20; i >= 1; --i) f[x][i] = f[f[x][i - 1]][i - 1];
    for(register int i = head[x]; i; i = edge[i].nex) {
        int y = edge[i].v;
        if(y == fa) continue;
        f[y][0] = x;
        Deal_First(y, x);
    }
}
inline int Get_Lca(int x, int y) {
    if(Dep[x] < Dep[y]) swap(x, y);
    for(register int i = 20; i >= 0; --i) {
        if(Dep[f[x][i]] >= Dep[y]) x = f[x][i];
        if(x == y) return x;
    }
    for(register int i = 20; i >= 0; --i)
        if(f[x][i] != f[y][i]) x = f[x][i], y = f[y][i];
    return f[x][0];
}
inline int Calc(int u, int v) {
    int Lca = Get_Lca(u, v);
    return Dis[u] + Dis[v] - 2 * Dis[Lca] + V[Lca];
}
signed main() {
    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);
    n = read(), Q = read(), k = read();
    for(register int i = 1; i <= n; ++i) V[i] = read();
    for(register int i = 1; i < n; ++i) {
        int u = read(), v = read();
        make_map(u, v), make_map(v, u);
    }
    Deal_First(1, 0);
    while(Q--) {
        int u = read(), v = read();
        printf("%lld\n", Calc(u, v));
    }
    return 0;
}

