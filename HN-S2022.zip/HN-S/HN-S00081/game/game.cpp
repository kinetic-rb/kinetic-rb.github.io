#include<bits/stdc++.h>
#define ls (x<<1)
#define rs (x<<1)|1
using namespace std;
typedef long long LL;
const int N = 1e5+2,inf = 1e9+7;
int n,m,q;
int a[N],b[N];
struct sgt
{
	int typ,t[N<<2];
	void pushup(int x)
	{
		if(typ) t[x] = max(t[ls],t[rs]);
		else t[x] = min(t[ls],t[rs]);
		return;
	}
	void build(int x,int l,int r)
	{
		if(l == r)
		{
			t[x] = (typ?-inf:inf);
			return;
		}
		int mid = (l+r)>>1;
		build(ls,l,mid);
		build(rs,mid+1,r);
		pushup(x);
	}
	void add(int x,int l,int r,int p,int k)
	{
		if(l == r)
		{
			t[x] = k;
			return;
		}
		int mid = (l+r)>>1;
		if(p <= mid) add(ls,l,mid,p,k);
		else add(rs,mid+1,r,p,k);
		pushup(x);
	}
	int ask(int x,int l,int r,int L,int R)
	{
		if(L <= l && r <= R) return t[x];
		int mid = (l+r)>>1,lans = (typ?-inf:inf),rans = (typ?-inf:inf);
		if(L <= mid) lans = ask(ls,l,mid,L,R);
		if(mid < R) rans = ask(rs,mid+1,r,L,R);
		return typ ? max(lans,rans) : min(lans,rans);
	}
}t[2][2],f[2];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i = 1;i <= n;i++)
		scanf("%d",&a[i]);
	for(int i = 1;i <= m;i++)
		scanf("%d",&b[i]);
	t[1][0].typ = 0; t[1][0].build(1,1,n);
	t[1][1].typ = 1; t[1][1].build(1,1,n);
	t[0][0].typ = 0; t[0][0].build(1,1,n);
	t[0][1].typ = 1; t[0][1].build(1,1,n);
	f[0].typ = 0; f[0].build(1,1,m);
	f[1].typ = 1; f[1].build(1,1,m);
	for(int i = 1;i <= n;i++)
	{
		if(a[i] > 0)
		{
			t[1][0].add(1,1,n,i,a[i]);
			t[1][1].add(1,1,n,i,a[i]);
		}
		else
		{
			t[0][0].add(1,1,n,i,a[i]);
			t[0][1].add(1,1,n,i,a[i]);
		}
	}
	for(int i = 1;i <= m;i++)
	{
		f[0].add(1,1,m,i,b[i]);
		f[1].add(1,1,m,i,b[i]);
	}
	for(int i = 1;i <= q;i++)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		LL bmax,bmin;
		bmin = f[0].ask(1,1,m,l2,r2);
		bmax = f[1].ask(1,1,m,l2,r2);
		LL abmin,abmax;
		if(bmin > 0) abmin = t[1][1].ask(1,1,n,l1,r1);
		else abmin = t[1][0].ask(1,1,n,l1,r1);
		if(bmax > 0) abmax = t[0][1].ask(1,1,n,l1,r1);
		else abmax = t[0][0].ask(1,1,n,l1,r1);
		printf("%lld\n",max(bmin*abmin,bmax*abmax));
	}
	return 0;
}
