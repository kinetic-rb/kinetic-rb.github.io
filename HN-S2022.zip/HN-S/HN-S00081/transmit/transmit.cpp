#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N = 2e5+2;
int n,m,k;
int cnt,nxt[N<<1],v[N<<1],h[N];
int q[N],dep[N],f[N];
LL w[N],g[N];
void add(int a,int b)
{
	nxt[++cnt] = h[a];
	v[cnt] = b;
	h[a] = cnt;
	return;
}
void dfs(int x,int fa)
{
	f[x] = fa;
	dep[x] = dep[fa]+1;
	for(int i = h[x];i;i = nxt[i])
	{
		int y = v[i];
		if(y != fa)
			dfs(y,x);
	}
}
int lca(int a,int b,int h,int t)
{
	while(a != b)
		if(dep[a] > dep[b]) { q[h++] = a; a = f[a]; }
		else { q[t--] = b; b = f[b]; }
	q[h] = a;
	return a;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 1;i <= n;i++)
		scanf("%lld",&w[i]);
	for(int i = 1;i < n;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		add(a,b);
		add(b,a);
	}
	dfs(1,0);
	for(int i = 1;i <= m;i++)
	{
		int a,b,c,len;
		scanf("%d%d",&a,&b);
		c = lca(a,b,1,n);
		len = dep[a]+dep[b]-dep[c]-dep[c]+1;
		lca(a,b,1,len);
		for(int j = 1;j <= len;j++)
		{
			LL mnn = g[j-1];
			if(j > 2 && k >= 2) mnn = min(mnn,g[j-2]);
			if(j > 3 && k >= 3) mnn = min(mnn,g[j-3]);
			g[j] = w[q[j]]+mnn;
		}
		printf("%lld\n",g[len]);
	}
	return 0;
}
