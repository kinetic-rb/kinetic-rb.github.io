#include<bits/stdc++.h>
using namespace std;
const int N = 2500+2,M = 20000+2;
const int inf = 4e18+7;
typedef long long LL;
typedef pair<LL,LL> PII;
int n,m,k;
int cnt,nxt[M],v[M],h[N],dis[N];
bool can[N][N],f[N][N];
queue<int> q;
LL ans,w[N];
priority_queue<PII> t[N];
void add(int a,int b)
{
	nxt[++cnt] = h[a];
	v[cnt] = b;
	h[a] = cnt;
	return;
}
void bfs(int s,int lim)
{
	while(q.size()) q.pop();
	q.push(s);
	dis[s] = 0;
	while(q.size())
	{
		int x = q.front();
		q.pop();
		for(int i = h[x];i;i = nxt[i])
		{
			int y = v[i];
			if(dis[y] != -1 || dis[x]+1 > lim) continue;
			dis[y] = dis[x]+1;
			q.push(y);
		}
	}
}
LL calc(PII a,PII b,int x,int y)
{
	int u = a.second,v = b.second;
	if(a.second == -1 || b.second == -1) return -inf;
	if(u == y || v == x || u == v) return -inf;
	return a.first+b.first;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 2;i <= n;i++)
		scanf("%lld",&w[i]);
	for(int i = 1;i <= m;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		add(a,b); add(b,a);
	}
	for(int x = 2;x <= n;x++)
	{
		memset(dis,-1,sizeof(dis));
		bfs(x,k+1);
		for(int y = 2;y <= n;y++)
		{
			if(dis[y] == -1 || x == y) continue;
			f[x][y] = 1;
			can[x][y] = 1;
		}
	}
	memset(dis,-1,sizeof(dis));
	bfs(1,k+1);
	for(int x = 2;x <= n;x++)
		if(dis[x] == -1)
			for(int y = 2;y <= n;y++)
				can[x][y] = 0;
	for(int x = 2;x <= n;x++)
		for(int y = 2;y <= n;y++)
			if(can[x][y] && x != y)
				t[y].push(make_pair(w[x]+w[y],x));
	for(int y = 2;y <= n;y++)
		for(int x = 2;x <= n;x++)
		{
			if(!f[x][y] || !t[x].size() || !t[y].size() || x == y) continue;
			LL now = -inf;
			PII xf,yf,xs,ys,res;
			xf = t[x].top();
			yf = t[y].top();
			xs = ys = make_pair(-1,-1);
			if(t[x].size() > 1) { res = t[x].top(); t[x].pop(); xs = t[x].top(); t[x].push(res); }
			if(t[y].size() > 1) { res = t[y].top(); t[y].pop(); ys = t[y].top(); t[y].push(res); }
			now = max(now,calc(xf,yf,x,y));
			now = max(now,calc(xf,ys,x,y));
			now = max(now,calc(xs,yf,x,y));
			now = max(now,calc(xs,ys,x,y));
			ans = max(ans,now);
		}
	printf("%lld",ans);
	return 0;
}
