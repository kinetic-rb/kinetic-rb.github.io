#include<bits/stdc++.h>
using namespace std;
const int N=1011;
#define ll long long
ll f[N][N][20],fa[3][100010][20],fb[3][100010][20];
ll n,m,q,a[N],b[N],logn[N];
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<=m;i++)cin>>b[i];
    logn[0]=-1;
    for(int i=1;i<=m;i++)logn[i]=logn[i/2]+1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++)f[i][j][0]=a[i]*b[j];
        for(int k=1;k<=19;k++){
            for(int j=1;j+(1<<k)-1<=m;j++){
                f[i][j][k]=min(f[i][j][k-1],f[i][j+(1<<(k-1))][k-1]);
            }
        }
    }
    for(int i=1;i<=n;i++)fa[1][i][0]=fa[2][i][0]=a[i];
    for(int i=1;i<=m;i++)fb[1][i][0]=fb[2][i][0]=b[i];
    for(int k=1;k<=19;k++){
        for(int j=1;j+(1<<k)-1<=n;j++){
            fa[1][j][k]=max(fa[1][j][k-1],fa[1][j+(1<<(k-1))][k-1]);
            fa[2][j][k]=min(fa[2][j][k-1],fa[2][j+(1<<(k-1))][k-1]);
        }
        for(int j=1;j+(1<<k)-1<=m;j++){
            fb[1][j][k]=max(fb[1][j][k-1],fb[1][j+(1<<(k-1))][k-1]);
            fb[2][j][k]=min(fb[2][j][k-1],fb[2][j+(1<<(k-1))][k-1]);
        }
    }   
    for(int i=1;i<=q;i++){
        int l1,r1,l2,r2;
        cin>>l1>>r1>>l2>>r2;
        ll ans=-1000000000000000000;
        if(l1==r1&&n>1000){
            int s=logn[r2-l2+1];
            if(a[l1]<0)cout<<a[l1]*max(fb[1][l2][s],fb[1][r2-(1<<s)+1][s])<<endl;
            else cout<<a[l1]*min(fb[2][l2][s],fb[2][r2-(1<<(s))+1][s])<<endl;
            continue;
        }
        if(l2==r2&n>1000){
            int s=logn[r1-l1+1];
            if(b[l2]<0)cout<<b[l2]*min(fa[2][l1][s],fa[2][r1-(1<<s)+1][s])<<endl;
            else cout<<b[l2]*max(fa[1][l1][s],fa[1][r1-(1<<(s))+1][s])<<endl;
            continue;
        }
        for(int j=l1;j<=r1;j++){
            int s=logn[(r2-l2+1)];
            ans=max(ans,min(f[j][l2][s],f[j][r2-(1<<(s))+1][s]));
            //cout<<ans<<" ";
        }
        cout<<ans<<endl;
    }
    return 0;
}