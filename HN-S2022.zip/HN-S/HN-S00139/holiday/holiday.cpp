#include<bits/stdc++.h>
using namespace std;
const int N=30;
const int M=51;
__int128 read(){
    //cout<<1<<" ";
    __int128 x=0;
    char c;
    c=getchar();
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9'){
        x*=10;
        x+=c-'0';
        c=getchar();
    }
    return x;
}
void write(__int128 x){
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return ;
}
__int128 n,m,a[N],k,f[N][1050010],ans,dis[N];
struct node{
    __int128 to,lt;
}e[M<<1],e2[501010];
__int128 last[N],tot;
void add(__int128 u,__int128 v){
    e[++tot].lt=last[u];
    e[tot].to=v;
    last[u]=tot;
    return ;
}
__int128 last2[N];
void add2(__int128 u,__int128 v){
    e2[++tot].lt=last2[u];
    e2[tot].to=v;
    last2[u]=tot;
    return ;
}
__int128 dfn[N];
void find(__int128 x,__int128 u,__int128 fa,__int128 step){
    dfn[u]=1;
    for(__int128 i=last[u];i;i=e[i].lt){
        __int128 v=e[i].to;
        if(v!=fa&&dfn[v]==0){
            if(step!=0){
                add2(x,v);
            }
            if(step<k)find(x,v,u,step+1);
        }
    }
}
void dfs(__int128 x,__int128 now,__int128 step){
    if(step==4){
        //cout<<f[x][now]<<" ";
        //ans=max(ans,f[x][now]);
        dis[x]=max(dis[x],f[x][now]);
        return ;
    }
    //cout<<f[x][now]<<" ";
    for(__int128 i=last[x];i;i=e[i].lt){
        __int128 v=e[i].to;
        //cout<<"u,v:"<<x<<" "<<v<<endl;
        if((now>>(v-1))&1)continue;
        f[v][now+(1<<(v-1))]=f[x][now]+a[v];
        dfs(v,now+(1<<(v-1)),step+1);
    }
    for(__int128 i=last2[x];i;i=e2[i].lt){
        __int128 v=e2[i].to;
        //cout<<"u,v:"<<x<<" "<<v<<endl;
        if((now>>(v-1))&1)continue;
        f[v][now+(1<<(v-1))]=f[x][now]+a[v];
        dfs(v,now+(1<<(v-1)),step+1);
    }
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    n=read(),m=read(),k=read();
    //cout<<n<<" "<<m<<" "<<k<<endl;
    //write(n);
    k=min(k,n);
    for(__int128 i=2;i<=n;i++)a[i]=read();
    for(__int128 i=1;i<=m;i++){
        __int128 u,v;
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    for(__int128 i=1;i<=n;i++){
        for(__int128 j=1;j<=n;j++)dfn[j]=0;
        find(i,i,i,0);
    }
    dfs(1,1,0);
    for(__int128 i=last[1];i;i=e[i].lt){
        __int128 v=e[i].to;
        //cout<<v<<" "<<dis[v]<<endl;
        ans=max(ans,dis[v]);
    }
    for(__int128 i=last2[1];i;i=e2[i].lt){
    	__int128 v=e[i].to;
    	ans=max(ans,dis[v]);
	} 
    write(ans);
    return 0;
}
