#include<bits/stdc++.h>
using namespace std;
const int N=1100;
const int M=1100;
int vis[N],sta[N],tot,dfn[N],id,low[N],n,m,f1[N][N],f2[N][N],f3[N][N],k,q,sum[N];
bool find(int u,int fa){
    if(dfn[u])return true;
    dfn[u]=1;
    bool opt=false;
    for(int v=1;v<=n;v++){
        if(u==v)continue;
        if(f1[u][v]){
            opt=find(v,u);
            break;
        }
    }
    vis[u]=opt;
    return opt;
}
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int u,v;
        cin>>u>>v;
        sum[u]++;
        f1[u][v]=f3[v][u]=1;//f3 表示这条边是否存在
        f2[v][u]=1;//f2 为反边
    }
    cin>>q;
    for(int i=1;i<=q;i++){
        int opt,u,v;
        cin>>opt;
        if(opt==1){
            cin>>u>>v;
            sum[u]--;
            f1[u][v]=0;
            f2[v][u]=0;            
        }
        if(opt==2){
            cin>>u;
            for(int j=1;j<=n;j++){
                if(f2[u][j])f1[j][u]=f2[u][j]=0,sum[j]--;
            }
        }
        if(opt==3){
            cin>>u>>v;
            f1[u][v]=f2[v][u]=1;
            sum[u]++;
        }
        if(opt==4){
            cin>>u;
            for(int j=1;j<=n;j++){
                if(f3[u][j]&&!f1[j][u])f1[j][u]=f2[u][j]=1,sum[j]++;
            }
        }
        bool flag=true;
        for(int j=1;j<=n;j++){
            if(sum[j]>1){
                cout<<"NO"<<endl;
                flag=false;
                break;
            }
        }
        for(int j=1;j<=n;j++)dfn[j]=0,vis[j]=false;
        if(flag){
            for(int j=1;j<=n;j++)
                if(!dfn[j])find(j,j);
            for(int j=1;j<=n;j++){
                if(vis[j]==false){
                    flag=false;
                    break;
                }
            }
            if(flag){
                cout<<"YES"<<endl;
            }
            else cout<<"NO"<<endl;
        }
        //else cout<<"NO"<<endl;
        //cout<<i<<" ";
    }
    return 0;
}