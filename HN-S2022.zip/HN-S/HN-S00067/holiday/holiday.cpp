#include<bits/stdc++.h>
#define mkp make_pair
#define st first
#define nd second
using namespace std;
const int mxn=2600;
inline int read(){
	int x=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x;
}

int n,m,lim,dis[mxn][mxn];
long long a[mxn],ans;
bool vis[mxn];
vector<int>ve[mxn];

void D(int fl,int x,long long val){//need speed up
	if(fl==4){
		if(dis[x][1]) ans=max(ans,val);
		return;
	}
	vis[x]=1;
	for(int i=2;i<=n;i++){
		if(dis[x][i]&&!vis[i]){
			D(fl+1,i,val+a[i]);
			vis[i]=0;
		}
	}
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),lim=read();
	memset(dis,0x3f,sizeof(dis));
	for(int i=2;i<=n;i++)a[i]=read();
	for(int i=1,u,v;i<=m;i++){
		u=read(),v=read();
		ve[u].push_back(v);
		ve[v].push_back(u);
	}

	priority_queue<pair<int,int> >q;
	for(int k=1;k<=n;k++){//dijkstra
		q.push(mkp(0,k));
		dis[k][k]=0;
		while(q.size()){
			int u=q.top().nd;q.pop();
			for(int i=0;i<ve[u].size();i++){
				int v=ve[u][i];
				if(dis[k][v]>dis[k][u]+1){
					dis[k][v]=dis[k][u]+1;
					q.push(mkp(-dis[k][v],v));
				}
			}
		}
	}
	int cnt=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			if(dis[i][j]<=lim+1){
				dis[i][j]=1;
			}
			else dis[i][j]=0;
		}
	D(0,1,0);
	cout<<ans<<endl;
}
//1-A-B-C-D-1
//每两个目标点之间d不超过k+1