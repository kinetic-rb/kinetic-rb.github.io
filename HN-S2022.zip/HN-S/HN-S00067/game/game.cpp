#include<bits/stdc++.h>
using namespace std;
const int mxn=1e5+7;
inline int read(){
	int x=0,s=1;char c=getchar();
	if(c=='-')s=-1;
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*s;
}
struct Node1{
	int l,r;
	int mx,mi;
}t1[4*mxn],t2[4*mxn];
int n,m,q,a[mxn],b[mxn];
void build(int l,int r,int p,Node1 t[],int source[]){
	t[p].l=l,t[p].r=r;
	if(l==r){t[p].mx=t[p].mi=source[l];return;}
	int mid=l+r>>1;
	build(l,mid,p*2,t,source);
	build(mid+1,r,p*2+1,t,source);
	t[p].mx=max(t[p*2].mx,t[p*2+1].mx);
	t[p].mi=min(t[p*2].mi,t[p*2+1].mi);
}
int querymx(int l,int r,int p,Node1 t[]){
	if(l<=t[p].l&&r>=t[p].r)return t[p].mx;
	int mid=t[p].l+t[p].r>>1;
	int tmx=-0x7fffffff;
	if(l<=mid){
		tmx=max(tmx,querymx(l,r,p*2,t));
	}
	if(r>mid){
		tmx=max(tmx,querymx(l,r,p*2+1,t));
	}
	return tmx;
}
int querymi(int l,int r,int p,Node1 t[]){
	if(l<=t[p].l&&r>=t[p].r)return t[p].mi;
	int mid=t[p].l+t[p].r>>1;
	int tmi=0x7fffffff;
	if(l<=mid)
		tmi=min(tmi,querymi(l,r,p*2,t));
	if(r>mid)
		tmi=min(tmi,querymi(l,r,p*2+1,t));
	return tmi;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	build(1,n,1,t1,a);build(1,m,1,t2,b);
	while(q--){
		int l1,r1,l2,r2;
		l1=read(),r1=read(),l2=read(),r2=read();
		if(l1==r1){
			int asel=a[l1],bsel;
			if(asel>0)bsel=querymi(l2,r2,1,t2);
			else bsel=querymx(l2,r2,1,t2);
			// cout<<"bsel "<<bsel<<endl;
			cout<<asel*bsel<<endl;
		}
		else if(l2==r2){
			int bsel=b[l2],asel;
			if(bsel>0)asel=querymx(l1,r1,1,t1);
			else asel=querymi(l1,r1,1,t1);
			// cout<<"asel "<<asel<<endl;
			cout<<asel*bsel<<endl;
		}
		else{
			int amx=querymx(l1,r1,1,t1),bmi=querymi(l2,r2,1,t2);
			cout<<amx*bmi<<endl;
		}
	}
}
/*
6 5 4
7 6 -1 -3 0 4
2 -5 0 6 -1
1 1 1 2
1 2 3 3
2 5 4 4
6 6 1 5

ans:
-35
0
36
-20
*/