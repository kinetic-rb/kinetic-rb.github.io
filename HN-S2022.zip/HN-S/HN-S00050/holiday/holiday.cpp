#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m,k;
int val[2510];
int head[2510],cnt;
int to[10010],nxt[10010];
void add(int x,int y)
{
	to[++cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
vector<int> t[2510];
struct jgt
{
	int id,k;
};
int vis[2510];
queue<jgt> q;
int cn[2510];
void bfs(int xt)
{
	while(!q.empty())
		q.pop();
	memset(vis,0,sizeof(vis));
	jgt lfxx=(jgt){xt,-1};
	q.push(lfxx);
	vis[xt]=1;
	while(!q.empty())
	{
		int x=q.front().id;
		int s=q.front().k;
		q.pop();
		if(s==k)
			continue;
		for(int i=head[x];i;i=nxt[i])
		{			
			int y=to[i];
			if(vis[y]==1)
				continue;
			t[xt].push_back(y);
			jgt a=(jgt){y,s+1};
			q.push(a);
			if(xt==1)
				cn[y]=1;
			vis[y]=1;
		}	
	}
}
int ans=0;
void dfs(int x,int dep,int v)
{
	if(dep==4)
	{
		if(cn[x]==1)
			ans=max(ans,v);
		return ;
	}
	int len=t[x].size();
	for(int i=0;i<len;i++)
	{
		int y=t[x][i];
		if(vis[y]==1) continue;
		vis[y]=1;
		dfs(y,dep+1,v+val[y]);
		vis[y]=0;
	}
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>val[i];
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=n;i++)
		bfs(i);
	memset(vis,0,sizeof(vis));
	vis[1]=1;
	dfs(1,0,0);
	cout<<ans;
	return 0;
} 
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
