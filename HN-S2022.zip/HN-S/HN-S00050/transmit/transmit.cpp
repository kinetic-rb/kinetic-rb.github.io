#include<bits/stdc++.h>
using namespace std;
int val[200010];
int head[200010],cnt;
int to[200010],nxt[200010];
int n,q,k;
void add(int x,int y)
{
	to[++cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
int g,t;
void dfs(int x,int fa,int v)
{
	if(x==t)
	{
		cout<<v<<endl;
		return ;
	}
	for(int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if(fa==y)
			continue;
		dfs(y,x,val[y]+v);
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
		cin>>val[i];
	for(int i=1;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=q;i++)
	{
		cin>>g>>t;
		dfs(g,0,0);
	}
	return 0;
 } 
