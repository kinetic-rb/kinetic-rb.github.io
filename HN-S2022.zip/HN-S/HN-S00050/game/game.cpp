#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int long long 
ll tamx[400010],tamn[400010];
ll tbmx[400010],tbmn[400010];
ll tmn[400010],tmx[400010];
int n,m,q;
ll a[100010],b[100010];
int ls(int x){return x<<1;}
int rs(int x){return x<<1|1;}
struct jgt
{
	ll a,b;
};
jgt myn(jgt x,jgt y)
{
	jgt z;
	z.a=max(x.a,y.a);
	z.b=min(x.b,y.b);
	return z;
}
void upa(int x){tamx[x]=max(tamx[ls(x)],tamx[rs(x)]);tamn[x]=min(tamn[ls(x)],tamn[rs(x)]);}
void builda(int x,int l,int r)
{
	if(l==r)
	{
		tamx[x]=a[l];
		tamn[x]=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	builda(ls(x),l,mid);
	builda(rs(x),mid+1,r);
	upa(x);
}

jgt aska(int x,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)
		return (jgt){tamx[x],tamn[x]};
	int mid=(l+r)>>1;
	jgt ans;
	ans.a=-2000000000000000000;
	ans.b=2000000000000000000;
	if(L<=mid)
		ans=myn(ans,aska(ls(x),l,mid,L,R));
	if(R>mid)
		ans=myn(ans,aska(rs(x),mid+1,r,L,R));
	return ans;
}
void upb(int x){tbmx[x]=max(tbmx[ls(x)],tbmx[rs(x)]);tbmn[x]=min(tbmn[ls(x)],tbmn[rs(x)]);}
void buildb(int x,int l,int r)
{
	if(l==r)
	{
		tbmx[x]=b[l];
		tbmn[x]=b[l];
		return ;
	}
	int mid=(l+r)>>1;
	buildb(ls(x),l,mid);
	buildb(rs(x),mid+1,r);
	upb(x);
}
jgt askb(int x,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)
		return (jgt){tbmx[x],tbmn[x]};
	int mid=(l+r)>>1;
	jgt ans;
	ans.a=-2000000000000000000;
	ans.b=2000000000000000000;
	if(L<=mid)
		ans=myn(ans,askb(ls(x),l,mid,L,R));
	if(R>mid)
		ans=myn(ans,askb(rs(x),mid+1,r,L,R));
	return ans;
}
void up(int x)
{
	tmx[x]=max(tmx[ls(x)],tmx[rs(x)]);
	tmn[x]=min(tmn[ls(x)],tmn[rs(x)]);
}
void build(int x,int l,int r)
{
	if(l==r)
	{
		tmx[x]=-2000000000;
		tmn[x]=2000000000;
		if(a[l]<=0)
			tmx[x]=a[l];
		if(a[r]>=0)
			tmn[x]=a[r];
		return ;
	} 
	int mid=(l+r)>>1;
	build(ls(x),l,mid);
	build(rs(x),mid+1,r);
	up(x);
}
jgt ask(int x,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)
		return (jgt){tmx[x],tmn[x]};
	int mid=(l+r)>>1;
	jgt ans;
	ans.a=-2000000000;
	ans.b=2000000000;
	if(L<=mid)
		ans=myn(ans,ask(ls(x),l,mid,L,R));
	if(R>mid)
		ans=myn(ans,ask(rs(x),mid+1,r,L,R));
	return ans;
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	std::ios::sync_with_stdio(false);
	std::cout.tie(0),std::cin.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=m;i++)
		cin>>b[i];
	builda(1,1,n);
	buildb(1,1,m);
	build(1,1,n);
	while(q--)
	{
		int l,r,x,y;
		cin>>l>>r>>x>>y;
		ll ans=-2000000000000000000;
		jgt d2=askb(1,1,m,x,y);
		if(d2.b>=0||d2.a<=0)
		{
			jgt d1=aska(1,1,n,l,r);
			ans=max(min(d1.a*d2.b,d1.a*d2.a),min(d1.b*d2.a,d1.b*d2.b));
			cout<<ans<<endl;
		}
		else
		{
			jgt d1=ask(1,1,n,l,r);	
			if(d1.b<=100000000000)
				ans=max(ans,min(d1.b*d2.b,d1.b*d2.a));
			if(d1.a>=-10000000000)
				ans=max(ans,min(d1.a*d2.a,d1.a*d2.b));
			cout<<ans<<endl;
		}
	}
	return 0;
} 
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

32 241 607 800
*/
