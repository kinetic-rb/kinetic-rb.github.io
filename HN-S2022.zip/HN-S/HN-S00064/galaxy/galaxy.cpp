#include <bits/stdc++.h>
using namespace std;
int n,m,q,u,v;
int op,x,y;
vector <int> fa[500003];
vector <int> son[500003];
map <long long,bool> p;
int cu[500003];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		fa[u].push_back(v);
		son[v].push_back(u);
	}
	for (int i=1;i<=n;i++){
		cu[i]=fa[i].size();
	}
	cin>>q;
	while (q--){
		scanf("%d",&op);
		if (op==1){
			scanf("%d%d",&x,&y);
			cu[x]--;
			p[x*1000000+y]=1;
		}
		if (op==2){
			scanf("%d",&x);
			for (int i=0;i<son[x].size();i++){
				int v=son[x][i];
				if (!p[v*1000000+x]){
					cu[v]--;
					p[v*1000000+x]=1;
				}
			}
		}
		if (op==3){
			scanf("%d%d",&x,&y);
			cu[x]++;
			p[x*1000000+y]=0;
		}
		if (op==4){
			scanf("%d",&x);
			for (int i=0;i<son[x].size();i++){
				int v=son[x][i];
				if (p[v*1000000+x]){
					cu[v]++;
					p[v*1000000+x]=0;
				}
			}
		}
		bool ok=true;
		for (int i=1;i<=n;i++){
			if (cu[i]!=1){
				ok=false;
				break;
			}
		}
		if (ok) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}

