#include <bits/stdc++.h>
using namespace std;
int n,m,k,u,v;
int num[2503];
vector <int> son[2503];
int mx;
bool vis[2503];
void dfs(int u,int sum,int len){
	vis[u]=1;
	for (int i=0;i<son[u].size();i++){
		int v=son[u][i];
		if (len==4){
			if (v==1) mx=max(mx,sum);
			continue;
		}
		if (!vis[v]){
			dfs(v,sum+num[v],len+1);
		}
	}
	vis[u]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout); 
	cin>>n>>m>>k;
	for (int i=2;i<=n;i++){
		scanf("%d",&num[i]);
	}
	for (int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		son[u].push_back(v);
		son[v].push_back(u);
	}
	if (k==0){
		dfs(1,0,0);
		cout<<mx;
		return 0;
	}
	else{
		sort(num+2,num+1+n);
		cout<<sum[2]+num[3]+num[4]+num[5];
		return 0;
	}
	return 0;
}

