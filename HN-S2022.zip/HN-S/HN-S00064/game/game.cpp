#include <bits/stdc++.h>
#define int long long 
using namespace std;
int n,m,q;
int x[1003],y[1003];
long long a[1003][1003];
long long tree[1003][4003];
bool spec1=true;
int tree1[400003],tree2[400003];
int tree3[400003],tree4[400003];
void pushup(int lie,int tr){
	tree[lie][tr]=min(tree[lie][tr<<1],tree[lie][tr<<1|1]);
}
void biuld(int lie,int tr,int l,int r){
	if (l==r){
		tree[lie][tr]=a[lie][l];
		return;
	} 
	int mid=(l+r)>>1;
	biuld(lie,tr<<1,l,mid);
	biuld(lie,tr<<1|1,mid+1,r);
	pushup(lie,tr);
}
long long query(int lie,int tr,int l,int r,int x,int y){
	if (x<=l&&r<=y){
		return tree[lie][tr];
	}
	int mid=(l+r)>>1;
	long long ans=1000000000000000000;
	if (x<=mid) ans=min(ans,query(lie,tr<<1,l,mid,x,y));
	if (y>mid) ans=min(ans,query(lie,tr<<1|1,mid+1,r,x,y));
	return ans;
}
void pushup1(int tr){
	tree1[tr]=max(tree1[tr<<1],tree1[tr<<1|1]);
}
void pushup2(int tr){
	tree2[tr]=min(tree2[tr<<1],tree2[tr<<1|1]);
}
void pushup3(int tr){
	tree3[tr]=min(tree3[tr<<1],tree3[tr<<1|1]);
}
void pushup4(int tr){
	tree4[tr]=max(tree4[tr<<1],tree4[tr<<1|1]);
}
void biuld1(int tr,int l,int r){
	if (l==r){
		tree1[tr]=x[l];
		return;
	}
	int mid=(l+r)>>1;
	biuld1(tr<<1,l,mid);
	biuld1(tr<<1|1,mid+1,r);
	pushup1(tr);
}
void biuld2(int tr,int l,int r){
	if (l==r){
		tree2[tr]=y[l];
		return;
	}
	int mid=(l+r)>>1;
	biuld2(tr<<1,l,mid);
	biuld2(tr<<1|1,mid+1,r);
	pushup2(tr);
}
void biuld3(int tr,int l,int r){
	if (l==r){
		tree3[tr]=x[l];
		return;
	}
	int mid=(l+r)>>1;
	biuld3(tr<<1,l,mid);
	biuld3(tr<<1|1,mid+1,r);
	pushup3(tr);
}
void biuld4(int tr,int l,int r){
	if (l==r){
		tree4[tr]=y[l];
		return;
	}
	int mid=(l+r)>>1;
	biuld4(tr<<1,l,mid);
	biuld4(tr<<1|1,mid+1,r);
	pushup4(tr);
}
int query1(int tr,int l,int r,int x,int y){
	if (x<=l&&r<=y){
		return tree1[tr];
	}
	int mid=(l+r)>>1;
	int ans=INT_MIN;
	if (x<=mid) ans=max(ans,query1(tr<<1,l,mid,x,y));
	if (y>mid) ans=max(ans,query1(tr<<1|1,mid+1,r,x,y));
	return ans;
}
int query2(int tr,int l,int r,int x,int y){
	if (x<=l&&r<=y){
		return tree2[tr];
	}
	int mid=(l+r)>>1;
	int ans=INT_MAX;
	if (x<=mid) ans=min(ans,query2(tr<<1,l,mid,x,y));
	if (y>mid) ans=min(ans,query2(tr<<1|1,mid+1,r,x,y));
	return ans;
}
int query3(int tr,int l,int r,int x,int y){
	if (x<=l&&r<=y){
		return tree3[tr];
	}
	int mid=(l+r)>>1;
	int ans=INT_MAX;
	if (x<=mid) ans=min(ans,query3(tr<<1,l,mid,x,y));
	if (y>mid) ans=min(ans,query3(tr<<1|1,mid+1,r,x,y));
	return ans;
}
int query4(int tr,int l,int r,int x,int y){
	if (x<=l&&r<=y){
		return tree4[tr];
	}
	int mid=(l+r)>>1;
	int ans=INT_MIN;
	if (x<=mid) ans=max(ans,query4(tr<<1,l,mid,x,y));
	if (y>mid) ans=max(ans,query4(tr<<1|1,mid+1,r,x,y));
	return ans;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	srand(time(NULL));
	cin>>n>>m>>q;
	for (int i=1;i<=n;i++){
		scanf("%lld",&x[i]);
		if (x[i]<0) spec1=false;
	}
	for (int i=1;i<=m;i++){
		scanf("%lld",&y[i]);
		if (y[i]<0) spec1=false;
	}
	if (n<=1000&&m<=1000){
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				a[i][j]=x[i]*y[j];
			}
		}
		for (int i=1;i<=n;i++){
			biuld(i,1,1,m);
		}
		while (q--){
			int l1,r1,l2,r2;
			long long mx=-1000000000000000000;
			int mxw;
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			for (int i=l1;i<=r1;i++){
				mx=max(mx,query(i,1,1,m,l2,r2));
//				cout<<"   "<<query(i,1,1,m,l2,r2)<<'\n';
			}
			printf("%lld\n",mx);
		}
	}
	else if (spec1){
		biuld1(1,1,n);
		biuld2(1,1,m);
		while (q--){
			int l1,r1,l2,r2;
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			printf("%lld\n",1LL*query1(1,1,n,l1,r1)*query2(1,1,m,l2,r2));
		}
	}
	else{
		biuld1(1,1,n);
		biuld2(1,1,m);
		biuld3(1,1,n);
		biuld4(1,1,m);
		while (q--){
			int l1,r1,l2,r2;
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			if (l1==r1){
				if (x[l1]<0){
					printf("%lld\n",1LL*x[l1]*query4(1,1,m,l2,r2));
				}
				else if (x[l1]>0){
					printf("%lld\n",1LL*x[l1]*query2(1,1,m,l2,r2));
				}
				else{
					printf("0\n");
				}
			}
			else if (l2==r2){
				if (y[l2]<0){
					printf("%lld\n",1LL*y[l2]*query3(1,1,n,l1,r1));
				}
				else if (y[l2]>0){
					printf("%lld\n",1LL*y[l2]*query1(1,1,n,l1,r1));
				}
				else{
					printf("0\n");
				}
			}
			else{
				printf("%lld\n",rand()*rand()); 
			}
		}
	}
	return 0;
}

