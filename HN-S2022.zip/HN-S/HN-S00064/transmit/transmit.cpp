#include <bits/stdc++.h>
using namespace std;
int n,q,k,uu,vv,nummn=INT_MAX;
long long mn;
int num[200003];
bool vis[200003];
vector <int> son[200003];
map <long long,bool> p;
void dfs(int u,int lv,int len,int lim,long long sum){
	vis[u]=1;
	for (int i=0;i<son[u].size();i++){
		int v=son[u][i];
		if (len==lim){
			if (v==lv) mn=min(mn,sum);
			continue;
		}
		dfs(v,lv,len+1,lim,sum+num[v]);
	}
	vis[u]=0;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for (int i=1;i<=n;i++){
		scanf("%d",&num[i]);
		nummn=min(nummn,num[i]);
	}
	for (int i=1;i<=n-1;i++){
		scanf("%d%d",&uu,&vv);
		son[uu].push_back(vv);
		son[vv].push_back(uu);
		p[uu*1000000+vv]=1;
		p[vv*1000000+uu]=1;
	}
	if (k==1){
		while (q--){
			scanf("%d%d",&uu,&vv);
			mn=1000000000000000000;
			dfs(uu,vv,0,k,num[uu]);
			printf("%lld\n",mn);
		}
	}
	else{
		while (q--){
			scanf("%d%d",&uu,&vv);
			printf("%lld\n",num[uu]+num[vv]+(p[uu*1000000+vv]?0:nummn));
		}
	}
	return 0;
}

