#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int v[2505];
int x[10005],y[10005];
int p;
int cnt,ans;
bool vis[2505];
void dfs(int l,int p)
{
	if(p==4)
		for(int i=1;i<=m;i++)
		{
			if(x[i]==l&&y[i]==1)
				ans=max(ans,cnt);
			if(y[i]==l&&x[i]==1)
				ans=max(ans,cnt);
		}
	for(int i=1;i<=m;i++)
	{
		if(x[i]==l&&!vis[y[i]])
		{
			vis[y[i]]=true;
			cnt+=v[y[i]];
			dfs(y[i],p+1);
			vis[y[i]]=false;
			cnt-=v[y[i]];
		}
		if(y[i]==l&&!vis[x[i]])
		{
			vis[x[i]]=true;
			cnt+=v[x[i]];
			dfs(x[i],p+1);
			vis[x[i]]=false;
			cnt-=v[x[i]];
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)	scanf("%d",&v[i]);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&x[i],&y[i]);
	vis[1]=true;
	dfs(1,0);
	printf("%d",ans);
	return 0;
}
