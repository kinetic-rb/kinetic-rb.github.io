#include<bits/stdc++.h>
using namespace std;
const int maxn=1000000000;
int n,m,q;
int a[100005];
int b[100005];
int l1,r1,l2,r2;
int c[1005][1005];
int ans,x;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) 	scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)	scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1)
		{
			ans=maxn;
			for(int i=l2;i<=r2;i++)
				ans=min(ans,c[l1][i]);
			printf("%d\n",ans);
			continue;
		}
		else if(l2==r2)
		{
			ans=-maxn;
			for(int i=l1;i<=r1;i++)
				ans=max(ans,c[i][l2]);
			printf("%d\n",ans);
			continue;
		}
		else
		{
			ans=-maxn;
			for(int i=l1;i<=r1;i++)
			{
				x=maxn;
				for(int j=l2;j<=r2;j++)
					x=min(x,c[i][j]);
				ans=max(ans,x);
			}
			printf("%d\n",ans);
			continue;
		}
	}
	return 0;
}
