#include <bits/stdc++.h>
using namespace std;
#define int long long
int n, m, k, sum, ans;
int a[1000005];
bool cmp(int x, int y)
{
	return x > y;
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w"stdout);
	cin >> n >> m >> k;
	for(register int i = 1; i <= n - 1; i ++)
		cin >> a[i];
	sort(a + 1, a + 1 + n, cmp);
	cout << a[1] + a[2] + a[3] + a[4];
	return 0;
}
