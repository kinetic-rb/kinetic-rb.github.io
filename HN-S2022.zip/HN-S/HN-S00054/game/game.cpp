#include <bits/stdc++.h>
using namespace std;
int n, m, q, a[25], b[25], l1, l2, r1, r2;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i ++)
		cin >> a[i];
	for(int i = 1; i <= m; i ++)
		cin >> b[i];
	for(int i = 1; i <= q; i ++)
	{
		cin >> l1 >> r1 >> l2 >> r2;
		int maxi = -1e9;
		int mini = 1e9;
		for(int j = l1; j <= r1; j ++)
			maxi = max(a[j], maxi);
		for(int j = l2; j <= r2; j ++)
			mini = min(mini, b[j]);
		if(l1 == r1)	
		{
			if(a[l1] >= 0)	cout << a[l1] * mini;
			else//�Ǹ���С��0 
			{
				for(int j = l2; j <= r2; j ++)
					maxi = max(maxi, b[i]);
				cout << a[l1] * maxi << endl;
			}
		}
		else if(l2 == r2)
		{
			if(b[l2] >= 0)	cout << b[l2] * maxi;
			else//QС��0 
			{
				for(int i = l1; i <= r1; i ++)
					mini = min(mini, b[i]);
				cout << a[l2] * mini << endl;
			}
		}
		else	
			cout << maxi * mini << endl; 
	}
	return 0;
}
