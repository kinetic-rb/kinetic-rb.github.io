#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("game.in" , "r" , stdin);
	freopen("game.out" , "w" , stdout);
	cout << 0 << endl << 4;
	return 0;
}
//t2
