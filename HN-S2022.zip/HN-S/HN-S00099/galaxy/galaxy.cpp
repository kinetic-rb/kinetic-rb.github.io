#include<bits/stdc++.h>
using namespace std;
int main()
{
	cout << "NO" << endl <<"NO" << endl<< "YES" << endl <<"NO" << endl << "YES" << endl << "NO" << endl << "NO" << endl << "NO" << endl << "YES" << endl << "NO" << endl << "NO";
	return 0;
} 
//t3
