#include<bits/stdc++.h>
using namespace std;
long long read()
{
	long long x=0,y=1;
	char ch;
	for(;!isdigit(ch);ch=getchar())if(ch=='-')y=-1;
	for(;isdigit(ch);ch=getchar())x=x*10+(ch-48);
	return x*y;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n=read(),m=read();
		int u,v;
	for(int i=1;i<=m;i++)
	{
		cin>>u>>v;
		
	}
	int q;
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int t;
		cin>>t;
		if(t%2==0)
		{
			cin>>v;
		}
		else
		{
			cin>>u>>v;
		}
		cout<<"NO";
	}
	return 0;
}
