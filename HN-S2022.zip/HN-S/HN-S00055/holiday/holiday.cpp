#include<bits/stdc++.h>
using namespace std;
int s[10005],z[1000][1000],f[1000],f3[1000];//0����ûȥ�� 
int n,m,k,maxx,p,q,j,summ,l;
long long read()
{
	long long x=0,y=1;
	char ch;
	for(;!isdigit(ch);ch=getchar())if(ch=='-')y=-1;
	for(;isdigit(ch);ch=getchar())x=x*10+(ch-48);
	return x*y;
}
void out()
{
	cout<<endl;
	for(int i=1;i<=n;i++)
	{int f=0;
		cout<<i<<" ";
		while(z[i][f]!=0)
		{cout<<z[i][f]<<" ";f++;}
		cout<<endl;}
}
int find()
{
	maxx=-1,q;
	for(int i=2;i<=n;i++)
	{
		if(s[i]>maxx&&f[i]==0)
		{
		maxx=s[i];q=i;}
	}
	return q;
}
int rfind(int g,int b)
{
	int f1=0;
	while(z[b][f1]!=0&&z[b][f1]!=g){f1++;}
	if(z[b][f1]==g)
	{return f1;}
	else
	{
	return 0;
	}
}
int reefind(int g,int b)
{
	int f1=0;l++;
	cout<<"תվһ��"; 
	cout<<z[b][f1]<<" ";
	while(z[b][f1]!=0&&z[b][f1]!=g){f1++;}
	cout<<f1<<" ";
	if(z[b][f1]==g)
	{return l;}
	else 
	{
	return reefind(g,b+1);
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();//n ��ĸ��� m �㻻����Ϣ y�ɻ��˴��� 
	for(int i=2;i<=n;i++){s[i]=read();}
	for(int i=1;i<=m;i++)
	{
	long long a=read(),b=read();
	int f1=0;
	while(z[a][f1]!=0){f1++;}
	z[a][f1]=b,f1=0;
	while(z[b][f1]!=0){f1++;}
	z[b][f1]=a;
	}
  
//	{
//		 j=find();//j�������վ 
//		f2=0,minn=10000;
//		while(z[p][f2]!=0)
//		{l=0;//���˴���
//		reefind(j,p);
//		if(l<minn){minn=l;}
//		f2++;
//		}
//		if(minn<=k)
//		{
//		f[j]=1;
//	    summ+=s[j];
//	    r++;
//	    cout<<"��"<<p<<"ת��"<<j<<"վ����"<<l<<"��"<<endl;
//		p=j;}
//	}
    sort(s+2,s+n+1);
    for(int i=n;i>=n-3;i--)
    {
    	summ+=s[i];
	}
	cout<<summ;
	return 0;
}
