#include<bits/stdc++.h>
using namespace std;
int a[10000],b[10000],c[10000],d[1000][1000],l1[10000],l2[10000],r2[10000],r1[10000];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    int n,m,q;
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++){cin>>a[i];}
    for(int i=1;i<=m;i++){cin>>b[i];}
	for(int i=1;i<=q;i++){cin>>l1[i]>>r1[i]>>l2[i]>>r2[i];}
    int maxx=-99999,minn=99999;
      for(int i=1;i<=n;i++)
      {for(int j=1;j<=m;j++)
      	{
      		d[i][j]=a[i]*b[j];
			if(d[i][j]<minn)minn=d[i][j];
			if(d[i][j]>maxx)maxx=d[i][j];
		}}
    cout<<minn<<endl<<maxx;
    return 0;
	
}
