#include <fstream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <unordered_map>

using namespace std;
using LL = long long;
using Pii = pair<int, int>;

const string kFile = "transmit";
ifstream fin(kFile + ".in");
ofstream fout(kFile + ".out");

const int kN = 2e5 + 1, kL = 20;
const LL kI = 2e14;

int n, q, k, f[kN][kL], d[kN];
LL v[kN], vd[kN];
vector<int> e[kN];

void D(int x, int _f) {
  d[x] = d[_f] + 1, vd[x] = vd[_f] + v[x], f[x][0] = _f;
  for (int i = 0; i < kL - 1; ++i) {
    f[x][i + 1] = f[f[x][i]][i];
  }
  for (int i : e[x]) {
    if (i != _f) {
      D(i, x);
    }
  }
}
int L(int x, int y) {
  if (d[x] < d[y]) {
    swap(x, y);
  }
  for (int i = kL - 1; i >= 0; --i) {
    if (d[x] - d[y] >> i & 1) {
      x = f[x][i];
    }
  }
  for (int i = kL - 1; i >= 0; --i) {
    if (f[x][i] != f[y][i]) {
      x = f[x][i], y = f[y][i];
    }
  }
  return x == y ? x : f[x][0];
}

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0), fout.tie(0);
  fin >> n >> q >> k;
  for (int i = 1; i <= n; ++i) {
    fin >> v[i];
  }
  for (int i = 1, x, y; i < n; ++i) {
    fin >> x >> y;
    e[x].push_back(y), e[y].push_back(x);
  }
  D(1, 0);
  for (int x, y; q--; ) {
    fin >> x >> y;
    int l = L(x, y);
    fout << vd[x] + vd[y] - vd[l] - vd[f[l][0]] << '\n';
  }
  return 0;
}

