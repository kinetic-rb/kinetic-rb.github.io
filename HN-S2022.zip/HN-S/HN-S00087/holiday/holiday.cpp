#include <fstream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <unordered_map>

using namespace std;
using LL = long long;
using Pii = pair<int, int>;

const string kFile = "holiday";
ifstream fin(kFile + ".in");
ofstream fout(kFile + ".out");

const int kN = 1001;

int n, m, k, d[kN][kN];
LL a[kN], ans;
vector<int> e[kN];

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0), fout.tie(0);
  fin >> n >> m >> k;
  for (int i = 2; i <= n; ++i) {
    fin >> a[i];
  }
  for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= n; ++j) {
      d[i][j] = (i == j ? 0 : 1e9);
    }
  }
  for (int i = 1, x, y; i <= m; ++i) {
    fin >> x >> y;
    e[x].push_back(y), e[y].push_back(x);
    d[x][y] = d[y][x] = 1;
  }
  for (int k = 1; k <= n; ++k) {
    for (int i = 1; i <= n; ++i) {
      for (int j = 1; j <= n; ++j) {
        d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
      }
    }
  }
  for (int x = 2; x <= n; ++x) {
    if (d[1][x] - 1 <= k) {
      for (int y = 2; y <= n; ++y) {
        if (y != x && d[x][y] - 1 <= k) {
          for (int z = 2; z <= n; ++z) {
            if (z != x && z != y && d[y][z] - 1 <= k) {
              for (int u = 2; u <= n; ++u) {
                if (u != x && u != y && u != z && d[z][u] - 1 <= k && d[u][1] - 1 <= k) {
                  ans = max(ans, a[x] + a[y] + a[z] + a[u]);
                }
              }
            }
          }
        }
      }
    }
  }
  fout << ans;
  return 0;
}

