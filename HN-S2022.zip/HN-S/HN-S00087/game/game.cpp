#include <fstream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <unordered_map>

using namespace std;
using LL = long long;
using Pii = pair<int, int>;

const string kFile = "game";
ifstream fin(kFile + ".in");
ofstream fout(kFile + ".out");

const int kN = 1e5 + 1, kL = 18;
const LL kI = 1e10;

int n, m, q;
vector<LL> la, lb;
LL a[kN][kL][2][2], b[kN][kL][2][2];
bool az[kN][kL], bz[kN][kL];

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0), fout.tie(0);
  fin >> n >> m >> q;
  for (int i = 1; i <= n; ++i) {
    for (int j = 0; j < kL; ++j) {
      a[i][j][0][0] = a[i][j][1][0] = kI;
      a[i][j][0][1] = a[i][j][1][1] = -kI;
    }
  }
  for (int i = 1; i <= m; ++i) {
    for (int j = 0; j < kL; ++j) {
      b[i][j][0][0] = b[i][j][1][0] = kI;
      b[i][j][0][1] = b[i][j][1][1] = -kI;
    }
  }
  for (int i = 1; i <= n; ++i) {
    LL x;
    fin >> x;
    if (x > 0) {
      a[i][0][0][0] = a[i][0][0][1] = x;
    } else if (x < 0) {
      a[i][0][1][0] = a[i][0][1][1] = x;
    } else {
      az[i][0] = 1;
    }
  }
  for (int i = 1; i <= m; ++i) {
    LL x;
    fin >> x;
    if (x > 0) {
      b[i][0][0][0] = b[i][0][0][1] = x;
    } else if (x < 0) {
      b[i][0][1][0] = b[i][0][1][1] = x;
    } else {
      bz[i][0] = 1;
    }
  }
  for (int j = 0; j < kL - 1; ++j) {
    for (int i = 1; i <= n; ++i) {
//      fout << a[i][j][0][0] << ',' << a[i][j][0][1] << ',' << a[i][j][1][0] << ',' << a[i][j][1][1] << ',' << az[i][j] << '\n';
      int x = i + (1 << j);
      a[i][j + 1][0][0] = min(a[i][j][0][0], x <= n ? a[x][j][0][0] : kI);
      a[i][j + 1][0][1] = max(a[i][j][0][1], x <= n ? a[x][j][0][1] : -kI);
      a[i][j + 1][1][0] = min(a[i][j][1][0], x <= n ? a[x][j][1][0] : kI);
      a[i][j + 1][1][1] = max(a[i][j][1][1], x <= n ? a[x][j][1][1] : -kI);
      az[i][j + 1] = az[i][j] || (x <= n ? az[x][j] : 0);
    }
//    fout << '\n';
  }
  for (int j = 0; j < kL - 1; ++j) {
    for (int i = 1; i <= m; ++i) {
//      fout << b[i][j][0][0] << ',' << b[i][j][0][1] << ',' << b[i][j][1][0] << ',' << b[i][j][1][1] << ',' << bz[i][j] << '\n';
      int x = i + (1 << j);
      b[i][j + 1][0][0] = min(b[i][j][0][0], x <= m ? b[x][j][0][0] : kI);
      b[i][j + 1][0][1] = max(b[i][j][0][1], x <= m ? b[x][j][0][1] : -kI);
      b[i][j + 1][1][0] = min(b[i][j][1][0], x <= m ? b[x][j][1][0] : kI);
      b[i][j + 1][1][1] = max(b[i][j][1][1], x <= m ? b[x][j][1][1] : -kI);
      bz[i][j + 1] = bz[i][j] || (x <= m ? bz[x][j] : 0);
    }
//    fout << '\n';
  }
  for (int l1, r1, l2, r2; q--; ) {
    fin >> l1 >> r1 >> l2 >> r2;
    la.clear(), lb.clear();
//    fout << "la: ";
    for (int pn = 0; pn < 2; ++pn) {
      LL mx = -kI, mn = kI;
      for (int i = kL - 1, x = l1; i >= 0; --i) {
        if (x + (1 << i) - 1 <= r1) {
          mx = max(mx, a[x][i][pn][1]), mn = min(mn, a[x][i][pn][0]);
          x += 1 << i;
        }
      }
      if (mx != -kI) {
        la.push_back(mx);
//        fout << mx << ' ';
      }
      if (mn != kI) {
        la.push_back(mn);
//        fout << mn << ' ';
      }
    }
    bool _f = 0;
    for (int i = kL - 1, x = l1; i >= 0; --i) {
      if (x + (1 << i) - 1 <= r1) {
        _f |= az[x][i], x += 1 << i;
      }
    }
    if (_f) {
      la.push_back(0);
//      fout << "0 ";
    }
//    fout << '\n';
//    fout << "lb: ";
    for (int pn = 0; pn < 2; ++pn) {
      LL mx = -kI, mn = kI;
      for (int i = kL - 1, x = l2; i >= 0; --i) {
        if (x + (1 << i) - 1 <= r2) {
          mx = max(mx, b[x][i][pn][1]), mn = min(mn, b[x][i][pn][0]);
          x += 1 << i;
        }
      }
      if (mx != -kI) {
        lb.push_back(mx);
//        fout << mx << ' ';
      }
      if (mn != kI) {
        lb.push_back(mn);
//        fout << mn << ' ';
      }
    }
    _f = 0;
    for (int i = kL - 1, x = l2; i >= 0; --i) {
      if (x + (1 << i) - 1 <= r2) {
        _f |= bz[x][i], x += 1 << i;
      }
    }
    if (_f) {
//      fout << "114514 ";
      lb.push_back(0);
    }
//    fout << '\n';
    LL ans = -1e18;
    for (LL i : la) {
      LL _ans = 1e18;
      for (LL j : lb) {
        _ans = min(_ans, i * j);
      }
      ans = max(ans, _ans);
    }
    fout << ans << '\n';
  }
  return 0;
}

