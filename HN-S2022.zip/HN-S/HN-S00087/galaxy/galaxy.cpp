#include <fstream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <unordered_map>

using namespace std;
using LL = long long;
using Pii = pair<int, int>;

const string kFile = "galaxy";
ifstream fin(kFile + ".in");
ofstream fout(kFile + ".out");

const int kN = 5e5 + 1;

int n, _m, m, q, d[kN], cd;
vector<int> oe[kN];
unordered_map<int, bool> e[kN];

void L(int x, int y) {
  if (!e[x][y]) {
    e[x][y] = 1, ++m, cd -= d[x] == 1, ++d[x], cd += d[x] == 1;
  }
}
void C(int x, int y) {
  if (e[x][y]) {
    e[x][y] = 0, --m, cd -= d[x] == 1, --d[x], cd += d[x] == 1;
  }
}

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0), fout.tie(0);
  fin >> n >> _m;
  for (int i = 1, x, y; i <= _m; ++i) {
    fin >> x >> y;
    oe[y].push_back(x);
    L(x, y);
  }
  fin >> q;
  for (int o, x, y; q--; ) {
    fin >> o >> x;
    if (o == 1) {
      fin >> y;
      C(x, y);
    } else if (o == 2) {
      for (int i : oe[x]) {
        C(i, x);
      }
    } else if (o == 3) {
      fin >> y;
      L(x, y);
    } else {
      for (int i : oe[x]) {
        L(i, x);
      }
    }
    fout << (n == m && cd == n ? "YES" : "NO") << '\n';
  }
  return 0;
}

