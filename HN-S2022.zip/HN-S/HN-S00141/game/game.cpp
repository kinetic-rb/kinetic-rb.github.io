#include<bits/stdc++.h>
using namespace std;
long long maxx,minn,n,m,q,a[100010],b[100010],l1[100010],r1[100010],l2[100010],r2[100010];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	long long c[n+10][m+10]={0};
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=q;i++)
	{
		cin>>l1[i]>>r1[i]>>l2[i]>>r2[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;i++)
	{
		maxx=-999999999;
		for(int j=l1[i];j<=r1[i];j++)
		{
			minn=999999999;
			for(int k=l2[i];k<=r2[i];k++)
			{
				if(c[j][k]<minn)
				{
					minn=c[j][k];
				}
			}
			if(minn>maxx)
			{
				maxx=minn;
			}
		}
		cout<<maxx<<endl;
	} 
	return 0;
}

