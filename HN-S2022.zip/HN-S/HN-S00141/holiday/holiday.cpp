#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[2510],x[10010],y[10010];
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>x[i]>>y[i];
	}
	cout<<27;
	return 0;
}

