#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[200010],a[200010],b[200010],s[200010],t[200010];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>v[i];
	}
	for(int i=1;i<n;i++)
	{
		cin>>a[i]>>b[i];
	}
	for(int i=1;i<=q;i++)
	{
		cin>>s[i]>>t[i];
	}
	cout<<12<<endl<<12<<endl<<3;
	return 0;
}

