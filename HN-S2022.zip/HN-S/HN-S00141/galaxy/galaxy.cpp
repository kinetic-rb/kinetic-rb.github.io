#include<bits/stdc++.h>
using namespace std;
int n,m,q,t,a,b,u[500010],v[500010];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>u[i]>>v[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		cin>>t;
		if(t==1 || t==3)
		{
			cin>>a>>b;
		}
		else
		{
			cin>>a;
		}
	}
	bool c[q+10];
	for(int i=1;i<=q;i++)
	{
		if(c[i])
		{
			cout<<"YES"<<endl;
		}
		else
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}

