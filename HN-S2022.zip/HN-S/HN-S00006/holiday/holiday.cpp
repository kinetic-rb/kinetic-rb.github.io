#include<bits/stdc++.h>
using namespace std;
struct node{
	int id;
	long long val;
}st[2900];
int n,m,k,u,v,dis[2500][2500],b[2900];
long long ans=0,maxx,jx[3];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	   st[i].id=i;
	for(int i=1;i<=n;i++)
	   for(int j=1;j<=n;j++)
	      dis[i][j]=123583;
	for(int i=1;i<=n;i++)
	    dis[i][i]=0;
	for(int i=2;i<=n;i++){
		scanf("%lld",&st[i].val);
		b[i]=st[i].val;
	}
	sort(b+1,b+n+1);
    jx[1]=b[n]+b[n-1]+b[n-2];
	jx[2]=b[n]+b[n-1];
	jx[3]=b[n];
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
	    dis[u][v]=1;
	    dis[v][u]=1;
	}
    for(int i=1;i<=n;i++)
       for(int j=1;j<=n;j++)
          for(int k=1;k<=n;k++)
             if(dis[i][j]>dis[i][k]+dis[k][j])
               dis[i][j]=dis[i][k]+dis[k][j];
    for(int i=2;i<=n;i++){
    	maxx=0;
    	if(dis[1][i]<=k+1&&st[i].val+jx[1]>ans){
    		for(int j=2;j<=n;j++){
    			if(dis[i][j]<=k+1&&i!=j&&st[i].val+jx[2]+st[j].val>ans){
    			   for(int l=2;l<=n;l++){
    			   		if(dis[j][l]<=k+1&&i!=l&&j!=l){
    			   			for(int f=2;f<=n;f++){
    			   				if(dis[l][f]<=k+1&&dis[f][1]<=k+1&&f!=i&&f!=j&&f!=l){
    			   					if(st[i].val+jx[3]+st[j].val+st[l].id>ans){
    			   						maxx+=st[f].val;
    			   						maxx+=st[i].val;
    			   						maxx+=st[j].val;
    			   						maxx+=st[l].val;
    			   						ans=max(ans,maxx);
    			   						maxx=0;
									}
								}
							}
						}
				   }
				}
			}
		}
	} 
	cout<<ans;
	return 0;
}


