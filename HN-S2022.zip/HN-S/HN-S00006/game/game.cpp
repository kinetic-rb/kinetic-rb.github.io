#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[1000],b[1000],l1,l2,r1,r2;
long long c[1000][1000],minn,mi,ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
	   scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
	   scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
	   for(int j=1;j<=m;j++)
	      c[i][j]=a[i]*b[j];
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		minn=-1000000000000000005;
		for(int j=l1;j<=r1;j++){
			mi=1000000000000000005;
			for(int k=l2;k<=r2;k++)
				mi=min(mi,c[j][k]);
			minn=max(mi,minn);	
		} 
		printf("%lld\n",minn);
	}
	return 0;
}
