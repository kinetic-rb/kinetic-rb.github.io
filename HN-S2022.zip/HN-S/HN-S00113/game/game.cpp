#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll read(){
	ll x,f=1;char c;
	while((c=getchar())<'0'||c>'9')if(c=='-')f=-1;
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10-48+c;
	return x*f;
}
const ll INF=1000000000000000000ll;
const int maxn=100020;
pair<int,int> tree1[maxn<<2];
pair<int,int> Getto(int x){
	return make_pair(x,x);
}
pair<int,int> Getup(pair<int,int> x,pair<int,int> y){
	x.first=min(x.first,y.first);
	x.second=max(x.second,y.second);
	return x;
}
void Init1(int p,int l,int r,int *t){
	if(l==r){tree1[p]=Getto(t[l]);return;}
	int mid=(l+r)/2;
	Init1(2*p,l,mid,t);
	Init1(2*p+1,mid+1,r,t);
	tree1[p]=Getup(tree1[2*p],tree1[2*p+1]);
}
pair<int,int> Ask1(int p,int l,int r,int L,int R){
	if(L<=l&&r<=R)return tree1[p];
	int mid=(l+r)/2;
	if(R<=mid)return Ask1(2*p,l,mid,L,R);
	if(mid<L)return Ask1(2*p+1,mid+1,r,L,R);
	return Getup(Ask1(2*p,l,mid,L,R),Ask1(2*p+1,mid+1,r,L,R));
}
int Min2[maxn<<2],Max2[maxn<<2],Mpl[maxn<<2],Mmn[maxn<<2];
void up(int p){
	Min2[p]=min(Min2[2*p],Min2[2*p+1]);
	Max2[p]=max(Max2[2*p],Max2[2*p+1]);
	int x=Mpl[2*p],y=Mpl[2*p+1];
	if(x==-1)Mpl[p]=y;
	else if(y==-1)Mpl[p]=x;
	else Mpl[p]=min(x,y);
	x=Mmn[2*p];y=Mmn[2*p+1];
	if(x==1)Mmn[p]=y;
	else if(y==1)Mmn[p]=x;
	else Mmn[p]=max(x,y);
}
void Init2(int p,int l,int r,int *t){
	if(l==r){
		Min2[p]=Max2[p]=t[l];
		if(t[l]<0)Mmn[p]=t[l],Mpl[p]=-1;
		else if(t[l]>0)Mmn[p]=1,Mpl[p]=t[l];
		else Mmn[p]=Mpl[p]=0;
		return;
	}
	int mid=(l+r)/2;
	Init2(2*p,l,mid,t);
	Init2(2*p+1,mid+1,r,t);
	up(p);
}
int AskMin2(int p,int l,int r,int L,int R){
	if(L<=l&&r<=R)return Min2[p];
	int mid=(l+r)/2;
	if(R<=mid)return AskMin2(2*p,l,mid,L,R);
	if(mid<L)return AskMin2(2*p+1,mid+1,r,L,R);
	return min(AskMin2(2*p,l,mid,L,R),AskMin2(2*p+1,mid+1,r,L,R));
}
int AskMax2(int p,int l,int r,int L,int R){
	if(L<=l&&r<=R)return Max2[p];
	int mid=(l+r)/2;
	if(R<=mid)return AskMax2(2*p,l,mid,L,R);
	if(mid<L)return AskMax2(2*p+1,mid+1,r,L,R);
	return max(AskMax2(2*p,l,mid,L,R),AskMax2(2*p+1,mid+1,r,L,R));
}
int AskMpl(int p,int l,int r,int L,int R){
	if(L<=l&&r<=R)return Mpl[p];
	int mid=(l+r)/2;
	if(R<=mid)return AskMpl(2*p,l,mid,L,R);
	if(mid<L)return AskMpl(2*p+1,mid+1,r,L,R);
	int a=AskMpl(2*p,l,mid,L,R),b=AskMpl(2*p+1,mid+1,r,L,R);
	if(a==-1)return b;
	if(b==-1)return a;
	return min(a,b);
}
int AskMmn(int p,int l,int r,int L,int R){
	if(L<=l&&r<=R)return Mmn[p];
	int mid=(l+r)/2;
	if(R<=mid)return AskMmn(2*p,l,mid,L,R);
	if(mid<L)return AskMmn(2*p+1,mid+1,r,L,R);
	int a=AskMmn(2*p,l,mid,L,R),b=AskMmn(2*p+1,mid+1,r,L,R);
	if(a==1)return b;
	if(b==1)return a;
	return max(a,b);
}
int a[maxn],b[maxn];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n=read(),m=read(),q=read();
	int l1,r1,l2,r2,c;pair<int,int> lq;ll anr;
	#define ans(x) (c=(x),min(1ll*c*lq.first,1ll*c*lq.second))
	for(int i=1;i<=n;i++)a[i]=read();
	Init2(1,1,n,a);
	for(int i=1;i<=m;i++)b[i]=read();
	Init1(1,1,m,b);
	while(q--){
		l1=read();r1=read();l2=read();r2=read();
		lq=Ask1(1,1,m,l2,r2);
		if(lq.second<=0)printf("%lld\n",ans(AskMin2(1,1,n,l1,r1)));
		else if(lq.first>=0)printf("%lld\n",ans(AskMax2(1,1,n,l1,r1)));
		else{
			anr=-INF;
			c=AskMpl(1,1,n,l1,r1);
			if(c!=-1)anr=max(anr,ans(c));
			c=AskMmn(1,1,n,l1,r1);
			if(c!=1)anr=max(anr,ans(c));
			printf("%lld\n",anr);
		}
	}
	return 0;
}
