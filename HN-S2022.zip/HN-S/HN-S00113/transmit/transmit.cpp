#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10-48+c;
	return x;
}
const int maxn=200200;
int n;
int fi[maxn],ne[maxn<<1],to[maxn<<1],tot;
int val[maxn],vc[maxn];
int dep[maxn],fa[maxn];
int fas[maxn][20];ll fav[maxn][20];
int aa[maxn],bb[maxn],ai,bi;ll dp[maxn],dr[maxn];
inline void add(int x,int y){
	ne[++tot]=fi[x];fi[x]=tot;
	to[tot]=y;
}
void dfs(int p){
	for(int i=fi[p];i;i=ne[i])
		if(to[i]!=fa[p]){
			fa[to[i]]=p;
			dep[to[i]]=dep[p]+1;
			dfs(to[i]);
		}
}
inline void lcainit(){
	fa[1]=0;dep[1]=1;dfs(1);
	for(int i=1;i<=n;i++)fas[i][0]=fa[i],fav[i][0]=val[i];
	for(int j=1;j<20;j++)
		for(int i=2;i<=n;i++)
			if(fas[i][j-1]&&fas[fas[i][j-1]][j-1])
				fas[i][j]=fas[fas[i][j-1]][j-1],
				fav[i][j]=fav[fas[i][j-1]][j-1]+fav[i][j-1];
}
inline ll lca(int x,int y){
	int s=dep[x]-dep[y],g=0;ll ans=0;
	if(s<0)s=-s,swap(x,y);
	while(s){
		if(s&1)ans+=fav[x][g],x=fas[x][g];
		s>>=1;g++;
	}
	if(x==y)return ans+val[x];
	g=20;
	while(g--)
		if(fas[x][g]!=fas[y][g])
			ans+=fav[x][g]+fav[y][g],
			x=fas[x][g],y=fas[y][g];
	return ans+val[x]+val[y]+val[fa[x]];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();int q=read(),k=read(),x,y;
	for(int i=1;i<=n;i++)
		vc[i]=val[i]=read();
	for(int i=1;i<n;i++)
		x=read(),y=read(),add(x,y),add(y,x),
		vc[x]=min(vc[x],val[y]),vc[y]=min(vc[y],val[x]);
	if(k==1){
		lcainit();
		while(q--){
			x=read();y=read();
			printf("%lld\n",lca(x,y));
		}
		return 0;
	}
	fa[1]=0;dep[1]=1;dfs(1);
	while(q--){
		ai=bi=0;
		x=read();y=read();
		while(x!=y)
			if(dep[x]<dep[y])bb[++bi]=y,y=fa[y];
			else aa[++ai]=x,x=fa[x];
		aa[++ai]=x;
		for(int i=bi;i>0;i--)
			aa[++ai]=bb[i];
		for(int i=1;i<=ai;i++)
			dp[i]=dr[i]=1000000000000000000ll;
		dp[1]=val[aa[1]];
		for(int i=1;i<ai;i++){
			dp[i+1]=min(dp[i+1],dp[i]+val[aa[i+1]]);
			dp[i+2]=min(dp[i+2],dp[i]+val[aa[i+2]]);
			if(k==3)
				dp[i+1]=min(dp[i+1],dr[i]+val[aa[i+1]]),
				dp[i+2]=min(dp[i+2],dr[i]+val[aa[i+2]]),
				dp[i+3]=min(dp[i+3],dp[i]+val[aa[i+3]]),
				dr[i+1]=min(dr[i+1],min(dp[i],dr[i])+vc[aa[i+1]]),
				dr[i+2]=min(dr[i+2],dp[i]+vc[aa[i+2]]);
		}
		printf("%lld\n",dp[ai]);
	}
	return 0;
}
