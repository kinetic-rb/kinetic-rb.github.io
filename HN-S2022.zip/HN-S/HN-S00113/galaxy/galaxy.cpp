#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10-48+c;
	return x;
}
const int maxn=1020;
int dis[maxn][maxn];
int rd[maxn];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n=read(),m=read(),q,x,y,op;
	memset(dis,0,sizeof dis);
	for(int i=1;i<=n;i++)
		rd[i]=0;
	for(int i=1;i<=m;i++)
		x=read(),y=read(),dis[x][y]=1,rd[x]++;
	q=read();
	while(q--){
		op=read();
		if(op==1)x=read(),y=read(),dis[x][y]=-1,rd[x]--;
		else if(op==3)x=read(),y=read(),dis[x][y]=1,rd[x]++;
		else if(op==2){
			x=read();
			for(int i=1;i<=n;i++)
				if(dis[i][x]==1)dis[i][x]=-1,rd[i]--;
		}
		else{
			x=read();
			for(int i=1;i<=n;i++)
				if(dis[i][x]==-1)dis[i][x]=1,rd[i]++;
		}
		x=0;
		for(int i=1;i<=n;i++)
			if(rd[i]!=1){
				x=1;
				puts("NO");
				break;
			}
		if(x==0)puts("YES");
	}
	return 0;
}
