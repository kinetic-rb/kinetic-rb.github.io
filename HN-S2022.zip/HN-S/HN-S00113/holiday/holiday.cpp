#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll read(){
	ll x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10-48+c;
	return x;
}
const int maxn=2502;
const int maxm=20002;
int n;
int id[maxn];
ll val[maxn];
int fi[maxn],ne[maxm],to[maxm],tot=0;
int dis[maxn][maxn];
queue<int>qs;
vector<int>vl[maxn];
int vili[maxn];
bool cmp(int x,int y){return val[x]>val[y];}
inline void add(int x,int y){
	ne[++tot]=fi[x];fi[x]=tot;
	to[tot]=y;
}
inline void dfs(int p,int *ds){
	for(int i=1;i<=n;i++)ds[i]=998244353;
	ds[p]=0;qs.push(p);
	while(!qs.empty()){
		p=qs.front();qs.pop();
		for(int i=fi[p];i;i=ne[i])
			if(ds[to[i]]==998244353)
				ds[to[i]]=ds[p]+1,qs.push(to[i]);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	int m=read(),k=read()+1;
	int x,y,nr;
	ll ans=0;
	for(int i=2;i<=n;i++)
		val[i]=read(),id[i]=i;
	sort(id+2,id+n+1,cmp);
	for(int i=1;i<=m;i++)
		x=read(),y=read(),add(x,y),add(y,x);
	for(int i=1;i<=n;i++)
		dfs(i,dis[i]);
	for(int i=2;i<=n;i++){
		vl[i].clear();vili[i]=0;
		for(int j=2;j<=n;j++)
			if(id[j]!=i&&dis[1][id[j]]<=k&&dis[id[j]][i]<=k)
				vl[i].push_back(id[j]),vili[i]++;
	}
	for(int i=2;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(dis[i][j]<=k){
				x=y=0;
				while(x<vili[i]&&vl[i][x]==j)x++;
				if(x==vili[i])continue;
				while(y<vili[j]&&vl[j][y]==i)y++;
				if(y==vili[j])continue;
				if(vl[i][x]!=vl[j][y])ans=max(ans,val[vl[i][x]]+val[vl[j][y]]+val[i]+val[j]);
				else{
					nr=x+1;
					while(nr<vili[i]&&vl[i][nr]==j)nr++;
					if(nr!=vili[i])ans=max(ans,val[vl[i][nr]]+val[vl[j][y]]+val[i]+val[j]);
					nr=y+1;
					while(nr<vili[j]&&vl[j][nr]==i)nr++;
					if(nr!=vili[j])ans=max(ans,val[vl[i][x]]+val[vl[j][nr]]+val[i]+val[j]);
				}
			}
	printf("%lld\n",ans);
	return 0;
}
