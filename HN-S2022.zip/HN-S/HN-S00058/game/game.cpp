#include<bits/stdc++.h>
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
using namespace std;
const int N=1e4+5;
long long a[N],b[N];
int n,m,q;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1,x;i<=n;++i)
		scanf("%lld",a+i);
	for(int i=1,x;i<=m;++i)
		scanf("%lld",b+i);
	while(q--){
		int x1,x2,y1,y2;
		long long maxn=-1,minn=0x7fffffff;
		scanf("%d%d%d%d",&x1,&x2,&y1,&y2);
		if(x1==x2){
			for(int i=y1;i<=y2;++i)
				minn=min(minn,a[x1]*b[i]);
			printf("%lld",minn);
		}
		else if(y1==y2){
			for(int i=x1;i<=x2;++i)
				maxn=max(maxn,a[i]*b[y1]);
			printf("%lld",maxn);
		}
		else{
			for(int i=x1;i<=x2;++i)
				maxn=max(maxn,a[i]);
			for(int i=y1;i<=y2;++i)
				minn=min(minn,b[i]);
			printf("%lld",maxn*minn);
		}
		puts("");
	}
	return 0;
}
