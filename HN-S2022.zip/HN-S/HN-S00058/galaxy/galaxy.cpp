#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int n,m,q;
struct Edge{
	int to,next,flag;
}e[2*N];
int tot,head[2*N];
void add(int u,int v){
	e[++tot]=(Edge){v,head[u],1};
	head[u]=tot;
}
bool vis[N],fff;
void dfs1(int u){
	for(int i=head[u];i;i=e[i].next){
		if(e[i].flag){
			int v=e[i].to;
			if(vis[v]&&!fff)
				fff=1;
			if(!vis[v]){
				vis[v]=1;
				dfs1(v);
			}
		}
	}
}
bool ok1(){
	memset(vis,0,sizeof vis);
	for(int i=1;i<=n;++i){
		if(!vis[i]){
			fff=0;
			vis[i]=1;
			dfs1(i);
			if(!fff)
				return 0;
		}
	}
	return 1;
}
bool ok2(){
	int cnt;
	for(int u=1;u<=n;++u){
		cnt=0;
		for(int i=head[u];i;i=e[i].next){
			if(e[i].flag){
				if(cnt==1)
					return 0;
				++cnt;
			}
		}
	}
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1,x,y;i<=m;++i){
		cin>>x>>y;
		add(x,y);
		add(y+n,x+n);
	}
	cin>>q;
	int t,u,v;
	while(q--){
		cin>>t;
		if(t==1){
			cin>>u>>v;
			for(int i=head[u];i;i=e[i].next){
				if(e[i].to==v){
					e[i].flag=0;
					break;
				}
			}
		}
		else if(t==2){
			cin>>u;
			for(int i=head[u+n];i;i=e[i].next)
				e[i-1].flag=0;
		}
		else if(t==3){
			cin>>u>>v;
			for(int i=head[u];i;i=e[i].next){
				if(e[i].to==v){
					e[i].flag=1;
					break;
				}
			}
		}
		else{
			cin>>u;
			for(int i=head[u+n];i;i=e[i].next)
				e[i-1].flag=1;
		}
		if(ok1()&&ok2())
			puts("YES");
		else
			puts("NO");
	}
	return 0;
}
