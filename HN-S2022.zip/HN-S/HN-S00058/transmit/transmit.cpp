#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,q,k;
struct Edge{
	int to,next;
}e[N];
long long tot,head[N],sum,ans,a[N];
bool vis[N];
void add(int u,int v){
	e[++tot]=(Edge){v,head[u]};
	head[u]=tot;
	e[++tot]=(Edge){u,head[v]};
	head[v]=tot;
}
void dfs(int u,int nn){
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(v==nn){
			ans=min(ans,sum);
			return;
		}
		if(!vis[v]){
		cout<<u<<' '<<v<<'\n';
			vis[v]=1,sum+=a[v];
			dfs(v,nn);
			vis[v]=0,sum-=a[v];
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;++i)
		cin>>a[i];
	for(int i=1,x,y;i<n;++i){
		cin>>x>>y;
		add(x,y);
	}
	int s,t;
	while(q--){
		cin>>s>>t;
		vis[s]=1,ans=0x7fffffff;
		dfs(s,t);
		cout<<(long long)(ans+a[s]+a[t])<<endl;
	}
	return 0;
}
