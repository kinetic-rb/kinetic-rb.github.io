#include<bits/stdc++.h>
using namespace std;
const int N=1e4+5;
int n,m,k;
struct Edge{
	int to,next;
}e[N];
long long tot,head[N],sum,ans,a[N];
bool vis[N];
void add(int u,int v){
	e[++tot]=(Edge){v,head[u]};
	head[u]=tot;
	e[++tot]=(Edge){u,head[v]};
	head[v]=tot;
}
void dfs(int u,int now){
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(now==4&&v==1){
			ans=max(ans,sum);
			return;
		}
		if(!vis[v]&&now<4){
			vis[v]=1,sum+=a[v];
			dfs(v,now+1);
			vis[v]=0,sum-=a[v];
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;++i)
		cin>>a[i];
	for(int i=1,x,y;i<=m;++i){
		cin>>x>>y;
		add(x,y);
	}
	vis[1]=1;
	dfs(1,0);
	cout<<ans;
	return 0;
}
