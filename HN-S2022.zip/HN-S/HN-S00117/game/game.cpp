#include<bits/stdc++.h>

using namespace std;

int n, m, q, a[100005], b[100005], az[1005][1005], af[1005][1005], bz[1005][1005], bf[1005][1005];
int da[1005][1005], db[1005][1005], xa[1005][1005], xb[1005][1005];

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	if (n > 1000 || m > 1000) {
		while (q--) {
			cout << q << endl;
		}
		return 0;
	}
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		da[i][i] = xa[i][i] = a[i];
		if(a[i] > 0) {
			az[i][i] = a[i], af[i][i] = -1000000001;
		}
		if (a[i] < 0) {
			az[i][i] = 1000000001, af[i][i] = a[i];
		}
		if (a[i] == 0) {
			az[i][i] = af[i][i] = 0;
		}
		for (int j = i - 1; j > 0; j--) {
			da[j][i] = max(a[j], da[j + 1][i]);
			xa[j][i] = min(a[j], xa[j + 1][i]);
			if (a[j] > 0) {
				az[j][i] = min(az[j + 1][i], a[j]), af[j][i] = af[j + 1][i];
			} 
			if (a[j] < 0){
				af[j][i] = max(af[j + 1][i], a[j]), az[j][i] = az[j + 1][i];
			}
			if (a[j] == 0) {
				az[j][i] = af[j][i] = 0;
			}
		}
	}
	for (int i = 1; i <= m; i++) {
		cin >> b[i];
		db[i][i] = xb[i][i] = b[i];
		if(b[i] > 0) {
			bz[i][i] = b[i], bf[i][i] = 1;
		} 
		if (b[i] < 0) {
			bf[i][i] = b[i], bz[i][i] = -1;
		}
		if (b[i] == 0) {
			bz[i][i] = bf[i][i] = 0;
		}
		for (int j = i - 1; j > 0; j--) {
			db[j][i] = max(b[j], db[j + 1][i]);
			xb[j][i] = min(b[j], xb[j + 1][i]);
			if (b[j] > 0) {
				bz[j][i] = max(bz[j + 1][i], b[j]), bf[j][i] = bf[j + 1][i];
			} 
			if (b[j] < 0){
				bf[j][i] = min(bf[j + 1][i], b[j]), bz[j][i] = bz[j + 1][i];
			}
			if (b[j] == 0) {
				bz[j][i] = max(bz[j + 1][i], 0);
				bf[j][i] = min(bf[j + 1][i], 0);
			}
		}
	}
	while (q--) {
		int l1, r1, l2, r2, x, y;
		cin >> l1 >> r1 >> l2 >> r2;
//		for (int i = l1; i <= r1; i++) {
//			cout << a[i] << " ";
//		}
//		cout << endl;
//		for (int i = l2; i <= r2; i++) {
//			cout << b[i] << " ";
//		}
//		cout << da[l1][r1] << " " << db[l2][r2] << " ";
//		cout << xa[l1][r1] << " " << xb[l2][r2] << " ";
//		cout << az[l1][r1] << " " << bz[l2][r2] << " ";
//		cout << af[l1][r1] << " " << bf[l2][r2] << "        ";
		if (da[l1][r1] <= 0) {
		  if (db[l2][r2] <= 0) {
				cout << xa[l1][r1] * db[l2][r2] << endl;
			} else {
				cout << da[l1][r1] * db[l2][r2] << endl;
			}
		} else if (xa[l1][r1] > 0) {
			if (xb[l2][r2] >= 0) {
				cout << da[l1][r1] * xb[l2][r2] << endl;
			} else {
				cout << xa[l1][r1] * xb[l2][r2] << endl;
			}
		} else {
			if (xb[l2][r2] >= 0) {
				cout << da[l1][r1] * xb[l2][r2] << endl;
			} else if (db[l2][r2] < 0) {
				cout << xa[l1][r1] * db[l2][r2] << endl;
			} else {
			  cout << max(az[l1][r1] * bf[l2][r2], af[l1][r1] * bz[l2][r2]) << endl;
			}
		}
	}
	return 0;
}
