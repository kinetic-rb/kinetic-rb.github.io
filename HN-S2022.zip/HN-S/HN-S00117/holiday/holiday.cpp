#include<bits/stdc++.h>

using namespace std;

int n, m, k, ans, a[2505], b[2505][2505];
bool bj[2505];

void dfs(int x, int y, int s) {
//	cout << x << " " << y << " " << s << endl;
	if (y == 4) {
		if (b[x][1] <= k) {
			ans = max(ans, s);
		}
		return;
	}
	int t = s;
	for (int i = 2; i <= n; i++) {
		if (b[x][i] <= k && !bj[i]) {
			bj[i] = 1;
			dfs(i, y + 1, t + a[i]);
			bj[i] = 0;
		}
	}
	return;
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 2; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			if (i != j) {
			  b[i][j] = k + 10;
			}
		}
	}
	for (int i = 1; i <= m; i++) {
		int u, v;
		cin >> u >> v;
		b[u][v] = b[v][u] = 0;
	}
	for (int i = 1; i <= n; i++) {
//		cout << "i = " << i << endl;
		for (int j = 1; j < n; j++) {
			for (int l = j + 1; l <= n; l++) {
				b[l][j] = b[j][l] = min(b[j][l], b[j][i] + b[i][l] + 1);
//				cout << b[j][l] << " ";
			}
//			cout << endl;
		}
	}
//	for (int i = 1; i <= n; i++) {
//		for (int j = 1; j <= n; j++) {
//			cout << b[i][j] << " ";
//		}
//		cout << endl;
//	}
	bj[1] = 1;
	dfs(1, 0, 0);
	cout << ans;
	return 0;
} 
