#include<bits/stdc++.h>
#define il inline
#define re register
using namespace std;
il int read(){
	re int a=0,ne=1;re char b=getchar();
	while(b<'0'||b>'9'){
		if(b=='-')ne=-ne;
		b=getchar();
	}
	while(b>='0'&&b<='9'){
		a=a*10+b-'0';
		b=getchar();
	}
	return a*ne;
}
int fa[200010][20],d[200010],v[200010],a,b,n,Q,k;
void pre(int nw){
	d[nw]=d[fa[nw][0]]+1;
	for(int i=1;i<=17;i++)
		fa[nw][i]=fa[fa[nw][i-1]][i-1];
}
int lca(int l,int r){
	if(d[l]>d[r])swap(l,r);
	while(d[r]>d[l])
		for(int i=17;i>=0;i--)
			if(d[fa[r][i]]>=d[l])r=fa[r][i];
	if(l==r)return l;
	for(int i=17;i>=0;i--)
		if(fa[r][i]!=fa[l][i])
			r=fa[r][i],l=fa[l][i];
	return fa[r][0];
}
struct asd{
	int a;
	bool operator <(asd b)const{
		return v[a]>v[b.a];
	}
	asd(){}
	asd(int ad){a=ad;}
};
int dp[200010];
int bfs(int s,int t){
	priority_queue<asd> q;
	q.push(asd(s));int tmp,temp,ans=0;
	while(!q.empty()){
		temp=tmp=q.top().a;
		q.pop();
		if(d[tmp]<=d[lca(s,t)]){ans+=dp[tmp];break;}
		for(int i=0;i<k;i++){
			dp[fa[tmp][0]]=dp[temp]+v[fa[tmp][0]];
			tmp=fa[tmp][0];
			if(!tmp)break;
			q.push(asd(tmp));
		}
	}
	while(!q.empty()){q.pop();}
	q.push(asd(t));
	while(!q.empty()){
		tmp=q.top().a;
		q.pop();
		if(d[tmp]<=d[lca(s,t)])
			return ans+dp[tmp];
		for(int i=0;i<k;i++){
			dp[fa[tmp][0]]=dp[tmp]+v[fa[tmp][0]];
			if(!tmp)break;
			tmp=fa[tmp][0];
			q.push(asd(tmp));
		}
	}
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	//sth
	n=read(),Q=read(),k=read();
	v[0]=114514;
	for(int i=1;i<=n;i++)
		v[i]=read();
	for(int i=1;i<n;i++){
		a=read(),b=read();
		fa[b][0]=a;
	}
	for(int i=1;i<=n;i++)
		if(fa[i][0]==0)
			d[i]=1;
		else pre(i);
	for(int i=0;i<Q;i++){
		a=read(),b=read();
		printf("%d\n",bfs(a,b)-v[lca(a,b)]+v[a]+v[b]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//6
