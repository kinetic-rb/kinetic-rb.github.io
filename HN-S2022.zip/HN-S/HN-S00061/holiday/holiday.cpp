#include<bits/stdc++.h>
#define il inline
#define re register
using namespace std;
il int read(){
	re int a=0,ne=1;re char b=getchar();
	while(b<'0'||b>'9'){
		if(b=='-')ne=-ne;
		b=getchar();
	}
	while(b>='0'&&b<='9'){
		a=a*10+b-'0';
		b=getchar();
	}
	return a*ne;
}
int N,M,K,u,v,score[100010],graph[2510][2510],answ=-1;pair<int,int> mxof[2510][5];
void gx(int l,int r,int sz){
	if(mxof[l][0].first<sz){
		mxof[l][4]=mxof[l][3];
		mxof[l][3]=mxof[l][2];
		mxof[l][2]=mxof[l][1];
		mxof[l][1]=mxof[l][0];
		mxof[l][0]=make_pair(sz,r);
		return;
	}
	if(mxof[l][1].first<sz){
		mxof[l][4]=mxof[l][3];
		mxof[l][3]=mxof[l][2];
		mxof[l][2]=mxof[l][1];
		mxof[l][1]=make_pair(sz,r);
		return;
	}
	if(mxof[l][2].first<sz){
		mxof[l][4]=mxof[l][3];
		mxof[l][3]=mxof[l][2];
		mxof[l][2]=make_pair(sz,r);
		return;
	}
	if(mxof[l][3].first<sz){
		mxof[l][4]=mxof[l][3];
		mxof[l][3]=make_pair(sz,r);
		return;
	}
	if(mxof[l][4].first<sz){
		mxof[l][4]=make_pair(sz,r);
		return;
	}
}
int mxofe(int l,int r,int k){
	for(int i=0;i<5;i++)
		if(mxof[k][i].second!=l&&mxof[k][i].second!=r)
			return mxof[k][i].first;
	return -1;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
//	memset(graph,-1,sizeof(graph));
	N=read();M=read(),K=read();
	for(re int i=2;i<=N;i++)score[i]=read();
	for(re int i=1;i<=N;i++)
		for(re int j=1;j<=N;j++)
			graph[i][j]=1048576,mxof[i][0].first=-1,mxof[i][1].first=-1,mxof[i][2].first=-1,mxof[i][3].first=-1,mxof[i][4].first=-1;
	for(re int i=0;i<M;i++){
		u=read(),v=read();
		graph[u][v]=1,graph[v][u]=1;
	}
	for(re int k=1;k<=N;k++)
		for(re int i=1;i<=N;i++)
			for(re int j=i+1;j<=N;j++)
				if(graph[i][j]>graph[i][k]+graph[k][j])
					graph[j][i]=graph[i][j]=graph[i][k]+graph[k][j];
	for(re int k=1;k<=N;k++)
		for(re int i=1;i<=N;i++)
			if(graph[i][k]-1<=K&&graph[k][1]-1<=K)
				gx(i,k,score[k]);
//	for(re int i=1;i<=N;i++)
//		for(re int j=1;j<=N;j++)
//			cout<<i<<' '<<j<<' '<<mx[i][j]<<' '<<graph[i][j]<<endl;
//		for(re int j=1;j<=N;j++)
//			cout<<mxof[j]<<endl;
	for(int i=2;i<=N;i++)
		for(int j=2;j<=N;j++)
			if(i!=j)
				for(int k=2;k<=N;k++)
					if(k!=i&&k!=j&&graph[i][j]-1<=K&&graph[j][k]-1<=K&&graph[i][1]-1<=K&&mxofe(i,j,k)!=-1&&answ<score[i]+score[j]+score[k]+mxofe(i,j,k)){
						answ=score[i]+score[j]+score[k]+mxofe(i,j,k);
					}
	printf("%d\n",answ);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1


27
*/
