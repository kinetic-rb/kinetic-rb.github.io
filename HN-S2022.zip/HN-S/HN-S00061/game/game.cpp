#include<bits/stdc++.h>
#define il inline
#define re register
#define int long long
#define fint int
using namespace std;
il int read(){
	re int a=0,ne=1;re char b=getchar();
	while(b<'0'||b>'9'){
		if(b=='-')ne=-ne;
		b=getchar();
	}
	while(b>='0'&&b<='9'){
		a=a*10+b-'0';
		b=getchar();
	}
	return a*ne;
}
int n,m,q,a[2097152],b[2097152],l1,l2,r1,r2;
struct seg{
	int bh,l,r,szi,sza,sz0;
	seg(){}
	seg(int a,int b,int c,int d=0,int e=0,int f=0){bh=a,l=b,r=c,szi=d,sza=e,sz0=f;}
}l[8000010];
seg min(seg a,seg b){
	return seg(0,0,0,min(a.szi,b.szi),max(a.sza,b.sza),a.sz0||b.sz0);
}
void mk_tree1(int le,int ri,int bh){
	l[bh]=seg(bh,le,ri);
	if(le==ri){l[bh].szi=l[bh].sza=b[le];l[bh].sz0=(b[le]==0);return;}
	if(le<=((l[bh].r+l[bh].l)>>1))mk_tree1(le,((l[bh].r+l[bh].l)>>1),bh*2);
	if(ri>=((l[bh].r+l[bh].l)>>1)+1)mk_tree1(((l[bh].r+l[bh].l)>>1)+1,ri,bh*2+1);
	l[bh].szi=min(l[bh*2].szi,l[bh*2+1].szi);
	l[bh].sza=max(l[bh*2].sza,l[bh*2+1].sza);
	l[bh].sz0=l[bh*2].sz0||l[bh*2+1].sz0;
}
seg ask(int le,int r,int nw){
	if(l[nw].l>=le&&l[nw].r<=r)return l[nw];
	if(le>((l[nw].r+l[nw].l)>>1))return ask(le,r,nw*2+1);
	if(r<=((l[nw].r+l[nw].l)>>1)+1)return ask(le,r,nw*2);
	return min(ask(le,((l[nw].r+l[nw].l)>>1),nw*2),ask(((l[nw].r+l[nw].l)>>1)+1,r,nw*2+1));
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	m=read();n=read();q=read();
	for(re fint i=1;i<=n;i++)b[i]=read();
	for(re fint i=1;i<=m;i++)a[i]=read();
	mk_tree1(1,n,1);
	seg tmp;
	for(re int i=1,ans=-12315245;i<=q;i++,ans=-12315245){
		l1=read(),r1=read(),l2=read(),r2=read();
		for(fint j=l1;j<=r1;j++)
			if((tmp=ask(l2,r2,1)).szi){
				if(tmp.sz0)
					ans=max(ans,max(max(0ll,tmp.sza*a[j]),tmp.szi*a[j]));
				else ans=max(max(tmp.sza*a[j],tmp.szi*a[j]),ans);
			}
		printf("%lld\n",ans==-12315245?0:ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

