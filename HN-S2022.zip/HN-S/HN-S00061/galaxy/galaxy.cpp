#include<bits/stdc++.h>
#define il inline
#define re register
using namespace std;
il int read(){
	re int a=0,ne=1;re char b=getchar();
	while(b<'0'||b>'9'){
		if(b=='-')ne=-ne;
		b=getchar();
	}
	while(b>='0'&&b<='9'){
		a=a*10+b-'0';
		b=getchar();
	}
	return a*ne;
}
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	//sth
	fclose(stdin);
	fclose(stdout);
	return 0;
}

