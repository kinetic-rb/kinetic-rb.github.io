#include<bits/stdc++.h>
using namespace std;

int n,m,q;
int c[100010][100010];
int a[100010];
int b[100010];
int l1[100010];
int r1[100010];
int l2[100010];
int r2[100010];

void init()
{
	for(int i=0;i<=n-1;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<=m-1;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=n-1;i++)
	{
		for(int j=1;j>=m-1;j++)
		{
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i=0;i<=q-1;i++)
	{
		cin>>l1[i]>>r1[i]>>l2[i]>>r2[i];
	}
}

int kk(int u)//�ҳ���С/��� 
{
	bool l=1;
	int o=INT_MIN;
	int p=INT_MIN;
	for(int i=1;i<=m;i++)
	{
		if(c[u][i]<0)
		{
			l=0;
			if(c[u][i]>o)
			{
				o=c[u][i];
			}
		}
		else
		{
			if(c[u][i]>p)
			{
				p=c[u][i];
			}
		}
	}
	return p;
}

int maxxl(int l[])//�ҵ����l 
{
	int ret=0;
	for(int i=0;i<=0;i++)
	{
		if(l[i]>ret)
			ret=l[i];
	}
	return ret;
}

int ll(int l_1,int r_1,int l_2,int r_2)
{
	
	int l[100010];
	for(int i=0;i<=10010;i++)
		l[i]=INT_MIN;
	for(int i=l_1;i<=r_1;i++)
	{
		l[i]=kk(i);
	}
	int u=maxxl(l);
	int ret=INT_MIN;
	for(int i=l_2;i<=r_2;i++)
	{
		if(c[u][i]>ret)
		{
			ret=c[u][i];
		}
	}
	return ret;
}

int main()
{
	cout<<"1111";
	freopen("D:\\HN-S00080\\game\\game.in","r",stdin);
	freopen("D:\\HN-S00080\\game\\game.out","w",stdout);
	init();
	for(int i=0;i<=q-1;i++)
	{
		cout<<ll(l1[i],r1[i],l2[i],r2[i]);
	}
	return 0;
}
