#include<bits/stdc++.h>
using namespace std;

int n,m,k;
int a[2510];
bool b[2510][2510];
bool v[2510];
int ret;

int maxx(int u)//ѡ����ǰ��ȥ�����ֵ���� 
{
	int ret=INT_MIN;
	for(int i=2;i<=n-1;i++)
	{
		if(a[i]>ret&&v[i]==0&&i!=u)
		{
			ret=i;
			return ret;
		}
	}
	return ret;
}

void init()//��ʼ�� 
{
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<=m-1;i++)
	{
		int o1;
		int o2;
		cin>>o1>>o2;
		b[o1][o2]=1;
		b[o2][o1]=1;
	}
}

int ok(int u,int k1)//�ҵ���ǰ��ȥ�ľ��� 
{
	int h=0;
	if(k1<0)
		return 1;
		
 	for(int i=2;i<=n;i++)
	{
		if(b[u][i]==1&&k>0)
		{
 			h+=ok(i,k1-1);
			v[i]=1;
		}
	}
	if(h==0)
	   h=1;
	return h;
}

void initv()//��ʼ��v���� 
{
	for(int i=0;i<=n-1;i++)
	{
		v[i]=0;
	}
}

bool YESorNO(int u,int k1)//��ǰ�����Ƿ���Իؼ� 
{
	bool l=0;
	
	if(u=1)
		return 1;
	
	if(k1<=0)
		return 0;
	
	for(int i=0;i<=n;i++)
	{
		if(b[i][u]==1&&k1>0)
		{
			l=YESorNO(i,k1-1);
		} 
	}
	
	return l;
}

void GO(int r,int p,int u) //��ʼִ�� 
{
	if(p==0)
	{
		if(YESorNO(u,k))
		{
			if(r>ret)
				ret=r;
		}
		
		return ;
	}
	
	while(1)
	{
		int t=ok(u,k);
		if(t==0)
			break;
			maxx(u);
		v[u]=0;
	}
}

int main()
{
	//*
	freopen("D:\\HN-S00080\\holiday\\holiday.in","r",stdin);
	freopen("D:\\HN-S00080\\holiday\\holiday.out","w",stdout);//*/
	
	init(); 
	initv();
	
	GO(0,4,1);
	
	
	cout<<ret;
	return 0;
}
