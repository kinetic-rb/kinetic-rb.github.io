#include<bits/stdc++.h>
using namespace std;
int n,m,k,go[2510][2510],zhi[2510],b[2510],tt[2510];
int dfs(int x,int id,int sum)
{
	if(x>k) return 0;//����ת������ 
	int mx=0;
	for(int i=1;i<=tt[id];i++)
	{
		int next=go[id][i];
		if(sum==4&&next!=1) continue;
		else if(sum==4&&next==1) return -1;
		int tmx=0;
		if(b[id]!=1&&sum<4)
		{
			tmx=dfs(x+1,next,sum);
	        b[id]=1;
			if(sum==3&&dfs(0,next,sum+1)==-1)
			{
				tmx=max(tmx,dfs(0,next,sum+1)+zhi[id]+1);
			}
			else if(sum<3) tmx=max(tmx,dfs(0,next,sum+1)+zhi[id]);
			b[id]=0;
		}
		if(tmx>mx) mx=tmx;
	}
	return mx;
}
int main()
{
	freopen("holiday.in","r",stdin);
	//freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
	{
		cin>>zhi[i];
	}
	/*for(int i=2;i<=n;i++)
	{
		cout<<zhi[i]<<" ";
	}
	cout<<endl;*/
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		go[a][++tt[a]]=b;
		go[b][++tt[b]]=a;
	}
	cout<<dfs(0,1,0);
	return 0;
}
