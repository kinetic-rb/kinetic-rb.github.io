#include<bits/stdc++.h>
using namespace std;
int n,m,u,v,q;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>u>>v;
	}
	cin>>q;
	while(q--)
	{
		cout<<"NO"<<endl;
	}
	return 0;
}

