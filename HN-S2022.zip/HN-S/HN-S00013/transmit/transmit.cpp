#include<bits/stdc++.h>
using namespace std;
long long n, k, fa[200005], q, v[200005];
bool find(long long x, long long y){
	if(x == y){
		return 1;
	}else if(x == 1){
		return 0;
	}
	return find(fa[x], y);
}
long long find2(long long x, long long y, long long ans){
	if(x == y){
		return ans + v[y];
	}
	return find2(fa[x], y, ans + v[x]);
}
int main(){
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin >> n >> q >> k;
	fa[1] = 1;
	for(long long i = 1; i <= n; i++){
		cin >> v[i];
	}
	for(long long i = 1; i <= n - 1; i++){
		long long u, v;
		cin >> u >> v;
		u > v ? fa[u] = v : fa[v] = u;
	}
	while(q--){
		long long s, t;
		cin >> s >> t;
		if(s < t)swap(s, t);
		if(find(s, t)){
			cout << find2(s, t, 0) << "\n";
		}else{
			cout << find2(s, 1, 0) + find2(t, 1, 0) - v[1]<< "\n";
		}
	}
	return 0;
}
