#include<bits/stdc++.h>
using namespace std;
int n, q, k, v[200005];
struct A{
	vector<int> next;
}a[200005]; 
int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> n >> q >> k;
	for(int i = 1; i <= n; i++){
		cin >> v[i];
	}
	for(int i = 1; i <= q; i++){
		int t, u, v;
		if(t == 1 || t == 3){
			cin >> u >> v;
			cout << "YES\n";
		}else{
			cin >> u;
			cout << "NO\n";
		}
	}
	return 0;
}
