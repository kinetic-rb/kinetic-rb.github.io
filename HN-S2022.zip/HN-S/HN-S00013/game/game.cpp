#include<bits/stdc++.h>
using namespace std;
const long long inf = 2147483647 * 2147483647;
long long n, m, q, l1, r1, l2, r2, a[100005], b[100005], qa[100005], qb[100005];
long long zd, zx, zd2, zx2, l11, l22;
int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
		if(a[i] < 0){
			qa[i] = qa[i - 1] + 1;
		}else{
			qa[i] = qa[i - 1];
		}
	}
	for(int i = 1; i <= m; i++){
		cin >> b[i];
		if(b[i] < 0){
			qb[i] = qb[i - 1] + 1;
		}else{
			qb[i] = qb[i - 1];
		}
	}
	while(q--){
		cin >> l1 >> r1 >> l2 >> r2;
		if(l1 == r1){
			long long mina = -inf;
			for(int i = l2; i <= r2; i++){
				mina = min(mina, a[l1] * b[i]);
			}
			cout << mina << endl;
		}else if(l2 == r2){
			long long maxa = -inf;
			for(int i = l1; i <= r1; i++){
				maxa = max(maxa, b[l2] * a[i]);
			}
			cout << maxa << endl;
		}else{
			if(qa[r1] - qa[l1 - 1] == 0 && qb[r2] - qb[l2 - 1] == 0){
				long long maxa = 0, minb = 0;
				for(int i = l1; i <= r1; i++){
					maxa = max(maxa, a[i]);
				}
				for(int i = l2; i <= r2; i++){
					minb = min(minb, b[i]);
				}
				cout << maxa * minb << endl;
			}else if(qa[r1] - qa[l1 - 1] == 0 && qb[r2] - qb[l2 - 1] != 0){
				long long mina = inf, minb = inf;
				for(int i = l1; i <= r1; i++){
					mina = min(mina, a[i]);
				}
				for(int i = l1; i <= r1; i++){
					minb = min(minb, b[i]);
				}
				cout << mina * minb << endl;
			}else if(qa[r1] - qa[l1 - 1] != 0 && qb[r2] - qb[l2 - 1] == 0){
				long long maxa = -inf, minb = inf;
				for(int i = l1; i <= r1; i++){
					maxa = max(maxa, a[i]);
				}
				for(int i = l2; i <= r2; i++){
					minb = min(minb, b[i]);
				}
				cout << maxa * minb << endl;
			}else if(qa[r1] - qa[l1 - 1] == r1 - l1 + 1 && qb[r2] - qb[l2 - 1] == r2 - l2 + 1){
				long long mina = inf, maxb = -inf;
				for(int i = l1; i <= r1; i++){
					mina = min(mina, a[i]);
				}
				for(int i = l2; i <= r2; i++){
					maxb = max(maxb, b[i]);
				}
				cout << mina * maxb << endl;
			}else if(qa[r1] - qa[l1 - 1] == r1 - l1 + 1 && qb[r2] - qb[l2 - 1] != r2 - l2 + 1){
				long long mina = inf, maxb = -inf;
				for(int i = l1; i <= r1; i++){
					mina = min(mina, a[i]);
				}
				for(int i = l2; i <= r2; i++){
					maxb = max(maxb, b[i]);
				}
				cout << mina * maxb << endl;
			}else{
				long long anss = -10000000000000000;
				long long maxa = -inf, minb = inf, mina = inf, maxb = -inf;
				long long zxza = 1000000000, zdfa = -1000000000;
				long long zxzb = 1000000000, zdfb = -1000000000;
				for(int i = l1; i <= r1; i++){
					maxa = max(maxa, a[i]);
					mina = min(mina, a[i]);
					if(a[i] >= 0)zxza = min(zxza, a[i]);
					if(a[i] <= 0)zdfa = min(zdfa, a[i]);
				}
				for(int i = l2; i <= r2; i++){
					maxb = max(maxb, a[i]);
					minb = min(minb, a[i]);
					if(b[i] >= 0)zxzb = min(zxza, a[i]);
					if(b[i] <= 0)zdfb = min(zdfa, a[i]);
				}
				if(zxza != 1000000000){
					anss = max(anss, zxza * minb);
				}
				if(zdfa != -1000000000){
					anss = max(anss, zdfa * zxzb);
				}
				if(maxa >= 0){
					anss = max(anss, maxa * minb);
				}else{
					anss = max(anss, maxa * maxb);
				}
				if(mina <= 0){
					anss = max(anss, mina * maxb);
				}else{
					anss = max(anss, mina * minb);
				}
				cout << anss << endl;
			}
		}
	}
	return 0;
}
