#include<bits/stdc++.h>
using namespace std;
long long n, v[2505], m, k, ans;
bool b[305][305];
int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin.tie(0), cout.tie(0);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++){
		cin >> v[i];
	} 
	for(int i = 1; i <= m; i++){
		int x, y;
		cin >> x >> y;
		b[x][y] = 1, b[y][x] = 1;
	}
	if(k == 0){
		for(int i = 2; i <= n; i++){
			for(int k = 2; k <= n; k++){
				for(int j = 2; j <= n; j++){
					for(int l = 2; l <= n; l++){
						if(b[1][i] && b[i][k] && b[k][j] && b[j][l] && b[l][1]){
							ans = max(ans, v[i] + v[j] + v[k] + v[l]);
						}
					}
				}
			}
		}
		cout << ans;
	}else{
		sort(v + 1, v + n + 1);
		cout << v[n] + v[n - 1] + v[n - 2] + v[n - 3];
	}
	return 0;
}
