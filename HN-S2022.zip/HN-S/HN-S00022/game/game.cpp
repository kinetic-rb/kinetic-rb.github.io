#include<bits/stdc++.h>
#define ll long long int
using namespace std;
ll a[10010],b[10010],c[10010][10010];
int i,j,l1,r1,l2,r2,m,n,q,wqw;

ll piay(int m,int n,int x,int y)
{
	ll ans,num,anns,numm;
	if(m!=n)
	{
		sort(a+m,a+n+1);
		ans=a[m],num=a[n];
		
	}
		
	if(x!=y)
	{
		
		sort(b+x,b+y+1);
		anns=b[x];
		numm=b[y];
	}
	else
	{
		numm=b[y];
		anns=b[x];	
	}	
	
	for(i=m;i<=n;i++)
	{
		for(j=x;j<=y;j++)
		{
			
			c[i][j]=a[i]*b[j];
		}
	}
	
	//cout<<num<<" "<<ans<<endl<<numm<<" "<<anns;
	if(anns<0)
	{
		for(i=m;i<=n;i++)
		{
			if(a[i]==0)
				return 0;
			
		}
		return 	ans*anns;	
	}
	else
		return num*anns;	
	 
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m;
	cin>>q; 
	for(i=1;i<=n;i++)
		cin>>a[i];
	for(i=1;i<=m;i++)
		cin>>b[i]; 
	
	for(i=1;i<q+q;i++)
	{
		cin>>l1>>r1>>l2>>r2;
		
		wqw=piay(l1,r1,l2,r2);
		cout<<wqw<<endl;
		
	}
	
	
	
	
	
	return 0;
}







 
