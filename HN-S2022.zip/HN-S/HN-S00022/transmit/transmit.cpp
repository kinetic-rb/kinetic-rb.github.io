#include<bits/stdc++.h>

using namespace std;
long long int n,q,k,i,j,a[210001],b[200001],v[200001],s,t;

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	
	cin>>n>>q>>k;
	for(i=0;i<n;i++)
		cin>>v[i];
	for(i=0;i<n-1;i++)
		cin>>a[i]>>b[i];
	for(i=0;i<q;i++)
		cin>>s>>t;
	cout<<12<<12<<3;
	
	
	
	
	
	
	return 0;
}







 
