#include<bits/stdc++.h>
#define ll long long int
using namespace std;
int teer[100001],next[100001],to[100001],e=1,adj[100001];
int n,m,k,i,j,x,y,ans;
struct senery
{
	int bianhao;
	int grade;
	bool fangwen;
}qqq[10001];
void link(int a,int b)

{
	
	teer[e]=a;
	to[e]=b;
	
	adj[e]=teer[e];
	next[e]=to[e];
	
	e++;
}
int dfs(int a)
{
	int num=0;
	if(!qqq[a].fangwen)
		qqq[a].fangwen=true;
	else
		return num;	
	
	for(i=0;i<4;i++)
	{
		
		num=max(dfs(next[teer[a]]),num+qqq[to[a]].grade);	
	}
	return num;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	qqq[1].bianhao=1;
	qqq[1].grade=0;
	for(i=2;i<=n;i++)
	{
		qqq[i].bianhao=i;
		
		cin>>qqq[i].grade;
	}
	for(i=1;i<=m;i++)
	{
		cin>>x>>y;
		link(x,y);
	}
	
	ans=dfs(1);
	cout<<ans-1;
	
	return 0;
}
