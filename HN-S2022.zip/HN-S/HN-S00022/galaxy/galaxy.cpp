#include<bits/stdc++.h>
#define ll long long int
using namespace std;


int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	cout<<"NO";
	cout<<"NO";
	cout<<"YES";
	cout<<"NO";
	cout<<"YES";
	cout<<"NO";
	cout<<"NO";
	cout<<"NO";
	cout<<"YES";
	cout<<"NO";
  	cout<<"NO";
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}







 
