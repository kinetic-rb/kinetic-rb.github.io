#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("galaxy.in");
fstream fout("galaxy.out");

const LL kMaxN = 5e5 + 1;
struct V {
	LL et, o;
} v[kMaxN];
LL n, m, q, t;
unordered_map<LL, bool> s;

LL W(LL x, LL y) {
	return x * kMaxN + y;
}

void Update(LL x, LL k) {
	if (v[x].o == 1) {
		t--;
	}
	if ((v[x].o += k) == 1) {
		t++;
	}
}

int main() {
  fin >> n >> m;
  for (LL i = 1, x, y; i <= m; i++) {
  	fin >> x >> y;
  	s[W(x, y)] = 1, v[x].o++;
	}
	for (LL i = 1; i <= n; i++) {
		t += v[i].o == 1;
	}
	fin >> q;
	for (LL i = 1, o, x, y; i <= q; i++) {
		fin >> o >> x;
		if (o == 1) {
			fin >> y;
			s[W(x, y)] = 0;
			Update(x, -1);
		} else if (o == 2) {
			for (LL i = 1; i <= n; i++) {
				if (s.count(W(i, x)) && s[W(i, x)]) {
					s[W(i, x)] = 0;
					Update(i, -1);
				}
			}
		} else if (o == 3) {
			fin >> y;
			s[W(x, y)] = 1;
			Update(x, 1);
		} else {
			for (LL i = 1; i <= n; i++) {
				if (s.count(W(i, x)) && !s[W(i, x)]) {
					s[W(i, x)] = 1;
					Update(i, 1);
				}
			}
		}
		fout << (t == n ? "YES\n" : "NO\n");
	}
  return 0;
}

