#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("holiday.in");
fstream fout("holiday.out");

struct V {
	LL v, d[2501];
	vector<LL> e;
} v[2501];
LL n, m, t, ans;
queue<LL> q;

int main() {
  fin >> n >> m >> t;
  t++, fill(&v[0].d[0], &v[0].d[2501], -1), fill(&v[1], &v[2501], v[0]);
  for (LL i = 2; i <= n; i++) {
  	fin >> v[i].v;
	}
  for (LL i = 1, x, y; i <= m; i++) {
  	fin >> x >> y;
  	v[x].e.push_back(y), v[y].e.push_back(x);
	}
	for (LL i = 1; i <= n; i++) {
		for (v[i].d[i] = 0, q.push(i); !q.empty(); q.pop()) {
			for (LL j : v[q.front()].e) {
				if (v[i].d[j] == -1) {
				  v[i].d[j] = v[i].d[q.front()] + 1;
				  q.push(j);
				}
			}
		}
	}
	for (LL i = 2; i <= n; i++) {
		if (v[1].d[i] <= t) {
			for (LL j = 2; j <= n; j++) {
				if (i != j && v[i].d[j] <= t) {
					for (LL k = 2; k <= n; k++) {
						if (i != k && j != k && v[j].d[k] <= t) {
							for (LL l = 2; l <= n; l++) {
								if (i != l && j != l && k != l && v[k].d[l] <= t && v[l].d[1] <= t) {
									ans = max(ans, v[i].v + v[j].v + v[k].v + v[l].v);
								}
							}
						}
					}
				}
			}
		}
	}
	fout << ans;
  return 0;
}

