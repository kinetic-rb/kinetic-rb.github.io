#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("game.in");
fstream fout("game.out");

const LL kMaxM = 18, kMaxN = 1e5 + 1, kInf = 2e9;
LL n, m, q, a[kMaxN], b[kMaxN], c[2][kMaxN], d[4][kMaxM][kMaxN], e[2][kMaxM][kMaxN], lg[kMaxN];  // 0:max 1:min 2: >=0 min 3: <0 max

LL FindD(LL l, LL r, LL p) {
	if (p == 0 || p == 3) {
		return max(d[p][lg[r - l + 1]][l], d[p][lg[r - l + 1]][r - (1 << lg[r - l + 1]) + 1]);
	} else if (p == 1 || p == 2) {
		return min(d[p][lg[r - l + 1]][l], d[p][lg[r - l + 1]][r - (1 << lg[r - l + 1]) + 1]);
	}
}

LL FindE(LL l, LL r, LL p) {
	if (!p) {
		return max(e[p][lg[r - l + 1]][l], e[p][lg[r - l + 1]][r - (1 << lg[r - l + 1]) + 1]);
	} else {
		return min(e[p][lg[r - l + 1]][l], e[p][lg[r - l + 1]][r - (1 << lg[r - l + 1]) + 1]);
	}
}

LL M(LL x, LL l, LL r) {
	return x * FindE(l, r, x > 0);
}

int main() {
  fin >> n >> m >> q;
  fill(&d[0][0][0], &d[1][0][0], -kInf), fill(&d[1][0][0], &d[2][0][0], kInf);
  fill(&d[2][0][0], &d[3][0][0], kInf), fill(&d[3][0][0], &d[4][0][0], -kInf);
  fill(&e[0][0][0], &e[1][0][0], -kInf), fill(&e[1][0][0], &e[2][0][0], kInf);
  for (LL i = 1; i <= n; i++) {
  	fin >> a[i];
  	d[0][0][i] = d[1][0][i] = a[i];
  	if (a[i] >= 0) {
  		d[2][0][i] = a[i];
		} else {
			d[3][0][i] = a[i];
		}
	}
	for (LL i = 1; i <= m; i++) {
		fin >> b[i];
		e[0][0][i] = e[1][0][i] = b[i];
		c[0][i] = c[0][i - 1], c[1][i] = c[1][i - 1];
		if (b[i] > 0) {
			c[0][i]++;
		} else if (b[i] < 0) {
			c[1][i]++;
		}
	}
	for (LL i = 1, j = 0; i < kMaxN; i++) {
		lg[i] = j;
		if (i == (1 << j + 1)) {
			j++;
		}
	}
	for (LL i = 1; i < kMaxM; i++) {
		for (LL j = 1; j <= n; j++) {
			if (j + (1 << i - 1) <= n) {
				d[0][i][j] = max(d[0][i - 1][j], d[0][i - 1][j + (1 << i - 1)]);
				d[1][i][j] = min(d[1][i - 1][j], d[1][i - 1][j + (1 << i - 1)]);
				d[2][i][j] = min(d[2][i - 1][j], d[2][i - 1][j + (1 << i - 1)]);
				d[3][i][j] = max(d[3][i - 1][j], d[3][i - 1][j + (1 << i - 1)]);
			} else {
				d[0][i][j] = d[0][i - 1][j];
				d[1][i][j] = d[1][i - 1][j];
				d[2][i][j] = d[2][i - 1][j];
				d[3][i][j] = d[3][i - 1][j];
			}
		}
		for (LL j = 1; j <= m; j++) {
			if (j + (1 << i - 1) <= m) {
				e[0][i][j] = max(e[0][i - 1][j], e[0][i - 1][j + (1 << i - 1)]);
				e[1][i][j] = min(e[1][i - 1][j], e[1][i - 1][j + (1 << i - 1)]);
			} else {
				e[0][i][j] = e[0][i - 1][j];
				e[1][i][j] = e[1][i - 1][j];
			}
		}
	}
	for (LL i = 1, l1, r1, l2, r2; i <= q; i++) {
		fin >> l1 >> r1 >> l2 >> r2;
		if (c[0][l2 - 1] == c[0][r2] && c[1][l2 - 1] == c[1][r2]) {  // none > 0 && none < 0
			fout << 0 << '\n';
		} else if (c[0][l2 - 1] == c[0][r2]) {                       // none > 0
			fout << M(FindD(l1, r1, 1), l2, r2) << '\n';
		} else if (c[1][l2 - 1] == c[1][r2]) {                       // none < 0
			fout << M(FindD(l1, r1, 0), l2, r2) << '\n';
		} else {
			fout << max(M(FindD(l1, r1, 2), l2, r2), M(FindD(l1, r1, 3), l2, r2)) << '\n';
		}
	}
  return 0;
}

