#include <bits/stdc++.h>
#define LL long long

using namespace std;

fstream fin("transmit.in");
fstream fout("transmit.out");

struct V {
	LL v, d, s, f[19];
	vector<LL> e;
} v[200001];
LL n, q, k;

void T(LL f, LL x) {
	for (LL i : v[x].e) {
		if (i != f) {
			v[i].d = v[x].d + 1, v[i].s = v[x].s + v[i].v, v[i].f[0] = x;
			T(x, i);
		}
	}
}

LL Lca(LL x, LL y) {
	if (v[x].d < v[y].d) {
		swap(x, y);
	}
	for (LL i = 18; i >= 0; i--) {
		if (v[x].d - (1 << i) >= v[y].d) {
			x = v[x].f[i];
		}
	}
	for (LL i = 18; i >= 0; i--) {
		if (v[x].f[i] != v[y].f[i]) {
			x = v[x].f[i], y = v[y].f[i];
		}
	}
	return x == y ? x : v[x].f[0];
}

int main() {
  fin >> n >> q >> k;
  for (LL i = 1; i <= n; i++) {
  	fin >> v[i].v;
	}
	for (LL i = 1, x, y; i < n; i++) {
		fin >> x >> y;
    v[x].e.push_back(y), v[y].e.push_back(x);
	}
	T(0, 1);
	for (LL i = 1; i <= 18; i++) {
		for (LL j = 1; j <= n; j++) {
			v[j].f[i] = v[v[j].f[i - 1]].f[i - 1];
		}
	}
	for (LL i = 1, x, y; i <= q; i++) {
		fin >> x >> y;
		LL t = Lca(x, y);
		fout << v[x].s + v[y].s - v[t].s * 2 + v[t].v << '\n';
	}
  return 0;
}

