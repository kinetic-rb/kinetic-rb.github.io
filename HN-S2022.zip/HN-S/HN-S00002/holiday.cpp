#include<bits/stdc++.h>
using namespace std;
int a[2501],map_[10001][10001],ans=-9999999,vis[2501];
int n,m,k,dir[10001];
void dfs(int dia,int num,int sum,int c){
	if(num==5&&dia==1){
		ans=max(ans,sum);
		return;
	}
	for(int i=1;i<=n;i++){
		for(int j=0;j<=1;j++){
			if(j==0){
				if(map_[dia][i]==1&&vis[i]==0&&c<k){
					dfs(i,num,sum,c+1);
				}
			}else{
				if(map_[dia][i]==1&&vis[i]==0){
					c=0;
					vis[i]=1;
					dfs(i,num+1,sum+a[i],c);
					vis[i]=0;
				}
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	a[1]=0;
	for(int i=2;i<=n;i++){
		cin>>a[i];
	}
	int head=1,flag=1;
	for(int i=1;i<=m;i++){
		int a,b;
		cin>>a>>b;
		map_[a][b]=1;
		map_[b][a]=1;
	}
	dfs(1,0,0,0);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/
