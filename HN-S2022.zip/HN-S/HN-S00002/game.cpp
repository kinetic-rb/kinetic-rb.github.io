#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[10001],b[10001],c[10001][10001];
int l1,r1,l2,r2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	while(q--){
		cin>>l1>>r1>>l2>>r2;
		int minn=999999999;
		for(int i=l1;i<=r1;i++){
			for(int j=l2;j<=r2;j++){
				minn=min(minn,abs(c[i][j]));
			}
		}
		cout<<minn<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/
