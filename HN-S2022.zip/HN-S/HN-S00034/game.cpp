#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL l1,l2,r1,r2,n,m,q,maxn,minn[100010],a[100010],b[100010],c[10000][10000];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	while(q--){
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		maxn=-0x3f3f3f3f3f3f;
		for(int i=0;i<=100000;i++)minn[i]=0x3f3f3f3f3f3f;
		for(int i=l1;i<=r1;i++){
			for(int j=l2;j<=r2;j++)
				minn[i]=min(minn[i],c[i][j]);
			maxn=max(maxn,minn[i]);
		}
		printf("%lld\n",maxn);
	}
	return 0;
}
/*
����һ 
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/

