#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL maxn=-1,n,m,k,a[10010][10010],num[2510],flag[2510],x,y;
void dfs(int now,int sum,int cishu){
	if(cishu==5){
		if(a[now][1]!=-1&&a[now][1]<=k+1)maxn=max(maxn,(LL)sum);
//		,printf("5:%lld-->1,sum=%lld\n",now,sum); 
		return;
	}
	for(int i=2;i<=n;i++){
		if(flag[i]==0&&a[now][i]>0&&a[now][i]<=k+1){
			flag[i]=1;
//			printf("%lld:%lld-->%lld,sum+=num[%lld]=%lld\n",cishu,now,i,i,num[i]+sum);//����
			dfs(i,sum+num[i],cishu+1);
			flag[i]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(a,-1,sizeof(a));//��ʼ����-1Ϊ����ͨ·�� 
	a[1][1]=0;
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;i++)scanf("%lld",&num[i]),a[i][i]=0;//�Լ����Լ��ľ���Ϊ0 
	for(int i=1;i<=m;i++){
		scanf("%lld%lld",&x,&y);
		a[x][y]=1,a[y][x]=1;
	}	
	//��ͨһ�ε���ĵ� 
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int k=1;k<=n;k++){
				if(a[i][j]>0&&a[j][k]>0){
					if(a[i][k]!=-1)a[i][k]=a[k][i]=min(a[i][k],a[i][j]+a[j][k]);
					else a[i][k]=a[k][i]=a[i][j]+a[j][k];
				}
			}
		}
	}
	//��ͨ��ε���ĵ� 
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			if(a[i][j]>k+1)a[i][j]=-1;//ת����������k
////			printf("%lld ",a[i][j]);
//		}
////		printf("\n");
//	}
	//���� 
	dfs(1,0,1);
	printf("%lld",maxn);
	return 0;
}
/*
����һ 
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
/*
������ 
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/

