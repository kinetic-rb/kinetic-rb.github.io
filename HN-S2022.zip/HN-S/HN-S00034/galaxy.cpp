#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL n,m,q,temp;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1,temp;i<=m;i++)cin>>temp>>temp;
	cin>>q;
	while(q--){
		printf("NO\n");
	}
	return 0;
}

