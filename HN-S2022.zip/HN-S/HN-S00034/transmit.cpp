#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL minn,ta,tb,n,Q,k,v[200010],a[10010][10010];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(a,-1,sizeof(a));
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++)cin>>v[i],a[i][i]=0;
	for(int i=1;i<=n-1;i++){
		scanf("%lld%lld",&ta,&tb);
		a[ta][tb]=1,a[tb][ta]=1;
	}	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int z=1;z<=n;z++){
				if(a[i][j]>0&&a[j][z]>0){
					if(a[i][z]!=-1)a[i][z]=a[z][i]=min(a[i][z],a[i][j]+a[j][z]);
					else a[i][z]=a[z][i]=a[i][j]+a[j][z];
				}
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(a[i][j]>k)a[i][j]=-1;
		}
	}
	while(Q--){
		LL s,t;
		cin>>s>>t;
		if(a[s][t]>0)printf("%lld\n",v[s]+v[t]);
		else{
			minn=0x3f3f3f3f3f3f;
			for(int i=1;i<=n;i++)
				if(a[s][i]>0&&a[i][t]>0)minn=min(minn,v[i]);
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					if(a[s][i]>0&&a[i][j]>0&&a[j][t]>0)minn=min(minn,v[i]+v[j]);
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					for(int z=1;z<=n;z++)
						if(a[s][i]>0&&a[i][j]>0&&a[j][z]>0&&a[z][t]>0)minn=min(minn,v[i]+v[j]+v[z]);
			printf("%lld\n",minn+v[s]+v[t]);
		}
	}
	//��ͨ��ε���ĵ� 
	return 0;
}

