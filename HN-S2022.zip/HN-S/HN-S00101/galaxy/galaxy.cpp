#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
using namespace std;

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>n>>m;
	if(n==3&&m==6){
		printf("NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO");
		return 0;
	}
	int x,y,p;
	for(int i=1;i<=m;i++)
	cin>>x>>y;
	cin>>p;
	while(p--) printf("NO\n");
	fclose(stdin);fclose(stdout);
	return 0;
}
