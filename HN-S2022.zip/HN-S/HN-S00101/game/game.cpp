#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <bits/stdc++.h>
using namespace std;
const int M=100005;
int n,m,q;
long long ans;
struct num
{
	int w,j;
}a[M],b[M];

bool cmp1(num y,num e){ return y.w>e.w || (y.w==e.w&&y.j>e.j);}
bool cmp2(num z,num p){ return z.w<p.w || (z.w==p.w&&z.j>p.j);}

int main()
{ 
	freopen("game.in ","r",stdin);//����������1/2�ķ֣�2����ƭ������
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
	{
		a[i].j=i;
		scanf("%d",&a[i].w);
	}
	for(int i=1;i<=m;i++)
	{
		b[i].j=i;
		scanf("%d",&b[i].w);
	}
	sort(a+1,a+n+1,cmp1);
	sort(b+1,b+m+1,cmp2);
	/*for(int i=1;i<=n;i++)
	cout<<a[i].j<<" "<<a[i].w<<endl;
	for(int i=1;i<=m;i++)
	cout<<b[i].j<<" "<<b[i].w<<endl;*/
	while(q--){
		int l1,l2,r1,r2,s,y;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(a[r1].w>0&&b[l1].w>0){//ȫ������������ 
		for(int i=1;i<=n;i++)
		if(a[i].j>=l1&&a[i].j<=r1) s=a[i].w;
		for(int i=1;i<=m;i++)
		if(b[i].j>=l2&&b[i].j<=r2) y=b[i].w;
		}
		else if(b[l1].w<0&&a[l1].w<0){
			s=a[a[l1].j].w;
			y=b[b[r2].j].w;
		}
		ans=(long long)s*y;
		printf("%lld\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
