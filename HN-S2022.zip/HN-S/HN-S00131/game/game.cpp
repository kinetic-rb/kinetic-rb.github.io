#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 5;
const int MAXB = 20;
const int INF = 2e9;
const long long LINF = 2e18;

struct ST {
    int stMax[MAXN][MAXB], stMin[MAXN][MAXB], lg[MAXN];

    void init(int a[MAXN], int n) {
        for(int i = 1; i <= n; i++) {
            stMax[i][0] = stMin[i][0] = a[i];
            //printf("%d ", a[i]);
        }
        //printf("\n");
        for(int j = 1; j <= MAXB - 1; j++) {
            for(int i = 1; i + (1 << j) - 1 <= n; i++) {
                stMax[i][j] = max(stMax[i][j - 1], stMax[i + (1 << (j - 1))][j - 1]);
                stMin[i][j] = min(stMin[i][j - 1], stMin[i + (1 << (j - 1))][j - 1]);
            }
        }
        for(int i = 2; i <= n; i++) {
            lg[i] = lg[i >> 1] + 1;
        }
    }

    int queryMax(int l, int r) {
        int s = lg[r - l + 1];
        return max(stMax[l][s], stMax[r - (1 << s) + 1][s]);
    }

    int queryMin(int l, int r) {
        int s = lg[r - l + 1];
        return min(stMin[l][s], stMin[r - (1 << s) + 1][s]);
    }
};

ST s1, s2, s3, s4, s5;
int a[MAXN], b[MAXN];
int x[MAXN], y[MAXN], z[MAXN];
int lg[MAXN];
int n, m, q;

int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);

    scanf("%d%d%d", &n, &m, &q);
    for(int i = 1; i <= n; i++) {
        x[i] = INF;
        y[i] = -INF;
        z[i] = INF;
    }
    for(int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
        if(a[i] > 0) {
            x[i] = a[i];
        } else if(a[i] < 0) {
            y[i] = a[i];
        } else {
            z[i] = a[i];
        }
    }
    for(int i = 1; i <= m; i++) {
        scanf("%d", &b[i]);
    }
    s1.init(x, n);
    s2.init(y, n);
    s3.init(z, n);
    s4.init(a, n);
    s5.init(b, m);
    for(int i = 1; i <= q; i++) {
        int l1, r1, l2, r2;

        scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
        long long ans = -LINF;
        int t1 = s5.queryMin(l2, r2), t2 = s5.queryMax(l2, r2);
        //printf("B Min: %d\n", t1);
        if(s3.queryMin(l1, r1) == 0) {
            ans = max(ans, 0ll);
        }
        int v = s4.queryMax(l1, r1);
        //printf("A Max: %d\n", v);
        if(v > 0) {
            ans = max(ans, 1ll * v * t1);
            ans = max(ans, 1ll * s1.queryMin(l1, r1) * t1);
            //printf("Min Zheng: %d\n", s1.queryMin(l1, r1));
        } else {
            ans = max(ans, 1ll * v * t2);
        }
        v = s4.queryMin(l1, r1);
        if(v < 0) {
            ans = max(ans, 1ll * v * t2);
            ans = max(ans, 1ll * s2.queryMax(l1, r1) * t2);
        } else {
            ans = max(ans, 1ll * v * t1);
        }
        printf("%lld\n", ans);
    }

    return 0;
}
