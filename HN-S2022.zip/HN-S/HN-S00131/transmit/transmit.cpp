#include<bits/stdc++.h>
using namespace std;

const int MAXN = 200000 + 5;
const int MAXM = 2000 + 5;

vector<int> G[MAXN];
int a[MAXN];
int dep[MAXN], fa[MAXN];
int tmp1[MAXN], tmp2[MAXN], t1, t2;
long long dp[MAXM][MAXM];
int n, q, k;

void dfs(int u, int f) {
    fa[u] = f;
    dep[u] = dep[f] + 1;
    for(int i = 0; i < (int)G[u].size(); i++) {
        int v = G[u][i];

        if(v == f) {
            continue;
        }
        dfs(v, u);
    }
}

long long solve(int u, int v) {
    int x = u, y = v;
    if(dep[x] < dep[y]) {
        swap(x, y);
    }
    while(dep[x] > dep[y]) {
        x = fa[x];
    }
    while(x != y) {
        x = fa[x]; y = fa[y];
    }
    int f = x;
    x = u; y = v;
    t1 = t2 = 0;
    while(x != f) {
        tmp1[++t1] = a[x];
        x = fa[x];
    }
    tmp1[++t1] = a[f];
    while(y != f) {
        tmp2[++t2] = a[y];
        y = fa[y];
    }
    for(int i = t2; i >= 1; i--) {
        tmp1[++t1] = tmp2[i];
    }
    int n = t1;
    for(int i = 1; i <= n; i++) {
        dp[i][i] = 0;
    }
    for(int l = 2; l <= n; l++) {
        for(int i = 1; i + l - 1 <= n; i++) {
            int j = i + l - 1;
            dp[i][j] = 1e18;
            if(l <= k + 1) {
                dp[i][j] = tmp1[i] + tmp1[j];
                continue;
            }
            for(int p = i + 1; p <= j - 1; p++) {
                dp[i][j] = min(dp[i][j], dp[i][p] + dp[p][j] - tmp1[p]);
            }
        }
    }
    return dp[1][n];
}

int main() {
    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);

    scanf("%d%d%d", &n, &q, &k);
    for(int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
    }
    for(int i = 1; i <= n - 1; i++) {
        int u, v;

        scanf("%d%d", &u, &v);
        G[u].push_back(v);
        G[v].push_back(u);
    }
    dfs(1, 0);
    for(int i = 1; i <= q; i++) {
        int u, v;

        scanf("%d%d", &u, &v);
        printf("%lld\n", solve(u, v));
    }

    return 0;
}
