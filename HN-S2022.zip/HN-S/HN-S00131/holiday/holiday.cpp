#include<bits/stdc++.h>
using namespace std;

const int MAXN = 2500 + 5;

queue<int> q;
vector<int> G[MAXN], H[MAXN];
int dis[MAXN][MAXN];
bool vis[MAXN];
long long s[MAXN], f[MAXN], g[MAXN];
int n, m, k;

bool cmp(int i, int j) {
    return s[i] > s[j];
}

void bfs(int s) {
    while(!q.empty()) q.pop();
    for(int i = 1; i <= n; i++) {
        vis[i] = false;
    }
    dis[s][s] = 0;
    vis[s] = true;
    q.push(s);
    while(!q.empty()) {
        int u = q.front(); q.pop();
        for(int i = 0; i < (int)G[u].size(); i++) {
            int v = G[u][i];

            if(vis[v]) {
                continue;
            }
            vis[v] = true;
            dis[s][v] = dis[s][u] + 1;
            q.push(v);
        }
    }
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);

    scanf("%d%d%d", &n, &m, &k);
    for(int i = 2; i <= n; i++) {
        scanf("%lld", &s[i]);
    }
    for(int i = 1; i <= m; i++) {
        int u, v;

        scanf("%d%d", &u, &v);
        G[u].push_back(v);
        G[v].push_back(u);
    }
    for(int i = 1; i <= n; i++) {
        bfs(i);
    }
    for(int i = 2; i <= n; i++) {
        for(int j = 2; j <= n; j++) {
            if(i == j || dis[1][j] > k + 1) {
                continue;
            }
            if(dis[i][j] <= k + 1) {
                H[i].push_back(j);
            }
        }
        sort(H[i].begin(), H[i].end(), cmp);
    }
    long long ans = 0;
    for(int i = 2; i <= n; i++) {
        if(H[i].size() < 1) {
            continue;
        }
        for(int j = i + 1; j <= n; j++) {
            if(dis[i][j] > k + 1 || H[j].size() < 1) {
                continue;
            }
            if(s[i] + s[H[i][0]] + s[j] + s[H[j][0]] <= ans) continue;
            for(int p = 0; p < (int)H[i].size() && p < 3; p++) {
                for(int q = 0; q < (int)H[j].size() && q < 3; q++) {
                    int a = H[i][p], d = H[j][q];
                    if(a == j || a == d || i == d) {
                        continue;
                    }
                    ans = max(ans, s[a] + s[i] + s[j] + s[d]);
                    //printf("%d %d %d %d : %lld %lld %lld %lld : %lld\n", a, i, j, d, s[a], s[i], s[j], s[d], s[a] + s[i] + s[j] + s[d]);
                }
            }
        }
    }
    printf("%lld\n", ans);

    return 0;
}
