#include<bits/stdc++.h>
using namespace std;

struct Line {
    int v, id;
};

const int MAXN = 500000 + 5;

vector<Line> G[MAXN], H[MAXN];
int in[MAXN], out[MAXN];
int from[MAXN], to[MAXN];
bool dele[MAXN];
int n, m, q;

int main() {
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);

    scanf("%d%d", &n, &m);
    for(int i = 1; i <= m; i++) {
        int u, v;

        scanf("%d%d", &u, &v);
        G[u].push_back((Line){v, i});
        H[v].push_back((Line){u, i});
        from[i] = u; to[i] = v;
    }
    scanf("%d", &q);
    while(q--) {
        int t, u, v;

        scanf("%d%d", &t, &u);
        if(t == 1) {
            scanf("%d", &v);
            for(int i = 0; i < (int)G[u].size(); i++) {
                if(G[u][i].v == v) {
                    dele[G[u][i].id] = true;
                    break;
                }
            }
        } else if(t == 2) {
            for(int i = 0; i < (int)H[u].size(); i++) {
                dele[H[u][i].id] = true;
            }
        } else if(t == 3) {
            scanf("%d", &v);
            for(int i = 0; i < (int)G[u].size(); i++) {
                if(G[u][i].v == v) {
                    dele[G[u][i].id] = false;
                    break;
                }
            }
        } else if(t == 4) {
            for(int i = 0; i < (int)H[u].size(); i++) {
                dele[H[u][i].id] = false;
            }
        }
        for(int i = 1; i <= n; i++) {
            in[i] = out[i] = 0;
        }
        for(int i = 1; i <= m; i++) {
            int u = from[i], v = to[i];
            if(dele[i]) {
                continue;
            }
            in[v]++; out[u]++;
        }
        bool flag = true;
        for(int i = 1; i <= n; i++) {
            if(out[i] != 1) {
                flag = false;
            }
        }
        if(flag) {
            printf("YES\n");
        } else {
            printf("NO\n");
        }
    }

    return 0;
}
