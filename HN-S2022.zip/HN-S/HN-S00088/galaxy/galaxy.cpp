#include<bits/stdc++.h>
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=s*10+(ch-'0');
		ch=getchar();
	}
	return s*f;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,m;
struct Edge{
	int to,next;
}edge[500010];
int num,head[500010];
void add(int from, int to){
	num++;
	edge[num].to=to;
	edge[num].next=head[from];
	head[from]=num;
}
map<pair<int,int>,bool>mp1;
map<int,bool>mp2;
bool vis[500010],can[500010];
void dfs(int x){
	if(mp2[x]) return;
	vis[x]=1;
	for(int i=head[x];i;i=edge[i].next){
		int y=edge[i].to;
		if(mp1[make_pair(x,y)]) continue;
		if(!vis[y]){
			vis[y]=1;
			dfs(y);
			vis[y]=0;
		}
		else{
			can[x]=1;
			continue;
		}
		if(can[y]) can[x]=1;
	}
}
int cind[500010],coud[500010];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		add(u,v);
		coud[u]++;
		cind[v]++;
	}
	int q=read();
	while(q--){
		int t=read();
		if(t==1){
			int u=read(),v=read();
			mp1[make_pair(u,v)]=1;
			coud[u]--;
			cind[v]--;
		}
		else if(t==2){
			int u=read();
			coud[u]=0;
			mp2[u]=1;
			for(int i=head[u];i;i=edge[i].next) cind[edge[i].to]--;
		}
		else if(t==3){
			int u=read(),v=read();
			mp1.erase(make_pair(u,v));
			coud[u]++;
			cind[v]++;
		}
		else{
			int u=read();
			mp2.erase(u);
			for(int i=head[u];i;i=edge[i].next) cind[edge[i].to]++,coud[u]++;
		}
		bool yes=true;
		for(int i=1;i<=n;i++){
			if(coud[i]!=1){
				yes=false;
				break;
			}
		}
		memset(vis,0,sizeof vis);
		memset(can,0,sizeof can);
		for(int i=1;i<=n;i++){
			if(!can[i]) dfs(i);
		}
		for(int i=1;i<=n;i++){
			if(!can[i]){
				yes=false;
				break;
			}
		}
		if(yes) puts("YES");
		else puts("NO");
	}
	return 0;
}
