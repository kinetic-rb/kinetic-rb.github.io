#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long w[2510];
struct Edge{
	int to,next;
}edge[20010];
int num,head[2510];
void add(int from, int to){
	num++;
	edge[num].to=to;
	edge[num].next=head[from];
	head[from]=num;
}
bool vis[2510];
int dis[2510][2510];
void bfs(int s){
	queue<int>q;
	q.push(s);
	for(int i=1;i<=n;i++) dis[s][i]=2147483647;
	memset(vis,0,sizeof vis);
	dis[s][s]=0;
	vis[s]=1;
	while(q.size()){
		int tmp=q.front();
		q.pop();
		for(int i=head[tmp];i;i=edge[i].next){
			int y=edge[i].to;
			if(dis[s][y]>dis[s][tmp]+1){
				dis[s][y]=dis[s][tmp]+1;
				if(!vis[y]) q.push(y),vis[y]=1;
			}
		}
	}
}
int ans[2510][3];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%lld",w+i);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v),add(v,u);
	}
	for(int i=1;i<=n;i++) bfs(i);
	for(int i=2;i<=n;i++){
		for(int j=2;j<=n;j++){
			if(i==j) continue;
			if(dis[1][i]<=k+1&&dis[i][j]<=k+1){
				long long tmp=w[i]+w[j];
				if(tmp>=w[j]+w[ans[j][0]]){
					ans[j][2]=ans[j][1];
					ans[j][1]=ans[j][0];
					ans[j][0]=i;
				}
				else if(tmp>=w[i]+w[ans[j][1]]) ans[j][2]=ans[j][1],ans[j][1]=i;
				else if(tmp>w[i]+w[ans[j][2]]) ans[j][2]=i;
			}
		}
	}
	long long anss=0;
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++){
			if(i==j||dis[i][j]>k+1) continue;
			int a,b;
			for(int ii=0;ii<3;ii++)
				for(int jj=0;jj<3;jj++){
					a=ans[i][ii],b=ans[j][jj];
					if(a!=0&&b!=0&&a!=j&&b!=i&&a!=b) anss=max(anss,w[i]+w[j]+w[a]+w[b]);
				}
		}
	printf("%lld\n",anss);
	return 0;
}
