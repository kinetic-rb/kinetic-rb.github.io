#include<bits/stdc++.h>
#define int long long
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=s*10+(ch-'0');
		ch=getchar();
	}
	return s*f;
}
void write(long long x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,m,q,a[100010],b[100010];
int amin[100010][20],amax[100010][20],apmin[100010][20],anmin[100010][20];
int bmin[100010][20],bmax[100010][20];
int minRMQ(int st[100010][20], int l, int r){
	int k=log2(r-l+1);
	return min(st[l][k],st[r-(1<<k)+1][k]);
}
int maxRMQ(int st[100010][20], int l, int r){
	int k=log2(r-l+1);
	return max(st[l][k],st[r-(1<<k)+1][k]);
}
inline long long calc(int aa, int l, int r){
	if(aa<=0) return (long long)aa*maxRMQ(bmax,l,r);
	else return (long long)aa*minRMQ(bmin,l,r);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++){
		amin[i][0]=amax[i][0]=a[i]=read();
		if(a[i]>0) apmin[i][0]=a[i],anmin[i][0]=-2147483647;
		else if(a[i]<0) apmin[i][0]=2147483647,anmin[i][0]=a[i];
	}
	for(int i=1;i<=m;i++)
		bmin[i][0]=bmax[i][0]=b[i]=read();
	for(int j=1;(1<<j)<=n;j++)
		for(int i=1;i<=n;i++){
			amin[i][j]=min(amin[i][j-1],amin[i+(1<<(j-1))][j-1]);
			amax[i][j]=max(amax[i][j-1],amax[i+(1<<(j-1))][j-1]);
			apmin[i][j]=min(apmin[i][j-1],apmin[i+(1<<(j-1))][j-1]);
			anmin[i][j]=max(anmin[i][j-1],anmin[i+(1<<(j-1))][j-1]);
			bmin[i][j]=min(bmin[i][j-1],bmin[i+(1<<(j-1))][j-1]);
			bmax[i][j]=max(bmax[i][j-1],bmax[i+(1<<(j-1))][j-1]);
		}
	while(q--){
		int l1=read(),r1=read(),l2=read(),r2=read();
		long long ans=max(calc(minRMQ(amin,l1,r1),l2,r2),calc(maxRMQ(anmin,l1,r1),l2,r2));
		if(minRMQ(apmin,l1,r1)!=2147483647) ans=max(ans,calc(minRMQ(apmin,l1,r1),l2,r2));
		if(maxRMQ(anmin,l1,r1)!=-2147483647) ans=max(ans,calc(maxRMQ(anmin,l1,r1),l2,r2));
		write(ans);
		putchar('\n');
	}
	return 0;
}
