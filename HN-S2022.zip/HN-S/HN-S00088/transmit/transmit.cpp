#include<bits/stdc++.h>
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=s*10+(ch-'0');
		ch=getchar();
	}
	return s*f;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,q,k,v[200010],dep[200010],up[200010][20];
long long sum[200010][3];
struct Edge{
	int to,next;
}edge[400010];
int num,head[200010];
void add(int from, int to){
	num++;
	edge[num].to=to;
	edge[num].next=head[from];
	head[from]=num;
}
void dp(int x, int fa){
	dep[x]=dep[fa]+1;
	up[x][0]=fa;
	if(k==1) sum[x][0]=sum[fa][0]+v[x];
	else if(k==2){
		sum[x][0]=min(sum[fa][0],sum[fa][1])+v[x];
		sum[x][1]=sum[fa][0];
	}
	else{
		sum[x][0]=min(min(sum[fa][0],sum[fa][1]),sum[fa][2])+v[x]; 
		sum[x][1]=sum[fa][0];
		sum[x][2]=sum[fa][1];
	}
	for(int i=head[x];i;i=edge[i].next){
		int y=edge[i].to;
		if(y==fa) continue;
		dp(y,x);
	}
}
int lca(int x, int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=log2(n)+1;i>=0;i--){
		if(dep[up[x][i]]>=dep[y]) x=up[x][i];
	}
	if(x==y) return x;
	for(int i=log2(n)+1;i>=0;i--){
		if(up[x][i]!=up[y][i]) x=up[x][i],y=up[y][i];
	}
	return up[x][0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++) scanf("%d",v+i);
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		add(u,v);
	}
	dep[1]=1;
	sum[1][0]=v[1];
	dp(1,0);
	for(int j=1;(1<<j)<=n;j++){
		for(int i=1;i<=n;i++){
			up[i][j]=up[up[i][j-1]][j-1];
		}
	}
	
	while(q--){
		int s=read(),t=read();
		int LCA=lca(s,t);
		if(k==1){
			write(sum[s][0]-sum[LCA][0]+sum[t][0]-sum[LCA][0]+v[LCA]);
		}
		else if(k==2){
			write(min(sum[s][0],sum[s][1])+min(sum[t][0],sum[t][1])-sum[LCA][0]-sum[LCA][1]+v[LCA]);
		}
		else{
			write(min(min(sum[s][0],sum[s][1]),sum[s][2])+min(min(sum[t][0],sum[t][1]),sum[t][2])-2*max(max(sum[LCA][0],sum[LCA][1]),sum[LCA][2])+v[LCA]);
		}
		putchar('\n');
	}
	return 0;
}
