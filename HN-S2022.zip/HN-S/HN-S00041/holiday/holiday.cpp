#include<bits/stdc++.h>
using namespace std;
vector<int> e[2505];
int n,m,k,t,id;
bool flag[2505];
unsigned long long as[2505],ans,maxn,y[2505],ansz[5];	
void dfs(int s,int q){ 
	if(flag[s]==0){
		e[t].push_back(s);
	}
	flag[s]=1;
	if(q==0){
		return ;
	}
	long long l=y[s],q2=q-1;
	for(long long i=0;i<l;i++){
		if(flag[e[s][i]]==0){
			dfs(e[s][i],q2);
		}
			
	}
}
bool cmp(int x,int y){
	return as[x]>as[y];
}
void dfs2(int ansn){
	if(ansn==4){
		long long l2=e[t].size();
		bool flag2=0;
		for(int j=0;j<l2;j++){
			if(e[t][j]==1){
				flag2=1;
				break;
			}
		}
		if(flag2==1){
			cout<<ans;
			exit(0);
		}else{
			return ;
		}
	}
	sort(e[t].begin(),e[t].end()+1,cmp);
	long long l=e[t].size(),t2=t;
 	for(long long j=0;j<l;j++){
 		t=e[t2][j];
 		if(t==1){
 			continue;	
		}
		if(flag[t]==0){
 			ans+=as[t];
			flag[t]=1;
			dfs2(ansn+1);
			flag[t]=0;
			ans-=as[t];
		}		
	}
	t=t2;
	return ;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>as[i];
	}

	for(int u,v,i=1;i<=m;i++){
		cin>>u>>v;
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=1;i<=n;i++){
		y[i]=e[i].size();
	}
	for(int i=1;i<=n;i++){
		memset(flag,0,sizeof(flag));
		t=i;
		long long l=e[i].size();flag[t]=1;
		for(long long j=0;j<l;j++){
			flag[e[i][j]]=1;
			dfs(e[i][j],k);
		}
	}

	memset(flag,0,sizeof(flag));
	t=1;
	dfs2(0);

	return 0;
}

