#include<bits/stdc++.h>
#define N 3005
using namespace std;
int n,m,t;
long long tu[N][N],a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>t;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			tu[i][j]=a[i]*b[j];
		}
	}
	while(t--){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		long long ans=LONG_LONG_MIN;
		for(int i=l1;i<=r1;i++){
			long long minn=LONG_LONG_MAX;
			for(int j=l2;j<=r2;j++){
				minn=min(minn,tu[i][j]);
			}
			ans=max(ans,minn);
		}
		cout<<ans<<"\n";
	}
	return 0;
}

