#include<bits/stdc++.h>

using namespace std;
vector<int> e[200005];
bool flag[200005],bo;
long long n,q,k,s[200005],sa,ea,ans;
void dfs(int c,int len){
	flag[c]=1;
	if(c==ea){
		cout<<s[sa]+s[ea]+ans<<"\n";
		bo=1;
		return ;
	}
	if(len>k){
		ans+=s[c];
		len%=k;
	}
	long long l=e[c].size();
	for(long long j=0;j<l;j++){
		if(flag[e[c][j]]==0){
			dfs(e[c][j],len+1);
			if(bo==1){
				return ;
			}
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		cin>>s[i];
	}
	for(int u,v,i=1;i<n;i++){
		cin>>u>>v;
		e[u].push_back(v);
		e[v].push_back(u);
	}
	while(q--){
		bo=0; 
		ans=0;
		cin>>sa>>ea;dfs(sa,0);
		if(bo==0){
			cout<<s[sa]+s[ea]<<"\n";
		}
	}
	return 0;
}
