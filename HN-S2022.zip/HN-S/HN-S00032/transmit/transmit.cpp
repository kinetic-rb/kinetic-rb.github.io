#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 5;

int n, q, k, s, t, v[N];
vector<int> c[N];

bool C(){
  for (int i = 0; i < c[s].size(); i++){
    if (c[s][i] == t){
      return 1;
    }
  }
  return 0;
}

int main(){
  freopen("transmit.in", "r", stdin);
  freopen("transmit.out", "w", stdout);
  cin >> n >> q >> k;
  for (int i = 1; i <= n; i++){
    cin >> v[i];
  }
  for (int i = 1; i < n; i++){
    int a, b;
    cin >> a >> b;
    c[a].push_back(b), c[b].push_back(a);
  }
  while (q--){
    cin >> s >> t;
    if (C()){
      cout << v[s] + v[t] << '\n';
    }
  }
  return 0;
}
