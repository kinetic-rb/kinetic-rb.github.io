#include <bits/stdc++.h>

using namespace std;

const int N = 1e3 + 5;

int n, m, q, t, u, v;
bool h[N], f[N], k[N][N], d[N][N];

bool D(int x){
  int sum = 0;
  for (int i = 1; i <= n; i++){
    sum += (k[x][i] == 0);
  }
  return (sum == 1);
}

bool C(int x){
  if (f[x]){
    return 1;
  }
  f[x] = 1;
  for (int i = 1; i <= n; i++){
    if (d[x][i] && !k[x][i] && h[i]){
      bool p = C(i);
      if (p){
        return 1;
      }
    }
  }
  return 0;
}

int main(){
  freopen("galaxy.in", "r", stdin);
  freopen("galaxy.out", "w", stdout);
  cin >> n >> m;
  for (int i = 1; i <= m; i++){
    int x, y;
    cin >> x >> y;
    d[x][y] = 1;
  }
  cin >> q;
  while (q--){
    cin >> t >> u;
    if (t == 1 || t == 3){
      cin >> v;
      k[u][v] = (t == 1 ? 1 : 0);
    } else {
      h[u] = (t == 2 ? 1 : 0);
    }
    bool flag = 1;
    fill(f + 1, f + n + 1, 0);
    for (int i = 1; i <= n; i++){
      if (!f[i] && !h[i] && (!D(i) || !C(i))){
        flag = 0;
        break;
      }
    }
    cout << (flag ? "YES\n" : "NO\n");
  }
  return 0;
} 
