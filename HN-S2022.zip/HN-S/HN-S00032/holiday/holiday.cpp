#include <bits/stdc++.h>

using namespace std;

const int N = 2505, M = 1e4 + 5;

int n, m, k;
long long ans, a[M];
vector<int> c[N];
bool v[N];

void dfs(int x, int p, long long s){
  if (x == 6){
    if (p == 1){
      ans = max(ans, s);
    }
    return ;
  }
  if (v[p]){
    return ;
  }
  v[p] = 1;
  for (int i = 0; i < c[p].size(); i++){
    dfs(x + 1, c[p][i], s + a[c[p][i]]);
  }
  v[p] = 0;
}

int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 2; i <= n; i++){
	  cin >> a[i];
  }
  for (int i = 1; i <= m; i++){
    int x, y;
    cin >> x >> y;
    c[x].push_back(y), c[y].push_back(x);
  }
  if (!k){
    dfs(1, 1, 0);
    cout << ans;
  }
	return 0;
} 
