#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 5, INF = INT_MAX;

int n, m, q;
bool flag = 1;
long long s1, s2, a[N], b[N];

int main(){
  freopen("game.in", "r", stdin);
  freopen("game.out", "w", stdout);
  cin >> n >> m >> q;
  for (int i = 1; i <= n; i++){
    cin >> a[i];
    flag &= (a[i] >= 0);
  }
  for (int i = 1; i <= m; i++){
    cin >> b[i];
    flag &= (b[i] >= 0);
  }
  while (q--){
    int l1, l2, r1, r2;
    long long maxa = -1, minb = INF;
    cin >> l1 >> l2 >> r1 >> r2;
    for (int i = l1; i <= l2; i++){
      maxa = max(maxa, a[i]);
    }
    for (int i = r1; i <= r2; i++){
      minb = min(minb, b[i]);
    }
    if (flag){
      cout << maxa * minb << '\n';
    }
  }
  return 0;
}
