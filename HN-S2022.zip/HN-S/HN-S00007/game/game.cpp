#include <bits/stdc++.h>
using namespace std;

long long n, m, q, a[100100], b[100100];

// struct tree
//     {long long l, r, ma;};

// struct qq
//     {tree tt[1010];
//     long long l, r, ma;}
//     t[1010];

// void build_build (long long p, long long l, long long r, long long P, long long L, long long R) {
//     t[P]. tt[p]. l = l, t[P]. tt[p]. r = r;
    
//     if (l == r) {
//         t[P]. tt[p]. ma = a[L] * b[l];

//         return ;
//     }

//     long long mid = t[P]. tt[p]. l + t[P]. tt[p]. r >> 1;

//     build_build (p << 1, l, mid, P, L, R);
//     build_build (p << 1 | 1, mid + 1, r, P, L, R);

//     t[P]. tt[p]. ma = min (t[P]. tt[p << 1]. ma, t[P]. tt[p << 1 | 1]. ma);
// }

// void build (long long p, long long l, long long r) {
// 	cout << l << " " << r << endl;
//     t[p]. l = l, t[p]. r = r;
    
//     if (l == r) {
//         build_build (1, 1, m, p, l, r);
//         t[p]. ma = t[p]. tt[1]. ma;

//         return ;
//     }

//     long long mid = t[p]. l + t[p]. r >> 1;

//     build (p << 1, l, mid);
//     build (p << 1 | 1, mid + 1, r);

//     t[p]. ma = max (t[p << 1]. ma, t[p << 1 | 1]. ma);
// }

// long long search_search (long long p, long long l, long long r, long long P, long long L, long long R) {
//     if (t[p]. tt[P]. l >= L && t[p]. tt[P]. r <= R)
//         return t[p]. tt[P]. ma;
    
//     long long mid = L + R >> 1, ans = 9999999999;

//     if (L < mid)
//         ans = min (ans, search_search (p, l, r, P << 1, L, R));
    
//     if (R >= mid)
//         ans = min (ans, search_search (p, l, r, P << 1 | 1, L, R));
    
//     return ans;
// }

// long long search (long long p, long long l, long long r, long long P, long long L, long long R) {
//     cout << t[p]. l << " " << t[p]. r << endl;

//     if (t[p]. l == t[p]. r)
//         return search_search (p, l, r, P, L, R);
    
//     long long mid = l + r >> 1, ans = -9999999999;

//     if (l < mid)
//         ans = max (ans, search (p << 1, l, r, P, L, R));
    
//     if (r >= mid)
//         ans = max (ans, search (p << 1 | 1, l, r, P, L, R));
    
//     return ans;
// }

signed main () {
 freopen ("game.in", "r", stdin);
 freopen ("game.out", "w", stdout);

    scanf ("%lld %lld %lld", &n, &m, &q);
    for (long long i = 1; i <= n; ++ i)
        scanf ("%lld", &a[i]);
    for (long long i = 1; i <= m; ++ i)
        scanf ("%lld", &b[i]);

    // build (1, 1, n);

    while (q --) {
        long long l1, r1, l2, r2;
        scanf ("%lld %lld %lld %lld", &l1, &r1, &l2, &r2);
        
        long long ma = -9999999999;
        for (long long i = l1; i <= r1; ++ i) {
            long long mi = 9999999999;
            for (long long j = l2; j <= r2; ++ j)
                mi = min (mi, a[i] * b[j]);
            
            ma = max (ma, mi);
        }

        printf ("%lld\n", ma);
            
        // printf ("%lld\n", search (1, l1, r1, 1, l2, r2));
    }

    return 0;
}