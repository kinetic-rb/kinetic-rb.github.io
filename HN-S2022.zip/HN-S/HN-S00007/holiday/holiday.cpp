#include <bits/stdc++.h>
using namespace std;

long long n, m, k, a[100100], tot,
    head[100100], dis[3030][3030], ti, l[3030][3030];

struct qq
    {long long to, next;}
    e[100100];

void add (long long x, long long y)
    {e[++ tot]. to = y, e[tot]. next = head[x], head[x] = tot;}

long long b[100100], q[100100], t = 0, w = 0;
void bfs (long long step) {
    t = w = 0;
    q[++ t] = step;

    while (w < t) {
        for (long long i = head[q[++ w]]; i; i = e[i]. next) {
            if (b[e[i]. to] != ti) {
                b[e[i]. to] = ti;
                
                dis[step][e[i]. to] = dis[step][q[w]] + 1;
                
                if (dis[step][e[i]. to] <= k + 1)
                    l[e[i]. to][step] = l[step][e[i]. to] = 1;
                
                q[++ t] = e[i]. to;
            }
        }
    }
}

long long sum[100100], B[100100], ans;
void dfs (long long step, long long x, long long sum) {
    if (step == 4) {
        if (l[x][1] == 1)
            ans = max (ans, sum);
        
        return ;
    }

    for (long long i = 1; i <= n; ++ i)
        if (B[i] == 0 && l[x][i] == 1) {
            B[i] = 1;

            dfs (step + 1, i, sum + a[i]);

            B[i] = 0;
        }
}

signed main () {
    freopen ("holiday.in", "r", stdin);
    freopen ("holiday.out", "w", stdout);

    scanf ("%lld %lld %lld", &n, &m, &k);
    
    for (long long i = 2; i <= n; ++ i)
        scanf ("%lld", &a[i]);
    for (long long i = 1; i <= m; ++ i) {
        long long x, y;
        scanf ("%lld %lld", &x, &y);
        add (x, y), add (y, x);
    }

    for (long long i = 1; i <= n; ++ i)
        ti = i, bfs (i);

    dfs (0, 1, 0);

    printf ("%lld", ans);

    return 0;
}