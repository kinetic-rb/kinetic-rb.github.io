#include <iostream> 
#include <vector>
#include <queue>
#include <cstdio>

using namespace std;

const long long kMaxN = 2501;

short Use[kMaxN], b[kMaxN][kMaxN];
queue<pair<long long, long long>> q;
vector<long long> v[kMaxN], able[kMaxN];
long long n, m, k, x, y, val[kMaxN], dis[kMaxN][kMaxN], Max[kMaxN][kMaxN];

void Find(long long x){
	q.push({1, x});
	while(!q.empty()) {
		pair<long long, long long> tmp = q.front();
		q.pop();
		if((dis[x][tmp.second] <= tmp.first && dis[x][tmp.second] > 0) || tmp.first > k) {
			continue;
		}
		dis[x][tmp.second] = tmp.first;
		able[x].push_back(tmp.second);
		for(long long i = 0; i < (long long)v[tmp.second].size(); i++) {
			q.push({tmp.first + 1, v[tmp.second][i]});
		}
	}
}

long long DFS(long long x, long long dep) {
	if(dep == 4) {
		return ((dis[x][1] <= k && dis[x][1] != 0) ? val[x] : 0);
	}
	if(b[x][dep]) {	
		return (Max[x][dep] > 0 ? val[x] + Max[x][dep] : 0);
	}
	b[x][dep] = Use[x] = 1;
	for(long long i = 0; i < (long long)able[x].size(); i++) {
		if(!Use[able[x][i]]) {
			Max[x][dep] = max(Max[x][dep], DFS(able[x][i], dep + 1));
		}
	}
	Use[x] = 0;
	return (Max[x][dep] > 0 ? val[x] + Max[x][dep] : 0);
}

int main() {
    freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin >> n >> m >> k;
	k += 2;
	for(long long i = 2; i <= n; i++) {
		cin >> val[i];
	}
	while(m--) {
		cin >> x >> y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for(long long i = 1; i <= n; i++) {
		Find(i);
	}
	cout << DFS(1, 0) << '\n';
	return 0;
}


