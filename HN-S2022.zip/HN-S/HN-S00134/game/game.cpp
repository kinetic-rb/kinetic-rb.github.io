#include <iostream> 
#include <cstdio>
#include <cmath>

const int kMaxN = 1e6 + 1;

long long n, m, q, l_1, l_2, r_1, r_2, a, k, L, R;
long long num[2][kMaxN], tree[8][4 * kMaxN + 1], ans[11];

long long build(long long x, long long l, long long r, bool cmp(long long a, long long b)){
	if(l == r) {
		tree[k][x] = num[a][l];
	}
	else {
		tree[k][x] = (cmp(build(x << 1, l, (l + r) >> 1, cmp), build((x << 1) + 1, ((l + r) >> 1) + 1, r, cmp)) ? tree[k][x << 1] : tree[k][(x << 1) + 1]);
	}
	return tree[k][x];
}

long long Find(long long x, long long l, long long r, bool cmp(long long a, long long b)){
	if(L <= l && r <= R) {
		return tree[k][x];
	}
	else if(R < l || r < L) {
		return num[a][L];
	}
	long long tmp1 = Find(x << 1, l, (l + r) >> 1, cmp), tmp2 = Find((x << 1) + 1, ((l + r) >> 1) + 1, r, cmp);
	return (cmp(tmp1, tmp2) ? tmp1 : tmp2);
}

int main() {
    freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%lld %lld %lld", &n, &m, &q);
	for(long long i = 1; i <= n; i++) {
		scanf("%lld", &num[0][i]);
	}
	for(long long i = 1; i <= m; i++) {
		scanf("%lld", &num[1][i]);
	}
	build(1, 1, n, [](long long a, long long b) { return a > b; });
	k++;
	build(1, 1, n, [](long long a, long long b) { return a < b; });
	k++;
	build(1, 1, n, [](long long a, long long b) {
		if(a <= 0 && b <= 0) {
			return abs(a) < abs(b);
		} else {
			return a <= 0;
		}
	});
	k++;
	build(1, 1, n, [](long long a, long long b) {
		if(a >= 0 && b >= 0) {
			return abs(a) < abs(b);
		} else {
			return a >= 0;
		}
	});
	a = 1;
	k++;
	build(1, 1, m, [](long long a, long long b) { return a > b; });
	k++;
	build(1, 1, m, [](long long a, long long b) { return a < b; });
	k++;
	build(1, 1, m, [](long long a, long long b) {
		if(a <= 0 && b <= 0) {
			return abs(a) < abs(b);
		} else {
			return a <= 0;
		}
	});
	k++;
	build(1, 1, m, [](long long a, long long b) {
		if(a >= 0 && b >= 0) {
			return abs(a) < abs(b);
		} else {
			return a >= 0;
		}
	});
	while(q--) {
		scanf("%lld %lld %lld %lld", &l_1, &r_1, &l_2, &r_2);
		a = 0, L = l_1, R = r_1;
		k = 0;
		ans[k] = Find(1, 1, n, [](long long a, long long b) { return a > b; });
		k++;
		ans[k] = Find(1, 1, n, [](long long a, long long b) { return a < b; });
		k++;
		ans[k] = Find(1, 1, n, [](long long a, long long b) {
			if(a <= 0 && b <= 0) {
				return abs(a) < abs(b);
			} else {
				return a <= 0;
			}
		});
		k++;
		ans[k] = Find(1, 1, n, [](long long a, long long b) {
			if(a >= 0 && b >= 0) {
				return abs(a) < abs(b);
			} else {
				return a >= 0;
			}
		});
		a = 1, L = l_2, R = r_2;
		k++;
		ans[k] = Find(1, 1, m, [](long long a, long long b) { return a > b; });
		k++;
		ans[k] = Find(1, 1, m, [](long long a, long long b) { return a < b; });
		k++;
		ans[k] = Find(1, 1, m, [](long long a, long long b) {
			if(a <= 0 && b <= 0) {
				return abs(a) < abs(b);
			} else {
				return a <= 0;
			}
		});
		k++;
		ans[k] = Find(1, 1, m, [](long long a, long long b) {
			if(a >= 0 && b >= 0) {
				return abs(a) < abs(b);
			} else {
				return a >= 0;
			}
		});
		bool b = 1;
		long long Max = 0;
		for(long long i = 0, Min = ans[i] * ans[4]; i < 4; i++, Min = ans[i] * ans[4]){
			for(long long j = 4; j < 7; j++) {
				Min = std::min(Min, ans[i] * ans[j]);
			}
			if(b) {
				Max = Min;
				b = 0;
			}
			Max = std::max(Max, Min);
		}
		printf("%lld\n", Max);
	}
	return 0;
}	

//fc game.out game4.ans


