#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,u,v,q,t;
	cin>>n>>m;
	while(m--) cin>>u>>v;
	cin>>q;
	while(q--)
	{
		cin>>t;
		if(t==1||t==3)
		{
			scanf("*%d*%d",u,v);
			cout<<"NO"<<endl;
		}
		else
		{
			scanf("*%d",u);
			cout<<"NO"<<endl;
		}
	}
	return 0;
}

