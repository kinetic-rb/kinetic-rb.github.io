#include<bits/stdc++.h>
using namespace std;

int a[100005],b[100005];

int sorta(int x,int y){
	int min=99999999;
	for(int i=x;i<=y;i++)
	{
		if(a[i]<min) min=a[i];
	}
	return min;
}

int sortb(int x,int y){
	int max=0;
	for(int i=x;i<=y;i++)
	{
		if(b[i]>max) max=b[i];
	}
	return max;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,l1,r1,l2,r2;
	scanf("%d%d%d",&n,&m,&q)
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1) cout<<a[l1]*sortb(l2,r2)<<endl;
		else if(l2==r2) cout<<sorta(l1,r1)*b[r2]<<endl;
		else cout<<a[l1]*b[r2]<<endl;
	}
	return 0;
}

