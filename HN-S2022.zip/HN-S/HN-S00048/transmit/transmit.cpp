#include<bits/stdc++.h>
using namespace std;
long long v[200005];
int a,b,s,t;

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++) cin>>v[i];
	for(int i=1;i<n;i++) cin>>a>>b;
	while(q--)
	{
		cin>>s>>t;
		cout<<s+t;
	}
	return 0;
}

