#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
ull a[2505],cnt=0,ans=0;
bool b[2505][2505]={0},flag[2505]={0};
int n,m,k,x,y,flag1=0,flag2=0,flag3=0,flag4=0,flago=0,flagj=0,flagi=0;

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%ull",&a[i]);
	while(m--)
	{
		scanf("%d%d",&x,&y);
		b[x][y]=1;
		b[y][x]=1;
	}
	for(int i=1;i<=n;i++)
	{
		cnt=0;
		flag[i]=0;
		if(b[1][i]==1)
		{
			flag[i]=1;
			cnt+=a[i];
			flag1=1;
			for(int j=1;j<=n;j++)
			{
				if(b[i][j]==1&&flag[j]!=1)
				{
					flag[j]=1;
					cnt+=a[j];
					flag2=1;
					for(int o=1;o<=n;o++)
					{
						if(b[j][o]==1&&flag[o]!=1)
						{
							flag[o]=1;
							cnt+=a[o];
							flag3=1;
							for(int p=1;p<=n;p++)
							{
								if(b[o][p]==1&&flag[p]!=1&&b[p][1]==1)
								{
									flag[p]=1;
									cnt+=a[p];
									flag4=1;
								}
								else continue;
							}
							if(flag4==0&&flago==0)
							{
								cnt-=a[o];
								flago=1;
							}
						}
						else continue;
					}
					if(flag3==0&&flagj==0)
					{
						cnt-=a[j];
						flagj=1;
					}
				}
				else continue;
			}
			if(flag2==0&&flagi==0)
			{
				cnt-=a[i];
				flagi=1;
			}
			ans=max(ans,cnt);
		}
		else continue;
	}
	cout<<ans-a[n-1];
	return 0;
}

