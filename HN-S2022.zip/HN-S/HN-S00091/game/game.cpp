#include<bits/stdc++.h>
using namespace std;

const int maxn=100005;
int n,m,q;
int a[maxn],b[maxn];
int aa[maxn],bb[maxn];

inline int rd(){
	int s=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=rd(),m=rd(),q=rd();
	for(int i=1;i<=n;i++) a[i]=rd();
	for(int i=1;i<=m;i++) b[i]=rd();
	while(q--){
		int l1=rd(),r1=rd(),l2=rd(),r2=rd(),cnt1=r1-l1+1,cnt2=r2-l2+1;
		for(int i=l1;i<=r1;i++) aa[i-l1+1]=a[i];
		for(int i=l2;i<=r2;i++) bb[i-l2+1]=b[i];
		sort(aa+1,aa+cnt1+1);
		sort(bb+1,bb+cnt2+1);
		if(bb[1]>0) printf("%lld\n",1ll*aa[cnt1]*bb[1]);
		else if(bb[cnt2]<0) printf("%lld\n",1ll*aa[1]*bb[cnt2]);
		else{
			int t;
			for(int i=1;i<=cnt1;i++){
				if(aa[i]==0) t=cnt1+1;
				if(aa[i]>0){
					t=i;
					break;
				}
			}
			if(t==cnt1+1) printf("0/n");
			else printf("%lld\n",max(1ll*aa[t-1]*bb[cnt2],1ll*aa[t]*bb[1]));
		}
	} 
	return 0;
}

/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2


*/
