#include<bits/stdc++.h>
using namespace std;

const int maxn=2505,maxm=10005,inf=1e9;
int n,m,k,cnte,ans=-inf;
int val[maxn];
int head[maxn],nxt[maxm],to[maxm];
int dis[maxn][maxn],vis[maxn];
struct node{
	int pos,dis,len;
};
priority_queue<node> q; 

inline bool operator<(node u,node v){
	return u.dis>v.dis;
}

inline int rd(){
	int s=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}

inline void adde(int u,int v){
	cnte++;
	nxt[cnte]=head[u];
	head[u]=cnte;
	to[cnte]=v;
}

inline void dijkstra(int s){
	for(int i=1;i<=n;i++) vis[i]=0;
	while(!q.empty()) q.pop();
	q.push((node){s,0,0});
	dis[s][s]=0;
	while(!q.empty()){
		int u=q.top().pos;q.pop();
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=head[u];i;i=nxt[i]){
			int v=to[i];
			if(dis[s][v]>dis[s][u]+1){
				dis[s][v]=dis[s][u]+1;
				q.push((node){v,dis[s][v],0});
			}
		}
	} 
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=rd(),m=rd(),k=rd()+1;
	for(int i=2;i<=n;i++) val[i]=rd();
	for(int i=1;i<=m;i++){
		int u=rd(),v=rd();
		adde(u,v),adde(v,u);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) dis[i][j]=inf;
	}
	for(int i=1;i<=n;i++) dijkstra(i);
	for(int i=2;i<=n;i++){
		if(dis[1][i]>k) continue;
		for(int j=2;j<=n;j++){
			if(i==j||dis[i][j]>k) continue;
			for(int l=2;l<=n;l++){
				if(i==l||j==l||dis[j][l]>k) continue;
				for(int z=2;z<=n;z++){
					if(i==z||j==z||l==z||dis[l][z]>k||dis[1][z]>k) continue;
					ans=max(ans,val[i]+val[j]+val[l]+val[z]);
				}
			}
		}
	}
	printf("%d",ans);
	return 0; 
}
/*7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4


*/
