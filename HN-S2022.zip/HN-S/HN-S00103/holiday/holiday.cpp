#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e4+10;
int n, m, k;
long long u, v;
long long a[maxn];
bool cmp(long long a, long long b) {
	return a > b;
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i++) {
		cin >> a[i];
	} 
	for(int i = 1; i <= m; i++) {
		scanf("%d%d", &u, &v);
	}
	sort(a + 2, a + n + 1, cmp);
	long long ans = 0;
	for(int i = 2; i <= 5; i++) {
		ans+=a[i];
	}
	cout << ans;
	return 0;
} 
