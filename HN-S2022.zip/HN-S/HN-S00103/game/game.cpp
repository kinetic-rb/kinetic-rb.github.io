#include <bits/stdc++.h>
using namespace std;
int n, m, q;
long long a[100010], b[100010];
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++)cin >> a[i];
	for(int i = 1; i <= m; i++)cin >> b[i];
	int l1, r1, l2, r2;
	while(q--) {
		cin >> l1 >> r1 >> l2 >> r2;
		if(l1 == r1) {
			long long ans = 1e18;
			for(int i = l2; i <= r2; i++) ans = min(ans, a[l1] * b[i]);
			cout << ans << endl;
		} else if(l2 == r2) {
			long long ans = -1e18;
			for(int i = l1; i <= r1; i++) ans = max(ans, b[l2] * a[i]);
			cout << ans << endl;
		}
	}
	return 0;
}
