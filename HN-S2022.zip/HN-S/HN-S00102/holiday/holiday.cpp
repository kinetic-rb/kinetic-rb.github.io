#include <bits/stdc++.h>

using namespace std;

int a[2505];

bool cmp(const int &i, const int &j){
  return i > j;
}

int main(){
  freopen("holiday.in", "r", stdin);
  freopen("holiday.out", "w", stdout);
  int n, m, k;
  cin >> n >> m >> k;
  for(int i = 1; i <= n; i++){
    cin >> a[i];
  }
  sort(a + 1, a + n + 1, cmp);
  int ans = 0;
  for(int i = 1; i <= 4; i++){
    ans += a[i];
  }
  cout << ans << '\n';
  return 0;
}
