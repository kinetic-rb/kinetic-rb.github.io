#include <bits/stdc++.h>

using namespace std;

long long a[100005], b[100005];

int main(){
  freopen("game.in", "r", stdin);
  freopen("game.out", "w", stdout);
	int n, m, q;
	bool f = 0;
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++){
	  cin >> a[i];
    if(a[i] <= 0){
      f = 1;
    }
  }
  for(int i = 1; i <= m; i++){
    cin >> b[i];
    if(b[i] <= 0){
      f = 1;
    }
  }
  while(q--){
	  int l1, r1, l2, r2, v1 = INT_MAX, x;
	  cin >> l1 >> r1 >> l2 >> r2;
    if(f){
      if(l1 == r1){
        long long minn = LLONG_MAX;
        for(int i = l2; i <= r2; i++){
          minn = min(minn, a[l1] * b[i]);
        }
        cout << minn << '\n';
      }
      else{
        long long maxx = INT_MIN;
        for(int i = l1; i <= r1; i++){
          maxx = max(maxx, a[i] * b[l2]);
        }
        cout << maxx << '\n';
      }
    }
    else{
      long long maxx = LLONG_MIN, v;
      for(int i = l1; i <= r1; i++){
        if(a[i] > maxx){
          maxx = a[i];
          v = i;
        }
      }
      long long minn = LLONG_MAX;
      for(int i = l2; i <= r2; i++){
        minn = min(minn, a[v] * b[i]);
      }
      cout << minn << '\n';
    }
  }
	return 0; 
} 
