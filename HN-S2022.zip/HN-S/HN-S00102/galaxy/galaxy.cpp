#include <bits/stdc++.h>

using namespace std;

int a[3005][3005], n, m, q, l, u[500005], v[500005], x[500005], t[500005];
bool f1[1005];

bool dfs(int x){
  if(f1[x]){
    return 1;
  }
  f1[x] = 1;
  for(int i = 1; i <= n; i++){
    if(a[x][i]){
      return dfs(i);
    }
  }
  return 0;
}

int main(){
  freopen("galaxy.in", "r", stdin);
  freopen("galaxy.out", "w", stdout);
  cin >> n >> m;
  for(int i = 1; i <= m; i++){
    int x, y;
    cin >> x >> y;
    a[x][y] = 2;
  }
  bool f2 = 0;
  cin >> q;
  for(int i = 1; i <= q; i++){
    cin >> t[i];
    if(t[i] == 1){
      cin >> u[i] >> v[i];
    }
    else if(t[i] == 2){
      cin >> x[i];
      f2 = 1;
    }
    else if(t[i] == 3){
      cin >> u[i] >> v[i];
    }
    else{
      cin >> x[i];
      f2 = 1;
    }
  }
  if(!f2){
    for(int k = 1; k <= q; k++){
      if(t[k] == 1){
        a[u[k]][v[k]] = 1;
      }
      else if(t[k] == 3){
        a[u[k]][v[k]] = 2;
      }
      bool f = 0;
      for(int i = 1; i <= n; i++){
        if(!dfs(i)){
          f = 1;
          break;
        }
      }
      if(!f){
        cout << "YES" << '\n';
      }
      else{
        cout << "NO" << '\n';
      }
    }
    return 0;
  }
  for(int k = 1; k <= q; k++){
    if(t[k] == 1){
      a[u[k]][v[k]] = 1;
    }
    else if(t[k] == 2){
      for(int i = 1; i <= n; i++){
        if(a[i][x[k]] == 2){
          a[i][x[k]] = 1;
        }
      }
    }
    else if(t[k] == 3){
      a[u[k]][v[k]] = 2;
    }
    else if(t[k] == 4){
      for(int i = 1; i <= n; i++){
        if(a[i][x[k]] == 1){
          a[i][x[k]] = 2;
        }
      }
    }
    bool f = 0;
    fill(f1 + 1, f1 + n + 1, 0);
    for(int i = 1; i <= n; i++){
      if(!dfs(i)){
        f = 1;
        break;
      }
    }
    if(f){
      cout << "NO" << '\n';
      continue;
    }
    for(int i = 1; i <= n; i++){
      l = 0;
      for(int j = 1; j <= n; j++){
        if(i == j){
          continue;
        }
        if(a[i][j] == 2){
          l++;
        }
      }
      if(l != 1){
        f = 1;
        break;
      }
    }
    if(f){
      cout << "NO" << '\n';
    }
    else{
      cout << "YES" << '\n';
    }
  }
  return 0;
}
