#include<bits/stdc++.h>
using namespace std;
const int N=500100;
int n,m,q,u,v,t;
bool o[N],vis[N],findx,bian[1050][1050];
struct str
{
	int x;
	bool f;
};
vector<str>a[N];
vector<int>b[N];
bool cmp(str x,str y)
{
	return x.x<y.x;
}
void f1(int x,int y,bool f)
{
	for(vector<str>::iterator i=a[x].begin();i!=a[x].end();i++)
		if((*i).x==y)
		{
			(*i).f=f;
			return;
		}
}
void dfs(int u)
{
	if(findx)
		return;
	for(vector<str>::iterator i=a[u].begin();i!=a[u].end();i++)
	{
		int v=(*i).x;
		if((*i).f&&bian[u][v])
		{
			//cout<<"csdbsdb:"<<u<<" "<<v<<" "<<vis[v]<<endl;
			if(vis[v])
			{
				findx=1;
				return;
			}
			vis[v]=1;
			dfs(v);
			vis[v]=0;
		}
	}
}
bool check()
{
	for(int u=1,s;u<=n;u++)
	{
		s=0;
		for(vector<str>::iterator i=a[u].begin();i!=a[u].end();i++)
			if((*i).f&&bian[u][(*i).x])
			{
				if(s)
					return 0;
				s++;
			}
		if(!s)
			return 0;
	}
	for(int i=1;i<=n;i++)
	{
		memset(vis,0,sizeof vis);
		vis[i]=1;
		findx=0;
		dfs(i);
		if(!findx)
			return 0;
	}
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=1000)
		for(int i=1;i<=m;i++)
			scanf("%d%d",&u,&v),bian[u][v]=1,a[u].push_back({v,1}),b[v].push_back(u);
	else
		for(int i=1;i<=m;i++)
			scanf("%d%d",&u,&v),a[u].push_back({v,1}),b[v].push_back(u);
	scanf("%d",&q);
	for(int i=1;i<=n;i++)
		o[i]=1;
	if(n>=1000)
	{
		while(q--)
		{
			scanf("%d",&t);
			if(t==1)
				scanf("%d%d",&u,&v),f1(u,v,0);
			else if(t==2)
				scanf("%d",&u),o[u]=0;
			else if(t==3)
				scanf("%d%d",&u,&v),f1(u,v,1);
			else
				scanf("%d",&u),o[u]=1;
			if(check())
				printf("YES\n");
			else
				printf("NO\n");
		}
		return 0;
	}
	while(q--)
	{
		scanf("%d",&t);
		if(t==1)
			scanf("%d%d",&u,&v),f1(u,v,0);
		else if(t==2)
		{
			scanf("%d",&u);
			for(vector<int>::iterator i=b[u].begin();i!=b[u].end();i++)
				bian[u][*i]=0;
		}
		else if(t==3)
			scanf("%d%d",&u,&v),f1(u,v,1);
		else
		{
			scanf("%d",&u);
			for(vector<int>::iterator i=b[u].begin();i!=b[u].end();i++)
				bian[u][*i]=1;
		}
		if(check())
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}
