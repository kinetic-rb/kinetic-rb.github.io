#include<bits/stdc++.h>
using namespace std;
const int N=2600;
int n,m,k,x,y;
long long ans,s[N];
bool f[N],f2[N];
vector<int>e[N],t[N];
void dfs(int u,int cnt,long long sum)
{
	if(cnt==4)
	{
		for(vector<int>::iterator i=e[u].begin();i!=e[u].end();i++)
			if((*i)==1)
			{
				ans=max(ans,sum);
				return;
			}
		return;
	}
	for(vector<int>::iterator i=e[u].begin();i!=e[u].end();i++)
	{
		int v=*i;
		if(!f[v])
			f[v]=1,dfs(v,cnt+1,sum+s[v]),f[v]=0;
	}
}
void dfs2(int r,int u,int cnt)
{
	for(vector<int>::iterator i=e[u].begin();i!=e[u].end();i++)
	{
		int v=*i;
		if(!f2[v])
		{
			f2[v]=1;
			if(cnt+1<=k)
				t[r].push_back(v),dfs2(r,v,cnt+1);
			f2[v]=0;
		}
	}
}
void dfs3(int u,int cnt,long long sum)
{
	if(cnt==4)
	{
		for(vector<int>::iterator i=t[u].begin();i!=t[u].end();i++)
			if((*i)==1)
			{
				ans=max(ans,sum);
				return;
			}
		return;
	}
	for(vector<int>::iterator i=t[u].begin();i!=t[u].end();i++)
	{
		int v=*i;
		if(!f[v])
			f[v]=1,dfs3(v,cnt+1,sum+s[v]),f[v]=0;
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",s+i);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&x,&y),e[x].push_back(y),e[y].push_back(x);
	f[1]=1;
	if(k==0)
	{
		dfs(1,0,0);
		printf("%lld",ans);
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		f2[i]=1;
		dfs2(i,i,-1);
		f2[i]=0;
	}
	dfs3(1,0,0);
	printf("%lld",ans);
	return 0;
}
