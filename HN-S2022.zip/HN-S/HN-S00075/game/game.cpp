#include<bits/stdc++.h>
using namespace std;
const int N=100100;
int n,m,q,l1,r1,l2,r2;
long long s,maxx,minx,a[N],b[N];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",a+i);
	for(int i=1;i<=m;i++)
		scanf("%lld",b+i);
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1)
		{
			if(a[l1]>0)
			{
				minx=INT_MAX;
				for(int i=l2;i<=r2;i++)
					minx=min(minx,b[i]);
				printf("%lld\n",a[l1]*minx);
			}
			else if(a[l1]<0)
			{
				maxx=INT_MIN;
				for(int i=l2;i<=r2;i++)
					maxx=max(maxx,b[i]);
				printf("%lld\n",a[l1]*maxx);
			}
			else
				printf("0\n");
		}
		else if(l2==r2)
		{
			if(b[l2]>0)
			{
				maxx=INT_MIN;
				for(int i=l1;i<=r1;i++)
					maxx=max(maxx,a[i]);
				printf("%lld\n",maxx*b[l2]);
			}
			else if(b[l2]<0)
			{
				minx=INT_MAX;
				for(int i=l1;i<=r1;i++)
					minx=min(minx,a[i]);
				printf("%lld\n",minx*b[l2]);
			}
			else
				printf("0\n");
		}
		else
		{
			maxx=INT_MIN;
			minx=INT_MAX;
			for(int i=l1;i<=r1;i++)
				maxx=max(maxx,a[i]);
			for(int i=l2;i<=r2;i++)
				minx=min(minx,b[i]);
			s=maxx*minx;
			printf("%lld\n",s);
		}
	}
	return 0;
}
