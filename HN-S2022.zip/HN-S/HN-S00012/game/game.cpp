#include<bits/stdc++.h>//60+
#define int long long
using namespace std;//  +max       -min       +min        -max
int a[100005],b[100005],t1[400005],t2[400005],t3[400005],t4[400005];
void build(int now,int l,int r){
//	printf("t:%d %d %d\n",now,l,r);
	if(l==r){
		if(b[l]>0) t1[now]=t3[now]=b[l],t2[now]=LONG_LONG_MAX,t4[now]=INT_MIN;
		else if(b[l]<0) t2[now]=t4[now]=b[l],t1[now]=LONG_LONG_MIN,t3[now]=INT_MAX;
		else t1[now]=t2[now]=t3[now]=t4[now]=0;
		return;
	}
	int mid=(l+r)>>1;
	if(mid>=l) build(now<<1,l,mid);
	if(r>mid) build(now<<1|1,mid+1,r);
	t1[now]=max(t1[now<<1],t1[now<<1|1]);
	t2[now]=min(t2[now<<1],t2[now<<1|1]);
	t3[now]=min(t3[now<<1],t3[now<<1|1]);
	t4[now]=max(t4[now<<1],t4[now<<1|1]);
}
long long find1(int fl,int fr,int now,int nl,int nr){
	if(fl==fr) return b[fr];
	if(fl==nl && fr==nr) return 1ll*max(t1[now],t4[now]);
	int mid=(nr+nl)>>1;
	if(fr<=mid) return find1(fl,fr,now<<1,nl,mid);
	else if(fl<=mid)
		return max(find1(fl,mid,now<<1,nl,mid),find1(mid+1,fr,now<<1|1,mid+1,nr));
	else return find1(fl,fr,now<<1|1,mid+1,nr);
}
long long find2(int fl,int fr,int now,int nl,int nr){
	if(fl==fr) return b[fr];
	if(fl==nl && fr==nr) return 1ll*min(t2[now],t3[now]);
	int mid=(nr+nl)>>1;
	if(fr<=mid) return find2(fl,fr,now<<1,nl,mid);
	else if(fl<=mid)
		return min(find2(fl,mid,now<<1,nl,mid),find2(mid+1,fr,now<<1|1,mid+1,nr));
	else return find2(fl,fr,now<<1|1,mid+1,nr);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	long long n,m,q;
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
	for(int i=1;i<=m*4;i++) t3[i]=LONG_LONG_MAX,t4[i]=LONG_LONG_MIN;
	build(1,1,m);
	while(q--){
		long long l1,r1,l2,r2,maxn=LONG_LONG_MIN;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		long long zhe=find1(l2,r2,1,1,m),fu=find2(l2,r2,1,1,m);
		if(fu>zhe) fu^=zhe^=fu^=zhe;
//		printf("%d %d\n",zhe,fu);
		for(int i=l1;i<=r1;i++){
			long long ji;
			if((fu>0 && zhe>0) || (fu<0 && zhe<0) || (fu==0 || zhe==0)){
				if(a[i]>0) ji=a[i]*fu;
				else if(a[i]<0) ji=a[i]*zhe;
			}
			else if(a[i]>0) ji=a[i]*fu;
			else ji=a[i]*zhe;
			maxn=max(maxn,ji);
		}
			
		printf("%lld\n",maxn);
	}
	return 0;
}/*
Sample 1:
Input:
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
Output:
0
4
Sample 2:
Input:
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
Output:
0
-2
3
2
-1
Sample 3:
Input:
3 3 10
1 2 3
5 2 4
1 2 1 2
Output:
4

*/
