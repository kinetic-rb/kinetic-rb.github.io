#include<bits/stdc++.h>//70+
using namespace std;
vector<int> t[200005],pos[200005];
int po[200005],dis[200005],k,n;
bool vis[200005];
void bfs(int s){
	for(int i=1;i<=n;i++) dis[i]=10;
	queue<int> q;
	q.push(s);
	dis[s]=-1;
	while(!q.empty()){
		int now=q.front();
		q.pop();
		for(int i=0;i<t[now].size();i++) if(dis[t[now][i]]>k){
			dis[t[now][i]]=dis[now]+1;
			if(dis[now]<k-1) q.push(t[now][i]);
			if(dis[now]<k)
				pos[s].push_back(t[now][i]);
		}
	}
}
inline bool cmp(int a,int b){
	return (po[a]==po[b]?po[a]<po[b]:dis[a]>dis[b]);
}
long long dfs(int now,int v,int deep){
	if(deep>=ceil(n/k)+2 || vis[now]) return INT_MAX;
//	printf("%d %d\n",now,v);
	if(now==v) return 1ll*po[v];
	vis[now]=1;
	long long ret=INT_MAX,cun=INT_MAX;
	for(int i=1;i<pos[now].size() && po[pos[now][i]]<=cun;i++){
		long long f=dfs(pos[now][i],v,deep+1);
		if(f) cun=po[pos[now][i]],ret=min(ret,f);
	}
	vis[now]=0;
	return ret+po[now];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);
	int q;
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&po[i]);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		t[u].push_back(v);
		t[v].push_back(u);
	}
	for(int i=1;i<=n;i++) bfs(i),sort(pos[i].begin(),pos[i].end(),cmp);
	while(q--){
		int u,v;
		scanf("%d%d",&u,&v);
		printf("%lld\n",dfs(u,v,0));
	}
	return 0;
}/*
Sample 1:
Input:
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
Output:
12
12
3
*/
/*#include<bits/stdc++.h>//70+
using namespace std;
vector<int> t[200005];
int po[200005],deep[200005],fa[200005][20],k,n;
void bfs(int s){
	queue<int> q;
	q.push(s);
	deep[s]=1;
	while(!q.empty()){
		int now=q.front();
		q.pop();
		for(int i=0;i<t[now].size();i++) if(deep[t[now][i]]>k)
			deep[t[now][i]]=deep[now]+1,q.push(t[now][i]),fa[t[now][i]][0]=now;
	}
}
inline bool cmp(int a,int b){
	return po[a]>po[b];
}
int main(){
//	freopen("transmit.in","r",stdin);
//	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);
	int q;
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&po[i]);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		t[u].push_back(v);
		t[v].push_back(u);
	}
	bfs(1);
	for(int i=1;i<=n;i++)
		for(int j=1;deep[i]-(1<<j);j++)
			fa[i][j]=fa[fa[i][j-1]][j-1];
	long long ans=0;
	for(int i=0;i<pos[1].size();i++){
		int a=pos[1][i];
		for(int j=0;j<pos[a].size();j++){
			int b=pos[a][j];
			if(b==1) continue;
			for(int k=0;k<pos[b].size();k++){
				int c=pos[b][k];
				if(c==1 || c==a) continue;
				for(int l=0;l<pos[c].size();l++){
					int d=pos[c][l];
					if(d!=1 && d!=a && d!=b && one[pos[c][l]]){
						ans=max(ans,1ll*po[a]+po[b]+po[c]+po[d]);
						break;
					}
				}
			}
		}
	}
	printf("%lld",ans);
	return 0;
}*/
