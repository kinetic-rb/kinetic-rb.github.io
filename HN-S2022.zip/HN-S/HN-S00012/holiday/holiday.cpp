#include<bits/stdc++.h>//70+
using namespace std;
vector<int> t[2503],pos[2503];
int po[2503],dis[2503],k,n;
bool one[2500];
void bfs(int s){
	for(int i=1;i<=n;i++) dis[i]=1001;
	queue<int> q;
	q.push(s);
	dis[s]=-1;
	while(!q.empty()){
		int now=q.front();
		q.pop();
		for(int i=0;i<t[now].size();i++) if(dis[t[now][i]]>k){
			dis[t[now][i]]=dis[now]+1;
			if(dis[now]<k-1) q.push(t[now][i]);
			if(dis[now]<k){
				pos[s].push_back(t[now][i]);
				if(t[now][i]==1) one[s]=1;
			}
		}
	}
}
inline bool cmp(int a,int b){
	return po[a]>po[b];
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	int m;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%d",&po[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		t[u].push_back(v);
		t[v].push_back(u);
	}
	for(int i=1;i<=n;i++) bfs(i),sort(pos[i].begin(),pos[i].end(),cmp);
	long long ans=0;
	for(int i=0;i<pos[1].size();i++){
		int a=pos[1][i];
		for(int j=0;j<pos[a].size();j++){
			int b=pos[a][j];
			if(b==1) continue;
			for(int k=0;k<pos[b].size();k++){
				int c=pos[b][k];
				if(c==1 || c==a) continue;
				for(int l=0;l<pos[c].size();l++){
					int d=pos[c][l];
					if(d!=1 && d!=a && d!=b && one[pos[c][l]]){
						ans=max(ans,1ll*po[a]+po[b]+po[c]+po[d]);
						break;
					}
				}
			}
		}
	}
	printf("%lld",ans);
	return 0;
}/*
n+n*(n+n*(n+n*n))
Sample 1:
Input:
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
Output:
27
Sample 2:
Input:
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
Output:
7
*/
