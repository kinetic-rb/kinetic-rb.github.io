#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read(){
	int s=0,w=1;char ch=getchar();
	while((ch<'0')||(ch>'9')){if(ch=='-'){w=-1;}ch=getchar();}
	while((ch>='0')&&(ch<='9')){s=(s<<3)+(s<<1)+ch-'0';ch=getchar();}
	return s*w;
}
const int N=2505;
const int M=20005;
int n,m,lim,tot,HeadL[N];
ll ans,val[N];
struct Edge{
	int from,to,nxt;
}edge[M];
inline void AddLine(int x,int y){
	edge[++tot].from=x;edge[tot].to=y;edge[tot].nxt=HeadL[x];HeadL[x]=tot;
	return ;
}
namespace Sub2{
	int cnt[305],vec[305][305],dist[305][305];
	inline bool cmp(int x,int y){return val[x]>val[y];}
	inline void dfs(int x,int fa,int dis,int y){
		dist[y][x]=dis;
		int i=HeadL[x];
		while(i!=0){
			if(edge[i].to!=fa&&dis<dist[y][edge[i].to])dfs(edge[i].to,x,dis+1,y);
			i=edge[i].nxt;
		}
		return ;
	}
	inline void Main(){
		memset(dist,0x3f,sizeof(dist));
		for(int i=1;i<=n;i++)dfs(i,0,-1,i);
		for(int i=1;i<=n;i++)
			for(int j=2;j<=n;j++)
				if(dist[i][j]<=lim&&i!=j)vec[i][++cnt[i]]=j;
		for(int i=1;i<=cnt[1];i++)
			for(int j=1;j<=cnt[vec[1][i]];j++)
				for(int k=1;k<=cnt[1];k++)
					for(int l=1;l<=cnt[vec[1][k]];l++)
						if(dist[vec[vec[1][i]][j]][vec[vec[1][k]][l]]<=lim&&vec[1][i]!=vec[vec[1][i]][j]&&vec[1][i]!=vec[vec[1][k]][l]&&vec[1][i]!=vec[1][k]&&vec[vec[1][i]][j]!=vec[vec[1][k]][l]&&vec[vec[1][i]][j]!=vec[1][k]&&vec[vec[1][k]][l]!=vec[1][k])
							ans=max(ans,val[vec[1][i]]+val[vec[vec[1][i]][j]]+val[vec[vec[1][k]][l]]+val[vec[1][k]]);
		printf("%lld\n",ans);
		return ; 
	}
}
namespace Sub3{
	int cnt[305],vec[305][305],dist[305][305];
	inline bool cmp(int x,int y){return val[x]>val[y];}
	inline void dfs(int x,int fa,int dis,int y){
		dist[y][x]=dis;
		int i=HeadL[x];
		while(i!=0){
			if(edge[i].to!=fa&&dis<dist[y][edge[i].to])dfs(edge[i].to,x,dis+1,y);
			i=edge[i].nxt;
		}
		return ;
	}
	inline void Main(){
		memset(dist,0x3f,sizeof(dist));
		for(int i=1;i<=n;i++)dfs(i,0,-1,i);
		for(int i=1;i<=n;i++)
			for(int j=2;j<=n;j++)
				if(dist[i][j]<=lim&&i!=j)vec[i][++cnt[i]]=j;
		for(int i=1;i<=n;i++)sort(vec[i]+1,vec[i]+cnt[i]+1,cmp);
			for(int i=1;i<=min(100,cnt[1]);i++){
				for(int j=1;j<=min(100,cnt[vec[1][i]]);j++)
					for(int k=1;k<=min(100,cnt[1]);k++)
						for(int l=1;l<=min(100,cnt[vec[1][k]]);l++)
							if(dist[vec[vec[1][i]][j]][vec[vec[1][k]][l]]<=lim&&vec[1][i]!=vec[vec[1][i]][j]&&vec[1][i]!=vec[vec[1][k]][l]&&vec[1][i]!=vec[1][k]&&vec[vec[1][i]][j]!=vec[vec[1][k]][l]&&vec[vec[1][i]][j]!=vec[1][k]&&vec[vec[1][k]][l]!=vec[1][k])
								ans=max(ans,val[vec[1][i]]+val[vec[vec[1][i]][j]]+val[vec[vec[1][k]][l]]+val[vec[1][k]]);
			}
		printf("%lld\n",ans);
		return ; 
	}
}
inline void Solve(){
	n=read();m=read();lim=read();
	for(int i=2;i<=n;i++)val[i]=read();
	for(int i=1,x,y;i<=m;i++){
		x=read();y=read();
		AddLine(x,y);AddLine(y,x); 
	}
	if(n<=300){Sub2::Main();return ;}
	if(n>300){Sub3::Main();return ;}
	return ;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	Solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
