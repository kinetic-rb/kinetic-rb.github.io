#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int s=0,w=1;char ch=getchar();
	while((ch<'0')||(ch>'9')){if(ch=='-'){w=-1;}ch=getchar();}
	while((ch>='0')&&(ch<='9')){s=(s<<3)+(s<<1)+ch-'0';ch=getchar();}
	return s*w;
}
const int N=1005;
int n,m,s,k,q,cnt[N];
bool vis[N][N],flag[N][N],vst[N];
inline bool dfs(int x,int fa){
	for(int i=1;i<=n;i++){
		if(vis[x][i]==true&&vis[i][x]==true)return true;
		if(i!=fa&&vst[i]==false){
			vst[i]=true;return dfs(i,x);vst[i]=false;
		}
	}
	return false;
}
inline void check(){
	for(int i=1;i<=n;i++)
		if(cnt[i]!=1){
			printf("NO\n");
			return ;
		}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)vst[j]=false;
		if(dfs(i,0)==false){
			printf("NO\n");
			return ;
		}
	}
	printf("YES\n");
	return ;
}
inline void Solve(){
	n=read();m=read();
	if(n>=100000){
		for(int i=1;i<=m;i++){s=read();k=read();}
		q=read();
		for(int i=1;i<=q;i++)printf("NO\n");
		return ;
	}
	for(int i=1,x,y;i<=m;i++){
		x=read();y=read();vis[x][y]=flag[x][y]=true;
		cnt[x]++;
	}
	q=read();
	for(int i=1,oper,x,y;i<=q;i++){
		oper=read();
		if(oper==1){x=read();y=read();flag[x][y]=false,cnt[x]--;}
		if(oper==2){x=read();for(int j=1;j<=n;j++)if(vis[j][x]==true&&flag[j][x]==true)flag[j][x]=false,cnt[j]--;}
		if(oper==3){x=read();y=read();flag[x][y]=true,cnt[x]++;}
		if(oper==4){x=read();for(int j=1;j<=n;j++)if(vis[j][x]==true&&flag[j][x]==false)flag[j][x]=true,cnt[j]++;}
		check();
	}
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	Solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
