#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int long long
inline int read(){
	int s=0,w=1;char ch=getchar();
	while((ch<'0')||(ch>'9')){if(ch=='-'){w=-1;}ch=getchar();}
	while((ch>='0')&&(ch<='9')){s=(s<<3)+(s<<1)+ch-'0';ch=getchar();}
	return s*w;
}
const int N=200005;
const int M=8000005;
const int INF=1e18;
const int K=25;
int n,q,k,tot,a[N],HeadL[N];
struct Edge{
	int from,to,nxt;
}edge[M];
inline void AddLine(int x,int y){
	edge[++tot].from=x;edge[tot].to=y;edge[tot].nxt=HeadL[x];HeadL[x]=tot;
	return ;
}
namespace Sub1{
	int dep[N],fa[N][K];ll dis[N];
	inline void Pre(int x,int fath){
		fa[x][0]=fath;dep[x]=dep[fath]+1;dis[x]=dis[fath]+a[x];
		for(int i=1;i<=20;i++)fa[x][i]=fa[fa[x][i-1]][i-1];
		int i=HeadL[x];
		while(i!=0){
			if(edge[i].to!=fath)Pre(edge[i].to,x);
			i=edge[i].nxt;
		}
		return ;
	}
	inline int LCA(int x,int y){
		if(dep[x]>dep[y])swap(x,y);
		for(int i=20;i>=0;i--)if(dep[x]<=dep[fa[y][i]])y=fa[y][i];
		if(x==y)return x;
		for(int i=20;i>=0;i--)if(fa[x][i]!=fa[y][i])x=fa[x][i],y=fa[y][i];
		return fa[x][0];
	}
	inline void Main(){
		Pre(1,0);
		for(int i=1,x,y,lca;i<=q;i++){
			x=read();y=read();lca=LCA(x,y);
			printf("%lld\n",dis[x]+dis[y]-2*dis[lca]+a[lca]);
		}
		return ;
	}
}
namespace Brute{
	int dist[2005][2005],dis[2005][2005];
	bool vis[2005];
	struct Node{
		int id,val;
		bool operator < (const Node &x) const {
			return val>x.val;
		}
	};
	priority_queue<Node>Q;
	inline void Dijkstra(int s){
		memset(vis,false,sizeof(vis));
		for(int i=1;i<=n;i++)dis[s][i]=INF;
		while(Q.empty()==false)Q.pop();
		dis[s][s]=0;Node k;k.id=s;k.val=0;Q.push(k);
		while(Q.empty()==false){
			Node p=Q.top();Q.pop();int x=p.id;
			if(vis[x]==true)continue;vis[x]=true;
			int i=HeadL[x];
			while(i!=0){
				if(dis[s][edge[i].to]>dis[s][x]+a[x]){
					dis[s][edge[i].to]=dis[s][x]+a[x];
					Node h;h.id=edge[i].to;h.val=dis[s][edge[i].to];
					Q.push(h);
				}
				i=edge[i].nxt;
			}
		}
		return ;
	}
	inline void dfs(int x,int fa,int y){
		int i=HeadL[x];
		while(i!=0){
			if(edge[i].to!=fa){
				dist[y][edge[i].to]=dist[y][x]+1;
				dfs(edge[i].to,x,y);
			}
			i=edge[i].nxt;
		}
		return ;
	}
	inline void Main(){
		for(int i=1;i<=n;i++)dfs(i,0,i);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(dist[i][j]<=k&&i!=j)
					AddLine(i,j);
		for(int i=1;i<=n;i++)Dijkstra(i);
		for(int i=1,x,y;i<=q;i++){
			x=read();y=read();
			printf("%lld\n",dis[x][y]+a[y]);
		}
		return ;
	}
}
inline void Solve(){
	n=read();q=read();k=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1,x,y;i<=n-1;i++){
		x=read();y=read();
		AddLine(x,y);AddLine(y,x);
	}
	if(k==1){Sub1::Main();return ;}
	if(n<=2000){Brute::Main();return ;}
	return ;
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	Solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
