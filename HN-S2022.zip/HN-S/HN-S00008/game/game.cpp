#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read(){
	int s=0,w=1;char ch=getchar();
	while((ch<'0')||(ch>'9')){if(ch=='-'){w=-1;}ch=getchar();}
	while((ch>='0')&&(ch<='9')){s=(s<<3)+(s<<1)+ch-'0';ch=getchar();}
	return s*w;
}
const int N=100005;
const ll INF=-1e18+5;
int n,m,q,a[N],b[N];
namespace Brute{
	inline void Main(){
		for(int i=1,l1,r1,l2,r2;i<=q;i++){
			ll ans=INF;
			l1=read();r1=read();l2=read();r2=read();
			for(int j=l1;j<=r1;j++){
				ll res=-INF;
				for(int k=l2;k<=r2;k++)res=min(res,(ll)a[j]*b[k]);
				ans=max(ans,res);
			}
			printf("%lld\n",ans);
		}
		return ;
	}
}
inline void Solve(){
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	Brute::Main();return ;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	Solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
