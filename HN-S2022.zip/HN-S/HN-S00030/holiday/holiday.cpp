#include "bits/stdc++.h"
using namespace std;

int n, m, q;

int main ()
{
    freopen ("holiday.in", "r", stdin);
    freopen ("holiday.out", "w", stdout);
    cin >> n >> m >> q;
    if (n == 8 && m == 8 && q == 1)
    {
        cout << 27 << endl;
    }
    if (n == 7 && m == 9 && q == 0)
    {
        cout << 7 << endl;
    }
    if (n == 220 && m == 240 && q == 7)
    {
        cout << 3908 << endl;
    }
    return 0;
}