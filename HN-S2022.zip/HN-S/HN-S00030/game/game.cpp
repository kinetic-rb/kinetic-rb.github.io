#include "bits/stdc++.h"
using namespace std;

int main ()
{
    freopen ("game.in", "r", stdin);
    freopen ("game.out", "w", stdout);
    return 0;
}