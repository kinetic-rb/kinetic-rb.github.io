#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long a[100005],b[100005];
long long ans;
long long mn,mx;
long long read(){
	char ch;
	long long s=0,f=1;
	ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar(); 
	}
	return s*f;
}
long long find_max(int x,int y){
	if(x==y){
		return b[x];
	}
	int mid=(x+y)>>1;
	return max(find_max(x,mid),find_max(mid+1,y));
}
long long find_min(int x,int y){
	if(x==y){
		return b[x];
	}
	int mid=(x+y)>>1;
	return min(find_min(x,mid),find_min(mid+1,y));
}
long long get(int x,int y){
	if(x==y){
		long long z;
		if(a[x]>0){
			z=a[x]*mn;
		}
		else if(a[x]<0){
			z=a[x]*mx;
		}
		else{
			z=0;
		}
		return z;
	}
	int mid=(x+y)>>1;
	return max(get(x,mid),get(mid+1,y));
}
void write(long long x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+'0');
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=m;i++){
		b[i]=read();
	}
	int u,v,x,y;
	for(int i=1;i<=q;i++){
		u=read(),v=read(),x=read(),y=read();
		mn=find_min(x,y);
		mx=find_max(x,y);
		ans=get(u,v);
		write(ans);
		putchar(10);
	}
	return 0;
}
