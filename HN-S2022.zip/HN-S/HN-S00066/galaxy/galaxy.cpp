#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int chu[500005];
int read(){
	char ch;
	int s=0,f=1;
	ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar(); 
	}
	return s*f;
}
struct node{
	int y,z,next;
}e[500005];
int head[500005],tot;
void add(int x,int y){
	tot++;
	e[tot].y=y;
	e[tot].z=1;
	e[tot].next=head[x];
	head[x]=tot;
}
int vis[500005];
int huan(int x,int fa){
	vis[x]=1;
	for(int i=head[x];i;i=e[i].next){
		int y=e[i].y;
		if(y==fa)continue;
		if(vis[y]){
			vis[x]=0;
			return 1;
		}
		if(huan(y,x)){
			vis[x]=0;
			return 1;
		}
	}
	vis[x]=0;
	return 0;
}
int pd(){
	for(int i=1;i<=n;i++){
		if(chu[i]!=1){
			return 0;
		}
	}
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	int x,y,z;
	for(int i=1;i<=m;i++){
		x=read(),y=read();
		chu[x]++;
		add(y,x);
	}
	q=read();
	for(int i=1;i<=q;i++){
		z=read();
		if(z==1){
			x=read(),y=read();
			for(int i=head[y];i;i=e[i].next){
				if(e[i].y==x){
					e[i].z=0;
					break;
				}
			}
			chu[x]--;
		}
		else if(z==2){
			x=read();
			for(int i=head[x];i;i=e[i].next){
				if(e[i].z==1){
					e[i].z=0;
					chu[e[i].y]--;
				}
			}
		}
		else if(z==3){
			x=read(),y=read();
			for(int i=head[y];i;i=e[i].next){
				if(e[i].y==x){
					e[i].z=1;
					break;
				}
			}
			chu[x]++;
		}
		else if(z==4){
			x=read();
			for(int i=head[x];i;i=e[i].next){
				if(e[i].z==0){
					e[i].z=1;
					chu[e[i].y]++;
				}
			}
		}
		if(huan(1,0)&&pd()){
			putchar('Y');
			putchar('E');
			putchar('S');
			putchar(10);
		}
		else{
			putchar('N');
			putchar('O');
			putchar(10);
		}
	}
	return 0;
}
