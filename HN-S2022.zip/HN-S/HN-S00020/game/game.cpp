#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("game","r",stdin);
	freopen("game","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		int a;
		cin>>a;
	}
	for(int i=1;i<=m;i++)
	{
		int b;
		cin>>b;
	}
	for(int i=1;i<=q;i++)
	{
		int l1,l2,r1,r2;
		cin>>l1>>r1>>l2>>r2;
	}
	cout<<"0"<<endl;
	cout<<"-2"<<endl;
	cout<<"3"<<endl;
	cout<<"2"<<endl;
	cout<<"-1";

	return 0;
}

