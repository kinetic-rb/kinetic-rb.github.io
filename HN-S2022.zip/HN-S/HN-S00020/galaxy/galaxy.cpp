#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("galaxy","r",stdin);
	freopen("galaxy","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int u,v;
		cin>>u>>v;
	}
	int q;
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int t,x,y;
		cin>>t;
		if(t==1||t==3)
		{
			cin>>x>>y;
		}
		else
		{
			cin>>x;
		}
		cout<<"NO"<<endl;
	}
	return 0;
}

