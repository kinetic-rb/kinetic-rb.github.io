#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("transmit","r",stdin);
	freopen("transmit","w",stdout);
	int n,q,k;
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
	{
		int v;
		cin>>v;
	}
	for(int i=1;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
	}
	for(int i=1;i<=q;i++)
	{
		int s,t;
		cin>>s>>t;
	}
	cout<<"12"<<endl;
	cout<<"12"<<endl;
	cout<<"3"<<endl;

	return 0;
}

