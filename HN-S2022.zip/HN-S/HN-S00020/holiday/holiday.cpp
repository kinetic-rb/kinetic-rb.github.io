#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("holiday","r",stdin);
	freopen("holiday","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<n;i++)
	{
		int x;
		cin>>x;
	}
	for(int i=1;i<=m;i++)
	{
		int w,e;
		cin>>w>>e;
	}
	cout<<"7";
	return 0;
}

