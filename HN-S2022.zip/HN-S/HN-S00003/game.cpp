#include<bits/stdc++.h>
using namespace std;

int n,m,q,A[100050],B[100050],l,r,ll,rr;
long long ans,now;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>A[i];
	for(int j=1;j<=m;j++)cin>>B[j];
	while(q--){
		cin>>l>>r>>ll>>rr;
		if(l==r){
			now=A[l];
			ans=99999999;
			for(int i=1;i<=m;i++){
				if(now*B[i]<ans)ans=now*B[i];
			}
		}else{
			now=B[ll];
			ans=-99999999;
			for(int i=1;i<=n;i++){
				if(now*A[i]>ans)ans=now*A[i];
			}
		}cout<<ans<<endl;
	}
	return 0;
}

