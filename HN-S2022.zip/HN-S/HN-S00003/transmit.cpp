#include<bits/stdc++.h>
using namespace std;

long long n,Q,k,v[200050],a,b,s,t,deep[200050],bz[200050][10],LOG,dp[200050],sl[200050],ans;
vector<long long>vec[200050];

long long lcu(int x,int y){
	if(deep[x]<deep[y])swap(x,y);
	for(int i=log2(deep[x])+1;i>=0;i--){
		if(deep[x]-pow(2,i)+1>=deep[y]){
			x=bz[x][i];
		}
	}if(x==y)return x;
	for(int i=LOG;i>=0;i--){
		if(bz[x][i]!=bz[y][i]){
			x=bz[x][i];
			y=bz[y][i];
		}
	}return bz[x][1];
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++){
		cin>>v[i];
		bz[i][0]=i;
	}for(int i=1;i<n;i++){
		cin>>a>>b;
		vec[a].push_back(b);
		vec[b].push_back(a);
	}queue<int>q;
	q.push(1);
	deep[1]=1;
	int fr;
	while(!q.empty()){
		fr=q.front();
		q.pop();
		for(int i=0;i<vec[fr].size();i++){
			if(deep[vec[fr][i]]==0){
				deep[vec[fr][i]]=deep[fr]+1;
				q.push(vec[fr][i]);
			}
		}
	}LOG=log2(n);
	for(int j=1;j<=LOG;j++){
		for(int i=1;i<=n;i++){
			for(int k=0;k<vec[i].size();k++){
				if(deep[i]>deep[vec[i][k]]){
					bz[i][j]=bz[vec[i][k]][j-1];
				}
			}
		}
	}while(Q--){
		cin>>s>>t;
		int LCU=lcu(s,t);
		if(deep[s]-deep[LCU]+deep[t]-deep[LCU]<=k){
			cout<<v[s]+v[t]<<endl;
			continue;
		}memset(dp,-1,sizeof(dp));
		int hh=0;
		int save=s,save2=t;
		while(s!=LCU){
			sl[hh]=v[s];
			s=bz[s][1];
			hh++;
		}sl[hh]=LCU;
		hh=deep[save]-deep[LCU]+deep[t]-deep[LCU];
		while(t!=LCU){
			sl[hh]=v[t];
			t=bz[t][1];
			hh--;
		}int len=deep[save]-deep[LCU]+deep[save2]-deep[LCU];
		if(k==1){
			ans=0;
			for(int i=0;i<=len;i++)ans+=sl[i];
			cout<<ans<<endl;
		}if(k==2){
			dp[0]=sl[0];
			dp[1]=sl[0]+sl[1];
			for(int i=2;i<=len;i++){
				dp[i]=min(dp[i-1],dp[i-2])+sl[i];
			}cout<<dp[len]<<endl;
		}if(k==3){
			dp[0]=sl[0];
			dp[1]=sl[0]+sl[1];
			dp[2]=sl[0]+sl[2];
			for(int i=3;i<=len;i++){
				dp[i]=min(dp[i-1],min(dp[i-2],dp[i-3]))+sl[i];
			}cout<<dp[len]<<endl;
		}
	}
	return 0;
}

