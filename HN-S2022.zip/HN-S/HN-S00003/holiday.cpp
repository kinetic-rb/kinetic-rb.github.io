#include<bits/stdc++.h>
using namespace std;

int n,m,k,val[2550],x,y,v[2550][2550],now,ans,f[4][2550],ks;
bool flag[2550],flag2[2550][2550];
vector<int>vec[2550];

void dfs(int no,int deep){
	if(ks>5310000)return;
	ks++;
	if(deep==4){
		for(int i=0;i<vec[no].size();i++){
			if(vec[no][i]==1){
				ans=max(ans,now);
				return;
			}
		}return;
	}int jyh=ans;
	for(int i=0;i<vec[no].size();i++){
		if(flag[vec[no][i]]==0&&vec[no][i]!=1){
			if(f[deep][no]!=0){
				ans=max(ans,now+f[deep][no]);
				break;
			}flag[vec[no][i]]=1;
			now+=val[vec[no][i]];
			dfs(vec[no][i],deep+1);
			now-=val[vec[no][i]];
			flag[vec[no][i]]=0;
		}
	}if(jyh!=ans)f[deep][no]=ans-now;
}

void kz(int org,int no,int deep){
	ks++;
	if(deep>k)return;
	for(int i=1;i<=n;i++){
		if(v[no][i]==0&&flag2[org][i]==0){
			flag2[org][i]=1;
			vec[org].push_back(i);
			kz(org,i,deep+1);
		}
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	memset(v,-1,sizeof(v));
	flag2[1][1]=1;
	for(int i=2;i<=n;i++){
		cin>>val[i];
		flag2[i][i]=1;
	}for(int i=1;i<=m;i++){
		cin>>x>>y;
		v[x][y]=0;
		v[y][x]=0;
	}for(int i=1;i<=n;i++){
		kz(i,i,0);
	}dfs(1,0);
	cout<<ans<<endl;
	return 0;
}
