#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[10010],ans;
int main()
{
	freopen("holiday.in","r",stdin); 
	freopen("holiday.out","w",stdout); 
	cin>>n>>m>>k;
	for(int i=1;i<=n-1;i++)
	{
	cin>>a[i];
	}
	sort(a+1,a+n);
	for(int i=n-1;i>=n-4;i--)
	{
		ans+=a[i];
	}
	cout<<ans<<endl;
	return 0;
 } 
