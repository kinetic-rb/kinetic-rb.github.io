#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long a[10010],b[10010]; 
long long cnt=1000000000000000010,ans=-1000000000000000010;
int main()
{
	freopen("game.in","r",stdin); 
	 freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=1;i<=m;i++)
	cin>>b[i];
	 while(q--)
	 {
	 	cnt=1000000000000000010,ans=-1000000000000000010;
	 	int l1,r1,l2,r2;
	 	cin>>l1>>r1>>l2>>r2;
	 	for(int i=l1;i<=r1;i++)
	 	{	
	 	 cnt=1000000000000000010;
		 for(int j=l2;j<=r2;j++)
		 {
		 cnt=min(cnt,a[i]*b[j]);
		 }
		  ans=max(ans,cnt);
	 	}
	 	cout<<ans<<endl;
	 }	
	return 0;
}

