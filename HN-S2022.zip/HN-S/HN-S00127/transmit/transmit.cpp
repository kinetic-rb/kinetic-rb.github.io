#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[1000010];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		cin>>x>>y;
	}
	for(int i=1;i<=k;i++)
	{
		int x,y;
		cin>>x>>y;
		cout<<a[x]+a[y]<<endl;
	}
	return 0;
} 
