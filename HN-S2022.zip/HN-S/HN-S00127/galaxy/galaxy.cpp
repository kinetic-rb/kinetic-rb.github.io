#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen(" galaxy.in","r",stdin);
	freopen(" galaxy.out","w",stdout);
	while(1)
	{
		cout<<"NO"<<endl;
	}
	return 0;
}
