#include<bits/stdc++.h>

using namespace std;

typedef long long LL;

const LL N=1e5+100,INF=1e18;
LL n,m,q;
LL A[N],B[N];

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	scanf("%d%d%d",&n,&m,&q);
	
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&A[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&B[i]);
	}
	
	while(q--)
	{
		LL l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		
		LL ans=-INF;
		for(int i=l1;i<=r1;i++)
		{
			LL res=INF;
			for(int j=l2;j<=r2;j++)
			{
				res=min(res,A[i]*B[j]);
			}
			
			ans=max(ans,res);
		}
		
		cout<<ans<<endl;
	}
	
	return 0;
}
