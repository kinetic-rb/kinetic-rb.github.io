#include<bits/stdc++.h>

using namespace std;

const int N=3000,INF=0x3f3f3f3f;

int n,m,k;
int g[N];
int d[N][N];
bool st[N];
int h[N],e[N],ne[N],idx=1;
int ans=-0x3f3f3f3f;

void dfs(int u,int v,int w)
{
	if(v==5)
	{
		if(u==1) ans=max(ans,w);
		return ;
	}
	
	for(int i=1;i<=n;i++)
	{
		if(d[u][i]!=INF&&d[u][i]-1<=k&&st[i]==0)
		{
			st[i]=1;
			dfs(i,v+1,w+g[i]);
			st[i]=0;
		}
	}
}

int main()
{
	//freopen("holiday.in","r",stdin);
	//freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	
	for(int i=2;i<=n;i++)
	{
		cin>>g[i];
	}
	
	for(int i=0;i<N;i++)
	{
		for(int j=0;j<N;j++)
		{
			d[i][j]=INF;
		}
	}
	while(m--)
	{
		int a,b;
		cin>>a>>b;
		d[a][b]=1;
		d[b][a]=1;
	}
	
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=1;k<=n;k++)
			{
				d[i][j]=min(d[i][j],d[i][k]+d[j][k]);
			}
		}
	}
	
	dfs(1,0,0);
	
	cout<<ans; 
	
	return 0;
}
