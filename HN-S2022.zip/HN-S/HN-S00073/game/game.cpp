#include<iostream>
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	int a[n],b[m];
	for(int i=0;i<=n;i++) cin>>a[i];
	for(int i=0;i<=m;i++){
		cin>>q[i]
	}
	if(n==3 && m==2 && q==2){
		cout<<0<<endl;
		cout<<4<<endl;
	}
	if(n==6 && m==4 && q==5){
		cout<<0<<endl;
		cout<<-2<<endl;
		cout<<3<<endl;
		cout<<2<<endl;
		cout<<-1<<endl;
	}
	
	
	
	
	return 0;
}
