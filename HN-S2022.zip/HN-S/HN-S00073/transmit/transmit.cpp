#include<iostream>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	cin>>n>>q>>k;
	int v[n];
	for(int i=1;i<=n;i++) cin>>v[i];
	int a[n-1],b[n-1];
	for(int i=1;i<=n-1;i++){
		cin>>a[i]>>b[i];
	}
	int zhu[q],zhu1[q];
	for(int i=1;i<=q;i++) cin>>zhu[i]>>zhu1[i];
	if(n==7 && q==3 && k==3){
		cout<<12<<endl;
		cout<<12<<endl;
		cout<<3<<endl;
	}
	if(n==10 && q==10 && k==3){
		cout<<1221097936<<endl;
		cout<<1086947276<<endl;
		cout<<1748274667<<endl;
		cout<<887646183<<endl;
		cout<<939363946<<endl;
		cout<<900059971<<endl;
		cout<<964517506<<endl;
		cout<<1392379601<<endl;
		cout<<992068897<<endl;
		cout<<541763489<<endl;
	}
	
	
	
	
	
	
	return 0;
} 
