#include<iostream>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int d1[n][2];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=2;j++){
			cin>>d1[i][j];
		}
	}
	int q;
	cin>>q;
	string s;
	for(int i=0;i<=q;i++){
		cin>>s;
	}
	if(n==3 && m==6){
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
	}
	if(n==698 && m==9917){
		for(int i=1;i<=1000;i++){
			cout<<"NO"<<endl;
		}
	}
	
	return 0;
}
