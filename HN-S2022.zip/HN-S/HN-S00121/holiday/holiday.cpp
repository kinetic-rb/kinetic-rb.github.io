#include <bits/stdc++.h>
using namespace std;
long long int n,m,x,y,f[3005][3005],s[3005][3005],c[3005],son[3005];
int K,ans;
void reads(){
	for(int i=1;i<n;i++){
	cin>>c[i+1];	
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		son[x]++;
		son[y]++;
		s[x][son[x]]=y;
		s[y][son[y]]=x;
	}
}
void work(int k,int d,int sy,int fs){
	if(sy==0)if(d==1)ans=max(ans,fs);
	for(int i=1;i<=son[d];i++){
		if(k==0)work(K,s[d][son[i]],sy-1,fs+c[d]);
		else {
		work(k-1,s[d][son[i]],sy,fs);
		work(K,s[d][son[i]],sy-1,fs+c[d]);
	}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>K;
	reads();
	work(K,1,4,0);
	cout<<ans<<endl;
	return 0;
}
