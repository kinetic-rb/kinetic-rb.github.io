#include<bits/stdc++.h>
using namespace std;
long long n,m,q,ans,l1,l2,r1,r2,a[10005],b[10005],c[10005][10005];
void work(){
	for(long long i=l1;i<=r1;i++){
		long long t=10000000;
		for(long long j=l2;j<=r2;j++){
			if(c[i][j]);
			else c[i][j]=a[i]*b[j];
			t=min(t,c[i][j]);
		}
		ans=max(ans,t);
}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(long long i=1;i<=n;i++)cin>>a[i];
	for(long long j=1;j<=m;j++)cin>>b[j];
	while(q){
		cin>>l1>>r1>>l2>>r2;
		ans = -10000000;
		work();
		cout<<ans<<endl;
		q-=1;
	}
	freclose("game.in");fclose("game.out");
	return 0;
}
