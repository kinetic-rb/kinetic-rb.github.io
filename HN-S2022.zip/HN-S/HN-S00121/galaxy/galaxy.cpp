#include <bits/stdc++.h>
using namespace std;
long long int n,m,q,x,y,sy[10005]={0},son[10005]={0},k,t;
struct h{
	int f[20005];
	int fa[5005];
}tt[20005];
int fg(){
	for(int i=1;i <= n;i++)
	if(sy[i]==1);
	else return 0;
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		tt[x].f[y]=1;
		son[y]++;
		tt[y].fa[son[y]]=x;
		sy[x]++;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>k;
		if(k==1){
			cin>>x>>y;
			tt[x].f[y]=2;
			sy[x]--;
		}
		else if(k==2){
			cin>>t;
			for(int i=1;i<=son[t];i++)
			if(tt[tt[t].fa[i]].f[t]==1){
		    tt[tt[t].fa[i]].f[t]=2;
			sy[tt[t].fa[i]]--;
		}
		}
		else if(k==3){
			cin>>x>>y;
			tt[x].f[y]=1;
			sy[x]++;
		}
		else if(k==4){
			cin>>t;
			for(int i=1;i<=son[t];i++)
			if(tt[tt[t].fa[i]].f[t]==2){
			tt[tt[t].fa[i]].f[t]=1;
			sy[tt[t].fa[i]]++;
		}
		}
		if(fg())cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
