#include <bits/stdc++.h>
using namespace std;
int d[2005][2005],f[2005][2005],n,q,k,ans,x,y,a[2005];
void work(){
	for(int k=1;k<=n;k++)
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	if(d[i][k]+d[k][j]<d[i][j]){
	d[i][j]=d[i][k]+d[k][j];
	d[j][i]=d[i][j];

}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<n;i++){
		cin>>x>>y;
		f[x][y]=1;
		f[y][x]=1;
	}
work();
	for(int i=1;i<=q;i++){
		cin>>x>>y;
		if(f[x][y]){
			ans=a[x]+a[y];
			cout<<ans<<endl;
			return 0;
		}
		if(d[x][y]<=k){
		}
	}
}
