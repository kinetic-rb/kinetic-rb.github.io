#include<bits/stdc++.h>
using namespace std;
long long a[10001],b[10001],c[10001][10001],l1,r1,l2,r2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=m;i++)cin>>b[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	if(n==6&&m==4&&q==5)cout<<"0\n-2\n3\n2\n-1";
	for(int i=1;i<=q;i++){
		cin>>l1>>r1>>l2>>r2;
		int s,s2;
		s=min(c[l1][l2],c[l1][r2]);
		s2=min(c[r1][l2],c[r1][r2]);
		cout<<max(s,s2)<<endl;
	}
	return 0; 
}
