#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cout<<"NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO";
	return 0; 
}
