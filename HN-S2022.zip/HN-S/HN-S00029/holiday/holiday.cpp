#include<bits/stdc++.h>
using namespace std;
const int MX = 2505;
typedef long long ll;
int n, m, k;
int f[MX][MX];
ll a[MX], ans = -1e18;
vector<int> v[MX];

void floyd()
{
	for(int k=1; k<=n; ++k)
		for(int i=1; i<=n; ++i)
		{
			if(f[i][k]>k+1) continue;
			for(int j=1; j<=n; ++j)
				if(f[k][j]<=k+1) f[i][j] = min(f[i][j], f[i][k]+f[k][j]);
		}

	for(int j=1; j<=n; ++j)
		for(int i=j+1; i<=n; ++i)
		{
			if(f[i][j]<=k+1) v[i].emplace_back(j), v[j].emplace_back(i);
		}
}

int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	memset(f, 0x3f, sizeof(f));
	cin>>n>>m>>k; f[1][1] = 0;
	for(int i=2; i<=n; ++i)
		cin>>a[i], f[i][i]=0;
	for(int i=1; i<=m; ++i)
	{
		int x, y; cin>>x>>y;
		f[x][y] = f[y][x] = 1;
		if(k==0) v[x].emplace_back(y), v[y].emplace_back(x);
	}
	if(k>0) floyd();
	for(int i=0; i<v[1].size(); ++i)
		for(int j=i+1; j<v[1].size(); ++j)
		{
			int A=v[1][i], B=v[1][j];
			for(int kk=0; kk<v[A].size(); ++kk)
			{
				if(v[A][kk]==1) continue;
				for(int l=0; l<v[B].size(); ++l)
				{
					int C=v[A][kk], D=v[B][l]; if(D==1) continue;
					if(A==D || B==C || C==D) continue;
					if(f[C][D]<=k+1)
					{
						ans = max(ans, a[A]+a[B]+a[C]+a[D]);
					}
				}
			}
				
		}
	cout<<ans<<endl;
	
	return 0;
}
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/


