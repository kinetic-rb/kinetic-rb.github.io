#include<bits/stdc++.h>
using namespace std;
const int MX = 1e5 + 5;
typedef long long ll;
int n, m, q;
ll ai[MX][20], aa[MX][20];
ll bi[MX][20], ba[MX][20];
ll mi[MX][20], ma[MX][20];
int lg[MX];

void init(){
	for(int i=1; i<=17; ++i)
		for(int x=1; x+(1<<i)-1<=n; ++x)
		{
			ai[x][i] = min(ai[x][i-1], ai[x+(1<<(i-1))][i-1]);
			aa[x][i] = max(aa[x][i-1], aa[x+(1<<(i-1))][i-1]);
		}
	for(int i=1; i<=17; ++i)
		for(int x=1; x+(1<<i)-1<=m; ++x)
		{
			bi[x][i] = min(bi[x][i-1], bi[x+(1<<(i-1))][i-1]);
			ba[x][i] = max(ba[x][i-1], ba[x+(1<<(i-1))][i-1]);
			
		}
	for(int i=1; i<=17; ++i)
		for(int x=1; x+(1<<i)-1<=n; ++x)
		{
			mi[x][i] = min(mi[x][i-1], mi[x+(1<<(i-1))][i-1]);
			ma[x][i] = max(ma[x][i-1], ma[x+(1<<(i-1))][i-1]);
		}
	lg[1] = 0; int limit = max(n, m);
	for(int i=2; i<=limit; ++i)
		lg[i] = lg[i>>1]+1;
}

ll aMIN(int l, int r)
{
	int k = lg[r-l+1];
	return min(ai[l][k], ai[r-(1<<k)+1][k]);
}
ll bMIN(int l, int r)
{
	int k = lg[r-l+1];
	return min(bi[l][k], bi[r-(1<<k)+1][k]);
}
ll aMAX(int l, int r)
{
	int k = lg[r-l+1];
	return max(aa[l][k], aa[r-(1<<k)+1][k]);
}
ll bMAX(int l, int r)
{
	int k = lg[r-l+1];
	return max(ba[l][k], ba[r-(1<<k)+1][k]);
}
ll mMIN(int l, int r)
{
	int k = lg[r-l+1];
	return min(mi[l][k], mi[r-(1<<k)+1][k]);
}
ll mMAX(int l, int r)
{
	int k = lg[r-l+1];
	return max(ma[l][k], ma[r-(1<<k)+1][k]);
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);

	cin>>n>>m>>q;
	
	for(int i=1; i<=n; ++i)
	{
		cin>>ai[i][0]; aa[i][0] = ai[i][0]; 
		if(ai[i][0]>0)
		{
			mi[i][0] = ai[i][0]; ma[i][0] = -1e9; 
		}
		else
		{
			ma[i][0] = ai[i][0]; mi[i][0] = 1e9;
		}
	}
	for(int i=1; i<=m; ++i)
	{
		cin>>bi[i][0]; ba[i][0] = bi[i][0]; 
		
	}
	init();
	for(int i=1; i<=q; ++i)
	{
		int l1, r1, l2, r2; cin>>l1>>r1>>l2>>r2;
		if(bMIN(l2, r2)>=0)
			cout<<aMAX(l1, r1)*bMIN(l2, r2)<<"\n";
		else if(bMAX(l2, r2)<0)
			cout<<aMIN(l1, r1)*bMAX(l2, r2)<<"\n";
		else if(aMIN(l1, r1)>=0)
			cout<<aMIN(l1, r1)*bMIN(l2, r2)<<"\n";
		else if(aMAX(l1, r1)<0)
			cout<<aMAX(l1, r1)*bMAX(l2, r2)<<"\n";
		else
		{
			ll ans = mMIN(l1, r1)*bMIN(l2, r2);
			ans = max(ans, mMAX(l1, r1)*bMAX(l2, r2));
			cout<<ans<<"\n";
		}
	}
	
	return 0;
}

/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/

