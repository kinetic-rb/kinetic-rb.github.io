#include<bits/stdc++.h>
using namespace std;
const int MX = 2e5+5;
typedef long long ll;
int n ,Q, k;
ll v[MX];

struct GRAPH
{
	int fst[MX], nxt[MX*2], v[MX*2], lnum;
	void addeg(int nu, int nv)
	{
		v[++lnum] = nv;
		nxt[lnum] = fst[nu];
		fst[nu] = lnum;
	}
} G;

struct CHAIN
{
	int siz[MX], dep[MX], fa[MX], son[MX], top[MX]; ll sum[MX];
	void dfs1(int x, int f)
	{
		dep[x] = dep[f] + 1; siz[x] = 1; fa[x] = f;
		for(int i=G.fst[x]; i; i=G.nxt[i])
		{
			int y = G.v[i];
			if(y == f) continue; 
			sum[y] = sum[x] + v[y]; dfs1(y, x);
			siz[x] += siz[y]; 
			if(siz[y] > siz[son[x]]) son[x] = y;
		}
	}
	
	void dfs2(int x, int f, int t)
	{
		top[x] = t;
		if(son[x]) dfs2(son[x], x, t);
		for(int i=G.fst[x]; i; i=G.nxt[i])
		{
			int y = G.v[i];
			if(y == f || y==son[x]) continue;
			dfs2(y, x, y);
		}
	}
	
	int lca(int x, int y)
	{
		int fx = top[x], fy = top[y];
		while(fx != fy)
		{
			if(dep[fx] < dep[fy]) swap(fx, fy), swap(x, y);
			x = fa[fx], fx = top[x];
		}
		if(dep[x]<dep[y]) return x;
		return y;
	}
	
	ll get(int x, int y)
	{
		ll ans = sum[x]+sum[y];
		int L = lca(x, y);
		ans -= sum[fa[L]]+sum[L];
		return ans;
	}
}C;

int main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	cin>>n>>Q>>k;
	for(int i=1; i<=n; i++)
	{
		cin>>v[i];
	}
	for(int i=1; i<n;i++)
	{
		int a, b;
		cin>>a>>b; G.addeg(a, b); G.addeg(b, a);
	}
	C.sum[1] = v[1]; C.dfs1(1, 0); C.dfs2(1, 0, 1); 
	for(int i=1; i<=Q; i++)
	{
		int s, t; cin>>s>>t;
		cout<<C.get(s, t)<<"\n";
	}

	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/


