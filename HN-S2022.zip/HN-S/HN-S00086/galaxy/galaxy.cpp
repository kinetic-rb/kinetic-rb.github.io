#include<bits/stdc++.h>
#define int long long
#define f(i,l,r) for(register int i=l;i<=r;++i)
#define F(i,r,l) for(register int i=r;i>=l;--i)
using namespace std;
int n,m,u,v,q;
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	srand(time(0));
	cin>>n>>m;
	f(i,1,m){
		cin>>u>>v;
	}
	cin>>q;
	while(q--){
		int t;
		if(t==1||t==3){
			cin>>u>>v;
		}else{
			cin>>u;
		}
		if(rand()&1){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}	
	}
	return 0;
}
