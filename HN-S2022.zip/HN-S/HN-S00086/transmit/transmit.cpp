#include<bits/stdc++.h>
#define int long long
#define f(i,l,r) for(register int i=l;i<=r;++i)
#define F(i,r,l) for(register int i=r;i>=l;--i)
using namespace std;
signed main(){
	return 0;
}
