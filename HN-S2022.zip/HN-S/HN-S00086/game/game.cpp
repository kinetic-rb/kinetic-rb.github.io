#include<bits/stdc++.h>
#define int long long
#define f(i,l,r) for(register int i=l;i<=r;++i)
#define F(i,r,l) for(register int i=r;i>=l;--i)
using namespace std;
int n,m,q,l1,l2,r1,r2;
int a[10010],b[10010],c[10010][10010],w[10010];
signed main(){
//	freopen("game.in","r",stdin);
//	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	f(i,1,n){
		cin>>a[i];
	}
	f(i,1,m){
		cin>>b[i];
	}
	f(i,1,n){
		f(j,1,m){
			c[i][j]=a[i]*b[j];
		}
	}
	while(q--){
		cin>>l1>>r1>>l2>>r2;
		int maxn=-0x3f3f3f3f,minn=0x3f3f3f3f,maxx,minx;
		if(l1==r1){
			f(i,1,m){
				minn=min(minn,c[i][l1]);
			}
			cout<<minn<<endl;
			continue;
		}
		if(l2==r2){
			f(i,1,n){
				maxn=max(maxn,c[l2][i]);
			}
			cout<<maxn<<endl;
			continue;
		}else{
			f(i,1,n){
				f(j,1,m){
					if(c[i][j]<0){
						w[i]++;
					}
				}
			}
			sort(w+1,w+1+n);
			int tot=0,ans=0;
			f(i,l1,r1){
				if(w[i]==tot){
					ans++;
					f(j,1,m)
						minn=min(minn,c[i][j]);
				}
				if(ans==0)
					tot++;
			}
			cout<<minn<<endl; 
		}
	}
	return 0;
}
