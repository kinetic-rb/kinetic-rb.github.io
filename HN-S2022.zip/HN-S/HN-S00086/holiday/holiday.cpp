#include<bits/stdc++.h>
#define int long long
#define f(i,l,r) for(register int i=l;i<=r;++i)
#define F(i,r,l) for(register int i=r;i>=l;--i)
using namespace std;
int tot,n,m,s;
int d[1000010],dq[1000010],v[1000010],head[1000010];
struct Edge{
	int u,v,dis;
}edge[1000010];
void add(int x,int y,int z){
	tot++;
	edge[tot].dis=z;
	edge[tot].v=y;
	edge[tot].u=head[x];
	head[x]=tot;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>s;
	f(i,1,n-1){
		cin>>dq[i];
	}
	f(i,1,m){
		int x,y,z;
		cin>>x>>y;
		add(x,y,1);
		add(y,x,1); 
	}
	priority_queue<pair<int ,int> >q;
	f(i,1,n){
		d[i]=-0x3f3f3f3f;
		v[i]=0;
	}
	d[1]=0;
	v[1]=1;
	q.push(make_pair(0,1));
	while(!q.empty()){
		int x=q.top().second;
		q.pop();
		for(int i=head[x];i;i=edge[i].u){
			int y=edge[i].v;
			
		}
	}
	return 0;
}
