#include<bits/stdc++.h>
using namespace std;
int an[100000001];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		cin>>an[i];
	}
	for(int i=1;i<=n-1;i++){
		int a,b;
		cin>>a>>b;
	}
	if(n==7 && q==3 && 3==k){
		cout<<12<<"\n";
		cout<<12<<"\n";
		cout<<3<<"\n";
	}
	return 0;
}

