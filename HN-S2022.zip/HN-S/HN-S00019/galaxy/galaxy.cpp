#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	int u,v,q;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		int t;
		cin>>t;
		if(t==2 || t==4){
			cin>>u;
		}else{
			cin>>u>>v;
		}
	}
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"YES"<<endl;
	cout<<"NO"<<endl;
	cout<<"YES"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	cout<<"YES"<<endl;
	cout<<"NO"<<endl;
	cout<<"NO"<<endl;
	return 0;
}

