#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int M=5005;
int n,m,k,x,y,maxx=-1;
long long p[2505];
int cnt1[2505],cnt2[2505];
struct node
{
	int next[M],last[M]; 
}v[M];

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>p[i];
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		v[y].last[++cnt2[y]]=x;
		v[x].next[++cnt1[x]]=y;
	}
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		maxx=0;
		for(int j=1;j<=cnt1[i];j++)
		{
//			cout<<i<<' '<<v[i].next[j]<<' ';
			int pri=p[v[i].next[j]];
			maxx=max(pri,maxx);
		}
		ans+=maxx;
	}
	cout<<ans<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
