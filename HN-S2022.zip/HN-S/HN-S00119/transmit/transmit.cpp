#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<algorithm>

using namespace std;

int n,Q,k;
int v[20005];
int a[20005],b[20005];
int s[20005],t[20005];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++)
		cin>>v[i];
	for(int i=1;i<n;i++)
		cin>>a[i]>>b[i];
	for(int i=1;i<=Q;i++)
	{
		cin>>s[i]>>t[i];
		cout<<v[s[i]]+v[t[i]]<<endl;
		
	}
		
	fclose(stdin);fclose(stdout);
	return 0;
}
