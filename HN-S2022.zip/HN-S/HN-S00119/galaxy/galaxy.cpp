#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<algorithm>

using namespace std;

int n,m,p;
struct node
{
	int u,v;
	bool f;
}c[500005];
int t,a,b,d;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>c[i].u>>c[i].v;
		c[c[i].u].f=1;
		c[c[i].v].f=1;
	}
	cin>>p;
	
	for(int i=1;i<p;i++)
	{
		cin>>t;
		int num=0;
		if(t==1)
		{
			cin>>a>>b;
			c[a].f=0;
			c[b].f=0;
			for(int j=1;j<=n;j++)
			{
				if(c[j].f==1)
					num++;
			}
			if(num==1) cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
		if(t==3)
		{
			cin>>a>>b;
			c[a].f=1;
			c[b].f=1;
			for(int j=1;j<=n;j++)
			{
				if(c[j].f==1)
					num++;
			}
			if(num==n) cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
		if(t==2){
			cout<<"NO"<<endl;
			cin>>d;
		}
		if(t==4){
			cin>>a>>b;
			cout<<"YES"<<endl;
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
