#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<algorithm>

using namespace std;

int n,m,q;
int l1,l2,r1,r2;
int a[100005],b[100005];
int c[10005][10005];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=m;i++)
		cin>>b[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			c[i][j]=a[i]*b[j];
		}
	while(q--)
	{
		int ans,a,b;
		cin>>l1>>r1>>l2>>r2;
		if(l1==r1||l2==r2)
		{
			if(l1==r1)
			{
				for(int i=l1;i<=r1;i++)
				for(int j=l2;j<=r2;j++)
				ans=min(ans,c[i][j]);
			}
			else
			{
				for(int i=l1;i<=r1;i++)
				for(int j=l2;j<=r2;j++)
				ans=max(ans,c[i][j]);
			}
			cout<<ans<<endl;
		}
		else
		{
			int f=1;
			for(int i=l1;i<=r1&&f==1;i++)
			{
				for(int j=l2;j<=r2;j++)
				{
					a=max(a,c[i][j]);
					b=min(b,c[i][j]);
					if(c[i][j]==0)
						f=0;
				}
			}
			if(f==0) cout<<0<<endl;
			else cout<<a*b<<endl;
		}
	}
	
	fclose(stdin);fclose(stdout);
	return 0;
}
/*3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/
