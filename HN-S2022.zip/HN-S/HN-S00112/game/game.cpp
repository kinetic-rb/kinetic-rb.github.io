#include<bits/stdc++.h>
using namespace std;
long long a[10005];
long long b[10005];
long long sb[10005][10005];
int main () {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n, m, k;
	scanf("%lld%lld%lld", &n, &m, &k);
	for (int i = 1; i <= n; i ++) scanf ("%lld", &a[i]);
	for (int i = 1; i <= m; i ++) scanf ("%lld", &b[i]);
//	for (int i = 1; i <= n ; i ++) {
//		for (int j = 1; j <= m; j ++) {
//			sb[i][j] = a[i] * b[j];
//		}
//	}
	for (int u = 1; u <= k; u ++) {
		int l1, r1, l2, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		if(l1 == r1) {
			long long minn = -1000000000000000000;
			for (int i = l2; i <= r2; i ++) {
				minn = min(minn, a[l1] * b[i]);
			}
			cout << minn << endl;
		}	
		else if(l2 == r2) {
			long long maxn = -1000000000000000000;
			for (int i = l1; i <= r1; i ++) {
				maxn = max(maxn, a[i] * b[l1]);
			}
			cout << maxn << endl;
		}	
		else {
			long long maxn = -1000000000000000000;
			for (int i = l1; i <= r1; i ++) {
				long long minn = 1000000000000000000;
				for (int j = l2; j <= r2; j ++) {
					minn = min(a[i] * b[j], minn);
				}
				maxn = max(minn, maxn); 
			}
			cout << maxn << endl;
		}
	}
	return 0;
}
