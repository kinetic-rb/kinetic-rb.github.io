#include<bits/stdc++.h>
using namespace std;
int bz[2505];
int lc[2505][2505];
int jl[2505]; 
bool bj[2505];
int sum, ans;
int js;
int n, m, k;
void deal(int x){
	if(x == 1&& sum == 4){
		js = ans;
		return ;
	} 
	if(sum > 4 )return ; 
	else {
		sum ++;
	//	cout << sum << endl;
		for (int i = 1; i <= jl[i]; i ++) {
			if (bj[lc[x][i]] == 0) {
				bj[lc[x][i]] = 1;
				ans += bz[lc[x][i]];
				deal(lc[x][i]);
				bj[lc[x][i]] = 0;
				ans -= bz[lc[x][i]];
			} 
		}
		sum --;
	}
}
int xbj;
int yuan;
int jjl[2505][2505];
void lj(int x) {
	xbj ++;
	//cout << xbj << endl;
	if(xbj > k) return ;
	for (int i = 1; i <= jl[x]; i ++) {
		if(yuan !=  lc[x][i]  && bj[lc[x][i]] == 0 && xbj + jjl[x][i] <= k) {
			jl[yuan] ++; 
			lc[yuan][jl[yuan]] = lc[x][i];
//			cout << lc[x][i]<< endl;
//			cout << jl[yuan] << endl;
			bj[lc[x][i]] = 1;
			xbj += jjl[x][i] + 1;
			jjl[yuan][jl[yuan]] = xbj;
			lj(lc[x][i]);
		}
	}
}
int main () {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n - 1; i ++) scanf ("%d", &bz[i]);
	for (int i = 1; i <= m; i ++) {
		int x, y;
		scanf("%d%d", &x, &y);
		jl[x] ++; 
		lc[x][jl[x]] = y;
		jl[y] ++;
		lc[y][jl[y]] = x;
	}
	bool jjjj = 1;
	if(k != 0) {
		jjjj = 0;
		for (int i = 1; i <= n ; i ++) {
			for (int j = 1; j <= jl[i]; j ++){
				xbj = 0;
				yuan = i;
				bj[i] = 1;
				bj[lc[i][j]] = 1;
				lj(lc[i][j]);
				bj[i] = 0;
				bj[lc[i][j]] = 0;
			}
		}
 } 
	int maxn = 0;
	for (int i = 2; i <= n ; i ++) {
		js =0;
		bj[i] = 1;
		deal(i);
		maxn = max(maxn, js);
		bj[i] = 0;
	}
	if(jjjj == 0) cout << maxn + 2;
	else cout << maxn;
	return 0;
}
