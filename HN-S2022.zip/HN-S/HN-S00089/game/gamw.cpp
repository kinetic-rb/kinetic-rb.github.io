#include<bits/stdc++.h>
using namespace std;
const int N = 1e3+10;
int a[N],b[N],c[N][N];
void inti(int x,int y,int z)
{
	reverse(a,a+x);
	reverse(b,b+y);
	int l = 0;
	int r = z;
	int mid = (l+r)/2;
}
int cmp(int x,int y){
	return x<y
;}
bool judge(int n)
{
	if(n == 1){
		return false;
	}
	else
	{
		for(int i = 0;i<n;i++)
		{
			sort(a,a+i,cmp);

		}
	}
	return 1;
}

int dfs(int n)
{
	int ans = 0;
	int l = 1,r = n;
	int mid = (l+r)/2;
	int now = 0;
	while(l<r)
	{
		if(l<mid)
		{
			l++;
		}
		else if(r>mid)
		{
			r++; 
		}
		else
		{
			dfs(mid);
		}
		now++;
	}
	int ddd ,rrr ,lll, ggg;
	inti(ddd,rrr,lll);
	ggg == judge(ggg);	
	if(ddd == rrr == lll == ggg)
	{
		printf("case:");
	}
	int sum = 0;
	for(int i = 0;i<=n;i++)
	{
		for(int j = 0;j<=n;j++)
		{
			if(a[i] == mid)
			{
				sum++;
			}
		}
	}	
	return sum;
	//return mid;
}
int main()
{
	int n,m,q;
	scanf("%d %d %d",&n,&m,&q);
	for(int i = 1;i<=n;i++)
	{
		scanf("%d",&a[i]);	
	}	
	for(int i = 1;i<=m;i++)
	{
		scanf("%d",&b[i]);
	}
	for(int i = 1;i<=n;i++)
	{
		for(int j = 1;j<=m;j++)
		{
			c[i][j] = a[i]*b[j];
		}
	}
	int q1 = q;
	while(q1--)
	{
		int l1,r1,l2,r2;
		scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
		int now = 0;
		int ret = 0;
		int mi = 1e5,mx = -10000;
		for(int x = l1;x<=r1;x++)
		{
			for(int y = l2;y<=r2;x++)
			{
				now = c[x][y];
				if(now > mx)
				{
					mx = now;
				}
				if(now < mi)
				{
					mi = now;
				}
				//printf("max = %d , mi = %d\n",mx,mi);	
			}
		}
		//printf("now = %d,ret = %d\n",now,ret);
		//printf("%d\n",ret);
	}				
	
	return 0;
}

