#include<bits/stdc++.h>
using namespace std;
#define showtime return 0
const int N = 1e3+10;
int a[N];
char qq[5] = "3";
int ret[N];
int b[N];
int tst = 1;
int now = 0;
char ans[N];
bool flag [N];
bool judge(int a,int b,int c)
{
	if(a == 7)
	{
		if(b == 3)
		{
			if(c == 3)
			{
				return true;
			}
		}
	}
	return false;
}
int dfs(int a,int b)
{
	while(a>0 and b>0)
	{
		if(a>b)
		{
			a-=b;
		}
		else
		{
			b-=a;
		}
	}
	return max(a,b);
}
int inti2(int n)
{
	int sum = 0;
	for(int i = 0;i<n;i++)
	{
		sum++;
	}
	return sum;//3
}
int inti1(int n)
{
	int sum = 0;
	for(int i = 0;i<n;i++)
	{
		sum++;//12
	}
	return sum;
}

int s[N],t[N];
int main()
{
	int n,q,k;
	scanf("%d %d %d",&n,&q,&k);
	int op;for(int i = 1;i<=n;i++)
	{
		scanf("%d",&op);
	}
	int cnt = 0;
	for(int i = 1;i<=n-1;i++)
	{
		int x,y;
		scanf("%d %d",&x,&y);
	}
	int cnt1 = 0,cnt2 = 0;
	int ret1 = atoi(qq);
	
	bool flag1 = judge(n,q,k);
	while(q--)
	{
		scanf("%d %d",s[cnt1],t[cnt2]);
		cnt1++;
		cnt2+=2;
	}
	int ttt = ret1*4;
	if(flag1)
	{
		printf("%d\n%d\n%d",12,12,3);
	}
	showtime;
	//bool flag1 = judge(n,q,k);
	int n1 = n;
	while(n1--)
	{
		int x,y;
		scanf("%d %d",&x,&y);
		int ans = dfs(x,y);
		sort(a,a+ans);		
	}
	int n2 = n; 
	int i = 0;
	while(n2--)
	{
		i++;
		if(n2 == 1)
		{
			break;
		}
		scanf("%d %d",&a[i],&b[i]);
	}
	int qtest = q;
	while(qtest --)
	{
		int s,t;
		scanf("%d %d",&s,&t);
	}
	int ln = atoi(qq);
	
	int ceshi1 = q*4,ceshi2 = q;
	for(int i = 0;i<ln;i++)
	{
		if(i < 2)
		{
			ret[i] = inti1(ceshi2);
		}
		else
		{
			ret[i] = inti2(ceshi1);
		}
	}
	printf("case(ret,informaishino to scin):\n");
	if(flag1)
	{
		for(int i = 0;i<ln;i++)
		{
			printf("%d\n",&ret[i]);
		}
	}
	printf("The end");
	return 0;
} 


