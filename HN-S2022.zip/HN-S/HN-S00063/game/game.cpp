#include<bits/stdc++.h>
using namespace std;
template<typename T>
void read(T &x){
	x=0;int f=1;char s=getchar();
	for(;s<'0'||s>'9';s=getchar())if(s=='-')f=-1;
	for(;s>='0'&&s<='9';s=getchar())x=x*10+s-'0';
	x*=f;
}
long long a[1005],b[1005],c[1005][1005],mi[1005][1005][12];
int n,m,q;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1;i<=n;++i)
		read(a[i]);
	
	for(int i=1;i<=m;++i)
		read(b[i]);
	
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			mi[i][j][0]=c[i][j]=a[i]*b[j];
	
	for(int i=1;i<=n;++i){
		for(int j=1;j<=10;++j){
			for(int k=1;k+(1<<j)-1<=m;++k)
				mi[i][k][j]=min(mi[i][k][j-1],mi[i][k+(1<<(j-1))][j-1]);
		}
	}
	
	while(q--){
		int l1,r1,l2,r2;
		read(l1),read(r1),read(l2),read(r2);
		long long ans=-1e18;
		for(int i=l1;i<=r1;++i){
			int k=log2(r2-l2+1);
			ans=max(ans,min(mi[i][l2][k],mi[i][r2-(1<<k)+1][k]));
		}
		printf("%lld\n",ans);
	}
	
	return 0;
}
