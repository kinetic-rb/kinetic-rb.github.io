#include<bits/stdc++.h>
using namespace std;
int n,m,k;
template<typename T>
void read(T &x){
	x=0;int f=1;char s=getchar();
	for(;s<'0'||s>'9';s=getchar())if(s=='-')f=-1;
	for(;s>='0'&&s<='9';s=getchar())x=x*10+s-'0';
	x*=f;
}
long long val[2505];
vector<int>e[2505],g[2505];
bool vis[2505],link[2505][2505];
void dfs(int u,int step,int st){
	if(step>k+1)return;
	link[st][u]=link[u][st]=1;
//	vis[u]=1;
	for(int v:e[u]){
		if(vis[v])continue;
		vis[v]=1;
		dfs(v,step+1,st);
	}
}
long long ans;
void dfs1(int u,int step,long long Val){
	if(step==4){
		if(!link[u][1])return;
		if(ans<Val)ans=Val;
		return;
	}
	for(int v:g[u]){
		if(vis[v])continue;
		vis[v]=1;
		dfs1(v,step+1,Val+val[v]);
		vis[v]=0;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=2;i<=n;++i)read(val[i]);
	for(int i=1;i<=m;++i){
		int u,v;
		read(u),read(v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	
	for(int i=1;i<=n;++i){
		memset(vis,0,sizeof(vis));
		vis[i]=true;
		dfs(i,0,i);
	}
	for(int i=1;i<=n;++i){
		for(int j=i+1;j<=n;++j){
			if(link[i][j]){
				g[i].push_back(j),g[j].push_back(i);
			}
		}
	}

	memset(vis,0,sizeof(vis));
	vis[1]=1;
	dfs1(1,0,0);
	
	cout<<ans<<endl;
	
	return 0;
}
