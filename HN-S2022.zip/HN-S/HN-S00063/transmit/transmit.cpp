#include<bits/stdc++.h>
using namespace std;
template<typename T>
void read(T &x){
	x=0;int f=1;char s=getchar();
	for(;s<'0'||s>'9';s=getchar())if(s=='-')f=-1;
	for(;s>='0'&&s<='9';s=getchar())x=x*10+s-'0';
	x*=f;
}
int n,Q,k;
int val[200005];
vector<int>e[200005];
int fa[200005][20],dep[200005],dis[200005];
void dfs(int u,int f){
	dep[u]=dep[f]+1;
	dis[u]=dis[f]+val[u];
	fa[u][0]=f;
	for(int v:e[u]){
		if(v==f)continue;
		dfs(v,u);
	}
}
int LCA(int x,int y){
	if(dep[x]>dep[y])swap(x,y);
	for(int j=18;~j;--j)if(fa[y][j]>=dep[x])y=fa[y][j];
	if(x==y)return x;
	for(int j=18;~j;--j)if(fa[x][j]!=fa[y][j])x=fa[x][j],y=fa[y][j];
	return fa[x][0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	read(n),read(Q),read(k);
	for(int i=1;i<=n;++i)read(val[i]);
	
	for(int i=1;i<n;++i){
		int u,v;
		read(u),read(v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	if(k==1){
		dis[1]=val[1];
		dfs(1,0);
		for(int j=1;j<=18;++j){
			for(int i=1;i<=n;++i)
				fa[i][j]=fa[fa[i][j-1]][j-1]; 
		}
		while(Q--){
			int x,y;
			read(x),read(y);
			int lca=LCA(x,y);
//			cout<<lca<<endl;
			printf("%d\n",dis[x]+dis[y]-dis[lca]*2+val[lca]);
		}
	}
	return 0;
} 
