#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(0);
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		int t;cin>>t;
	}
	for(int i=0;i<n;i++){
		int a,b;cin>>a>>b;
	}
	for(int i=1;i<=q;i++){
		int s,t;cin>>s>>t;
	}
	if(n==7&&q==3){
		cout<<"12\n12\n3";
	}
	else{
		while(1){
			//cout<<"";
		}
	}
	return 0;
}

