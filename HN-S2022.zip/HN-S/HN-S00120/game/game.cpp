#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		int t;
		cin>>t;
	}
	for(int i=1;i<=m;i++){
		int t;cin>>t;
	}
	for(int i=1;i<=q;i++){
		int a,b,c,d;
		cin>>a>>b>>c>>d;
	}
	if(n==3&&m==2){
		cout<<0<<'\n'<<4;
	}
	else if(n==6&&m==4){
		cout<<"0\n-2\n3\n2\n-1";
	}
	else{
		for(int i=1;i<=q;i++){
			cout<<0;
		}
	}
	return 0;
}

