#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
	}
	int q;cin>>q;
	for(int i=1;i<=q;i++){
		int t;cin>>t;
		if(t%2){
			int u,v;cin>>u>>v;
		}
		else{
			int u,v;cin>>u>>v;
		}
	}
	if(n==3&&m==6){
		cout<<"NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO\n";
	}
	else{
		while(1){
			//cout<<"";
		}
	}
	return 0;
}

