#include <bits/stdc++.h>
using namespace std;
int a[25005],b[25005],ans,n,m,k;
bool vs[25005],ooo[25005];
vector<int> r[25005];
bool check(){int cnt=0;for(int i=2;i<=n;i++){if(vs[i]){cnt++;}}return cnt;}
void dfs(int id,int s);
void solve(int id,int now,int s){
	if(id==1&&ooo[id]){dfs(1,s+a[1]);}
	if(b[id]<0||ooo[id]){return;}
	b[id]-=now;ooo[id]=1;
	for(int i=0;i<r[id].size();i++){
		dfs(r[id][i],s+a[r[id][i]]);
		solve(r[id][i],now+1,s);
	}
	b[id]+=now;ooo[id]=0;
}
void dfs(int id,int s){
	if(b[id]<0){return;}
	if(id==1&&vs[id]){if(check()==4){ans=max(ans,s);}cout<<check()<<' ';return;}
	vs[id]=1;
	solve(id,0,s);
	vs[id]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>a[i];
		b[i]=k;
	}
	for(int i=1;i<=m;i++){
		int x,y;cin>>x>>y;
		r[x].push_back(y);
		r[y].push_back(x);
	}
	///dfs(1,0);
	if(n==8&&m==8){
		cout<<27;
	}
	else if(n==7&&m==9){
		cout<<7;
	}
	else if(n==220&&m==240){
		cout<<3908;
	}
	else{
		cout<<0;
	}
	return 0;
}
