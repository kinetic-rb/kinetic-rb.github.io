#include<bits/stdc++.h>
using namespace std;
long long a[100001],b[100001];
long long suan(int s1,int e1,int s2,int e2){
	long long maxx=LONG_LONG_MAX*(-1);
	for(int i = s1-1;i<e1;i++){
		long long minn=LONG_LONG_MAX;
		for(int j = s2-1;j<e2;j++){
			minn=min(a[i]*b[j],minn);
		}
		maxx=max(maxx,minn);
	}
	return maxx;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i = 0;i<n;i++){
		cin>>a[i];
	}
	for(int i = 0;i<m;i++){
		cin>>b[i];
	}
	for(int i = 0;i<q;i++){
		int s1,e1,s2,e2;
		cin>>s1>>e1>>s2>>e2;
		cout<<suan(s1,e1,s2,e2)<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
