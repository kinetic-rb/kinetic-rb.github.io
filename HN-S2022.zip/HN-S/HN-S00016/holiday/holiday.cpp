#include<bits/stdc++.h>
using namespace std;
long long a[2502];
long long b[2502][2502];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	unsigned long long x=100;
	cin>>n>>m>>k;
	cout<<x;
	for(int i = 2;i<=n;i++){
		cin>>a[i];
	}
	a[0]=1;
	for(int i = 0;i<2502;i++){
		for(int j = 0;j<2502;j++){
			b[i][j]=1000;
		}
	}
	for(int i = 0;i<m;i++){
		int s,e;
		cin>>s>>e;
		b[s][e]=b[e][s]=1;
	}
	for(int k = 0;k<n;k++){
		for(int i = 0;i<n;i++){
			if(k==i){
				continue;
			}
			for(int j = 0;j<n;j++){
				if(i==j||k==j||b[i][j]==1){
					continue;
				}
				
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
