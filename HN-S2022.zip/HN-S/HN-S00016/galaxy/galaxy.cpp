#include<bits/stdc++.h>
using namespace std;
vector<vector<int> > chu;
vector<int> cun;
int aaa[1000000];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,cun1,cun2;
	cin>>n>>m;
	for(int i = 0;i<=n+1;i++){
		chu.push_back(cun);
		for(int j = 0;j<=n+1;j++){
			chu.at(i).push_back(0);
		} 
	}
	for(int i = 0;i<m;i++){
		cin>>cun1>>cun2;
		chu.at(cun2).at(cun1)=2;
	}
	int f,t;
	cin>>f;
	for(int i = 0;i<f;i++){
		cin>>t;
		if(t==1){
			int x,y;
			cin>>x>>y;
			chu[y][x]=1;
		}
		if(t==2){
			int x;
			cin>>x;
			int s=chu.at(x).size(); 
			for(int j = 0;j<s;j++){
				if(chu[x][j]==2){
					chu[x][j]=1;
				}
			}
		}
		if(t==3){
			int x,y;
			cin>>x>>y;
			chu[y][x]=2;
		}
		if(t==4){
			int x;
			cin>>x;
			int s=chu.at(x).size(); 
			for(int j = 0;j<s;j++){
				if(chu[x][j]==1){
					chu[x][j]=2;
				}
			}
		}
		int ji=0,pd=1;
		for(int k = 0;k<n;k++){
			int s=chu.at(k).size(); 
			for(int j = 0;j<s;j++){
				if(chu[k][j]==2){
					ji++;
					aaa[j]++;
					if(aaa[j]>1){
						pd=0;
					}
				}
			}
		}
		if(ji==n&&pd==1){
			cout<<"yes"<<endl;
		}
		else{
			cout<<"no"<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
