#include<bits/stdc++.h>
using namespace std;
long long n,m,q;
long long a[200010],b[200010],jl1[200010],jl2[200010];
long long xl,xq,minn,maxx,fw;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	if(n>=1100)
	{
		long long le1,le2,re1,re2;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
			jl1[i]=1e9;
		}
		for(int i=1;i<=m;i++)
		{
			cin>>b[i];
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				jl1[i]=min(jl1[i],a[i]*b[j]);
				jl2[j]=max(jl2[j],a[i]*b[j]);
			}
		}
		for(int i=1;i<=q;i++)
		{
			cin>>le1>>re1>>le2>>re2;
			if(le1==re1)
			{
				cout<<jl1<<endl;
				continue;
			}
			if(le2==re2)
			{
				cout<<jl2<<endl;
				continue;
			}
		}
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];
	}
	maxx=a[1]*b[1];
	minn=a[1]*b[1];
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			minn=min(a[i]*b[j],minn);
			maxx=max(a[i]*b[j],maxx);
		}
	}
	maxx=abs(maxx);
	minn=abs(minn);
	fw=max(maxx,minn);
	fw=fw+100;
	for(int i=1;i<=q;i++)
	{
		long long le1,le2,re1,re2;
		cin>>le1>>re1>>le2>>re2;
		long long minz=-fw,minf=-fw;
		for(int j=le1;j<=re1;j++)
		{
			long long pd=0;
			long long zhen=fw,fu=fw;
			for(int k=le2;k<=re2;k++)
			{
				if(a[j]*b[k]<0)
				{
					pd=1;
					fu=min(fu,a[j]*b[k]);
				}
				else
				{
					zhen=min(zhen,a[j]*b[k]);
				}
			}
			if(pd==0)
			{
				minz=max(zhen,minz);
			}
			else
			{
				minf=max(fu,minf);
			}
		}
		if(minz==-fw)
		{
			cout<<minf<<endl;
			continue;
		}
		if(minf==-fw)
		{
			cout<<minz<<endl;
			continue;
		}
		cout<<max(minz,minf)<<endl;
	}
	return 0;
}
