#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int fs[10010];
struct edge
{
	int to,next,zhi;
}e[200010];
int head[200010],aa;
void add(int u,int v,int w)
{
	e[++aa].to=v;
	e[aa].zhi=w;
	e[aa].next=head[u];
	head[u]=aa;
}
int ans,f[2510],vis[2510];
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n-1;i++)
	{
		cin>>fs[i];
	}
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		add(a,b,1);
	}
	sort(fs+1,fs+n+1);
	int cnt=0;
	for(int i=n;i>=1;i--)
	{
		if(cnt==4)
		{
			break;
		}
		ans+=fs[i];
		cnt++;
	}
	cout<<ans;
	return 0;
}
