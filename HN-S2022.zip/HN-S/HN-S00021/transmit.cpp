#include <bits/stdc++.h>
#define file_in(x) (freopen(#x".in", "r", stdin))
#define file_out(x) (freopen(#x".out", "w", stdout))
#define vi vector
#define pb push_back
#define int long long

using namespace std;

char _c; bool _f; template <class T> void IN(T &x) {
  _f = x = 0; while (_c = getchar(), !isdigit(_c)) {if (_c == '-') _f = 1;}
  while (isdigit(_c)) {x = x * 10 + _c - '0', _c = getchar();} if (_f) x = -x;
}

template <class T> void _write(T x) {
  if (x < 0) return putchar('-'), _write(-x);
  if (x > 9) _write(x / 10);
  putchar('0' + x % 10);
}
template <class T> void write_s(T x) {_write(x), putchar(' ');}
template <class T> void write(T x) {_write(x), putchar('\n');}
template <class first, class... rest>
void write(first fir, rest... res) {
  write_s(fir), write(res...);
}

#define debug(...) (_debug(#__VA_ARGS__, __VA_ARGS__))
template <class T> void _debug(const char *format, T x) {
  cerr << format << " = " << x << endl;
}
template <class first, class... rest>
void _debug(const char *format, first fir, rest... res) {
  while (*format != ',') cerr << *format++;
  cerr << " = " << fir << ',', _debug(format + 1, res...);
}

bool START;

const int kN = 2e5 + 5, inf = 3e14;

int n, q, k, a[kN], f[20][kN], dep[kN];
vi <int> G[kN];

struct node {
  int f[3][3], len;

  void init() {
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j)
	f[i][j] = inf;
    len = -1;
  }
} d1[20][kN], d2[20][kN];

bool END;

node mg(node w, node b) {
  if (w.len < 0) return b;
  if (b.len < 0) return w;
  node c; c.init();
  for (int x = 0; x < 3; ++x)
    for (int y = 0; y < 3; ++y)
      for (int i = 0; i < 3; ++i)
	for (int j = 0; j < 3; ++j)
	  if (i + j + 1 <= k)
	    c.f[x][y] = min(c.f[x][y], w.f[x][i] + b.f[j][y]);
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) {
      if (j + 1 + b.len < k)
	c.f[i][j + 1 + b.len] = min(c.f[i][j + 1 + b.len], w.f[i][j]);
      if (i + 1 + w.len < k)
	c.f[i + 1 + w.len][j] = min(c.f[i + 1 + w.len][j], b.f[i][j]);
    }
  c.len = w.len + b.len + 1;
  return c;
}

void add_e(int x, int y) {G[x].pb(y);}

int dfs2(int x, int fa, int dis) {
  if (dis < 0) return inf;
  if (!dis) return a[x];
  int res = inf;
  for (int i = 0; i < G[x].size(); ++i) {
    int to = G[x][i]; if (to == fa) continue;
    res = min(res, dfs2(to, x, dis - 1));
  } return res;
}

void dfs(int x, int fa) {
  for (int i = 0; i <= k; ++i)
    d1[0][x].f[i][i] = d2[0][x].f[i][i] = dfs2(x, 0, i);
  d1[0][x].len = d2[0][x].len = 0;
  f[0][x] = fa, dep[x] = dep[fa] + 1;
  for (int i = 1; (1 << i) <= n; ++i) f[i][x] = f[i - 1][f[i - 1][x]];
  for (int i = 1; (1 << i) <= n; ++i) d1[i][x] = mg(d1[i - 1][x], d1[i - 1][f[i - 1][x]]);
  for (int i = 1; (1 << i) <= n; ++i) d2[i][x] = mg(d2[i - 1][f[i - 1][x]], d2[i - 1][x]);
  for (int i = 0; i < G[x].size(); ++i) {
    int to = G[x][i]; if (to == fa) continue;
    dfs(to, x);
  }
}

int lca(int x, int y) {
  if (dep[x] < dep[y]) swap(x, y);
  for (int i = log2(n); i >= 0; --i) if (dep[x] - (1 << i) >= dep[y]) x = f[i][x];
  if (x == y) return x;
  for (int i = log2(n); i >= 0; --i) if (f[i][x] != f[i][y]) x = f[i][x], y = f[i][y];
  return f[0][x];
}

node ga(int x, int y, int lc) {
  node r1, r2; r1.init(), r2.init();
  for (int i = log2(n); i >= 0; --i)
    if (dep[x] - (1 << i) + 1 > dep[lc])
      r1 = mg(r1, d1[i][x]), x = f[i][x];
  for (int i = log2(n); i >= 0; --i)
    if (dep[y] - (1 << i) + 1 >= dep[lc]) {
      r2 = mg(d2[i][y], r2);
      y = f[i][y];
    }
  return mg(r1, r2);
}

signed main() {
  file_in(transmit), file_out(transmit);
  IN(n), IN(q), IN(k);
  for (int i = 1; i <= n; ++i) IN(a[i]);
  for (int i = 1; i < n; ++i) {
    int x, y; IN(x), IN(y), add_e(x, y), add_e(y, x);
  }
  for (int i = 0; (1 << i) <= n; ++i)
    for (int j = 0; j <= n; ++j)
      d1[i][j].init(), d2[i][j].init();
  dfs(1, 0);
  while (q--) {
    int x, y; IN(x), IN(y);
    int lc = lca(x, y);
    node res = ga(x, y, lc);
    write(res.f[0][0]);
  }
  return 0;
}
/*
7 1 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
 */
