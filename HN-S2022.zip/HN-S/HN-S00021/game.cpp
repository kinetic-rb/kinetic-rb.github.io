#include <bits/stdc++.h>
#define file_in(x) (freopen(#x".in", "r", stdin))
#define file_out(x) (freopen(#x".out", "w", stdout))
#define vi vector
#define pb push_back
#define int long long

using namespace std;

char _c; bool _f; template <class T> void IN(T &x) {
  _f = x = 0; while (_c = getchar(), !isdigit(_c)) {if (_c == '-') _f = 1;}
  while (isdigit(_c)) {x = x * 10 + _c - '0', _c = getchar();} if (_f) x = -x;
}

template <class T> void _write(T x) {
  if (x < 0) return putchar('-'), _write(-x);
  if (x > 9) _write(x / 10);
  putchar('0' + x % 10);
}
template <class T> void write_s(T x) {_write(x), putchar(' ');}
template <class T> void write(T x) {_write(x), putchar('\n');}
template <class first, class... rest>
void write(first fir, rest... res) {
  write_s(fir), write(res...);
}

#define debug(...) (_debug(#__VA_ARGS__, __VA_ARGS__))
template <class T> void _debug(const char *format, T x) {
  cerr << format << " = " << x << endl;
}
template <class first, class... rest>
void _debug(const char *format, first fir, rest... res) {
  while (*format != ',') cerr << *format++;
  cerr << " = " << fir << ',', _debug(format + 1, res...);
}

bool START;

const int kN = 1e5 + 5, inf = 1e18 + 5;

int n, m, q;

struct node {
  int n, a[kN], s1[20][kN], s2[20][kN], b1[20][kN], b2[20][kN], c[10], tot, p[kN], len;

  void ga(int l, int r) {
    int k = log2(r - l + 1);
    tot = 0;
    int t = max(s1[k][l], s1[k][r - (1 << k) + 1]);
    if (t > -inf && t < inf) c[++tot] = t;
    
    t = min(s2[k][l], s2[k][r - (1 << k) + 1]);
    if (t > -inf && t < inf) c[++tot] = t;
    
    t = max(b1[k][l], b1[k][r - (1 << k) + 1]);
    if (t > -inf && t < inf) c[++tot] = t;
    
    t = min(b2[k][l], b2[k][r - (1 << k) + 1]);
    if (t > -inf && t < inf) c[++tot] = t;
    
    if (len > 0 && p[len] >= l) {
      int ps = lower_bound(p + 1, p + 1 + len, l) - p;
      if (p[ps] <= r) c[++tot] = 0;
    }
  }

  void init() {
    len = 0;
    for (int i = 1; i <= n; ++i) {
      s1[0][i] = (a[i] > 0) ? a[i] : -inf;
      s2[0][i] = (a[i] > 0) ? a[i] : inf;
      b1[0][i] = (a[i] < 0) ? a[i] : -inf;
      b2[0][i] = (a[i] < 0) ? a[i] : inf;
      if (!a[i]) p[++len] = i;
    }
    for (int i = 1; (1 << i) <= n; ++i)
      for (int j = 1; j + (1 << i) - 1 <= n; ++j) {
	s1[i][j] = max(s1[i - 1][j], s1[i - 1][j + (1 << (i - 1))]);
	s2[i][j] = min(s2[i - 1][j], s2[i - 1][j + (1 << (i - 1))]);
	b1[i][j] = max(b1[i - 1][j], b1[i - 1][j + (1 << (i - 1))]);
	b2[i][j] = min(b2[i - 1][j], b2[i - 1][j + (1 << (i - 1))]);
      }
    
  }
  
} t1, t2;

bool END;

signed main() {
  file_in(game), file_out(game);
  IN(n), IN(m), IN(q);
  t1.n = n, t2.n = m;
  for (int i = 1; i <= n; ++i) IN(t1.a[i]);
  for (int i = 1; i <= m; ++i) IN(t2.a[i]);
  t1.init(), t2.init();
  while (q--) {
    int l1, r1, l2, r2; IN(l1), IN(r1), IN(l2), IN(r2);
    t1.ga(l1, r1), t2.ga(l2, r2);
    int ans = -inf;
    for (int i = 1; i <= t1.tot; ++i) {
      int res = inf;
      for (int j = 1; j <= t2.tot; ++j)
	res = min(res, t1.c[i] * t2.c[j]);
      ans = max(ans, res);
    }
    printf("%lld\n", ans);
  }
  return 0;
}
