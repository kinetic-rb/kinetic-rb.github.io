#include <bits/stdc++.h>
#define file_in(x) (freopen(#x".in", "r", stdin))
#define file_out(x) (freopen(#x".out", "w", stdout))
#define vi vector
#define pb push_back
#define __int128 long long
#define int long long

using namespace std;

char _c; bool _f; template <class T> void IN(T &x) {
  _f = x = 0; while (_c = getchar(), !isdigit(_c)) {if (_c == '-') _f = 1;}
  while (isdigit(_c)) {x = x * 10 + _c - '0', _c = getchar();} if (_f) x = -x;
}

template <class T> void _write(T x) {
  if (x < 0) return putchar('-'), _write(-x);
  if (x > 9) _write(x / 10);
  putchar('0' + x % 10);
}
template <class T> void write_s(T x) {_write(x), putchar(' ');}
template <class T> void write(T x) {_write(x), putchar('\n');}
template <class first, class... rest>
void write(first fir, rest... res) {
  write_s(fir), write(res...);
}

#define debug(...) (_debug(#__VA_ARGS__, __VA_ARGS__))
template <class T> void _debug(const char *format, T x) {
  cerr << format << " = " << x << endl;
}
template <class first, class... rest>
void _debug(const char *format, first fir, rest... res) {
  while (*format != ',') cerr << *format++;
  cerr << " = " << fir << ',', _debug(format + 1, res...);
}

bool START;

const int kN = 2505, kM = 1e4 + 5;
const __int128 inf = 4e18 + 5;

int n, m, k;
__int128 a[kN], d[kN][kN], b[kN], c[kN], t[kN], w[305][305], ans = -inf;
vi <int> G[kN];
bool v[kN];

bool END;

//__int128

void add_e(int x, int y) {G[x].pb(y);}

void bfs(int s) {
  queue <int> q; q.push(s);
  for (int i = 0; i <= n; ++i) v[i] = 0;
  v[s] = 1;
  while (!q.empty()) {
    int x = q.front(); q.pop();
    for (int i = 0; i < G[x].size(); ++i) {
      int to = G[x][i];
      if (!v[to]) d[s][to] = d[s][x] + 1, v[to] = 1, q.push(to);
    }
  }
}

void sol(int j) {
  for (int i = 1; i <= n; ++i) {
    if (i == j || d[i][j] > k) continue;
    for (int l = 1; l <= n; ++l) {
      if (l == i || l == j || d[i][l] > k || d[1][l] > k) continue;
      ans = max(ans, a[l] + a[i] + a[j] + w[i][l]);
    }
  }
}

signed main() {
  //  cerr << (&END - &START) / 1024.0 / 1024.0 << endl;
  file_in(holiday), file_out(holiday);
  IN(n), IN(m), IN(k), k++;
  for (int i = 2; i <= n; ++i) IN(a[i]);
  for (int i = 1; i <= m; ++i) {
    int x, y; IN(x), IN(y);
    add_e(x, y), add_e(y, x);
  }
  a[1] = -inf;
  for (int i = 1; i <= n; ++i) bfs(i);
  if (k == 1) {
    __int128 ans = -inf;
    for (int i = 1; i <= n; ++i) {
      for (int j = 0; j < G[i].size(); ++j) {
	int x = G[i][j];
	if (d[1][x] > 1) continue;
	for (int l = 0; l < G[i].size(); ++l) {
	  if (l == j) continue;
	  int y = G[i][l];
	  for (int p = 0; p < G[y].size(); ++p) {
	    int z = G[y][p]; if (z == y || z == i || z == x || d[1][z] > 1) continue;
	    ans = max(ans, a[i] + a[x] + a[y] + a[z]);
	  }
	}
      }
    }
    write(ans);
    return 0;
  }
  for (int i = 1; i <= n; ++i) {
    for (int l = 1; l <= n; ++l) {
      for (int j = 1; j <= n; ++j) {
	if (j == i || j == l || d[i][j] > k || d[1][j] > k) t[j] = -inf;
	else t[j] = a[j];
      }
      b[0] = -inf;
      for (int j = 1; j <= n; ++j) b[j] = max(b[j - 1], t[j]);
      c[n + 1] = -inf;
      for (int j = n; j > 0; --j) c[j] = max(c[j + 1], t[j]);
      for (int j = 1; j <= n; ++j) w[l][j] = max(b[j - 1], c[j + 1]);
    }
    sol(i);
  }
  write(ans);
  return 0;
}
