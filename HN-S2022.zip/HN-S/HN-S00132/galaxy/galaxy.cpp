#include<bits/stdc++.h>
using namespace std;
int n,m,q;
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(!('0'<=ch&&ch<='9')){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=rd(),m=rd();
	for(int i=1;i<=m;i++) 
		int x=rd(),y=rd();
	int q=rd();
	while(q--){
		puts("NO");
	}
	return 0;
}

