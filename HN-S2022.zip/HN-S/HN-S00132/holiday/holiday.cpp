#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k;
vector<int> edge[5005];
int a[5005];
int dis[5005][5005];
int dp[5][5005];
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(!('0'<=ch&&ch<='9')){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
queue<int>q;
inline void bfs(int big){
	q.push(big);
	while(q.size()){
		int x=q.front();q.pop();
		for(int i=0;i<edge[x].size();i++){
			int y=edge[x][i];
			if(dis[big][x]+1<dis[big][y]){
				dis[big][y]=dis[big][x]+1;
				q.push(y);
			}			
		}
	}
}
int ans;
int vis[50005];

void dfs(int x,int v,int w){
	if(v==4){
		if(dis[x][1]<=k){
			ans=max(w,ans);
		}
		return ;
	}
	for(int i=x+1;i<=n;i++){
		if(dis[x][i]>k||vis[i]) continue;
		vis[i]=1;
		dfs(i,v+1,w+a[i]);
		vis[i]=0; 
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=rd(),m=rd(),k=rd();
	for(int i=2;i<=n;i++){
		a[i]=rd();
	}
	for(int i=1;i<=m;i++){
		int x=rd(),y=rd();
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			dis[i][j]=k+1;
	for(int i=1;i<=n;i++) dis[i][i]=-1;
	for(int i=1;i<=n;i++) bfs(i);
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++) printf("%lld ",dis[i][j]);
//		puts("");
//	}
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/
