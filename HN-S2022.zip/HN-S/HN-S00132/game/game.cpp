#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,q;
int a[100005],b[100005];
int fa[2][100005][55],fb[2][100005][55];
int zheng[100005][55];
int fu[100005][55];
int ze[100005],ro[100005];
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(!('0'<=ch&&ch<='9')){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int finda(int opt,int l,int r){//cout<<l;
	int k=log2(r-l+1);
	//cout<<l<<" "<<k<<" "<<(r-(1<<k)+1)<<"\n";
	int jntm=fa[opt][l][k],jgby=fa[opt][r-(1<<k)+1][k];
	
	if(!opt) return max(jntm,jgby);
	else return min(jntm,jgby);
	return 114514;
}
int findb(int opt,int l,int r){
	int k=log2(r-l+1);
	int jntm=fb[opt][l][k],jgby=fb[opt][r-(1<<k)+1][k];
	if(!opt) return max(jntm,jgby);
	else return min(jntm,jgby);
	return 114514;
}
int findz(int l,int r){
	int k=log2(r-l+1);
	int jntm=zheng[l][k],jgby=zheng[r-(1<<k)+1][k];
	return min(jntm,jgby);
}
int findf(int l,int r){
	int k=log2(r-l+1);
	int jntm=fu[l][k],jgby=fu[r-(1<<k)+1][k];
	return min(jntm,jgby);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=rd(),m=rd(),q=rd();
	for(int i=1;i<=n;i++) a[i]=rd(),fa[1][i][0]=fa[0][i][0]=a[i];
	for(int i=1;i<=m;i++) b[i]=rd(),fb[1][i][0]=fb[0][i][0]=b[i];
	for(int i=1;i<=n;i++){
		if(a[i]>0)zheng[i][0]=a[i],fu[i][0]=1e9+1;
		else zheng[i][0]=1e9+1,fu[i][0]=-a[i];
		if(a[i]==0){
			ze[i]++;
		}
		ze[i]+=ze[i-1];
	}
	for(int i=1;i<=m;i++){
		ro[i]=ro[i-1];
		if(b[i]==0) ro[i]++;
	}
	for(int i=1;i<=25;i++){
		for(int j=1;j+(1<<i)-1<=n;j++){
		
			fa[0][j][i]=max(fa[0][j][i-1],fa[0][j+(1<<(i-1))][i-1]);
			fa[1][j][i]=min(fa[1][j][i-1],fa[1][j+(1<<(i-1))][i-1]);
		}
	}
	for(int i=1;i<=25;i++){
		for(int j=1;j+(1<<i)-1<=m;j++){
			fb[0][j][i]=max(fb[0][j][i-1],fb[0][j+(1<<(i-1))][i-1]);
			fb[1][j][i]=min(fb[1][j][i-1],fb[1][j+(1<<(i-1))][i-1]);
		}
	}
	for(int i=1;i<=25;i++){
		for(int j=1;j+(1<<i)-1<=n;j++){
			zheng[j][i]=min(zheng[j][i-1],zheng[j+(1<<(i-1))][i-1]);
			fu[j][i]=min(fu[j][i-1],fu[j+(1<<(i-1))][i-1]);
		}
	}
	while(q--){
		
		int fl=rd(),fr=rd(),kl=rd(),kr=rd();
		int jn=finda(0,fl,fr),tm=finda(1,fl,fr),jg=findb(0,kl,kr),by=findb(1,kl,kr);//cout<<1<<endl;
		int zs=findz(fl,fr),fs=findf(fl,fr);
		int ls;
		if(jg<0)
			if(tm<=0)
				ls=tm*jg;
			else
				ls=tm*by;
		else if(by<0)
			if(tm>0)
				ls=tm*by;
			else
				ls=max(zs*by,-1*fs*jg);
		else
			ls=jn*by;
		if(ls<0)
			if(ze[fr]-ze[fl-1]!=0) puts("0");
			else printf("%lld\n",ls);
		else
			if(ro[kr]-ro[kl-1]>0) puts("0");
			else printf("%lld\n",ls);
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/
