#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,k;
int a[100005];
int f[55][500005];
int dep[500005];
int hv[500005];
vector<int> edge[1000005];
int jntm[2005][2005];
int dis[2005][2005];
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(!('0'<=ch&&ch<='9')){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int x){
	for(int i=0;i<edge[x].size();i++){
		int y=edge[x][i];
		if(dep[y]) continue;
		dep[y]=dep[x]+1;
		hv[y]=hv[x]+a[y];
		f[0][y]=x;
		for(int j=1;j<=20;j++) f[j][y]=f[j-1][f[j-1][y]];
		dfs(y);
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=20;i>=0;i--){
		if(dep[f[i][x]]>=dep[y]) x=f[i][x];
	}
	if(x==y) return x;
	for(int i=20;i>=0;i--){
		if(f[i][x]!=f[i][y]) x=f[i][x],y=f[i][y];
	}
	return f[0][x];
}
void qwq(int x){
	for(int i=0;i<edge[x].size();i++){
		int y=edge[x][i];
		for(int j=0;j<edge[y].size();j++){
			int z=edge[y][j];
			jntm[x][z]=1;
			if(k==3){
				for(int p=0;p<edge[z].size();p++){
					jntm[x][edge[z][p]]=1;
				}
			}
		}
	}
}
int sum;
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=rd(),q=rd(),k=rd();
	for(int i=1;i<=n;i++) a[i]=rd(),sum+=a[i];
	
	if(k==1){
		for(int i=1;i<n;i++){
			int x=rd(),y=rd();
			edge[x].push_back(y);
			edge[y].push_back(x);
		}
		dep[1]=1;
		hv[1]=a[1];
		dfs(1);
//		for(int i=1;i<=n;i++)
//			for(int j=0;j<4;j++){
//				cout<<i<<" "<<j<<" "<<f[j][i]<<"\n";
//			}
		while(q--){
			int x=rd(),y=rd();
			int lc=lca(x,y);
		//	cout<<lc<<"\n";
			int ans=hv[x]+hv[y]-2*hv[lc]+a[lc];
			printf("%lld\n",ans);
		}
		return 0;
	}
	for(int i=1;i<n;i++){
		int x=rd(),y=rd();
		jntm[x][y]=1;
		jntm[y][x]=1;
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
		qwq(i);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(jntm[i][j]){
				dis[i][j]=a[i]+a[j];
			}
			else{
				dis[i][j]=sum+10;
			}
		}
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int p=1;p<=n;p++){
				dis[j][p]=min(dis[j][p],dis[j][i]+dis[i][p]-a[i]);
			}
	while(q--){
		int x=rd(),y=rd();
		printf("%lld\n",dis[x][y]);
	}
	return 0;
}
/*
6 1 1 
1 1 1 1 1 1 
1 2 
1 3
3 4
3 5
5 6
4 6
*/
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/

