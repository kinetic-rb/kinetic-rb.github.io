#include<bits/stdc++.h>
#define rd read()
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
long long a[100010],b[100010];
int n,m,q;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=rd,m=rd,q=rd;
	for(int i=1;i<=n;i++){
		a[i]=rd;
	}
	for(int i=1;i<=m;i++){
		b[i]=rd;
	}
	while(q--){
		int l1=rd,r1=rd,l2=rd,r2=rd,x;
		long long maxx=-9e18;
		for(int i=l1;i<=r1;i++){
			long long minn=9e18;
			for(int j=l2;j<=r2;j++){
				minn=min(minn,a[i]*b[j]);
			}
			if(minn>maxx){
				x=i;
				maxx=minn;
			}
		}
		long long ans=9e18;
		for(int j=l2;j<=r2;j++){
			ans=min(ans,(long long)a[x]*b[j]);
		}
		cout<<ans<<endl;
	}
	return 0;
}
