#include<bits/stdc++.h>
#define rd read()
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
struct edge{
	int to;
	int next;
}e[20010];
int head[2510],tot;
int w[2510],n,m,k,ans;
void add(int x,int y){
	tot++;
	e[tot].to=y;
	e[tot].next=head[x];
	head[x]=tot;
}
int dis[2510][2510];
bool vis[2510];
void dijkstra(int s){
	priority_queue<pair<int,int> >q;
	q.push(make_pair(0,s));
	memset(vis,0,sizeof(vis));
	memset(dis[s],0x3f,sizeof(dis[s]));
	dis[s][s]=0;
	while(!q.empty()){
		int x=q.top().second;
		q.pop();
		if(vis[x]){
			continue;
		}
		vis[x]=1;
		for(int i=head[x];i;i=e[i].next){
			int y=e[i].to;
			if(dis[s][y]>dis[s][x]+1){
				dis[s][y]=dis[s][x]+1;
				if(!vis[y]){
					q.push(make_pair(-dis[s][y],y));
				}
			}
		}
	}
}
bool viss[5010];
void dfs(int x,int val,int visit){
	if(visit==4&&dis[x][1]<=k+1){
		ans=max(ans,val);
		return;
	}
	for(int i=2;i<=n;i++){
		if(viss[i]||dis[x][i]>k+1){
			continue;
		}
		viss[i]=1;
		dfs(i,val+w[i],visit+1);
		viss[i]=0;
	}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=rd,m=rd,k=rd;
	memset(viss,0,sizeof(viss));
	viss[1]=1;
	for(int i=2;i<=n;i++){
		w[i]=rd;
	}
	for(register int i=1;i<=m;i++){
		int x=rd,y=rd;
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=n;i++){
		dijkstra(i);
	}
	dfs(1,0,0);
	cout<<ans;
	return 0;
}
