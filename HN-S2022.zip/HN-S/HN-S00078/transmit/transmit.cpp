#include<bits/stdc++.h>
#define rd read()
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
struct edge{
	int to;
	int next;
}e[400010];
int head[200010],tot;
void add(int x,int y){
	tot++;
	e[tot].to=y;
	e[tot].next=head[x];
	head[x]=tot;
}
int n,q,k,v[200010];
long long ans=1e18;
int dis[200010];
bool vis[200010];
void dijkstra(int s){
	priority_queue<pair<int,int> >q;
	q.push(make_pair(0,s));
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(dis));
	dis[s]=0;
	while(!q.empty()){
		int x=q.top().second;
		q.pop();
		if(vis[x]){
			continue;
		}
		vis[x]=1;
		for(int i=head[x];i;i=e[i].next){
			int y=e[i].to;
			if(dis[y]>dis[x]+1){
				dis[y]=dis[x]+1;
				if(!vis[y]){
					q.push(make_pair(-dis[y],y));
				}
			}
		}
	}
}
bool viss[200010];
int s,t;
void search(int x,long long need){
	need+=v[x];
	if(x==t||(need>=ans)){
		ans=min(ans,need);
		return;
	}
	dijkstra(x);
	for(int i=1;i<=n;i++){
		if(dis[i]<=k&&!viss[i]){
			viss[i]=1;
			search(i,need);
			viss[i]=0;
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=rd,q=rd,k=rd;
	for(int i=1;i<=n;i++){
		v[i]=rd;
	}
	for(int i=1;i<=n-1;i++){
		int x=rd,y=rd;
		add(x,y);
		add(y,x);
	}
	while(q--){
		s=rd,t=rd;
		ans=1e18;
		viss[s]=1;
		search(s,0);
		cout<<ans<<"\n";
	}
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

*/
