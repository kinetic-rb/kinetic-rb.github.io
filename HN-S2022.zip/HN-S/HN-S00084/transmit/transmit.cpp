#include<bits/stdc++.h>
#define inf 1e18
#define int long long
#define N 200005
#define file(x) freopen(x".in","r",stdin);freopen(x".out","w",stdout)
using namespace std;
int read(){
	int w=0,h=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')h=-h;ch=getchar();}
	while(ch>='0'&&ch<='9'){w=w*10+ch-'0';ch=getchar();}
	return w*h;
}
struct Edge{int next,to;}edge[N<<1];
int n,Q,K,T[N];
int head[N],num;vector<int>G[N];
void add(int u,int v){edge[++num]=(Edge){head[u],v};head[u]=num;}
void dfs(int u,int fa,int fr,int dis){
	if(dis<=K){if(u!=fr)G[fr].emplace_back(u);}else return;
	for(int i=head[u];i;i=edge[i].next){
		int v=edge[i].to;if(v==fa)continue;
		dfs(v,u,fr,dis+1);
	}
}
int dist[N];bool vis[N];
priority_queue<pair<int,int>>q;
signed main(){
	file("transmit");
	n=read();Q=read();K=read();
	for(int i=1;i<=n;i++)T[i]=read();
	for(int i=2;i<=n;i++){
		int u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<=n;i++)dfs(i,0,i,0);
	while(Q--){
		int x=read(),y=read();
		for(int i=1;i<=n;i++)dist[i]=inf,vis[i]=false;
		dist[x]=T[x];q.push(make_pair(-T[x],x));
		while(!q.empty()){
			int u=q.top().second;q.pop();
			if(vis[u])continue;vis[u]=true;
			for(auto v:G[u])
				if(dist[u]+T[v]<dist[v])
					dist[v]=dist[u]+T[v],q.push(make_pair(-dist[v],v));
		}
		printf("%lld\n",dist[y]);
	}
	return 0;
}
