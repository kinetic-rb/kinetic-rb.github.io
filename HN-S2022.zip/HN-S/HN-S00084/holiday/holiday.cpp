#include<bits/stdc++.h>
#define int long long
#define inf 5e18
#define N 2505
#define M 10005
#define file(x) freopen(x".in","r",stdin);freopen(x".out","w",stdout)
using namespace std;
int read(){
	int w=0,h=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')h=-h;ch=getchar();}
	while(ch>='0'&&ch<='9'){w=w*10+ch-'0';ch=getchar();}
	return w*h;
}
struct Edge{int next,to;}edge[M<<1];
int n,m,K,ans,W[N];
int head[N],num;
vector<int>G[N];
vector<pair<int,int>>to[N];
int dist[N][N];bool vis[N];
void add(int u,int v){edge[++num]=(Edge){head[u],v};head[u]=num;}
void bfs(int s){
	for(int i=1;i<=n;i++)vis[i]=false;
	queue<int>q;vis[s]=true;q.push(s);
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int i=head[u];i;i=edge[i].next){
			int v=edge[i].to;
			if(vis[v])continue;
			dist[s][v]=dist[s][u]+1;
			vis[v]=true;q.push(v);
		}
	}
}
signed main(){
	file("holiday");
	n=read();m=read();K=read()+1;W[1]=-inf;
	for(int i=2;i<=n;i++)W[i]=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<=n;i++){
		bfs(i);
		for(int j=1;j<=n;j++)
			if(dist[i][j]&&dist[i][j]<=K)G[i].emplace_back(j);
	}
	for(auto u:G[1])for(auto v:G[u])if(v!=1)to[v].emplace_back(make_pair(W[u]+W[v],u));
	for(int i=2;i<=n;i++)
		sort(to[i].begin(),to[i].end(),[&](pair<int,int>x,pair<int,int>y){return x.first>y.first;});
	for(int i=2;i<=n;i++)
		for(auto j:G[i]){
			auto iti=to[i].begin(),itj=to[j].begin();
			if(iti==to[i].end()||itj==to[j].end())continue;
			if((*iti).second==j)iti++;if((*itj).second==i)itj++;
			if(iti==to[i].end()||itj==to[j].end())continue;
			if((*iti).second!=(*itj).second)
				ans=max(ans,(*iti).first+(*itj).first);
			else{
				auto ti=iti,tj=itj;ti++;tj++;
				if(ti!=to[i].end())ans=max(ans,(*ti).first+(*itj).first);
				if(tj!=to[j].end())ans=max(ans,(*iti).first+(*tj).first);
			}
		}
	printf("%lld\n",ans);
	return 0;
}
