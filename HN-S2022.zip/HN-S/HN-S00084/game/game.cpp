#include<bits/stdc++.h>
#define int long long
#define inf 2000000000000000000
#define N 100005
#define file(x) freopen(x".in","r",stdin);freopen(x".out","w",stdout)
using namespace std;
int read(){
	int w=0,h=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')h=-h;ch=getchar();}
	while(ch>='0'&&ch<='9'){w=w*10+ch-'0';ch=getchar();}
	return w*h;
}
int n,m,q,a[N],b[N],sumz[N][2],sumf[N][2];
namespace SGT{
#define ls k<<1
#define rs k<<1|1
#define mid ((l+r)>>1)
	struct Data{int Maxf,Minz,Min,Max;}tr[N<<3];
	Data Pushup(Data lt,Data rt){return(Data){max(lt.Maxf,rt.Maxf),min(lt.Minz,rt.Minz),min(lt.Min,rt.Min),max(lt.Max,rt.Max)};}
	void Build(int k,int l,int r){
		if(l==r){
			if(a[l]<=0)tr[k].Maxf=a[l],tr[k].Minz=inf;
			else tr[k].Minz=a[l],tr[k].Maxf=-inf;
			tr[k].Min=tr[k].Max=a[r];return;
		}
		Build(ls,l,mid);Build(rs,mid+1,r);tr[k]=Pushup(tr[ls],tr[rs]);
	}
	Data Query(int k,int l,int r,int x,int y){
		if(l>=x&&r<=y)return tr[k];
		Data lt=(Data){-inf,inf,inf,-inf},rt=(Data){-inf,inf,inf,-inf};
		if(x<=mid)lt=Query(ls,l,mid,x,y);
		if(mid<y)rt=Query(rs,mid+1,r,x,y);
		return Pushup(lt,rt);
	}
}
using namespace SGT;
namespace Sparse_Table{
	int Min[N][20],Max[N][20],lg[N];
	void Build(){
		for(int i=2;i<=m;i++)lg[i]=lg[i>>1]+1;
		for(int i=1;i<=m;i++)Min[i][0]=Max[i][0]=b[i];
		for(int j=1;j<=18;j++)
			for(int i=1;i+(1<<j)-1<=m;i++){
				Min[i][j]=min(Min[i][j-1],Min[i+(1<<(j-1))][j-1]);
				Max[i][j]=max(Max[i][j-1],Max[i+(1<<(j-1))][j-1]);
			}
	}
	int AskMin(int l,int r){int k=lg[r-l+1];return min(Min[l][k],Min[r-(1<<k)+1][k]);}
	int AskMax(int l,int r){int k=lg[r-l+1];return max(Max[l][k],Max[r-(1<<k)+1][k]);}
}
using namespace Sparse_Table;
signed main(){
	file("game");
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)a[i]=read(),sumf[i][0]=sumf[i-1][0]+(a[i]<=0),sumz[i][0]=sumz[i-1][0]+(a[i]>0);
	for(int i=1;i<=m;i++)b[i]=read(),sumf[i][1]=sumf[i-1][1]+(b[i]<=0),sumz[i][1]=sumz[i-1][1]+(b[i]>0);
	Build(1,1,n);Build();
	for(int i=1;i<=q;i++){
		int la=read(),ra=read(),lb=read(),rb=read(),ans=-inf;
		Data res=Query(1,1,n,la,ra);
		if(sumf[rb][1]-sumf[lb-1][1]==0){
			if(sumz[ra][0]-sumz[la-1][0]==0)ans=max(ans,AskMax(lb,rb)*res.Max);
			else ans=max(ans,AskMin(lb,rb)*res.Max);
			if(res.Maxf!=-inf)ans=max(ans,AskMax(lb,rb)*res.Maxf);
		}
		else if(sumz[rb][1]-sumz[lb-1][1]==0){
			if(res.Minz!=inf)ans=max(ans,AskMin(lb,rb)*res.Minz);
			if(sumf[ra][0]-sumf[la-1][0]==0)ans=max(ans,AskMin(lb,rb)*res.Min);
			else ans=max(ans,AskMax(lb,rb)*res.Min);
		}
		else{
			if(res.Minz!=inf)ans=max(ans,res.Minz*AskMin(lb,rb));
			if(res.Maxf!=-inf)ans=max(ans,res.Maxf*AskMax(lb,rb));
		}
		printf("%lld\n",ans);
	}
	return 0;
}
