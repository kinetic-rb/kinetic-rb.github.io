#include<bits/stdc++.h>
#define N 500005
#define file(x) freopen(x".in","r",stdin);freopen(x".out","w",stdout)
using namespace std;
int read(){
	int w=0,h=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')h=-h;ch=getchar();}
	while(ch>='0'&&ch<='9'){w=w*10+ch-'0';ch=getchar();}
	return w*h;
}
int n,m,q,chk,in[N],out[N],ava[N],vis[N];
vector<pair<int,bool>>G[N];
void dfs(int u){
	vis[u]=true;if(vis[u]){chk=true;return;}
	for(auto v:G[u])if(v.second)dfs(v.first);
}
void tag(int u){
	if(ava[u])return;ava[u]=true;
	for(auto v:G[u])if(v.second)tag(v.first);
}
signed main(){
	file("galaxy");
	n=read();m=read();
	for(int i=1,u,v;i<=m;i++)
		u=read(),v=read(),G[v].emplace_back(make_pair(u,true)),in[v]++,out[u]++;
	q=read();
	while(q--){
		int opt=read(),x=read(),y,flg=true;
		if(opt==1||opt==3)y=read();
		if(opt==1){
			out[x]--;in[y]--;
			for(auto&u:G[y])if(u.first==x)u.second=false;
		}
		if(opt==3){
			out[x]++;in[y]++;
			for(auto&u:G[y])if(u.first==x)u.second=true;
		}
		if(opt==2)
			for(auto&u:G[x])
				if(u.second)out[u.first]--,in[x]--,u.second=false;
		if(opt==4)
			for(auto&u:G[x])
				if(!u.second)out[u.first]++,in[x]++,u.second=true;
		for(int i=1;i<=n;i++)ava[i]=vis[i]=false;
		for(int i=1;i<=n;i++){
			if(!in[i])continue;
			if(out[i]>1){flg=false;break;}
			if(ava[i])continue;chk=false;
			dfs(i);if(chk)tag(i);
		}
		if(flg)for(int i=1;i<=n;i++)if(!in[i]&&!ava[i]){flg=false;break;}
		puts(flg?"YES":"NO");
	}
	return 0;
}
