//I love CCF forever.
#include<bits/stdc++.h>
#define INF 0x3f3f3f
using namespace std;
const int N=5005,M=1e8+5;
int n,m,k;
int v[N],v2[M];
bool g[N][N];
bool vis[N];
queue<int> q;
void add(int a,int b){
	g[a][b]=g[b][a]=true;
}
bool bfs(int a,int b,int t){
	int temp[N],popt=0;
	memset(temp,0,sizeof(temp));
	int p=0;
	q.push(a);
	while(!q.empty()){
		if(popt==temp[p]){
			t++;
			p++;
		}
		if(t>k){
			return false;
		}
		if(q.front()==b){
			return true;
		}
		for(int i=1;i<=n;i++){
			if(g[q.front()][i]){
				q.push(i);
				temp[p]++;
			}
		}
		popt++;
		q.pop();
	}
}
bool cmp(int a,int b){
	return a>b;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(g,0,sizeof(g));
	memset(vis,false,sizeof(vis));
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>v[i];
		v2[v[i]]=i;
	}for(int i=0;i<m;i++){
		int a,b;
		cin>>a>>b;
		add(a,b);	
	}
	sort(v+2,v+n+1,cmp);
	int I=n-1;
	int anss=-99;
	while(I--){
		int ans=0;
		int c=0;
		int kkk=1;
		for(int i=2;i<=n;i++){
			if(c==4) break;
			if(bfs(kkk,v2[v[i]],0)&&(!(vis[v2[v[i]]]))){
				kkk=v2[v[i]];
				ans+=v[i];
				vis[v2[v[i]]]=true;
				c++;
			}
		}
		anss=max(ans,anss);
	} 
	cout<<anss;
	return 0;
}
//Wake up
