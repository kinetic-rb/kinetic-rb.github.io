#include<bits/stdc++.h>
using namespace std;
int n, m, k;
long long a[5000];
int b[5000][5000], ss[5000];
int head=1,tail=1;
struct node
{
	int x, s, s1;
	long long sum;
} t[20000];
bool vis[5000];
long long sum1;
int dfs(int xx,int yy)
{
	if(t[xx].x==1&&t[xx].s==5) 
	{
		sum1=max(sum1,t[xx].sum);
		vis[t[xx].x]=0;
		return 0;
	}
	for(int i=1;i<=ss[t[xx].x];i++)
	{
		if((vis[b[t[xx].x][i]]==1||b[t[xx].x][i]==1)&&t[xx].s1<k)
		{
			t[xx+1].x=b[t[xx].x][i];
			t[xx+1].s=t[xx].s;
			t[xx+1].s1=t[xx].s1+1;
			t[xx+1].sum=t[xx].sum;
			dfs(xx+1,1);
		}
		else if(vis[b[t[xx].x][i]]==0)
		{
			t[xx+1].x=b[t[xx].x][i];
			t[xx+1].s=t[xx].s+1;
			vis[b[t[xx].x][i]]=1;
			t[xx+1].sum=t[xx].sum+a[b[t[xx].x][i]];
			dfs(xx+1,0);
		}
	}
	if(yy==0) 
		vis[t[xx].x]=0;
	return 0;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++)
	{
		int x, y;
		cin>>x>>y;
		ss[x]++;
		ss[y]++;
		b[x][ss[x]]=y;
		b[y][ss[y]]=x;
	}
	t[1].x=1;
	dfs(1,0);
	cout<<sum1;
	return 0;
}
