#include<bits/stdc++.h>
using namespace std;
int n, m, q;
long long a[600000], b[600000];
int la, ra, lb, rb;
bool c, d;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	srand(time(0));
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) 
	{
		cin>>a[i];
		if(a[i]<0) c=1;
	}
	for(int i=1;i<=m;i++) 
	{
		cin>>b[i];
		if(b[i]<0) d=1;
	}
	if(c==0&&d==0)
	{
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d%d%d",&la,&ra,&lb,&rb);
			int maxn=-1e9, minn=-1e9;
			int maxni, minni;
			for(int j=la;j<=ra;j++)
				if(a[j]>maxn)
					maxn=a[j], maxni=j;
			for(int j=lb;j<=rb;j++)
				if(b[j]<minn)
					minn=b[j], minni=j;
			cout<<a[maxni]*b[minni]<<endl;	
		}
		return 0;
	}
	int nowa_i, nowb_i, besta_i, bestb_i;
	for(int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&la,&ra,&lb,&rb);
		int nowa_ans, nowb_ans, besta_ans=-1e9, bestb_ans=1e9;
		double t=300000, st_t=clock();
		while(t>0.0000001&&double(clock()-st_t)/CLOCKS_PER_SEC<=0.7/q)
		{
			nowa_i=la+rand()%(ra-la+1);
			nowb_i=lb+rand()%(rb-lb+1);
			nowa_ans=nowb_ans=a[nowa_i]*b[nowb_i];
			if(nowa_ans>besta_ans)
				besta_ans=nowa_ans, besta_i=nowa_i;
			if(nowb_ans<bestb_ans)
				bestb_ans=nowb_ans, bestb_i=nowb_i;
			t*=0.99;
		}
		cout<<a[besta_i]*b[bestb_i]<<endl;
	}
	return 0;
}
