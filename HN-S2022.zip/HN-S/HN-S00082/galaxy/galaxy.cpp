#include<bits/stdc++.h>
using namespace std;
int main(){ 
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>>n>>m;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
