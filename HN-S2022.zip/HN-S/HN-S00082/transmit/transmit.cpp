#include<bits/stdc++.h>
using namespace std;
int main(){ 
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	cin>>n>>q>>k;
	int v[n+1]={};
	for(int i=0;i<n;i++){
		cin>>v[i];
	}
	int a[n]={},b[n]={};
	for(int i=0;i<n-1;i++){
		cin>>a[i]>>b[i];
	}
	int s[q+1]={},t[q+1]={};
	for(int i=0;i<q;i++){
		cin>>s[i]>>t[i];
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
