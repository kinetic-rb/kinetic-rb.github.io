#include<bits/stdc++.h>
using namespace std;
int main(){ 
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>m>>q;
	int A[n+1]={},B[m+1]={};
	for(int i=0;i<n;i++){
		cin>>A[i];
	} 
	for(int i=0;i<m;i++){
		cin>>B[i];
	}
	int l1[q+1]={},r1[q+1]={},l2[q+1]={},r2[q+1]={};
	for(int i=0;i<q;i++){
		cin>>l1[i]>>r1[i]>>l2[i]>>r2[i];
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
