#include<bits/stdc++.h>
using namespace std;
int main(){ 
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	int a[n]={};
	for(int i=0;i<n-1;i++){
		cin>>a[i];
	}
	int x[m+1]={},y[m+1]={};
	for(int i=0;i<m;i++){
		cin>>x[i]>>y[i];
	}
	cout<<1<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
