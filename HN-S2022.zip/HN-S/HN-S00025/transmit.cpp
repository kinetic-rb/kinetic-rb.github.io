#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 200010
struct edge{
    int ne,to;
}a[N*2];
int n,Q,k,num,head[N],vl[N],S[N],T[N];
inline int rd(){
    int s=0;char ch=getchar();bool f=0;
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
    while(ch>='0'&&ch<='9') s=(s<<3)+(s<<1)+(ch^48),ch=getchar();
    return f?-s:s;
}
inline void add(int u,int v){
    a[++num]=(edge){head[u],v};
    head[u]=num;
}
namespace bl{
    priority_queue<pair<ll,int> > q;
    int ds[210][210];
    ll dis[210];
    bool vis[210];
    inline void dfs(int st,int u,int fa){
        for(int v,i=head[u];i;i=a[i].ne){
            v=a[i].to;if(v==fa) continue;
            ds[st][v]=ds[st][u]+1,dfs(st,v,u);
        }
    }
    inline void qwq(int u,int mb){
        for(int i=1;i<=n;i++) dis[i]=2e18,vis[i]=0;
        dis[u]=vl[u],q.push(make_pair(-vl[u],u));
        while(!q.empty()){
            u=q.top().second;q.pop();
            if(vis[u]) continue;vis[u]=1;
            for(int v=1;v<=n;v++)
                if(u!=v&&ds[u][v]<=k&&dis[v]>dis[u]+vl[v]){
                    dis[v]=dis[u]+vl[v];
                    q.push(make_pair(-dis[v],v));
                }
        }
        printf("%lld\n",dis[mb]);
    }
    inline void solve(){
        for(int i=1;i<=n;i++) dfs(i,i,0);
        for(int i=1;i<=Q;i++) qwq(S[i],T[i]);
        exit(0);
    }
}
namespace k1{
    int f[N][20],dep[N];
    ll dis[N];
    inline void dfs(int u,int fa){
        f[u][0]=fa,dep[u]=dep[fa]+1,dis[u]=dis[fa]+vl[u];
        for(int i=1;i<20;i++)
            f[u][i]=f[f[u][i-1]][i-1];
        for(int v,i=head[u];i;i=a[i].ne){
            v=a[i].to;if(v==fa) continue;
            dfs(v,u);
        }
    }
    inline int lca(int u,int v){
        if(dep[u]<dep[v]) swap(u,v);
        for(int i=19;i>=0;i--) if(dep[f[u][i]]>=dep[v]) u=f[u][i];
        if(u==v) return u;
        for(int i=19;i>=0;i--) if(f[u][i]!=f[v][i]) u=f[u][i],v=f[v][i];
        return f[u][0];
    }
    inline void solve(){
        dfs(1,0);
        for(int i=1;i<=Q;i++){
            int lcaa=lca(S[i],T[i]);
            printf("%lld\n",dis[S[i]]+dis[T[i]]-2*dis[lcaa]+vl[lcaa]);
        }
        exit(0);
    }
}
namespace k2{
    bool vis[N];
    ll ans[N],f[N],g[N];
    int col[N],rt,siz,sz[N],dl[N],tp,du,emm[N];
    vector<int> xw[N],zcq;
    inline void dfs(int u,int fa){
        sz[u]=1,f[u]=2e18,dl[++tp]=u;
        for(int v,i=head[u];i;i=a[i].ne){
            v=a[i].to;if(v==fa||vis[v]) continue;
            dfs(v,u),sz[u]+=sz[v];
        }
    }
    inline void find_rt(int u,int fa){
        int mx=siz-sz[u];
        for(int v,i=head[u];i;i=a[i].ne){
            v=a[i].to;if(v==fa||vis[v]) continue;
            find_rt(v,u),mx=max(mx,sz[v]);
        }
        if(mx*2<=siz) rt=u;
    }
    inline void pre(int u,int fa,int cl){
        if(cl) col[u]=cl;
        for(int v,i=head[u];i;i=a[i].ne){
            v=a[i].to;if(v==fa||vis[v]) continue;
            if(fa) f[v]=min(f[u],f[fa])+vl[v];
            else f[v]=f[u]+vl[v];
            pre(v,u,cl);
        }
    }
    inline void dfz(int u){
        if(!xw[u].size()) return ;
        tp=0,dfs(u,0),siz=sz[u],find_rt(u,0),vis[rt]=1,du=0;
        //cout<<u<<':'<<rt<<"!!!"<<endl;
        for(int v,i=head[rt];i;i=a[i].ne){
            v=a[i].to;if(vis[v]) continue;
            f[v]=vl[v],pre(v,rt,v);
        }
        for(int i=1;i<=tp;i++) g[dl[i]]=f[dl[i]],f[dl[i]]=2e18;
        f[rt]=vl[rt],pre(rt,0,0),col[rt]=rt;
        zcq=xw[u],xw[u].clear();
        for(int id:zcq){
            //cout<<id<<':'<<col[S[id]]<<','<<col[T[id]]<<endl;
            if(col[S[id]]==col[T[id]]) xw[col[S[id]]].push_back(id);
            else ans[id]=min(f[S[id]]+f[T[id]]-vl[rt],g[S[id]]+g[T[id]]);
        }
        for(int v,i=head[rt];i;i=a[i].ne){
            v=a[i].to;if(vis[v]) continue;
            dfz(v);
        }
    }
    inline void solve(){
        for(int i=1;i<=Q;i++) xw[1].push_back(i);
        dfz(1);
        for(int i=1;i<=Q;i++) printf("%lld\n",ans[i]);
        exit(0);
    }
}
int main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    n=rd(),Q=rd(),k=rd();
    for(int i=1;i<=n;i++) vl[i]=rd();
    for(int u,v,i=1;i<n;i++) u=rd(),v=rd(),add(u,v),add(v,u);
    for(int i=1;i<=Q;i++) S[i]=rd(),T[i]=rd();
    if(k==1) k1::solve();
    if(k==2) k2::solve();
    if(n<=200&&Q<=200) bl::solve();
    return 0;
}