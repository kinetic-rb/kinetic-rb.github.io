#include<bits/stdc++.h>
using namespace std;
#define N 100010
#define ll long long
int n,m,q,a[N],b[N],lg[N],q1[3][N],q2[3][N],l1,r1,l2,r2;
ll ans,res;
inline int rd(){
    int s=0;char ch=getchar();bool f=0;
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
    while(ch>='0'&&ch<='9') s=(s<<3)+(s<<1)+(ch^48),ch=getchar();
    return f?-s:s;
}
struct st{
    int f[20][N];
    inline int ask(int l,int r){
        int t=lg[r-l+1];
        return max(f[t][l],f[t][r-(1<<t)+1]);
    }
    inline void init(int mx){
        for(int j=1;(1<<j)<=mx;j++)
            for(int i=1;i+(1<<j)-1<=mx;i++)
                f[j][i]=max(f[j-1][i],f[j-1][i+(1<<(j-1))]);
    }
}T1[4],T2[4];
inline bool cza(int tp){return q1[tp][r1]!=q1[tp][l1-1];}
inline bool czb(int tp){return q2[tp][r2]!=q2[tp][l2-1];}
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=rd(),m=rd(),q=rd();
    lg[0]=-1;for(int i=1;i<=max(n,m);i++) lg[i]=lg[i/2]+1;
    for(int i=1;i<=n;i++) a[i]=rd();
    for(int i=1;i<=m;i++) b[i]=rd();
    for(int i=1;i<=n;i++){
        for(int j=0;j<4;j++) T1[j].f[0][i]=-0x3f3f3f3f;
        if(a[i]>0) T1[0].f[0][i]=a[i],T1[1].f[0][i]=-a[i];
        else if(a[i]<0) T1[2].f[0][i]=a[i],T1[3].f[0][i]=-a[i];
    }
    for(int i=1;i<=m;i++){
        for(int j=0;j<4;j++) T2[j].f[0][i]=-0x3f3f3f3f;
        if(b[i]>0) T2[0].f[0][i]=b[i],T2[1].f[0][i]=-b[i];
        else if(b[i]<0) T2[2].f[0][i]=b[i],T2[3].f[0][i]=-b[i];
    }
    for(int i=0;i<4;i++) T1[i].init(n),T2[i].init(m);
    for(int i=1;i<=n;i++){
        if(a[i]>0) q1[0][i]=1;
        else if(a[i]==0) q1[1][i]=1;
        else q1[2][i]=1;
    }
    for(int i=1;i<=m;i++){
        if(b[i]>0) q2[0][i]=1;
        else if(b[i]==0) q2[1][i]=1;
        else q2[2][i]=1;
    }
    for(int i=1;i<=n;i++)
        for(int j=0;j<3;j++)
            q1[j][i]+=q1[j][i-1],q2[j][i]+=q2[j][i-1];
    while(q--){
        l1=rd(),r1=rd(),l2=rd(),r2=rd();
        ans=-2e18;
        for(int i=0;i<4;i++){
            if(i<2&&!cza(0)) continue;
            if(i>=2&&!cza(2)) continue;
            ll v1=T1[i].ask(l1,r1);
            if(i&1) v1*=-1;
            res=2e18;
            for(int j=0;j<4;j++){
                if(j<2&&!czb(0)) continue;
                if(j>=2&&!czb(2)) continue;
                ll v2=T2[j].ask(l2,r2);
                if(j&1) v2*=-1;
                //cout<<i<<','<<j<<':'<<v1<<','<<v2<<endl;
                res=min(res,v1*v2);
            }
            ans=max(ans,res);
        }
        if(ans<0&&cza(1)) ans=0;
        if(ans>0&&czb(1)) ans=0;
        printf("%lld\n",ans);
    }
    return 0;
}