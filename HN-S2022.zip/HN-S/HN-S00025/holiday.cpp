#include<bits/stdc++.h>
using namespace std;
#define N 2510
#define ll long long
struct edge{
    int ne,to;
}G[20010];
int n,m,k,num,head[N],ds[N][N];
ll a[N],ans;
inline ll rd(){
    ll s=0;char ch=getchar();bool f=0;
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
    while(ch>='0'&&ch<='9') s=(s<<3)+(s<<1)+(ch^48),ch=getchar();
    return f?-s:s;
}
inline void add(int u,int v){
    G[++num]=(edge){head[u],v};
    head[u]=num;
}
queue<int> q;
inline void bfs(int st){
    q.push(st),ds[st][st]=0;
    while(!q.empty()){
        int u=q.front();q.pop();
        for(int v,i=head[u];i;i=G[i].ne){
            v=G[i].to;if(ds[st][v]!=0x3f3f3f3f) continue;
            ds[st][v]=ds[st][u]+1,q.push(v);
        }
    }
}
struct node{
    int xl[3];
    inline void gx(int x){
        if(a[x]>=a[xl[0]]) xl[2]=xl[1],xl[1]=xl[0],xl[0]=x;
        else if(a[x]>=a[xl[1]]) xl[2]=xl[1],xl[1]=x;
        else if(a[x]>a[xl[2]]) xl[2]=x;
    }
}f[N];
inline void upd(int A,int B,int C,int D){
    //cout<<A<<','<<B<<','<<C<<','<<D<<endl;
    if(!A||!D) return ;
    //if(A==B||A==C||A==D||B==C||B==D||C==D) puts("???"),exit(0);
    ans=max(ans,a[A]+a[B]+a[C]+a[D]);
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    n=rd(),m=rd(),k=rd(),a[0]=-1;
    for(int i=2;i<=n;i++) a[i]=rd();
    for(int u,v,i=1;i<=m;i++) u=rd(),v=rd(),add(u,v),add(v,u);
    memset(ds,0x3f3f3f3f,sizeof ds);
    for(int i=1;i<=n;i++) bfs(i);
    for(int x=2;x<=n;x++){
        if(ds[1][x]>k+1) continue;
        for(int y=2;y<=n;y++){
            if(x==y||ds[x][y]>k+1) continue;
            f[y].gx(x);
        }
    }
    for(int j1,B=2;B<=n;B++)
        for(int j2,C=2;C<=n;C++){
            if(B==C||ds[B][C]>k+1) continue;
            j1=0,j2=0;
            if(f[B].xl[0]==C) j1=1;
            if(f[C].xl[0]==B) j2=1;
            if(f[B].xl[j1]==f[C].xl[j2]){
                if(f[C].xl[j2+1]==B) upd(f[B].xl[j1],B,C,f[C].xl[j2+2]);
                else upd(f[B].xl[j1],B,C,f[C].xl[j2+1]);
                if(f[B].xl[j1+1]==C) upd(f[B].xl[j1+2],B,C,f[C].xl[j2]);
                else upd(f[B].xl[j1+1],B,C,f[C].xl[j2]);
            }
            else upd(f[B].xl[j1],B,C,f[C].xl[j2]);
        }
    printf("%lld\n",ans);
    return 0;
}