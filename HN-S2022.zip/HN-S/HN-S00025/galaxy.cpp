#include<bits/stdc++.h>
using namespace std;
#define N 500010
#define ll long long
int n,m,q,U[N],V[N];
bool vis[N];
unordered_map<ll,int> qaq;
inline int rd(){
    int s=0;char ch=getchar();bool f=0;
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
    while(ch>='0'&&ch<='9') s=(s<<3)+(s<<1)+(ch^48),ch=getchar();
    return f?-s:s;
}
namespace bl{
    int cnt[N];
    inline void solve(){
        for(int i=1;i<=m;i++) vis[i]=1,cnt[U[i]]++;
        while(q--){
            int t=rd(),u=rd(),v,id;
            if(t==1){
                v=rd(),id=qaq[1ll*u*n+v];
                vis[id]=0,cnt[U[id]]--;
            }
            else if(t==2){
                for(int j=1;j<=m;j++) if(vis[j]&&V[j]==u) vis[j]=0,cnt[U[j]]--;
            }
            else if(t==3){
                v=rd(),id=qaq[1ll*u*n+v];
                vis[id]=1,cnt[U[id]]++;
            }
            else{
                for(int j=1;j<=m;j++) if(!vis[j]&&V[j]==u) vis[j]=1,cnt[U[j]]++;
            }
            bool flg=1;
            for(int j=1;flg&&j<=n;j++) if(cnt[j]!=1) flg=0;
            puts(flg?"YES":"NO");
        }
        exit(0);
    }
}
/*namespace sub{
    inline void solve(){
        for(int i=1;i<=q;i++){
            int t=rd(),u=rd(),v,id;
            if(t==1) v=rd(),id=qaq[1ll*u*n+v],vis[id]=0;
            else if(t==2){for(int j=1;j<=m;j++) if(vis[j]&&V[j]==u) vis[j]=0;}
            else if(t==3) v=rd(),id=qaq[1ll*u*n+v],vis[id]=1;
            else return ;
        }

        exit(0);
    }
}*/
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    n=rd(),m=rd();
    for(int i=1;i<=m;i++) U[i]=rd(),V[i]=rd(),qaq[1ll*U[i]*n+V[i]]=i;
    q=rd();
    if(n<=1000&&m<=10000&&q<=1000) bl::solve();
    //sub::solve();
    return 0;
}