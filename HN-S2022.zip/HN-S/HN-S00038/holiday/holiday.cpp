#include<bits/stdc++.h>
using namespace std;
const int N = 2505;
struct node {
	long long num, id;
} a[N];
long long n, m, k;
bool dis[N][N];
long long mp[N], ans;
bool vis[N];
inline long long read() {
	long long x = 0;
	bool flag = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = 1;
			ch = getchar();
		}
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + ch - '0';
		ch = getchar();
	}
	if(!flag) {
		return x;
	} else {
		return ~(x - 1);
	}
}
inline void write(long long x) {
	if(x < 0) {
		x = ~(x - 1);
		putchar('-');
	}
	if(x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
inline bool cmp(node x, node y) {
	return x.num > y.num;
}
inline void dfs(int x, int cnt, long long sum) {
	if(cnt == 4) {
		ans = sum;
		return ;
	}
	int i = x + 1;
	for(; i <= n && vis[i] && !dis[x][i]; i++) {
	}
	vis[i] = 1;
	dfs(i, cnt + 1, sum + a[i].num);
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n = read(), m = read(), k = read();
	a[1] = {0, 1};
	for(int i = 2; i <= n; i++) {
		a[i].num = read();
		a[i].id = i;
	}
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1; i <= n; i++) {
		mp[a[i].id] = i;
	}
	while(m--) {
		int x = read(), y = read();
		dis[x][y] = 1;
	}
	if(!k) {
		dfs(1, 0, 0);
		write(ans);
		return 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

