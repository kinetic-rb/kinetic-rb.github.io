#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e5 + 5;
int n, q, k, v[N], ans;
vector<int> e[N];
bool f[N];
inline int read() {
	int x = 0;
	bool flag = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = 1;
			ch = getchar();
		}
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + ch - '0';
		ch = getchar();
	}
	if(!flag) {
		return x;
	} else {
		return ~(x - 1);
	}
}
inline void write(int x) {
	if(x < 0) {
		x = ~(x - 1);
		putchar('-');
	}
	if(x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
inline void dfs(int noww, int t, int step, int p) {
	if(noww == t) {
		ans = min(ans, step);
		return ;
	}
	for(int i = 0; i < e[noww].size(); i++) {
		if(!f[e[noww][i]]) {
			f[e[noww][i]] = 1;
			dfs(e[noww][i], t, step + v[e[noww][i]], p + 1);
			f[e[noww][i]] = 0;
		}
	}
}
signed main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	n = read(), q = read(), k = read();
	for(int i = 1; i <= n; i++) {
		v[i] = read();
	}
	for(int i = 1; i < n; i++) {
		int a = read(), b = read();
		e[a].push_back(b);
		e[b].push_back(a);
	}
	while(q--) {
		memset(f, 0, sizeof(f));
		ans = INT_MAX;
		int s = read(), t = read();
		f[s] = 1;
		dfs(s, t, v[s], 0);
		write(ans);
		puts("");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

