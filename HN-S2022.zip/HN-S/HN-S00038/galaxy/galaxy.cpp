#include<bits/stdc++.h>
using namespace std;
const int N = 5e5 + 5;
map<int, map<int, int> > mp1;
int n, m, q;
bool f[N], flag;
inline long long read() {
	long long x = 0;
	bool flag = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = 1;
			ch = getchar();
		}
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + ch - '0';
		ch = getchar();
	}
	if(!flag) {
		return x;
	} else {
		return ~(x - 1);
	}
}
inline void write(long long x) {
	if(x < 0) {
		x = ~(x - 1);
		putchar('-');
	}
	if(x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
inline void dfs(int noww, int x) {
	if(noww == x) {
		flag = 1;
		return ;
	}
	int cnt = 0;
	for(int i = 1; i <= n; i++) {
		if(cnt > 1) {
			flag = 0;
			break;
		}
		if(!f[i] && mp1[noww][i] == 1) {
			cnt++;
			f[i] = 1;	
			dfs(i, x);
			f[i] = 0;
		}
	}
}
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	n = read(), m = read();
	while(m--) {
		int u = read(), v = read();
		mp1[u][v] = 1;
	}
	q = read();
	while(q--) {
		memset(f, 0, sizeof(f));
		bool ff = 1;
		int t = read();
		if(t == 1) {
			int u = read(), v = read();
			mp1[u][v] = -1;
		} else if(t == 2) {
			int u = read();
			for(int i = 1; i <= n; i++) {
				if(mp1[i][u] == 1) {
					mp1[i][u] = -1;
				}
			}
		} else if(t == 3) {
			int u = read(), v = read();
			mp1[u][v] = 1;
		} else {
			int u = read();
			for(int i = 1; i <= n; i++) {
				if(mp1[i][u] == -1) {
					mp1[i][u] = 1;
				}
			}
		}
		for(int i = 1; i <= n; i++) {
			int cnt = 0;
			flag = 0;
			for(int j = 1; j <= n; j++) {
				if(cnt > 1) {
					break;
				}
				if(mp1[i][j] == 1) {
					f[j] = 1;
					dfs(j, i);
					cnt++;
				}
			}
			if(!flag) {
				ff = 0;
				break;
			}
		}
		if(ff) {
			puts("YES");
		} else {
			puts("NO");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

