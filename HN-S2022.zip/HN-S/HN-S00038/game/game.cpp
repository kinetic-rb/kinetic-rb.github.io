#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
long long n, m, q, a[N], b[N];
inline long long read() {
	long long x = 0;
	bool flag = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = 1;
			ch = getchar();
		}
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + ch - '0';
		ch = getchar();
	}
	if(!flag) {
		return x;
	} else {
		return ~(x - 1);
	}
}
inline void write(long long x) {
	if(x < 0) {
		x = ~(x - 1);
		putchar('-');
	}
	if(x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	bool f = 0;
	n = read(), m = read(), q = read();
	for(int i = 1; i <= n; i++) {
		a[i] = read();
		if(a[i] < 0) {
			f = 1;
		}
	}
	for(int i = 1; i <= m; i++) {
		b[i] = read();
		if(b[i] < 0) {
			f = 1;
		}
	}
	if(!f) {
		while(q--) {
			int la = read(), ra = read(), lb = read(), rb = read();
			long long maxi = INT_MIN, mini = INT_MAX;
			for(int i = la; i <= ra; i++) {
				maxi = max(maxi, a[i]);
			}
			for(int i = lb; i <= rb; i++) {
				mini = min(mini, b[i]);
			}
			write(maxi * mini);
			puts("");
		}
		return 0;
	}
	while(q--) {
		int la = read(), ra = read(), lb = read(), rb = read();
		if(la == ra) {
			if(a[la] == 0) {
				puts("0");
				continue;
			}
			if(a[la] > 0) {
				long long mini = INT_MAX;
				for(int i = lb; i <= rb; i++) {
					mini = min(mini, b[i]);
				}
				write(a[la] * mini);
			} else {
				long long maxi = INT_MIN;
				for(int i = lb; i <= rb; i++) {
					maxi = max(maxi, b[i]);
				}
				write(a[la] * maxi);
			}
		} else if(lb == rb) {
			if(b[lb] == 0) {
				puts("0");
				continue;
			}
			if(b[lb] > 0) {
				long long maxi = INT_MIN;
				for(int i = la; i <= ra; i++) {
					maxi = max(maxi, a[i]);
				}
				write(maxi * b[lb]);
			} else {
				long long mini = INT_MAX;
				for(int i = la; i <= ra; i++) {
					mini = min(mini, a[i]);
				}
				write(mini * b[lb]);
			}
		}
		puts("");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

