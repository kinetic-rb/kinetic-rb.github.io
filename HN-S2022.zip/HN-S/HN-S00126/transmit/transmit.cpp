#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;
using ll = long long;

const int N = 2e5 + 1;

struct E {
  ll s, v;
  int f[21], d;
  vector<int> e;
} v[N];

int n, q, k;

void Dfs(int x, int f) {
  v[x].s = v[f].s + v[x].v, v[x].d = v[f].d + 1;
  for (int i = 1; i <= 20; ++i) {
    v[x].f[i] = v[v[x].f[i - 1]].f[i - 1];
  }
  for (int i : v[x].e) {
    if (i != f) {
      Dfs(i, x);
    }
  }
}

int LCA(int x, int y) {
  if (v[x].d < v[y].d) {
    swap(x, y);
  }
  for (int i = 0; i <= 20; ++i) {
    if (v[x].d - (1 << i) == v[y].d) {
      x = v[x].f[i];
    }
  }
  if (x == y) {
    return x;
  }
  for (int i = 20; i >= 0; --i) {
    if (v[x].f[i] != v[y].f[i]) {
      x = v[x].f[i], y = v[y].f[i];
    }
  }
  return v[x].f[0];
}

int main() {
  freopen("transmit.in", "r", stdin);
  freopen("transmit.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> q >> k;
  for (int i = 1; i <= n; ++i) {
    cin >> v[i].v;
  }
  for (int i = 1, x, y; i < n; ++i) {
    cin >> x >> y;
    v[y].f[0] = x;
    v[x].e.push_back(y);
  }
  Dfs(1, 0);
  for (int i = 1, x, y; i <= q; ++i) {
    cin >> x >> y;
    int z = LCA(x, y);
    cout << v[x].s + v[y].s - 2 * v[z].s + v[z].v << '\n';
  }
  return 0;
}