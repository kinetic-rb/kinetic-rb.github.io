#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;
using pii = pair<int, int>;
using ll = long long;

const int N = 2501;

struct E {
  ll p;
  vector<int> e, t;
} v[N];

int n, m, k;
ll ans;
bool f[N][N], b[N];

void Bfs(int x) {
  queue<pii> q;
  f[x][x] = 1;
  for (int i : v[x].t) {
    f[x][i] = 1, q.push({i, 0});
  }
  while (!q.empty()) {
    pii p = q.front();
    q.pop();
    v[x].e.push_back(p.first);
    if (p.second == k) {
      continue;
    }
    for (int i : v[p.first].t) {
      if (!f[x][i]) {
        q.push({i, p.second + 1});
        f[x][i] = 1;
      }
    }
  }
}

void Dfs(int x, int s, ll sum) {
  if (s == 5) {
    if (f[1][x]) {
      ans = max(ans, sum);
    }
    return;
  }
  for (int i : v[x].e) {
    if (!b[i]) {
      b[i] = 1;
      Dfs(i, s + 1, sum + v[i].p);
      b[i] = 0;
    }
  }
}

int main() {
  freopen("holiday.in", "r", stdin);
  freopen("holiday.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m >> k;
  for (int i = 2; i <= n; ++i) {
    cin >> v[i].p;
  }
  for (int i = 1, x, y; i <= m; ++i) {
    cin >> x >> y;
    v[x].t.push_back(y);
    v[y].t.push_back(x);
  }
  for (int i = 1; i <= n; ++i) {
    Bfs(i);
  }
  b[1] = 1;
  Dfs(1, 1, 0);
  cout << ans;
  return 0;
}