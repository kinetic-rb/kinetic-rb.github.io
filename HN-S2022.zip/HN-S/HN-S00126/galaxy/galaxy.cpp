#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

const int N = 1001;

int n, m, q;
vector<int> e[N];
bool f[N][N], b[N];

bool Dfs(int x) {
  if (b[x]) {
    return 1;
  }
  b[x] = 1;
  bool _b = 0;
  for (int i : e[x]) {
    if (!f[x][i]) {
      _b |= Dfs(i);
    }
  }
  return _b;
}

bool C() {
  for (int i = 1; i <= n; ++i) {
    int d = 0;
    for (int j : e[i]) {
      if (!f[i][j]) {
        d++;
      }
    }
    if (d != 1) {
      return 0;
    }
    fill(b + 1, b + n + 1, 0);
    if (!Dfs(i)) {
      return 0;
    }
  }
  return 1;
}

int main() {
  freopen("galaxy.in", "r", stdin);
  freopen("galaxy.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m;
  for (int i = 1, x, y; i <= m; ++i) {
    cin >> x >> y;
    e[x].push_back(y);
  }
  cin >> q;
  for (int i = 1, op, x, y; i <= q; ++i) {
    cin >> op;
    if (op == 1) {
      cin >> x >> y;
      f[x][y] = 1;
    } else if (op == 2) {
      cin >> x;
      for (int j = 1; j <= n; ++j) {
        f[j][x] = 1;
      }
    } else if (op == 3) {
      cin >> x >> y;
      f[x][y] = 0;
    } else {
      cin >> x;
      for (int j = 1; j <= n; ++j) {
        f[j][x] = 0;
      }
    }
    cout << (C() ? "YES" : "NO") << '\n';
  }
  return 0;
}