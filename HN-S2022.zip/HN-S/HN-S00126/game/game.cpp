#include <algorithm>
#include <cstdio>
#include <iostream>

using namespace std;
using ll = long long;

const int N = 1e5 + 2;

int n, m, q, l1, r1, l2, r2;
ll a[N], b[N], sta[N * 2][23], stb[N * 2][23], v[N];
bool f;

void BL() {
  for (int i = 1; i <= q; ++i) {
    cin >> l1 >> r1 >> l2 >> r2;
    ll mx = -1e18;
    for (int j = l1; j <= r1; ++j) {
      ll mn = 1e18;
      for (int k = l2; k <= r2; ++k) {
        mn = min(mn, a[j] * b[k]);
      }
      mx = max(mx, mn);
    }
    cout << mx << '\n';
  }
}

void ST() {
  fill(stb[0], stb[m + 1], 1e18);
  for (int i = 1, j = 0; i <= n; ++i) {
    sta[i][0] = a[i];
    j += i == (1 << (j + 1)) + 1;
    v[i] = j;
  }
  for (int i = 1, j = 0; i <= m; ++i) {
    stb[i][0] = b[i];
    j += i == (1 << (j + 1)) + 1;
    v[i] = j;
  }
  for (int j = 1; j <= 20; ++j) {
    if (1 << j <= n) {
      for (int i = 1; i <= n; ++i) {
        sta[i][j] = max(sta[i][j - 1], sta[i + (1 << (j - 1))][j - 1]);
      }
    }
    if (1 << j <= m) {
      for (int i = 1; i <= m; ++i) {
        stb[i][j] = min(stb[i][j - 1], stb[i + (1 << (j - 1))][j - 1]);
      }
    }
  }
  for (int i = 1; i <= q; ++i) {
    cin >> l1 >> r1 >> l2 >> r2;
    int d1 = v[r1 - l1 + 1], d2 = v[r2 - l2 + 1];
    cout << max(sta[l1][d1], sta[r1 - (1 << d1) + 1][d1]) * min(stb[l2][d2], stb[r2 - (1 << d2) + 1][d2]) << '\n';
  }
}

int main() {
  freopen("game.in", "r", stdin);
  freopen("game.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m >> q;
  f = 1;
  for (int i = 1; i <= n; ++i) {
    cin >> a[i];
    if (a[i] <= 0) {
      f = 0;
    }
  }
  for (int i = 1; i <= m; ++i) {
    cin >> b[i];
    if (b[i] <= 0) {
      f = 0;
    }
  }
  if (f && n > 200) {
    ST();
  } else {
    BL();
  }
  return 0;
}