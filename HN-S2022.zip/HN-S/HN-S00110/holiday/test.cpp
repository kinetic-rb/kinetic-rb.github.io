#include<bits/stdc++.h>
using namespace std;
signed main(){
	long long xx;
	cout<<sizeof(xx);
	return 0;
}
