#include<bits/stdc++.h>
using namespace std;
/*
���֪��ÿ������Զ���Ե��Ǹ��㣬
����Լ�¼f[i][j]��ʾ ��j�������ǵ�i,����߹��˶��ٷ֡�
��f[i][j]��ÿһ�����Ե�i�ĵ�kת�ơ�f[i][j]=f[k][j-1]+a[i] 
*/
const int maxn=800;
long long a[maxn];
int n,m,k;
int head[maxn<<2], son[maxn<<2], pre[maxn<<2];
int tot;
bool can[maxn][maxn];
long long f[maxn][7];
void add(int x,int y) {
	son[++tot]=y;
	pre[tot]=head[x];
	head[x]=tot;
}
bool vis[maxn];
int dis[maxn];
void dijk(int s) {
	priority_queue<pair<int,int> , vector<pair<int,int> >, greater<pair<int,int> > > q;
	memset(vis, false, sizeof(vis));
	memset(dis, 0x7f, sizeof(dis));
	q.push(make_pair(s,0));
	while(!q.empty()) {
		pair<int,int> x=q.top();
		q.pop();
		int u=x.first, dd=x.second;
//		if(vis[u]) continue;
		vis[u]=true;
		for(int i=head[u];i;i=pre[i]) {
			int v=son[i];
			if(dd+1<dis[v]) {
				dis[v]=dd+1;
				q.push(make_pair(v, dis[v]));
			}
		}
	}
	for(int i=1;i<=n;i++) {
		if(dis[i]-1<=k) {
			can[i][s]=true;
		}
	}
}
bool vi[maxn];
long long ans;
void dfs(int x,int dep,long long res) {
	if(dep==5) {
		if(can[1][x]) ans=max(ans, res);
		return ;
	}
	for(int i=2;i<=n;i++) {
		if(can[i][x] && !vi[i]) {
			vi[i]=true;
			dfs(i, dep+1, res+a[i]); 
			vi[i]=false;
		}
	}
}
signed main(){
	freopen("holiday3.in", "r", stdin);
	//freopen("holiday.out", "w", stdout);
	memset(can, false, sizeof can); 
	scanf("%d%d%d", &n, &m, &k);
	for(int i=2;i<=n;i++) {
		scanf("%lld", &a[i]);
	}
	for(int i=1;i<=m;i++) {
		int x,y;
		scanf("%d%d", &x, &y);
		add(x,y); add(y,x);
	}
	// ��ÿ���������·
	for(int i=1;i<=n;i++) {
		dijk(i);
	} 
	dfs(1,1,0);
	//���㲻ͬ ��ͬ ��ͬ 
//	for(int i=2;i<=n;i++) {
//		if(can[i][1]) f[i][1]=a[i];
//	}
//	for(int j=2;j<=4;j++) {
//		for(int i=2;i<=n;i++) {
//			for(int k=i+1;k<=n;k++) {
//			//	if(k==i) continue; 
//				if(can[i][k]) {
//			//		printf(" Trans from %d jus %lld\n", k, f[k][j-1]);
//					f[i][j]=max(f[i][j], f[k][j-1]+a[i]);
//				}
//			}
//		//	printf("f %d %d Is %lld\n", i, j, f[i][j]); 
//		}
//	}
//	for(int i=2;i<=n;i++) if(can[1][i]) ans=max(ans, f[i][4]);
	cout<<ans<<endl;
	return 0;
}
