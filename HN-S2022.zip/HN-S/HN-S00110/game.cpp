#include<bits/stdc++.h>
#define ls p<<1
#define rs p<<1|1
#define int long long
using namespace std;
const int maxn=1e5+10;
int n,m,q;
int a[maxn], b[maxn];
int minf[maxn], maxz[maxn];
struct T {
	int Mz, Az, Mf, Af;
	bool Z, F, zer;
	T() {
		Mf=0; Az=0;
		Mz=LONG_LONG_MAX; Af=LONG_LONG_MIN;
		Z=F=false;
		zer=false;
	}
} ;
T merge(T b,T c) {
	T a;
	a.Z=(b.Z|c.Z);
	a.F=(b.F|c.F);
	a.zer=(b.zer|c.zer);
	a.Az=max(b.Az, c.Az);
	a.Mz=min(b.Mz, c.Mz);
	a.Af=max(b.Af, c.Af);
	a.Mf=min(b.Mf, c.Mf);
	return a;
}
struct Seg {
	T t[maxn<<4];
	int a[maxn];
	void pushup(int p) {
		t[p]=merge(t[ls], t[rs]);
	}
	void build(int p,int l,int r) {
		if(l==r) {
			if(a[l]>0) {
				t[p].Z=true;
				t[p].Az=max(t[p].Az, a[l]);
				t[p].Mz=min(t[p].Mz, a[l]);
			} else if(a[l]<0) {
				t[p].F=true;
				t[p].Af=max(t[p].Af, a[l]);
				t[p].Mf=min(t[p].Mf, a[l]);
			} else t[p].zer=true;
			return ;
		}
		int mid=l+r>>1;
		build(ls,l,mid);
		build(rs,mid+1,r);
		pushup(p);
	}
	T query(int p,int L,int R,int l,int r) {
		if(l>=L && r<=R) {
			return t[p];
		}
		T res;
		int mid=l+r>>1;
		if(L<=mid) res=query(ls,L,R,l,mid);
		if(R>mid) res=merge(res, query(rs,L,R,mid+1,r));
		return res;
	}
}s1,s2;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	/*
	�������߶������и��������
	��ȻA�����ȡ����B�л�ȡ��С�ĸ�
	��֮ȡ��������
	��������ֻ������ ȡͬ�����Եļ���
	*/
	cin>>n>>m>>q;
	for(int i=1; i<=n; i++) {
		scanf("%lld", &s1.a[i]);
	}
	for(int i=1; i<=m; i++) {
		scanf("%lld", &s2.a[i]);
	}
	s1.build(1,1,n); s2.build(1,1,n);
	while(q--) {
		int la, lb, ra, rb;
		scanf("%lld%lld%lld%lld", &la, &ra, &lb, &rb);
		//��¼
		T x=s1.query(1,la,ra,1,n);
		T x2=s2.query(1,lb,rb,1,n);
		long long mnf=x.Mf, mxz=x.Az, mnz=x.Mz, mxf=x.Af;
		bool zh=x.Z, fu=x.F;
		bool zero=x.zer;
		
		long long mn=x2.Mf, mx=x2.Az, mnZ=x2.Mz, mxF=x2.Af;
		bool zer=x2.zer;
		if(mn==0 && mx==0) {
			// nothing but 0
			puts("0");
			continue;
		}
		if(mn==0) {
			// û�ø�����
			long long ans=LONG_LONG_MIN;
			if(zero) ans=max(ans, (long long)0);
			if(zh)ans=max(ans, mxz*(mnZ==LONG_LONG_MAX?0:mnZ));
			if(fu)ans=max(ans, mxf*(mx==0?0:mx));
			if(zer)ans=min(ans, (long long)0);
			printf("%lld\n", ans);
			continue;
		}
		if(mx==0) {
			long long ans=LONG_LONG_MIN;
			if(zero) ans=max(ans, (long long)0);
			if(fu) ans=max(ans, mnf*(mxF==LONG_LONG_MIN?0:mxF));
			if(zh) ans=max(ans, mnz*(mn==0?0:mn));
			if(zer) ans=min(ans, (long long)0);
			printf("%lld\n", ans);
			continue;
		}
		// all have
		if(zero) puts("0");
		else {
			if(zh && fu)printf("%lld\n", max(mnz*mn, mxf*mx));
			else if(zh) printf("%lld\n", mnz*mn);
			else if(fu) printf("%lld\n", mxf*mx);
		}
	}
	return 0;
}
//-4741330216564600
