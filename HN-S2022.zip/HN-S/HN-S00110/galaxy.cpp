#include<bits/stdc++.h>
using namespace std;
signed main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=m;i++) scanf("%d%d", &n, &n); 
	int q;
	cin>>q;
	while(q--) {
		puts("No");
	}
	return 0;
}
