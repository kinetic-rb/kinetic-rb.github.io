#include<bits/stdc++.h>
using namespace std;
#define ll long long
vector<int>g[2505];
int d[2505][2505];
ll a[2505];
struct node{
	int a,b;
};
queue<node>q;
ll dp[6][2505];
int p[6][2505][6];
inline bool check(int I,int J,int X){
	for(int i=1;i<=I;i++)
		if(p[I][J][i]==X)
			return 0;
	return 1;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for(int i=1;i<=n;i++){
		q.push(node{i,0});
		while(!q.empty()){
			int x=q.front().a,y=q.front().b;
			q.pop();
			for(int j=0;j<g[x].size();j++){
				int z=g[x][j];
				if(!d[i][z]){
					d[i][z]=y+1;
					q.push(node{z,y+1});
				}
			}
		}
		for(int j=1;j<=n;j++)d[i][j]--;
		d[i][i]=0;
	}
//	for(int i=1;i<=n;i++)
//		for(int j=1;j<=n;j++)
//			printf("%-2d%s",d[i][j],(j==n?"\n":" "));
	memset(dp,-0x3f3f3f3f,sizeof(dp));
	for(int j=2;j<=n;j++)
		dp[1][j]=a[j],p[1][j][1]=j;
	for(int i=2;i<=4;i++)
		for(int j=2;j<=n;j++)
			for(int x=2;x<=n;x++)
				if(x!=j&&check(i-1,x,j)&&d[j][x]<=k&&dp[i][j]<dp[i-1][x]+a[j]){
					dp[i][j]=dp[i-1][x]+a[j];
					for(int rp=1;rp<i;rp++)
						p[i][j][rp]=p[i-1][x][rp];
					p[i][j][i]=j;
				}
	ll ans(0);		
	for(int i=2;i<=n;i++)
		if(d[i][1]<=k){
			ans=max(ans,dp[4][i]);
//			for(int l=1;l<=4;l++)
//				printf("%d ",p[4][i][l]);
//			printf("\n");			
		}	
	printf("%lld",ans);
	return 0;
}
