#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,m,q;
	scanf("%d%d%d",&n,&q,&m);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
	}
	while(q--){
		scanf("%d",&n);
		printf("%d\n",m*3-n);
	}
	return 0;
}
