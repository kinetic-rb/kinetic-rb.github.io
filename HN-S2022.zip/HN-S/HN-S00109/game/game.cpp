#include<bits/stdc++.h>
using namespace std;
#define lowbit(x) (x&-x)
#define inf 0x3f3f3f3f
int n,m;
int a[100005],tra1[100005],tra2[100005];
int b[100005],trb1[100005],trb2[100005];
int X1[100005],tr1[100005];
int X2[100005],tr2[100005];
inline void init(){
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(a[i]<0)X1[i]=inf,X2[i]=a[i];
		else X1[i]=a[i],X2[i]=-inf;
		for(int j=i;j<=n;j+=lowbit(j))
			tr1[j]=min(tr1[j],X1[i]),
			tr2[j]=max(tr2[j],X2[i]),
			tra1[j]=max(tra1[j],a[i]),
			tra2[j]=min(tra2[j],a[i]);
	}
//	for(int i=1;i<=n;i++)
//		cout<<tr1[i]<<"^\n";
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		for(int j=i;j<=m;j+=lowbit(j))
			trb1[j]=max(trb1[j],b[i]),
			trb2[j]=min(trb2[j],b[i]);
	}
}
inline int qrya1(int l,int r){
	int res=-inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=max(tra1[r],res),r-=lowbit(r);
		else res=max(a[r],res),r--;
	return max(a[l],res);
}
inline int qryb1(int l,int r){
	int res=-inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=max(trb1[r],res),r-=lowbit(r);
		else res=max(b[r],res),r--;
	return max(b[l],res);
}
inline int qrya2(int l,int r){
	int res=inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=min(tra2[r],res),r-=lowbit(r);
		else res=min(a[r],res),r--;
	return min(a[l],res);
}
inline int qryb2(int l,int r){
	int res=inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=min(trb2[r],res),r-=lowbit(r);
		else res=min(b[r],res),r--;
	return min(b[l],res);
}
inline int qry1(int l,int r){
	int res=inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=min(tr1[r],res),r-=lowbit(r);
		else res=min(X1[r],res),r--;
	return min(X1[l],res);
}
inline int qry2(int l,int r){
	int res=-inf;
	while(l<r)
		if(r-lowbit(r)>=l)res=max(tr2[r],res),r-=lowbit(r);
		else res=max(X2[r],res),r--;
	return max(X2[l],res);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int q;
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1,N=max(n,m);i<=N;i++)
		tra1[i]=trb1[i]=tr2[i]=-inf,
		tra2[i]=trb2[i]=tr1[i]=inf;
	init();
	while(q--){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int amx=qrya1(l1,r1),amn=qrya2(l1,r1),bmx=qryb1(l2,r2),bmn=qryb2(l2,r2);
//		printf("%d %d %d %d*\n",amx,amn,bmx,bmn);
		long long as1,as2;
		if(bmn>=0){
			as1=amx;
			as2=bmn;
		}else{
			if(bmx<=0){
				as1=amn;
				if(amn>=0)as2=bmn;
				else as2=bmx;
			}else{
				if(amx<=0){
					as1=amx;
					as2=bmx;
				}else{
					if(amn>=0){
						as1=amn;
						as2=bmn;
					}else{
						long long x1=qry1(l1,r1);
						long long x2=qry2(l1,r1);
//						cout<<x1<<' '<<x2<<"&\n";
						if(x1*bmn<x2*bmx){
							as1=x2;
							as2=bmx;
						}else{
							as1=x1;
							as2=bmn;							
						}
					}
				}
			}
		}
		printf("%lld\n",as1*as2);
	}
	return 0;
}
