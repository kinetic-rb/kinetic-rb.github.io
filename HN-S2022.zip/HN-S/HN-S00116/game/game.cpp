#include <bits/stdc++.h>
using namespace std;
long long a[100010],b[100010];
long long Lmax,Lmin;
long long Qmax,Qmin;
bool q0,l0;
long long  n,m,q;
long long l1,r1,l2,r2;
const long long inf=1e9+10;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	long long  i,j,k,l;
	for(i=1;i<=n;i++)
	cin>>a[i];
	for(i=1;i<=m;i++)
	cin>>b[i];
	for(i=1;i<=q;i++)
	{
		cin>>l1>>r1>>l2>>r2;
		Lmax=-inf;
		Qmax=-inf;
		Lmin=inf;
		Qmin=inf;
		l0=false;
		q0=false;
		long long ans=0;
		for(j=l1;j<=r1;j++)
		{
			Lmax=max(Lmax,a[j]);
			Lmin=min(Lmin,a[j]);
			if(a[j]==0)
			l0=true;
		}
		for(j=l2;j<=r2;j++)
		{
			Qmax=max(Qmax,b[j]);
			Qmin=min(Qmin,b[j]);
			if(b[j]==0)
			q0=true;
		}
		if(Qmin>=0)
		{
			if(Lmax>=0)
			ans=Lmax*Qmin;
			else
			ans=Lmax*Qmax;
			cout<<ans<<endl;
			continue;
		}
		else if(Qmax<=0)
		{
			if(Lmin<=0)
			ans=Lmin*Qmax;
			else
			ans=Lmin*Qmin;
			cout<<ans<<endl;
			continue;
		}
		else if(Qmax==0&&Qmin==0)
		{
			cout<<0<<endl;
			continue;
		}
		else
		{
			if(l0)
			cout<<0<<endl;
			else
			{
				ans=-inf;
				bool tf;
				for(j=l1;j<=r1;j++)
				{
					if(a[j]<=0)
					ans=max(ans,a[j]*Qmax);
					else
					ans=max(ans,a[j]*Qmin);
				}
				cout<<ans<<endl;
			}
		}
		
	}
	return 0;
}
/*
belief2022
*/
