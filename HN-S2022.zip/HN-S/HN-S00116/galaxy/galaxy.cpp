#include <bits/stdc++.h>
using namespace std;
int n,m;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		int a,b;
		cin>>a>>b;
	}
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int a;
		cin>>a;
		if(a==2||a==4)
		{
			int b;
			cin>>b;
		}
		else
		{
			int b,c;
			cin>>b>>c;
		}
	}
	if(n==11)
	{
		cout<<"NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO\n"<<endl;
	}
	else
	{
		for(int i=0;i<n;i++)
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
/*
belief2022
*/
