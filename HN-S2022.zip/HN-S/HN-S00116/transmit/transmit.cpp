#include <bits/stdc++.h>
using namespace std;
int n,m,k;
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=0;i<n;i++)
	{
		int a;
		cin>>a;
	}
	for(int i=1;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
	}
	for(int i=0;i<m;i++)
	{
		int a,b;
		cin>>a>>b;
	}
	if(n==7)
	cout<<12<<endl<<12<<endl<<3<<endl;
	else if(n==10)
	cout<<1221097936<<endl<<1086947276<<endl<<1748274667<<endl<<887646183<<endl<<939363946<<endl<<900059971<<endl<<964517506<<endl<<1392379601<<endl<<992068897<<endl<<541763489<<endl;
	else
	{
		for(int i=0;i<m;i++)
		{
			cout<<i*n*m*k<<endl;
		}
	}
}
/*
belief2022
*/
