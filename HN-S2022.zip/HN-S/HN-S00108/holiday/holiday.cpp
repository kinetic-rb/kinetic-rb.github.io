#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
int n,m,K,dis[2510][2510];
pair<long long,int>jg[2510][3];
long long s[2510],ans;
vector<int>v[2510];
queue<int>q;
void bfs(int S){
    for(int i=1;i<=n;i++)dis[S][i]=K+1;
    q.push(S);dis[S][S]=0;for(int x:v[S]){q.push(x);dis[S][x]=0;}
    while(q.size()){
        int x=q.front();q.pop();
        for(int y:v[x]){
            if(dis[S][y]>dis[S][x]){dis[S][y]=dis[S][x]+1;q.push(y);}
        }
    }
}
void ins(pair<long long,int>x,int y){
    for(int i=0;i<3;i++){
        if(jg[y][i].fi<x.fi){
            for(int j=i+1;j<3;j++)jg[y][j]=jg[y][j-1];
            jg[y][i]=x;break;
        }
    }
}
void work(int x,int y){
    for(int i=0;i<3;i++){if(!jg[x][i].se)break;
        for(int j=0;j<3;j++){if(!jg[y][j].se)break;
            if(jg[x][i].se==y||jg[y][j].se==x||jg[y][j].se==jg[x][i].se)continue;
            ans=max(ans,s[x]+s[y]+jg[x][i].fi+jg[y][j].fi);
        }
    }
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&K);
    for(int i=2;i<=n;i++)scanf("%lld",&s[i]);
    for(int i=1;i<=m;i++){
        int x,y;scanf("%d%d",&x,&y);v[x].push_back(y);v[y].push_back(x);
    }
    for(int i=1;i<=n;i++)bfs(i);
    for(int i=2;i<=n;i++){
        for(int j=2;j<=n;j++){
            if(i==j||dis[1][j]>K||dis[i][j]>K)continue;
            ins({s[j],j},i);
        }
    }
    for(int i=2;i<=n;i++){
        for(int j=2;j<=n;j++){
            if(i==j||dis[i][j]>K)continue;
            work(i,j);
        }
    }cout<<ans;
    return 0;
}