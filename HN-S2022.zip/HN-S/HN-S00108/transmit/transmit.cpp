#include<bits/stdc++.h>
using namespace std;
int n,Q,k;
long long qz[200010];
vector<int>v[200010];
namespace SUB12{
    int f[200010][20],dep[200010];
    void dfs(int x,int ff){
        dep[x]=dep[ff]+1;qz[x]+=qz[ff];f[x][0]=ff;
        for(int i=1;i<18;i++)f[x][i]=f[f[x][i-1]][i-1];
        for(int y:v[x]){
            if(y==ff)continue;
            dfs(y,x);
        }
    }
    int lca(int x,int y){
        if(dep[x]<dep[y])swap(x,y);
        for(int i=17;i>=0;i--){
            if(dep[f[x][i]]>=dep[y])x=f[x][i];
        }if(x==y)return x;
        for(int i=17;i>=0;i--){
            if(f[x][i]!=f[y][i]){x=f[x][i];y=f[y][i];}
        }return f[x][0];
    }
    void work(){
        dfs(1,0);
        while(Q--){
            int x,y,lc;scanf("%d%d",&x,&y);lc=lca(x,y);//cerr<<"["<<lc<<"]"<<endl;
            printf("%lld\n",qz[x]+qz[y]-qz[lc]-qz[f[lc][0]]);
        }
    }
}
int main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    scanf("%d%d%d",&n,&Q,&k);
    for(int i=1;i<=n;i++)scanf("%lld",&qz[i]);
    for(int i=1;i<n;i++){
        int x,y;scanf("%d%d",&x,&y);v[x].push_back(y);v[y].push_back(x);
    }
    SUB12::work();
    return 0;
}