#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[2][100010],qwq[2][4],cz[2][4];
struct TR{
    int mxz,mnz,mxf,mnf;
};
struct TREE{
    TR tr[400010];
    TR merge(TR x,TR y){
        if(y.mxz!=-1){if(x.mxz==-1){x.mxz=y.mxz;}else x.mxz=max(x.mxz,y.mxz);}
        if(y.mnz!=-1){if(x.mnz==-1){x.mnz=y.mnz;}else x.mnz=min(x.mnz,y.mnz);}
        if(y.mxf!=-1){if(x.mxf==-1){x.mxf=y.mxf;}else x.mxf=max(x.mxf,y.mxf);}
        if(y.mnf!=-1){if(x.mnf==-1){x.mnf=y.mnf;}else x.mnf=min(x.mnf,y.mnf);}
        return x;
    }
    void js(int p,int l,int r,int op){
        if(l==r){
            if(a[op][l]>=0){tr[p].mxz=tr[p].mnz=a[op][l];tr[p].mxf=tr[p].mnf=-1;}
            else{tr[p].mxf=tr[p].mnf=-a[op][l];tr[p].mxz=tr[p].mnz=-1;}return;
        }int mid=(l+r)>>1,ls=p<<1,rs=(p<<1)+1;
        js(ls,l,mid,op);js(rs,mid+1,r,op);
        tr[p]=merge(tr[ls],tr[rs]);
    }
    TR cx(int p,int l,int r,int ll,int rr){
        if(ll<=l&&r<=rr)return tr[p];
        int mid=(l+r)>>1,ls=p<<1,rs=(p<<1)+1;TR jg={-1,-1,-1,-1};
        if(ll<=mid)jg=merge(jg,cx(ls,l,mid,ll,rr));
        if(rr>mid)jg=merge(jg,cx(rs,mid+1,r,ll,rr));
        return jg;
    }
}tre[2];
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);
    for(int i=1;i<=n;i++)scanf("%d",&a[0][i]);
    for(int i=1;i<=m;i++)scanf("%d",&a[1][i]);
    tre[0].js(1,1,n,0);
    tre[1].js(1,1,m,1);
    while(q--){
        int l,r,ll,rr;TR qw[2];scanf("%d%d%d%d",&l,&r,&ll,&rr);
        qw[0]=tre[0].cx(1,1,n,l,r);qwq[0][0]=-qw[0].mnf;qwq[0][1]=-qw[0].mxf;qwq[0][2]=qw[0].mnz;qwq[0][3]=qw[0].mxz;
        cz[0][0]=qw[0].mnf;cz[0][1]=qw[0].mxf;cz[0][2]=qw[0].mnz;cz[0][3]=qw[0].mxz;
        qw[1]=tre[1].cx(1,1,m,ll,rr);qwq[1][0]=-qw[1].mnf;qwq[1][1]=-qw[1].mxf;qwq[1][2]=qw[1].mnz;qwq[1][3]=qw[1].mxz;
        cz[1][0]=qw[1].mnf;cz[1][1]=qw[1].mxf;cz[1][2]=qw[1].mnz;cz[1][3]=qw[1].mxz;
        long long ans=-1e18-1;
        for(int i=0;i<4;i++){
            if(cz[0][i]==-1)continue;
            long long jg=1e18+1;
            for(int j=0;j<4;j++){
                if(cz[1][j]==-1)continue;
                jg=min(jg,1ll*qwq[0][i]*qwq[1][j]);
            }
            ans=max(ans,jg);
        }printf("%lld\n",ans);
    }return 0;
}