#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
int n,m,q,du[500010];
vector<pair<int,int> >v[500010];
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        int x,y;scanf("%d%d",&x,&y);v[y].push_back({x,1});du[x]++;
    }scanf("%d",&q);
    while(q--){
        int op,x,y;scanf("%d%d",&op,&x);
        if(op==1){
            scanf("%d",&y);
            for(auto &i:v[y])if(i.fi==x){i.se=0;break;}
            du[x]--;
        }
        else if(op==2){
            for(auto &i:v[x])if(i.se==1){i.se=0;du[i.fi]--;}
        }
        else if(op==3){
            scanf("%d",&y);
            for(auto &i:v[y])if(i.fi==x){i.se=1;break;}
            du[x]++;
        }
        else{
            for(auto &i:v[x])if(i.se==0){i.se=1;du[i.fi]++;}
        }int flg=0;
        //for(int i=1;i<=n;i++)cerr<<"["<<du[i]<<"]";
        //cerr<<endl;
        for(int i=1;i<=n;i++)if(du[i]!=1){flg=1;break;}
        if(flg)puts("NO");
        else puts("YES");
    }return 0;
}