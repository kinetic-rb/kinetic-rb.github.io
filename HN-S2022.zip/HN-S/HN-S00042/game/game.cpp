#include<bits/stdc++.h>
using namespace std;
long long a[10005][10005],x[100005],y[100005];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for (int i=1;i<=n;++i)
	{
		cin>>x[i];
	}
	for (int i=1;i<=m;++i)
	{
		cin>>y[i];
	}
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			a[i][j]=x[i]*y[j];
		}
	}
	for (int i=1;i<=q;++i)
	{
		long long l1,r1,l2,r2,maxx=-99999999999999999;
		cin>>l1>>r1>>l2>>r2;
		for (int j=l1;j<=r1;++j)
		{
			 long long mi=99999999999999999; 
			 for (int k=l2;k<=r2;++k)
			 {
			 	 if (a[j][k]<mi) mi=a[j][k];
			 }
			 maxx=max(maxx,mi);
		}
		cout<<maxx<<endl;
	}
	return 0;
} 
