#include<bits/stdc++.h>
using namespace std;
int u[500005],v[500005],s[500005];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q;
	cin>>n>>m;
	for(int i=1;i<=m;++i) 
	{
		cin>>u[i]>>v[i]; 
	} 
	cin>>q;
	for (int i=1;i<=q;++i)
	{
		int u,v,t;
		cin>>t;
		if (t==1)
		{
			cin>>u>>v;
		}
		else if (t==2)
		{
			cin>>u;
		}
		else if (t==3)
		{
			cin>>u>>v;
		}
		else if (t==4)
		{
			cin>>u;
		}
		cout<<"NO";
    }
    
} 
