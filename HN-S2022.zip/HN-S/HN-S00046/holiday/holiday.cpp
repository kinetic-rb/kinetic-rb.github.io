#include <bits/stdc++.h>
using namespace std;
int n, m, k;
int64_t score[2501];
vector<int> node[2501];
bool visited[2501];
vector<int> node2[2501];
int64_t ans = 0;
void bfs(int start) {
    memset(visited, 0, sizeof(visited));
    queue<pair<int, int>> q;
    visited[start] = true;
    q.push(make_pair(start, 0));
    while(!q.empty()) {
        auto at = q.front();
        q.pop();
        if(at.second > k) {
            continue;
        }
        for(auto i = node[at.first].begin(); i != node[at.first].end(); i++) {
            if(visited[*i]) {
                continue;
            }
            node2[start].push_back(*i);
            visited[*i] = true;
            q.push(make_pair(*i, at.second + 1));
        }
    }
}
void dfs2(int at, int step, int64_t sum) {
    if(step == 4) {
        for(auto i = node2[at].begin(); i != node2[at].end(); i++) {
            if(*i == 1) {
                ans = max(ans, sum);
            }
        }
        return;
    }
    visited[at] = true;
    for(auto i = node2[at].begin(); i != node2[at].end(); i++) {
        if(!visited[*i]) {
            dfs2(*i, step + 1, sum + score[*i]);
        }
    }
    visited[at] = false;
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) {
	    cin >> score[i];
    }
    for(int i = 1; i <= m; i++) {
        int from, to;
        cin >> from >> to;
        node[from].push_back(to);
        node[to].push_back(from);
    }
    for(int i = 1; i <= n; i++) {
        bfs(i);
    }
    memset(visited, 0, sizeof(visited));
    dfs2(1, 0, 0);
    cout << ans << endl;
}

