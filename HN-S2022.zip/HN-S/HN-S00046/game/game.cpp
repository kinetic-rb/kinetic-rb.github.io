#include <bits/stdc++.h>
using namespace std;
int qLog[100001];
int n, m, q;
int64_t a[100001], b[100001];
bool special1 = true;
int64_t aSTable[2][2][100001][17];
int64_t bSTable[2][100001][17];
void buildSTable() {
    for(int i = n; i >= 1; i--) {
        if(a[i] >= 0) {
            aSTable[0][0][i][0] = 0x3f3f3f3f3f3f3f3f;
            aSTable[0][1][i][0] = 0xc0c0c0c0c0c0c0c0;
            aSTable[1][0][i][0] = a[i];
            aSTable[1][1][i][0] = a[i];
        } else {
            aSTable[0][0][i][0] = a[i];
            aSTable[0][1][i][0] = a[i];
            aSTable[1][0][i][0] = 0x3f3f3f3f3f3f3f3f;
            aSTable[1][1][i][0] = 0xc0c0c0c0c0c0c0c0;
        }
        for(int j = 1; i + (1 << j) - 1 <= n; j++) {
            aSTable[0][0][i][j] = min(aSTable[0][0][i][j - 1], aSTable[0][0][i + (1 << (j - 1))][j - 1]);
            aSTable[0][1][i][j] = max(aSTable[0][1][i][j - 1], aSTable[0][1][i + (1 << (j - 1))][j - 1]);
            aSTable[1][0][i][j] = min(aSTable[1][0][i][j - 1], aSTable[1][0][i + (1 << (j - 1))][j - 1]);
            aSTable[1][1][i][j] = max(aSTable[1][1][i][j - 1], aSTable[1][1][i + (1 << (j - 1))][j - 1]);
        }
    }
    for(int i = m; i >= 1; i--) {
        bSTable[0][i][0] = b[i];
        bSTable[1][i][0] = b[i];
        for(int j = 1; i + (1 << j) - 1 <= m; j++) {
            bSTable[0][i][j] = min(bSTable[0][i][j - 1], bSTable[0][i + (1 << (j - 1))][j - 1]);
            bSTable[1][i][j] = max(bSTable[1][i][j - 1], bSTable[1][i + (1 << (j - 1))][j - 1]);
        }
    }
}
void preprocess() {
    qLog[1] = 0;
    for(int i = 2; i <= max(n, m); i++) {
        qLog[i] = qLog[i >> 1] + 1;
    }
    buildSTable();
}
int64_t calcA(int positive, int high, int l, int r) {
    int length = r - l + 1;
    if((1 << qLog[length]) == length) {
        return aSTable[positive][high][l][qLog[length]];
    } else {
        if(!high) {
            return min(aSTable[positive][high][l][qLog[length]], calcA(positive, high, l + (1 << qLog[length]), r));
        } else {
            return max(aSTable[positive][high][l][qLog[length]], calcA(positive, high, l + (1 << qLog[length]), r));
        }
    }
}
int64_t calcB(int high, int l, int r) {
    int length = r - l + 1;
    if((1 << qLog[length]) == length) {
        return bSTable[high][l][qLog[length]];
    } else {
        if(!high) {
            return min(bSTable[high][l][qLog[length]], calcB(high, l + (1 << qLog[length]), r));
        } else {
            return max(bSTable[high][l][qLog[length]], calcB(high, l + (1 << qLog[length]), r));
        }
    }
}
void solve() {
    int l1, r1, l2, r2;
    cin >> l1 >> r1 >> l2 >> r2;
    int64_t ans = 0xc0c0c0c0c0c0c0c0;
    int64_t minB = calcB(0, l2, r2);
    int64_t maxB = calcB(1, l2, r2);
    if(minB < 0) {
        int64_t tmp = calcA(1, 0, l1, r1);
        if(tmp != 0x3f3f3f3f3f3f3f3f) {
            ans = max(ans, tmp * minB);
        }
    } else {
        int64_t tmp = calcA(1, 1, l1, r1);
        if(tmp != static_cast<int64_t>(0xc0c0c0c0c0c0c0c0)) {
            ans = max(ans, tmp * minB);
        }
    }
    if(maxB < 0) {
        int64_t tmp = calcA(0, 0, l1, r1);
        if(tmp != 0x3f3f3f3f3f3f3f3f) {
            ans = max(ans, tmp * maxB);
        }
    } else {
        int64_t tmp = calcA(0, 1, l1, r1);
        if(tmp != static_cast<int64_t>(0xc0c0c0c0c0c0c0c0)) {
            ans = max(ans, tmp * maxB);
        }
    }
    cout << ans << endl;
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++) {
	    cin >> a[i];
    }
    for(int i = 1; i <= m; i++) {
        cin >> b[i];
    }
    preprocess();
    for(int i = 1; i <= q; i++) {
        solve();
    }
}

