#include <bits/stdc++.h>
using namespace std;
int n, m, q;
bool rawLine[1001][1001];
bool line[1001][1001];
void operate(int type, int from, int to) {
    if(type == 1) {
        line[from][to] = false;
    } else if(type == 2) {
        for(int i = 1; i <= n; i++) {
            line[i][from] = false;
        }
    } else if(type == 3) {
        line[from][to] = true;
    } else {
        for(int i = 1; i <= n; i++) {
            line[i][from] = rawLine[i][from];
        }
    }
}
bool check() {
    for(int i = 1; i <= n; i++) {
        int cnt = 0;
        for(int j = 1; j <= n; j++) {
            if(line[i][j]) {
                cnt++;
            }
            if(cnt > 1) {
                return false;
            }
        }
        if(cnt != 1) {
            return false;
        }
    }
    return true;
}
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m;
	for(int i = 1; i <= m; i++) {
	    int from, to;
	    cin >> from >> to;
	    rawLine[from][to] = true;
	    line[from][to] = true;
    }
    cin >> q;
    for(int i = 1; i <= q; i++) {
        int type, from, to = 0;
        cin >> type >> from;
        if(type == 1 || type == 3) {
            cin >> to;
        }
        operate(type, from, to);
        if(check()) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
}

