#include <bits/stdc++.h>
using namespace std;
struct Line {
    int to;
    int64_t weight;
};
int n, Q, maxStep;
int64_t v[200002];
vector<int> node[200002];
vector<Line> node2[400004];
int64_t minw[400004];
bool visited[400004];
priority_queue<pair<int64_t, int>, vector<pair<int64_t, int>>, greater<pair<int64_t, int>>> q;
void bfs(int start) {
    memset(visited, 0, sizeof(visited));
    queue<pair<int, int>> q;
    visited[start] = true;
    q.push(make_pair(start, 0));
    while(!q.empty()) {
        auto at = q.front();
        q.pop();
        if(at.second == maxStep) {
            continue;
        }
        for(auto i = node[at.first].begin(); i != node[at.first].end(); i++) {
            if(visited[*i]) {
                continue;
            }
            node2[start * 2].push_back(Line{(*i) * 2 - 1, 0});
            visited[*i] = true;
            q.push(make_pair(*i, at.second + 1));
        }
    }
}
void dij(int start) {
    memset(minw, 0x3f, sizeof(minw));
    memset(visited, 0, sizeof(visited));
    minw[start] = 0;
    q.push(make_pair(minw[start], start));
    while(!q.empty()) {
        int at = q.top().second;
        q.pop();
        if(visited[at]) {
            continue;
        }
        visited[at] = true;
        for(auto i = node2[at].begin(); i != node2[at].end(); i++) {
            if(visited[i->to]) {
                continue;
            }
            if(minw[i->to] <= minw[at] + i->weight) {
                continue;
            }
            minw[i->to] = minw[at] + i->weight;
            q.push(make_pair(minw[i->to], i->to));
        }
    }
}
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> Q >> maxStep;
	for(int i = 1; i <= n; i++) {
	    cin >> v[i];
    }
    for(int i = 1; i < n; i++) {
        int from, to;
        cin >> from >> to;
        node[from].push_back(to);
        node[to].push_back(from);
    }
    for(int i = 1; i <= n; i++) {
        bfs(i);
        node2[i * 2 - 1].push_back(Line{i * 2, v[i]});
    }
    for(int i = 1; i <= Q; i++) {
        int from, to;
        cin >> from >> to;
        dij(from * 2 - 1);
        cout << minw[to * 2] << endl;
    }
}

