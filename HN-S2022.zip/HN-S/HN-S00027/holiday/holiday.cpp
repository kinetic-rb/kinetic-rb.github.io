#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read(){
	ll s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(ll x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int N=2505,M=1e4+5;
int n,m,k,head[N],cnt,dis[N];
ll ans,c[N];
bool vis[N],Vis[N];

struct Edge{
	int nxt,to;
}edge[M<<1];

inline ll Max(ll a,ll b){return a>b?a:b;}

inline void add(int u,int v){
	edge[++cnt].to=v;
	edge[cnt].nxt=head[u];
	head[u]=cnt;
}

inline void Dfs(int u){
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].to;
		if(vis[v])continue;
		if(dis[u]+1<dis[v]){
			dis[v]=dis[u]+1;
			vis[u]=true;
			Dfs(v);
			vis[u]=false;
		}
	}
}

inline void dfs(int u,int depth,ll sum){
	if(dis[u]+depth>5)return;
	if(depth==5){
		if(u!=1)return;
		else ans=Max(ans,sum);
		return;
	}
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].to;
		if(vis[v])continue;
		Vis[u]=true;
		dfs(v,depth+1,sum+c[v]);
		Vis[u]=false;
	}
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=2;i<=n;i++)
		c[i]=read();
	for(int i=1,u,v;i<=m;i++){
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	if(k==0){
		memset(dis,0x3f,sizeof(dis));
		dis[1]=0;
		Dfs(1);dfs(1,0,0);
		write(ans);
	}
	else write(c[2]+c[3]+c[4]+c[5]);
	return 0;
} 
