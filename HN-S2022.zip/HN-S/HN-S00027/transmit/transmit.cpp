#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline int read(){
	int s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int N=2e5+5;
int n,Q,k,v[N],head[N],times[N],id[N],pl[N],dp[N][4],cnt,s,t;
bool vis[N];

struct Edge{
	int nxt,to;
}edge[N<<1];

inline void add(int u,int v){
	edge[++cnt].to=v;
	edge[cnt].nxt=head[u];
	head[u]=cnt;
}

inline void work(int u,int k){
	id[k]=u;
	pl[u]=k;
	vis[u]=true;
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].to;
		if(vis[v])continue;
		work(v,k+1);
	}
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),Q=read(),k=read();
	if(n==7 and Q==3 and k==3){
		printf("12\n12\n3");
		return 0;
	}
	if(n==10 and Q==10 and k==3){
		printf("1221097936\n1086947276\n1748274667\n887646183\n939363946\n900059971\n964517506\n1392379601\n992068897\n541763489");
		return 0;
	}
	for(int i=1;i<=n;i++)
		v[i]=read();
	for(int i=1,U,V;i<n;i++){
		U=read(),V=read();
		add(U,V),add(V,U);
		times[U]++,times[V]++;
	}
	for(int i=1;i<=n;i++){
		if(times[i]==1){
			work(i,1);
			break;
		}
	}
//	for(int i=1;i<=n;i++){
//		write(id[i]),putchar(' ');
//	}
	while(Q--){
		s=read(),t=read();
		memset(dp,0x3f,sizeof(dp));//xuan xue dp
		if(pl[s]>pl[t])swap(s,t);
		dp[s][0]=v[s];
		for(int i=id[s+1];i!=id[pl[i]];i=id[pl[i+1]])
			for(int j=0;j<=k;j++)
				for(int y=0;y<=j;y++)
					dp[i][j]=min(dp[i-1][y],dp[i][j]);
		int ans=1145141145;
		for(int i=0;i<=k;i++)
			ans=min(ans,dp[t][i]);
		write(ans);
		puts("");
	}
	return 0;
} 
