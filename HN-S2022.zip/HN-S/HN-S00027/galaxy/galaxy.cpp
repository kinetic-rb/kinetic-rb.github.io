#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline int read(){
	int s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int N=1e3+5,M=5e5+5;
int n,m,q,cdu[N],mp[N][N],head[M],cnt;
bool pd=false;

struct Edge{
	int nxt,to,w;
}edge[M<<1];

inline void add(int u,int v,int w){
	edge[++cnt].to=v;
	edge[cnt].nxt=head[u];
	edge[cnt].w=w;
	head[u]=cnt;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	if(n<=1000){
		for(int i=1,u,v;i<=m;i++){
			u=read(),v=read();
			mp[u][v]=1;cdu[u]++;
		}
		q=read();
		for(int i=1,t,u,v;i<=q;i++){
			t=read();
			if(t==1){
				u=read(),v=read();
				mp[u][v]=2;
				cdu[u]--;
			}
			if(t==2){
				u=read();
				for(int i=1;i<=n;i++)
					if(mp[i][u]==1)
						mp[i][u]=2,cdu[i]--;
			}
			if(t==3){
				u=read(),v=read();
				mp[u][v]=1;
				cdu[u]++;
			}
			if(t==4){
				u=read();
				for(int i=1;i<=n;i++)
					if(mp[i][u]==2)
						mp[i][u]=1,cdu[i]++;
			}
			pd=true;
			for(int i=1;i<=n;i++)
				if(cdu[i]!=1){
					pd=false;
					break;
				}
			if(pd)puts("YES");
			else puts("NO");
		}
	}else{
		for(int i=1,u,v;i<=m;i++){
			u=read(),v=read();
			add(v,u,1);
			cdu[u]++;
			add(v,u,3);
		}
		for(int i=1,t,u,v;i<=q;i++){
			t=read();
			if(t==1){
				u=read(),v=read();
				for(int i=head[u];i;i=edge[i].nxt)
					if(edge[i].to==v){
						edge[i].w=4;
						break;
					}
				cdu[u]--;
			}
			if(t==2){
				u=read();
				for(int i=head[u];i;i=edge[i].nxt)
					if(edge[i].w==1)
						cdu[edge[i].to]--,edge[i].w=2;
					else if(edge[i].w==3)
						cdu[edge[i].to]--,edge[i].w=4;
			}
			if(t==3){
				u=read(),v=read();
				for(int i=head[u];i;i=edge[i].nxt)
					if(edge[i].to==v){
						edge[i].w=3;
						break;
					}
				cdu[u]++;
			}
			if(t==4){
				u=read();
				for(int i=head[u];i;i=edge[i].nxt)
					if(edge[i].w==2)
						cdu[edge[i].to]--,edge[i].w=1;
					else if(edge[i].w==4)
						cdu[edge[i].to]--,edge[i].w=3;
			}
			pd=true;
			for(int i=1;i<=n;i++)
				if(cdu[i]!=1){
					pd=false;
					break;
				}
			if(pd)puts("YES");
			else puts("NO");
		}
	}
	return 0;
} 
