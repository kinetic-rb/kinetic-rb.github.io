#include<bits/stdc++.h>
using namespace std;
//sto O(n^2) orz
typedef long long ll;

inline int read(){
	int s=0,f=1;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' and ch<='9'){s=(s<<1)+(s<<3)+(ch^48);ch=getchar();}
	return f*s;
}

inline void write(ll x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

inline ll Min(ll a,ll b){return a<b?a:b;}
inline ll Max(ll a,ll b){return a>b?a:b;}

const int N=1e5+5;
const ll inf=1e18+5;
int n,m,q,a[N],b[N],l1,l2,r1,r2;
ll c[N][N];

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=m;i++)
		b[i]=read();
	while(q--){
		l1=read(),r1=read(),l2=read(),r2=read();
		ll ans=-inf;
		for(int i=l1;i<=r1;i++){
			ll k=inf;
			for(int j=l2;j<=r2;j++)
				k=Min(k,1ll*a[i]*b[j]);
			ans=Max(ans,k);
		}
		write(ans);
		puts("");
	}
	return 0;
} 
