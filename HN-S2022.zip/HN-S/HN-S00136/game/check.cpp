#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(0);
	system("fc game.out game.ans");
	return 0;
}
