#include<bits/stdc++.h>
using namespace std;
#define int long long
const int MX=2e5+100;
int n,m,q,a[MX],b[MX],inf=1e9+1;
struct sgt{
	int maxx[MX<<2],minn[MX<<2];
	#define lc (s<<1)
	#define rc (s<<1|1)
	#define mid (l+r)/2
	
	void pushup(int s){
		maxx[s]=max(maxx[lc],maxx[rc]);
		minn[s]=min(minn[lc],minn[rc]);
	}
	
	void build(int l,int r,int s){
		if(l==r){
			maxx[s]=-inf;
			minn[s]=inf;
			return;
		}
		build(l,mid,lc);
		build(mid+1,r,rc);
		pushup(s);
	}
	
	void update(int l,int r,int s,int k,int num){
		if(l==r){
			maxx[s]=minn[s]=num;
			return;
		}
		if(k<=mid) update(l,mid,lc,k,num);
		else update(mid+1,r,rc,k,num);
		pushup(s);
	}
	
	int query_min(int l,int r,int s,int L,int R){
		if(L<=l&&r<=R) return minn[s];
		int ans=inf;
		if(L<=mid) ans=min(ans,query_min(l,mid,lc,L,R));
		if(R>mid) ans=min(ans,query_min(mid+1,r,rc,L,R));
		return ans;
	}
	
	int query_max(int l,int r,int s,int L,int R){
		if(L<=l&&r<=R) return maxx[s];
		int ans=-inf;
		if(L<=mid) ans=max(ans,query_max(l,mid,lc,L,R));
		if(R>mid) ans=max(ans,query_max(mid+1,r,rc,L,R));
		return ans;
	}
}tree[2][3]; //1 all;2 >0,3<0
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m>>q;
	for(int j=0;j<3;j++) tree[0][j].build(1,n,1);
	for(int j=0;j<3;j++) tree[1][j].build(1,m,1);
	for(int i=1;i<=n;i++){
		cin>>a[i];
		tree[0][0].update(1,n,1,i,a[i]);
		if(a[i]>=0) tree[0][1].update(1,n,1,i,a[i]);
		else tree[0][2].update(1,n,1,i,a[i]);
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
		tree[1][0].update(1,m,1,i,b[i]);
		if(b[i]>=0) tree[1][1].update(1,m,1,i,b[i]);
		else tree[1][2].update(1,m,1,i,b[i]);		
	}
	
	while(q--){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		int s1=-1e18,s2=-1e18;int ok=0;
		int x=tree[1][0].query_min(1,m,1,l2,r2);
		int y=tree[1][0].query_max(1,m,1,l2,r2);
		
		int d1=tree[0][1].query_max(1,n,1,l1,r1);
		if(d1==-inf) ok=1;
		if(ok!=1){
			if(x>0) s1=x*d1;
			else s1=x*tree[0][1].query_min(1,n,1,l1,r1);			
		}

		int d2=tree[0][2].query_max(1,n,1,l1,r1);
		if(d2==-inf)  ok=2;
		if(ok!=2){
			if(y>0) s2=y*d2;
			else s2=y*tree[0][2].query_min(1,n,1,l1,r1);			
		}

		if(ok==1) cout<<s2<<'\n';
		else if(ok==2) cout<<s1<<'\n';
		else cout<<max(s1,s2)<<'\n';
	}
	return 0;
}
