#include<bits/stdc++.h>
using namespace std;
const int MX=1e6+100;
#define int long long
int n,m,k,dis[MX],max1[MX],max2[MX],ans,max3[MX];
vector<int>g[MX],a[MX];
bool vis[MX],f[MX];
void dfs(int u,int dep,int now){
	if(dep>k+1) return;
	vis[u]=1;
	f[u]=1;
	for(int i=0;i<g[u].size();i++){
		int v=g[u][i];
		if(vis[v]) continue;
		dfs(v,dep+1,now);
	}
	vis[u]=0;
}

bool check(int x,int y,int z,int d){
	if(x==0||d==0) return 0;
	if(x==y||y==z||x==d||x==z||y==d||z==d) return 0;
	else return 1;
}
void dfs1(int u,int dep,int now){
	if(dep>k+1) return;
	vis[u]=1;
	if(u!=now&&f[u]&&u!=1){
		if(dis[u]>dis[max1[now]]) max3[now]=max2[now],max2[now]=max1[now],max1[now]=u;
		else if(dis[u]>dis[max2[now]]) max3[now]=max2[now],max2[now]=u;
		else if(dis[u]>dis[max3[now]]) max3[now]=u;
	}
	for(int i=0;i<g[u].size();i++){
		int v=g[u][i];
		if(vis[v]) continue;
		dfs1(v,dep+1,now);
	}
	vis[u]=0;
}

void dfs2(int u,int dep,int now){
	if(dep>k+1) return;
	vis[u]=1;
	if(check(max1[now],now,u,max1[u])) ans=max(ans,dis[max1[now]]+dis[now]+dis[u]+dis[max1[u]]);
	if(check(max1[now],now,u,max2[u])) ans=max(ans,dis[max1[now]]+dis[now]+dis[u]+dis[max2[u]]);
	if(check(max1[now],now,u,max3[u])) ans=max(ans,dis[max1[now]]+dis[now]+dis[u]+dis[max3[u]]);
	if(check(max2[now],now,u,max2[u])) ans=max(ans,dis[max2[now]]+dis[now]+dis[u]+dis[max2[u]]);
	if(check(max2[now],now,u,max3[u])) ans=max(ans,dis[max2[now]]+dis[now]+dis[u]+dis[max3[u]]);
	if(check(max3[now],now,u,max3[u])) ans=max(ans,dis[max3[now]]+dis[now]+dis[u]+dis[max3[u]]);
	for(int i=0;i<g[u].size();i++){
		int v=g[u][i];
		if(vis[v]) continue;
		dfs2(v,dep+1,now);
	}
	vis[u]=0;	
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++) cin>>dis[i];
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		g[x].push_back(y);
		g[y].push_back(x);
	}
	
	dfs(1,0,1);
	
	for(int i=2;i<=n;i++) dfs1(i,0,i);
	
//	cout<<max1[3];
	for(int i=2;i<=n;i++) dfs2(i,0,i);
	
	cout<<ans;
	return 0;
}
