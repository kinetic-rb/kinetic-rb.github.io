#include<bits/stdc++.h>
using namespace std;
const int MX=1e6+100;
int n,m;
vector<int>g[MX],g1[MX];
int f[5000][5000],vis[MX],use[MX];
bool flag[MX],v[MX],check[MX];
stack<int>s;
int dfn[MX],low[MX],num,col[MX],cnt,out[MX],siz[MX];
void tarjan(int u){
	low[u]=dfn[u]=++num;
	s.push(u);use[u]=1;
	for(int i=0;i<g[u].size();i++){
		int v=g[u][i];
		if(f[u][v]) continue;
		out[u]++;
		if(!dfn[v]){
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(use[v]){
			low[u]=min(low[u],dfn[v]);
		}
	}
	if(low[u]==dfn[u]){
		cnt++;
		while(s.top()!=u){
			col[s.top()]=cnt;
			use[s.top()]=0;
			siz[cnt]++;
			s.pop();
		}
		use[u]=0,col[u]=cnt;siz[cnt]++;
		s.pop();
	}
}

void dfs(int u){
	v[u]=1;
	check[col[u]]=1;
	if(siz[col[u]]>1) flag[col[u]]=1;
	for(int i=0;i<g[u].size();i++){
		int to=g[u][i];
		if(f[u][to]||v[to]) continue;
		int cu=col[u],cv=col[to];
		if(siz[cu]>1) flag[cv]=1;
		if(siz[cv]>1) flag[cu]=1; 
		dfs(to);		
	}
	v[u]=0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		g[x].push_back(y);
		g1[y].push_back(x);
	}
	
	int q;
	cin>>q;
	while(q--){
		int t,u,v;bool ok=0;
		cin>>t;
		if(t==1){
			cin>>u>>v;
			f[u][v]=1;
		}
		else if(t==2){
			cin>>u;
			vis[u]=1;
			for(int i=0;i<g1[u].size();i++){
				int v=g1[u][i];
				f[v][u]=1;
			}
		}
		else if(t==3){
			cin>>u>>v;
			f[u][v]=0;
		}
		else if(t==4){
			cin>>u;
			for(int i=0;i<g1[u].size();i++){
				int v=g1[u][i];
				f[v][u]=0;
			}
		}
		
		
		for(int i=1;i<=n;i++) if(!dfn[i]) tarjan(i);
		
		for(int i=1;i<=n;i++)	if(out[i]!=1) ok=1;
		for(int i=1;i<=n;i++)
			if(check[col[i]]==0) dfs(i);
		for(int i=1;i<=cnt;i++)
			if(!flag) ok=1;
			
		if(ok==1) cout<<"NO"<<'\n';
		else cout<<"YES"<<'\n';
		
		for(int i=1;i<=n;i++) dfn[i]=out[i]=low[i]=0;
		for(int i=1;i<=cnt;i++) siz[i]=col[i]=flag[i]=check[i]=0;
		cnt=0;
		num=0;
	}
	return 0;
}
