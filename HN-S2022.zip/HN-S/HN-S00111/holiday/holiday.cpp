#include <bits/stdc++.h>
#define int long long
using namespace std;//AFOOOOOOOOO�� 
int dis[10000001],vis[10000001];
int point[10000001];
int n,m,k,cnt,head[10000001];

struct node{
	int to,next;
}e[1000001];
void addedge(int x,int y){
	e[++cnt].to=y;
	e[cnt].next=head[x];
	head[x]=cnt;
	return;
}
struct go{
	int k;//�� 
	int l;//�� 
};
void spfa(int S){
	queue<go> q;
	for(int i=1;i<=n;i++){
		dis[i]=333333333;
		vis[i]=0;
	}
	go tmp;
	tmp.k=S;
	tmp.l=0;
	q.push(tmp);
	dis[S]=0;
	vis[S]=1;
	while(!q.empty()){
		go p=q.front();
		int x=p.k;
		q.pop();
//		cout<<"Now expanding: "<<x<<endl;
		vis[x]=0;
		if(vis[x]==1)continue;
		for(int i=head[x];i;i=e[i].next){
			int v=e[i].to;
//			if(v==1)continue;
			if(dis[v]>dis[x]+point[v]&&p.l+1<=4){
				dis[v]=dis[x]+point[v];
	//			cout<<"Dis["<<v<<"] has updated to "<<dis[v]<<" Step:"<<p.l+1<<endl;;
				if(!vis[v]){
					tmp.k=v;
					tmp.l=p.l+1;
					q.push(tmp);
					vis[v]=1;
				}
			}
		}
	}
	return;
}
int x,y,z;
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>point[i];
		point[i]*=-1;
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
	//	if(x>y)swap(x,y);
		addedge(x,y);
		addedge(y,x);
	}
	spfa(1);
	cout<<-dis[1]<<endl;
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

8 10 0
9 7 1 8 2 3 6 8
1 9
1 8
1 5
1 4
9 2
2 3
3 4
5 6
6 7
7 8
*/
