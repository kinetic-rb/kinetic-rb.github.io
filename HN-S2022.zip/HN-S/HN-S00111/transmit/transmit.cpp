#include <bits/stdc++.h>
using namespace std;
int dep[1000001],fa[1000001];//�����������һ�дDP+LCA+����+�߶��� 
int n,q,cnt,k;
int x,y;
int point[1000001],head[1000001];
struct edge{
	int to,next;
}e[100001];
void addedge(int x,int y){
	++cnt;
	e[cnt].to=y;
	e[cnt].next=head[x];
	head[x]=cnt;
	return;
}
void dfs(int u,int fat){
	dep[u]=dep[fat]+1;
	fa[u]=fat;
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(v==fat)continue;
		dfs(v,u);
	}
	return;
}
int lca(int u,int v){
	int ans=0;
	if(dep[u]<dep[v])swap(u,v);
	while(1){
		
		if(dep[u]==dep[v]){
			break;
		}
		
	//	cout<<u<<"----->";
	
		ans+=point[u];
		for(int i=1;i<=k;i++)u=fa[u];
	//	ans+=point[u];
	//	cout<<u<<" "<<point[u]<<" "<<ans<<endl;
	}
	if(u==v){
		ans+=point[u];
		return ans;
	}
	while(1){
		
	//	cout<<"u:"<<u<<"----->"<<fa[u]<<" "<<point[u]<<" ";
		ans+=point[u];
		for(int i=1;i<=k;i++){
			u=fa[u];
		}
		
	//	cout<<ans<<endl;
	//	cout<<"v:"<<v<<"----->"<<fa[v]<<" "<<point[v]<<" ";
		ans+=point[v];
		for(int i=1;i<=k;i++){
			v=fa[v];
		}
			
	//	cout<<ans<<endl;
		if(v==u){
			ans+=point[v];
			break;
		}
	}
	return ans;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)cin>>point[i];
	for(int i=1;i<=n-1;i++){
		cin>>x>>y;
		addedge(x,y);
		addedge(y,x);
	}
	dfs(1,0);
//	cout<<"DFSdone\n";
	while(q--){
		cin>>x>>y;
//		cout<<"Ans:"<<fa[x]<<" "<<[y]<<endl;
		cout<<lca(x,y)<<endl;
	}
	return 0;
}
/*
8 4 1
1 2 3 4 5 6 7 8
1 2
1 3
2 4
2 5
3 6
3 7
7 8
4 7
5 6
1 2
6 8
*/
