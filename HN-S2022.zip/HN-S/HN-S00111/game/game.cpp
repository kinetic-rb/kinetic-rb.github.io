#include <iostream>
#include <cstring>
using namespace std;
long long a[1000001],b[1000001];
int n,m,q;
long long c[5005][5005];
long long maxx[5005];//���ǵ���ôдRMQ�ˣ�ֻ������ 
long long max_(long long x,long long y){
	if(x>=y){
		return x;
	}else{
		return y;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
//	cout<<endl;
	for(int i=1;i<=n;i++){
//		maxx[i][1]=12487940;
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
//			maxx[i][j]=min(maxx[i][j-1],c[i][j]);
		//	cout<<c[i][j]<<" ";
		}
	//	cout<<endl;
	}
	/*
	Ѱ��һ�е���Сֵ��Ȼ������ô�����������ֵ 
	*/
//	for(int i=1;i<=n;i++){
////		cout<<maxx[i]<<":";
//		for(int j=1;j<=m;j++){
//		//	c[i][j]=a[i]*b[j];
//			cout<<c[i][j]<<" ";
//		}
//		cout<<endl;
//	}
	int l1,l2,r1,r2;
	while(q--){
		//memset(maxx,1e9,sizeof(maxx));
		for(int i=1;i<=n;i++)maxx[i]=1e18;
		cin>>l1>>r1>>l2>>r2;
		for(long long i=l1;i<=r1;i++){
			for(long long j=l2;j<=r2;j++){
				//maxx[i]=min(maxx[i],c[i][j]);
				if(maxx[i]>c[i][j]){
				//	cout<<maxx[i]<<" maxx["<<i<<"]="<<c[i][j]<<", i="<<j<<endl;
					maxx[i]=c[i][j];
				}
			}
		//	cout<<maxx[i]<<endl;
		}
		long long ans=-1e18;
		for(int i=l1;i<=r1;i++){
			ans=max_(ans,maxx[i]);
		}
		cout<<ans<<endl;
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3

1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/
