#include <bits/stdc++.h>
#include <windows.h>
using namespace std;//ϣ�����Ͻ����������� 
int n,m,l,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>n>>l;
	}
	cin>>q;
	srand(time(/*114514*/NULL));
	for(int i=1;i<=q;i++){
		int k=rand()%3;
		if(k==0)cout<<"NO\n";
		else cout<<"YES\n";
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2

*/
