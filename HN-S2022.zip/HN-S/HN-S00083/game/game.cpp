#include<bits/stdc++.h>
using namespace std;
int a[100005],b[100005];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	int l1,r1,l2,r2;
	for(int i=0;i<q;i++){
		cin>>l1>>r1>>l2>>r2;
		int x,y;
		int mx=-2147483647;
		bool bx;
		for(int j=l1;j<=r1;j++){
			int mn=2147483647,fe;
			for(int k=l2;k<=r2;k++){
				if(a[j]*b[k]<mn){
					mn=a[j]*b[k];
					fe=j;
				}
			}
			if(mn>mx){
				mx=mn;
				x=fe;
			}
		}
		int mn1=2147483647;
		for(int j=l1;j<=r1;j++){
			int mx1=-2147483647,fe;
			for(int k=l2;k<=r2;k++){
				if(a[j]*b[k]>mx1){
					mx1=a[j]*b[k];
					fe=k;
				}
			}
			if(mn1>mx1){
				mn1=mx1;
				y=fe;
			}
		}
		cout<<a[x]*b[y]<<endl;
	}
	return 0;
}

