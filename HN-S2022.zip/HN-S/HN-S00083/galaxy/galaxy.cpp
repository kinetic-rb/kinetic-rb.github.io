#include<bits/stdc++.h>
using namespace std;
int cd[6][500005],n,m;
int jdcd[2][500005];
bool lxcs(int u)
{
	int ans=0;
	for(int i=jdcd[0][u-1]+1;i<=jdcd[0][u];i++){
		if(cd[0][i]==1){
			ans++;
		}
	}
	if(ans==1){
		return true;
	}
	else{
		return false;
	}
}
bool fj(int u,int v,bool tm_sharweek=1)
{
	if((u==v)&&(tm_sharweek==0)){
		return true;
	}
	if(jdcd[0][u]==-1){
		return false;
	}
	for(int i=jdcd[0][u-1]+1;i<=jdcd[0][u];i++){
		if(cd[2][jdcd[0][u]]){
			return fj(cd[1][jdcd[0][u]],v,0);
		}
	}
}
bool fg()
{
	for(int i=0;i<m;i++){
		if(!(fj(i,i)&&lxcs(i))){
			return false;
		}
	}
	return true;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int q;
	cin>>n>>m;
	for(int i=0;i<m;i++){
		cin>>cd[0][i]>>cd[1][i];
		cd[3][i]=cd[0][i];
		cd[4][i]=cd[1][i];
		cd[2][i]=1;
		jdcd[0][i]=-1;
		jdcd[1][i]=-1;
	}
	for(int i=0;i<m;i++){
		for(int j=i+1;j<m;j++){
			if(cd[0][j]<cd[0][i]){
				swap(cd[0][j],cd[0][i]);
				swap(cd[1][j],cd[1][i]);
			}
		}
	}
	for(int i=0;i<m;i++){
		for(int j=i+1;j<m;j++){
			if(cd[4][j]<cd[4][i]){
				swap(cd[3][j],cd[3][i]);
				swap(cd[4][j],cd[4][i]);
			}
		}
	}
	for(int i=0;i<m;i++){
		jdcd[0][cd[0][i]]=i;
	}
	for(int i=0;i<m;i++){
		jdcd[1][cd[4][i]]=i;
	}
	for(int i=0;i<m;i++){
		for(int j=jdcd[1][cd[0][i]-1]+1;j<=jdcd[1][cd[0][i]+1];j++){
			if(cd[2][i]==cd[4][j]){
				cd[5][j]=i;
			}
		}
	}
	cin>>q;
	for(int i=0;i<q;i++){
		int t;
		cin>>t;
		if(t==1){
			int u,v;
			cin>>u>>v;
			for(int j=jdcd[0][u-1]+1;j<=jdcd[0][u];j++){
				if(v==cd[1][j]){
					cd[2][i]=0;
				}
			}
		}
		if(t==2){
			int u;
			cin>>u;
			for(int j=jdcd[1][u-1]+1;j<=jdcd[1][u];j++){
				cd[2][cd[5][i]]=0;
			}
		}
		if(t==3){
			int u,v;
			cin>>u>>v;
			for(int j=jdcd[0][u-1]+1;j<=jdcd[0][u];j++){
				if(v==cd[1][j]){
					cd[2][i]=1;
				}
			}
		}
		if(t==4){
			int u;
			cin>>u;
			for(int j=jdcd[1][u-1]+1;j<=jdcd[1][u];j++){
				cd[2][cd[5][i]]=1;
			}
			for(int j=jdcd[0][u-1]+1;j<=jdcd[0][u];j++){
				cd[2][i]=1;
			}
		}
		if(fg()){
			cout<<"YES"<<endl;
		}
		else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
