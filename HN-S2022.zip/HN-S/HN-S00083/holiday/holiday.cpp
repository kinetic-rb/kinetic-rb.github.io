#include<bits/stdc++.h>
using namespace std;
typedef struct{
	long long score;
	int pd[2501];
	int pdn;
	long long canget;
	int nextj;
} JD;
JD jd[2501];
int sx[2501];
int b[2501];
int hs[10],hsn;
int hs1[10],hs1n;
int n,m,k,sl=0,ans=0,nowjd=1,temp=0;
bool hfpd(int num1,int num2,int kk)
{
	if(kk==-1){
		if(num1==num2){
			return true;
		}
		else{
			return false;
		}
	}
	if(num1==num2){
		return true;
	}
	for(int i=0;i<jd[num1].pdn;i++){
		if(hfpd(jd[num1].pd[i],num2,kk-1)){
			return true;
		}
	}
	return false;
}
int ddjd(int num1,int kk)
{
	if(kk==0){
		if(jd[num1].pdn>=1){	
			return 1;
		}
		else{
			return 0;
		}
	}
	if(jd[num1].pdn==0){
		return 0;
	}
	int mx=-2147483647;
	for(int i=0;i<jd[num1].pdn;i++){
		int wjy=ddjd(jd[num1].pd[i],kk-1)+1;
		if(mx<wjy){
			mx=wjy;
		}
	}
	return mx;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	jd[1].score=0;
	sx[1]=1;
	for(int i=2;i<=n;i++){
		cin>>jd[i].score;
		jd[i].pdn=0;
		sx[i]=i;
	}
	for(int i=0;i<m;i++){
		int da,db;
		cin>>da>>db;
		jd[da].pd[jd[da].pdn]=db;
		jd[da].pdn++;
		jd[db].pd[jd[db].pdn]=da;
		jd[db].pdn++;
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(jd[sx[j]].score<jd[sx[i]].score){
				swap(sx[j],sx[i]);
			}
		}
	}
	b[1]=true;
	hs[0]=0;
	hsn=0;
	for(int i=n;i>=1;i--){
		if(b[sx[i]]==0){
			if(hfpd(nowjd,sx[i],k)){
					ans+=jd[sx[i]].score;
					sl++;
					nowjd=sx[i];
					i=n;
					b[nowjd]=1;
					hsn++;
					hs[hsn]=ans;
					hs1n++;
					hs1[hs1n]=nowjd;
					if(sl>=4){
						cout<<ans;
						return 0;
					}
			}
		}
		if(b[sx[i]]==-1){
			b[sx[i]]=0;
		}
		if((i==1)&&(sl<4)){
			i=n;
			hsn--;
			ans=hs[hsn];
			b[nowjd]=-1;
			hs1n--;
			nowjd=hs1[hs1n];
		}
		else{
			continue;
		}
	}
	cout<<ans;
	return 0;
}

