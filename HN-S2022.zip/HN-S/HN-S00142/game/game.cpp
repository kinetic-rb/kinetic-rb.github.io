#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=100001,M=100001;
int n,m,q;
int a[N],b[M],c[1001][1001];
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=m;i++)
		b[i]=read();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	while(q--){
		int l,r,ll,rr;
		l=read();
		r=read();
		ll=read();
		rr=read();
		int maxn=-1e18;
		for(int i=l;i<=r;i++){
			int minn=1e18;
			for(int j=ll;j<=rr;j++){
				minn=min(minn,c[i][j]);
			}
			maxn=max(maxn,minn);
		}
		cout<<maxn<<endl;
	}
	return 0;
}
