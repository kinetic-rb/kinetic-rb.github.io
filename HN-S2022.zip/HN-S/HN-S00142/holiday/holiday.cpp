#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2510,M=10000001;
int n,m,k,num_edge,ans;
int dq[N],dis[N][N],head[M],vis[N];
struct Edge{
	int net,to,q;
}edge[M];
void add_edge(int from,int to,int q){
	edge[++num_edge].net=head[from];
	edge[num_edge].q=q;
	edge[num_edge].to=to;
	head[from]=num_edge;
}
priority_queue<pair<int,int> >q;
void dj(int s){
	for(int i=1;i<=n;i++)
		dis[s][i]=1e9;
	dis[s][s]=0;
	q.push(make_pair(0,s));
	while(!q.empty()){
		int r=q.top().second;
		q.pop();
		if(vis[r]==1)
			continue;
		vis[r]=1;
		for(int i=head[r];i;i=edge[i].net){
			if(dis[s][edge[i].to]>edge[i].q+dis[s][r]){
				dis[s][edge[i].to]=edge[i].q+dis[s][r];
				q.push(make_pair(-dis[s][edge[i].to],edge[i].to));
			}
		}
	}
}
struct dddd{
	int now,qz,num;
};
struct road{
	int a,b,c,d;
};
queue<pair<dddd,road> >qq;
void bfs(){
	dddd aa;
	road aaa;
	aaa.a=-1,aaa.b=-1,aaa.c=-1,aaa.d=-1;
	aa.now=1,aa.num=0,aa.qz=0;
	qq.push(make_pair(aa,aaa));
	while(!qq.empty()){
		dddd bb=qq.front().first;
		road bbb=qq.front().second;
		int noww=bb.now,numm=bb.num,qzz=bb.qz;
		qq.pop();
		if(noww==1&&numm==4){
			ans=max(ans,qzz);
			continue;
		}
		if(numm>4)
			continue;
		for(int i=head[noww];i;i=edge[i].net){
			if(bbb.a!=edge[i].to&&bbb.b!=edge[i].to&&bbb.c!=edge[i].to&&bbb.d!=edge[i].to){
				if(edge[i].to==1&&numm<4){
					continue;
				}
				vis[edge[i].to]=1;
				dddd cc;
				cc.now=edge[i].to,cc.num=numm+1,cc.qz=qzz+dq[edge[i].to];
				if(edge[i].to==1){
					cc.num--;
					qq.push(make_pair(cc,bbb));
				}
				else{
					if(bbb.a==-1)
						bbb.a=edge[i].to;
					else if(bbb.b==-1)
						bbb.b=edge[i].to;
					else if(bbb.c==-1)
						bbb.c=edge[i].to;
					else if(bbb.d==-1)
						bbb.d=edge[i].to;	 
					qq.push(make_pair(cc,bbb));
				}
			}
		}
	}
}
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	m=read();
	k=read();
	dq[1]=0;
	for(int i=2;i<=n;i++){
		dq[i]=read();
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[i][j]=1e9;
		}
	}
	for(int i=1;i<=m;i++){
		int a,b;
		a=read();
		b=read();
		add_edge(a,b,1);
		add_edge(b,a,1);
	}
	if(k==0){
		bfs();
		cout<<ans;
		return 0;
	}
	for(int i=1;i<=n;i++){
		dj(i);
		for(int j=1;j<=n;j++)
			vis[j]=0;
	}
	memset(head,0,sizeof(head));
	num_edge=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(dis[i][j]-1<=k&&i!=j){
				add_edge(i,j,0);
			}
		}
	}
	bfs();
	cout<<ans;
	return 0;
}

