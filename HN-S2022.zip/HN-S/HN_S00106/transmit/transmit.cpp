#include<bits/stdc++.h>
#define int long long
#define N 200010
using namespace std;
struct hhh{
	int v,next;
}dl[N*2];
int n,q,k,u,v,tot,ans,sum;
int dep[N],siz[N],son[N],head[N],w[N],f[N],a[N],top[N];
void qxx(int u,int v){
	dl[++tot].v=v;
	dl[tot].next=head[u];
	head[u]=tot;
}
void dfs(int u,int fa){
	f[u]=fa,dep[u]=dep[fa]+1,siz[u]=1;
	for(int i=head[u];i;i=dl[i].next){
		int v=dl[i].v;
		if(v==fa) continue;
		dfs(v,u);
		siz[u]+=siz[v];
		if(siz[son[u]]<siz[v]) son[u]=v;
	}
}
void dfs2(int u,int t){
	top[u]=t;
	if(!son[u]) return;
	dfs2(son[u],t);
	for(int i=head[u];i;i=dl[i].next){
		int v=dl[i].v;
		if(v!=f[u]&&v!=son[u]) dfs2(v,v);
	}
}
int lca(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=f[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}
void check(int dep,int last,int pos){
	if(dep==sum){
		ans=min(ans,pos);
		return;
	}
	check(dep+1,1,pos+w[a[dep]]);
	if(last!=k) check(dep+1,last+1,pos);
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0); 
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++) cin>>w[i];
	for(int i=1;i<n;i++){
		cin>>u>>v;
		qxx(u,v),qxx(v,u);
	}
	dfs(1,1);
	dfs2(1,1);
	while(q--){
		cin>>u>>v;
		sum=dep[u]+dep[v]-1;
		int G=u,GG=v,tot=0,grz=lca(u,v);
		while(u!=grz) a[++tot]=u,u=f[u];
		a[++tot]=grz,tot=0;
		while(v!=grz) a[sum-tot]=v,v=f[v],tot++;
		for(int i=1;i<=sum;i++) cout<<a[i]<<" ";
		cout<<endl;
		ans=INT_MAX,check(2,1,0);
		cout<<ans+w[G]+w[GG]<<endl;
	}
	return 0;
}
