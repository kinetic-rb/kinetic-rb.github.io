#include<bits/stdc++.h>
#define int long long
#define N 100010
using namespace std;
struct hhh{
	int l,r,mx,mi,pos,mxx,mii;
}q[N*4],q2[N*4];
int n,m,Q,l1,r1,l2,r2;
int a[N],b[N];
void build(int bh,int l,int r){
	q[bh].l=l,q[bh].r=r;
	if(l==r){
		q[bh].mx=q[bh].mi=b[l];
		q[bh].pos=(b[l]==0);
		return;
	}
	int mid=(l+r)>>1;
	build(bh*2,l,mid),build(bh*2+1,mid+1,r);
	q[bh].mi=min(q[bh*2].mi,q[bh*2+1].mi),q[bh].mx=max(q[bh*2].mx,q[bh*2+1].mx),q[bh].pos=q[bh*2].pos|q[bh*2+1].pos;
}
void build2(int bh,int l,int r){
	q2[bh].l=l,q2[bh].r=r;
	if(l==r){
		if(a[l]>0) q2[bh].mx=q2[bh].mxx=a[l],q2[bh].mi=-INT_MAX;
		else q2[bh].mi=q2[bh].mii=a[l],q2[bh].mx=INT_MAX;
		q2[bh].pos=(a[l]==0);
		return;
	}
	int mid=(l+r)>>1;
	build2(bh*2,l,mid),build2(bh*2+1,mid+1,r);
	q2[bh].mi=max(q2[bh*2].mi,q2[bh*2+1].mi),q2[bh].mx=min(q2[bh*2].mx,q2[bh*2+1].mx),q2[bh].mxx=max(q2[bh*2].mxx,q[bh*2+1].mxx),q2[bh].mii=min(q2[bh*2].mii,q2[bh*2+1].mii),q2[bh].pos=q2[bh*2].pos|q2[bh*2+1].pos;
}
int query(int bh,int L,int R){
	if(q[bh].l>=L&&q[bh].r<=R) return q[bh].mi;
	int mid=(q[bh].l+q[bh].r)>>1,ans=INT_MAX;
	if(L<=mid) ans=query(bh*2,L,R);
	if(R>mid) ans=min(ans,query(bh*2+1,L,R));
	return ans;
}
int find(int bh,int L,int R){
	if(q2[bh].l>=L&&q2[bh].r<=R) return q2[bh].mi;
	int mid=(q2[bh].l+q2[bh].r)>>1,ans=-INT_MAX;
	if(L<=mid) ans=find(bh*2,L,R);
	if(R>mid) ans=max(ans,find(bh*2+1,L,R));
	return ans;
}
int query2(int bh,int L,int R){
	if(q[bh].l>=L&&q[bh].r<=R) return q[bh].mx;
	int mid=(q[bh].l+q[bh].r)>>1,ans=-INT_MAX;
	if(L<=mid) ans=query2(bh*2,L,R);
	if(R>mid) ans=max(ans,query2(bh*2+1,L,R));
	return ans;
}
int find2(int bh,int L,int R){
	if(q2[bh].l>=L&&q2[bh].r<=R) return q2[bh].mx;
	int mid=(q2[bh].l+q2[bh].r)>>1,ans=INT_MAX;
	if(L<=mid) ans=find2(bh*2,L,R);
	if(R>mid) ans=min(ans,find2(bh*2+1,L,R));
	return ans;
}
int get(int bh,int L,int R){
	if(q[bh].l>=L&&q[bh].r<=R) return q[bh].pos;
	int mid=(q[bh].l+q[bh].r)>>1,ans=0;
	if(L<=mid) ans=get(bh*2,L,R);
	if(R>mid) ans|=get(bh*2+1,L,R);
	return ans;
}
int get2(int bh,int L,int R){
	if(q2[bh].l>=L&&q2[bh].r<=R) return q2[bh].pos;
	int mid=(q2[bh].l+q2[bh].r)>>1,ans=0;
	if(L<=mid) ans=get2(bh*2,L,R);
	if(R>mid) ans|=get2(bh*2+1,L,R);
	return ans;
}
int find3(int bh,int L,int R){
	if(q2[bh].l>=L&&q2[bh].r<=R) return q2[bh].mii;
	int mid=(q2[bh].l+q2[bh].r)>>1,ans=INT_MAX;
	if(L<=mid) ans=find3(bh*2,L,R);
	if(R>mid) ans=min(ans,find3(bh*2+1,L,R));
	return ans;
}
int find4(int bh,int L,int R){
	if(q2[bh].l>=L&&q2[bh].r<=R) return q2[bh].mxx;
	int mid=(q2[bh].l+q2[bh].r)>>1,ans=-INT_MAX;
	if(L<=mid) ans=find4(bh*2,L,R);
	if(R>mid) ans=max(ans,find4(bh*2+1,L,R));
	return ans;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m>>Q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	build(1,1,m),build2(1,1,n);
	while(Q--){
		cin>>l1>>r1>>l2>>r2;
		int ans=query(1,l2,r2),ans2=query2(1,l2,r2),sum=find(1,l1,r1),sum2=find2(1,l1,r1),sum3=find3(1,l1,r1),sum4=find4(1,l1,r1);
		int fans=-LONG_LONG_MAX;
		if(ans>0) fans=ans*sum4;
		else fans=ans*sum2;
		if(ans2>0) fans=max(fans,ans2*sum);
		else fans=max(fans,ans2*sum3);
		if(get(1,l2,r2)||get2(1,l1,r1)) fans=max(fans,(long long)0);
		cout<<fans<<endl;
	}
	return 0;
}
