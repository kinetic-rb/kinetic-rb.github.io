#include<bits/stdc++.h>
#define N 1010
using namespace std;
int n,m,q,u,v,op,top;
int w[N][N],tot[N],p[N],f[N],out[N],ans[N],stk[N];
void dfs(int u){
	for(int i=1;i<=top;i++) if(u==stk[i]){ans[u]=1;return;}
	stk[++top]=u;
	dfs(f[u]),ans[u]=ans[f[u]];
	top--;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		w[u][v]=1,p[++tot[v]]=u,out[u]++;
	}
	cin>>q;
	while(q--){
		cin>>op>>u;
		if(op==1){
			cin>>v;
			if(w[u][v]) w[u][v]=0,out[u]--;
		}
		if(op==2){
			for(int i=1;i<=tot[u];i++) if(w[p[i]][u]) w[p[i]][u]=0,out[p[i]]--;
		}
		if(op==3){
			cin>>v;
			if(!w[u][v]) w[u][v]=1,out[u]++;
		}
		if(op==4){
			for(int i=1;i<=tot[u];i++) if(!w[p[i]][u]) w[p[i]][u]=1,out[p[i]]++;
		}
		int grz=0;
		for(int i=1;i<=n;i++) if(out[i]!=1){grz=1;break;}
		if(grz){
			cout<<"NO\n";
			continue;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++) if(w[i][j]){f[i]=j;break;}
		}
		memset(ans,0,sizeof(ans));
		for(int i=1;i<=n;i++) if(!ans[i]) dfs(i);
		for(int i=1;i<=n;i++) if(!ans[i]){grz=1;break;}
		if(grz) cout<<"NO\n";
		else cout<<"YES\n";
	}
	return 0;
}
