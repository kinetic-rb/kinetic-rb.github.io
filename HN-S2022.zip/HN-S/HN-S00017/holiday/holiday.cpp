#include<iostream>
#include<cstdio>
using namespace std;
int n,m,k;
struct Map{
	int point;
	int to[1001];
	int next_to[1001];
	int now;
	int next_now;
}p[2500];
void go(int n,int l)
{
	p[n-l].next_to[p[n-l].next_now]=n;
	if(l==k)
		return;
	for(int i=1;i<p[n].now;i++)
	{
		go(p[n].to[i],l+1);
	}
}
int togo(int n,int po,int l)
{
	if(l==4)
	{
		if(n==1)
			return po;
		else
			return -1;
	}
	int maxn=-1;
	for(int i=1;i<p[n].now;i++)
	{
		maxn=max(maxn,togo(p[n].to[i],po+=p[p[n].to[i]].point,l+1));
	}
	for(int i=1;i<p[n].next_now;i++)
	{
		maxn=max(maxn,togo(p[n].next_to[i],po+=p[p[n].next_to[i]].point,l+1));
	}
	return maxn;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	int x,y;
	p[1].now=1;
	p[1].next_now=1;
	for(int i=2;i<=n;i++)
	{
		cin>>p[i].point;
		p[i].now=1;
		p[i].next_now=1;
	}
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		p[x].to[p[x].now]=y;
		p[y].to[p[y].now]=x;
		p[x].now++;
		p[y].now++;
	}
	if(k>1);
	for(int i=1;i<=n;i++)
	{
		go(1,0);
	}
	printf("%d\n",togo(1,0,0));
	fclose(stdin); 
	fclose(stdout); 
	return 0;
}
