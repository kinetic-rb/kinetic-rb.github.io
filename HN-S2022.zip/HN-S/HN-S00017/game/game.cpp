#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long a[100001]={},b[100001]={};
	int m,n,q;
	int l1,l2,r1,r2;
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long minn,maxn=-0x7fffffffffffffff;
		for(int i=l1;i<=r1;i++)
		{
			minn=0x7fffffffffffffff;
			for(int j=l2;j<=r2;j++)
			{
				minn=min(minn,a[i]*b[j]);
			}
			maxn=max(maxn,minn);
		}
		cout<<maxn;
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
