#include<bits/stdc++.h>
using namespace std;
vector<int>l[2505];
int n,m,k,x,y;
long long a[2505],ma;
bool v[2505],u[2505][10];
void dfs(int p,int z,int s,long long po){
  if(s>k){
    return;
  }
  if(z==5){
    if(p==1){
      ma=max(ma,po);
    }
    return;
  }
  if(u[p][z]==0){
    u[p][z]=1;
    int lc=l[p].size();
    for(int i=0;i<lc;i++){
      dfs(l[p][i],z,s+1,po);
    }
    u[p][z]=0;
  }
  if(v[p]==0){
    v[p]=1;
    int lc=l[p].size();
    for(int i=0;i<lc;i++){
      dfs(l[p][i],z+1,0,po+a[p]);
    }
    v[p]=0;
  }
}
int main(){
  freopen("holiday.in","r",stdin);
  freopen("holiday.out","w",stdout);
  cin>>n>>m>>k;
  for(int i=2;i<=n;i++){
    cin>>a[i];
  }
  for(int i=1;i<=m;i++){
    cin>>x>>y;
    l[x].push_back(y);
    l[y].push_back(x);
  }
  int lct=l[1].size();
  for(int i=0;i<lct;i++){
    dfs(l[1][i],1,0,0);
  }
  cout<<ma;
	return 0;
}
