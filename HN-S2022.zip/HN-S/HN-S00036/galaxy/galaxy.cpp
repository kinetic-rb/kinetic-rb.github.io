#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,q;
int main(){
  freopen("galaxy.in","r",stdin);
  freopen("galaxy.out","w",stdout);
  cin>>n>>m;
  for(int i=1;i<=m;i++){
    cin>>a>>b;
  }
  cin>>q;
  for(int i=1;i<=q;i++){
    cout<<"YES\n";
  }
	return 0;
}
