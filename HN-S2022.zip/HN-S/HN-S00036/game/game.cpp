#include<bits/stdc++.h>
using namespace std;
int n,m,q,l1,r1,l2,r2;
long long a[100005],b[100005],ma,mi;
int main(){
  freopen("game.in","r",stdin);
  freopen("game.out","w",stdout);
  cin>>n>>m>>q;
  for(int i=1;i<=n;i++){
    cin>>a[i];
  } 
  for(int i=1;i<=m;i++){
    cin>>b[i];
  } 
  for(int i=1;i<=q;i++){
    cin>>l1>>r1>>l2>>r2;
    ma=LONG_LONG_MIN;
    for(int j=l1;j<=r1;j++){
      mi=LONG_LONG_MAX;
      for(int k=l2;k<=r2;k++){
        mi=min(mi,a[j]*b[k]);
      }
      ma=max(ma,mi);
    }
    cout<<ma<<"\n";
  }
	return 0;
}
