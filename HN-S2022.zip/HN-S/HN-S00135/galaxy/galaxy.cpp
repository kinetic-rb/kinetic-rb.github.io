#include<bits/stdc++.h>
using namespace std;
int n,m;
int lian[10001][10001] = {};
int work = 0;
bool flag = 1;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i = 0;i <= m;i++){
		for(int j = 0;j <= m;j++){
			lian[i][j] = -1;
		}
	}
	for(int i = 0;i < m;i++){
		int x,y;
		cin>>x>>y;
		lian[x][y] = 1;
	}
	cin>>work;
	for(int i = work;i > 0;i--){
		int a,b,c;
		cin>>a;
		if(a == 1){
			cin>>b>>c;
			lian[b][c] = 0;
		}
		else if(a == 2){
			cin>>b;
			for(int j = 1;j <= n;j++){
				if(lian[j][b] == 1){
					lian[j][b] = 0;
				}
			}
		}
		else if(a == 3){
			cin>>b>>c;
			lian[b][c] = 1;
		}
		else if(a == 4){
			cin>>b;
			for(int j = 1;j <= n;j++){
				if(lian[j][b] == 0){
					lian[j][b] = 1;
				}
			}
		}
		int num = 0;
		for(int i = 0;i < m;i++){
			for(int j = 0;j < m;j++){
				if(lian[i][j] == 1){
					num++;
				}
			}
		}
		if(num == m){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
} 
