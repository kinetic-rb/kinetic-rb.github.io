#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int fen[10001] = {};
bool get[1001][1001] = {}; 
int maxn = -1;
int cnt = 0,flag = 0;
int num = 0,been[1001] = {};
void find(int x,int a,int b){
	x--;
	for(int i = 0;i < n;i++){
		if(get[b][i] == true){
			if(x>0){
				for(int j = 0;j < n;j++){
					if(get[i][j] = true){
						get[a][j] = true;
						get[j][a] = true;
					}
				}
			}
			get[a][i] = true;
			get[i][a] = true;
		}
	}
}
void bfs(int start){
	num++;
	been[num] = start;
	for(int i = 1;i <= num;i++){
		if(start = been[i]){
			return;
		}
	}
	if(cnt>maxn){
		maxn = cnt;
	}
	if(flag>4){
		return;
	}
	for(int i = 0;i < n;i++){
		if(get[start][i] == true){
			cnt+=fen[start];
			bfs(i);
		}
	}
}
int main(){
//	freopen("holiday.in","r",stdin);
//	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i = 2;i <= n;i++){
		cin>>fen[i];
	}
	for(int i = 0;i < n;i++){
		int x,y;
		cin>>x>>y;
		get[x][y] = true;
		get[y][x] = true;
	}
	for(int i = 0;i < n;i++){
		for(int j = 0;j < n;j++){
			if(get[i][j] == true){
				for(int f = 1;f <= k;f++){
					find(f,i,j);
				}
			}
		}
	}
	cout<<maxn<<endl;
	return 0;
} 
