#include<bits/stdc++.h>
using namespace std;
typedef lng long long;
const int maxn=2500+7;
const int maxm=2*1e4+7;
struct edge{int v,nx;}e[maxm];
int n,m,p,eh[maxn],ec;
lng scr[maxn];
void addedge(int u,int v){
	e[++ec].v=v;
	e[ec].nx=aeh[u];
	eh[u]=ec;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&p);
	for(int i=2;i<=n;++i)
		scanf("%lld",&scr[i]);
	for(int i=1,x,y;i<=m;++i)
		scanf("%d%d",&x,&y),addedge(x,y),addedge(y,x);
	
	return 0;
} 
