#include<bits/stdc++.h>
using namespace std;
int ans=0;
int main(){
	for(int i=1;i<=2500*2500*100;++i)++ans;
	cout<<(2500*2500*100);
	return 0;
} 
