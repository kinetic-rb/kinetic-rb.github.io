#include<bits/stdc++.h>
using namespace std;
typedef long long lng;

const int maxn=2500+7;
const int maxm=2*1e4+7;
const int inf=1e9;


int n,m,p;
lng scr[maxn];

//n<=300 part
struct node{
	lng s;int v[6];
	void init(node & x){
		s=x.s;
		for(int i=1;i<=5;++i)
			v[i]=x.v[i];
	}
}f[maxn][6];
bool visit(node &x,int y){
	for(int i=1;i<=5;++i)
		if(x.v[i]==y)return 1;
	return 0;
}
int d[maxn][maxn];

//p=0 part
struct edge{int v,nx;}e[maxm];
int eh[maxn],ec;
void addedge(int u,int v){e[++ec].v=v,e[ec].nx=eh[u],eh[u]=ec;}
lng ans2=0;
bool vis[maxn];
lng st[maxn][6];
void dfs(int u,int c,lng s){
	if(c>5)return;
	if(s<st[u][c])return;
	st[u][c]=s;
	if(c==5){
		if(u==1)ans2=max(ans2,s);
		return;
	}else{
		for(int i=eh[u];i;i=e[i].nx){
			int v=e[i].v;
			if(vis[v])continue;
			vis[v]=1;
			dfs(v,c+1,s+scr[v]);
			vis[v]=0;
		}
	}
}
//main
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	scanf("%d%d%d",&n,&m,&p);
	for(int i=2;i<=n;++i)
			scanf("%lld",&scr[i]);
	
	if(n<=300){
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				if(i!=j)d[i][j]=inf;
		
		for(int i=1,x,y;i<=m;++i)
			scanf("%d%d",&x,&y),d[x][y]=d[y][x]=1;
		for(int k=1;k<=n;++k)
			for(int i=1;i<=n;++i)
				for(int j=1;j<=n;++j)
					d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
					
		for(int c=1;c<=5;++c){
			for(int i=1;i<=n;++i){
				if(c==1&&i!=1)continue;
				if(f[i][c-1].v[c-1]==0&&c!=1)continue;
				for(int j=1;j<=n;++j){
					if(i==j)continue;
					if(c==5&&j!=1)continue;
					if( d[i][j]-1<=p  && 
					    f[j][c].s<f[i][c-1].s+scr[j]  &&
					    !visit(f[i][c-1],j) )
						f[j][c].init(f[i][c-1]),f[j][c].s+=scr[j],f[j][c].v[c]=j;
				}
			}
		}
	//	for(int i=1;i<=5;++i)
	//		printf("%d ",f[1][5].v[i]); 
		printf("%lld",f[1][5].s);
	}else if(p==0){
		for(int i=1,x,y;i<=m;++i)
			scanf("%d%d",&x,&y),addedge(x,y),addedge(y,x);
		dfs(1,0,0);
		printf("%lld",st[1][5]);
	}
	return 0;
} 
