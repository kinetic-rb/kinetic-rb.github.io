#include<bits/stdc++.h>
using namespace std;
int main(){
	double ans=5616513;
	for(int i=1;i<=1e8;++i)ans+=1684,ans*=12,ans/=50;
	cout<<pow(2,14);
	return 0;
}

