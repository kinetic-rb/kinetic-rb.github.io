#include<bits/stdc++.h>
using namespace std;
typedef long long lng ;
const int maxn=1e5+7,maxm=1e3+7;
const lng inf=1e18;
const int inf2=1e9;
template<typename T>
void read(T &x){
	bool neg=0;char c=getchar();x=0;
	for(;c<'0'||c>'9';c=getchar())if(c=='-')neg=1;
	for(;'0'<=c&&c<='9';c=getchar())x=x*10+c-'0';
	if(neg)x=-x;
}
inline void chkmin(lng &a,lng b){if(b<a)a=b;}
int n,m,q;
int a[maxn],b[maxn];
int sta[maxn][15][2],stb[maxn][15][2];
int lg[maxn];int L,R,id;
inline int qa(int x){
	int len=lg[R-L+1];
	if(x==0)return min(sta[L][len][x],sta[R-len+1][len][x]);
	if(x==1)return max(sta[L][len][x],sta[R-len+1][len][x]);
}
inline int qb(int x){
	int len=lg[R-L+1];
	if(x==0)return min(stb[L][len][x],stb[R-len+1][len][x]);
	if(x==1)return max(stb[L][len][x],stb[R-len+1][len][x]);
}

struct tree{
#define lcd (x<<1)
#define rcd (x<<1|1)
#define xm ((xl+xr)>>1)
	lng val[4*maxm];
	void build(int x,int xl,int xr){
		if(xl==xr){val[x]=(lng)a[id]*b[xl];return;}
		if(1<=xm)build(lcd,xl,xm),val[x]=min(val[lcd],val[rcd]);
		if(xm<m)build(rcd,xm+1,xr),val[x]=min(val[lcd],val[rcd]);
	}
	lng query(int x,int xl,int xr){
		if(xl==xr){return val[x];}
		lng ans=inf;
		if(L<=xm)ans=min(ans,query(lcd,xl,xm));
		if(xm<R)ans=min(ans,query(rcd,xm+1,xr));
		return ans;
	}
}seg[maxm];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]),sta[i][0][0]=sta[i][0][1]=a[i];
	for(int i=1;i<=m;++i)scanf("%d",&b[i]),stb[i][0][0]=stb[i][0][1]=a[i];
	if(n<=1000&&m<=1000){
		for(int i=1;i<=n;++i){
			id=i;seg[i].build(1,1,m);
		}
		for(int l1,r1,l2,r2;q--;){
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			lng ans=-inf;L=l2,R=r2;
			for(int i=l1;i<=r1;++i)
				ans=max(ans,seg[i].query(1,1,m));
			printf("%lld\n",ans);
		}
	}else{
		lg[0]=-1;
		for(int i=1;i<=1e5;++i){
			lg[i]=lg[i/2]+1;
			for(int j=1;j<=14;++j)
				sta[i][j][0]=-inf2,sta[i][j][1]=inf2,
				stb[i][j][0]=-inf2,stb[i][j][1]=inf2;
		}
		for(int j=1;j<=14;++j){
			for(int i=1;i<=n;++i)
				sta[i][j][0]=min(sta[i][j-1][0],sta[i+(1<<j-1)][j-1][0]),
				sta[i][j][1]=max(sta[i][j-1][1],sta[i+(1<<j-1)][j-1][1]);
			printf("%d %d\n",qa(1),qa(0));
			for(int i=1;i<=m;++i)
				stb[i][j][0]=min(stb[i][j-1][0],stb[i+(1<<j-1)][j-1][0]),
				stb[i][j][1]=max(stb[i][j-1][1],stb[i+(1<<j-1)][j-1][1]);
		}
		for(int l1,r1,l2,r2;q--;){
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			lng ans=-inf;
			if(l1==r1){
				L=l2,R=r2;
				if(a[l1]>0)ans=(lng)qb(0)*a[l1];
				else ans=(lng)qb(1)*a[l1];
			}else if(l2==r2){
				L=l1,R=r1;
				if(b[l2]>0)ans=(lng)qa(1)*b[l1];
				else ans=(lng)qa(0)*b[l2];
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
