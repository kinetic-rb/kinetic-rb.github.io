#include<bits/stdc++.h>
using namespace std;
long long value[20010];
vector<int> a[20010];
vector<int> road[20010];
int book[20010];
bool can[20010];
long long f[20010];
struct node
{
	int x,value;
};
int n,m,k;
void bfs(int start)
{
	queue<node> q;
	q.push((node){start,0});
	while(q.size())
	{
		node x=q.front();
		q.pop();
		if(book[x.x]==start||x.value>k) continue;
		book[x.x]=start;
		road[start].push_back(x.x);
		for(int i=0;i<a[x.x].size();i++)
			q.push((node){a[x.x][i],x.value+1});
	}
}
void dfs(int x,int end,long long ans)
{
	if(f[x]<=ans||book[x])
		return ;
	f[x]=ans;
	book[x]=1;
	for(int i=0;i<road[x].size();i++)
		dfs(road[x][i],end,ans+value[road[x][i]]);
	book[x]=0;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
		scanf("%lld",value+i);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		a[x].push_back(y);
		a[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
		bfs(i);
	while(m--)
	{
		int x,y;
		cin>>x>>y; 
		memset(f,0x7f,sizeof(f));
		memset(book,0,sizeof(book));
		dfs(x,y,value[x]);
		printf("%lld",f[y]);
	}
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
