#include<bits/stdc++.h>
using namespace std;
vector<int> a[500010];
vector<int> b[500010];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		a[x].push_back(y);
		b[y].push_back(x); 
	}
	int q;
	cin>>q;
	while(q--)
	{
		int op;
		scanf("%d",&op);
		if(op==1)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			a[x].erase(find(a[x].begin(),a[x].end(),y));
		}
		else if(op==2)
		{
			int x;
			scanf("%d",&x);
			for(int i=0;i<b[x].size();i++)
			{
				vector<int> :: iterator it;
				it=find(a[b[x][i]].begin(),a[b[x][i]].end(),x);
				if(it==a[b[x][i]].end())
					continue;
				a[b[x][i]].erase(it);
			}
		}
		else if(op==3)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			a[x].push_back(y);
		}
		else
		{
			int x;
			scanf("%d",&x);
			for(int i=0;i<b[x].size();i++)
			{
				vector<int> :: iterator it;
				it=find(a[b[x][i]].begin(),a[b[x][i]].end(),x);
				if(it!=a[b[x][i]].end())
					continue;
				a[b[x][i]].push_back(x);
			}
		}
		bool flag=1;
		for(int i=1;i<=n;i++)
			if(a[i].size()!=1)
			{
				flag=0;
				break;
			}
		if(flag)
			printf("YES\n");
		else
			printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
