#include<bits/stdc++.h>
using namespace std;
long long value[2510];
vector<int> a[2510];
vector<int> road[2510];
int book[2510];
bool can[2510];
long long f[2510][10];
struct node
{
	int x,value;
};
int n,m,k;
void bfs(int start)
{
	queue<node> q;
	for(int i=0;i<a[start].size();i++)
		q.push((node){a[start][i],0});
	while(q.size())
	{
		node x=q.front();
		q.pop();
		if(book[x.x]==start||x.value>k) continue;
		book[x.x]=start;
		road[start].push_back(x.x);
		for(int i=0;i<a[x.x].size();i++)
			q.push((node){a[x.x][i],x.value+1});
	}
}
void dfs(int x,int t,long long ans)
{
	if(x==1&&t==5)
	{
		f[x][t]=max(f[x][t],ans);
		return ;
	}
	if(f[x][t]>=ans||book[x]||t>=5)
		return ;
	f[x][t]=ans;
	book[x]=1;
	for(int i=0;i<road[x].size();i++)
		dfs(road[x][i],t+1,ans+value[road[x][i]]);
	book[x]=0;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		scanf("%lld",value+i);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		a[x].push_back(y);
		a[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
		bfs(i);
	memset(book,0,sizeof(book));
	for(int i=1;i<=n;i++)
		for(int j=0;j<6;j++)
			f[i][j]=-1;
	dfs(1,0,0);
	cout<<f[1][5];
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
