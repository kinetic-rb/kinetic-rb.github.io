#include<bits/stdc++.h>
using namespace std;
int sta[100010][30];
int stb[100010][30];
int tb[100010][30];
long long Max(long long a,long long b)
{
	return a>b?a:b;
}
long long Min(long long a,long long b)
{
	return a<b?a:b;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		scanf("%d",sta[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",stb[i]);
	for(int i=1;i<=m;i++)
		tb[i][0]=stb[i][0];
	bool flag=0;
	for(int i=1;i<=n;i++)
		if(sta[i][0]<0)
			flag=1;
	for(int i=1;i<=m;i++)
		if(stb[i][0]<0)
			flag=1;
	
	for(int i=1;(1<<i)<=n;i++)
		for(int j=1;j+(1<<i)-1<=n;j++)
			sta[j][i]=max(sta[j][i-1],sta[j+(1<<(i-1))][i-1]);
	for(int i=1;(1<<i)<=m;i++)
		for(int j=1;j+(1<<i)-1<=m;j++)
			stb[j][i]=min(stb[j][i-1],stb[j+(1<<(i-1))][i-1]);
	for(int i=1;(1<<i)<=m;i++)
		for(int j=1;j+(1<<i)-1<=m;j++)
			tb[j][i]=max(tb[j][i-1],tb[j+(1<<(i-1))][i-1]);
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int k1=log2(r1-l1+1),k2=log2(r2-l2+1);
		if(!flag)
		{
			printf("%lld\n",max(sta[l1][k1],sta[r1-(1<<k1)+1][k1])*1l*min(stb[l2][k2],stb[r2-(1<<k2)+1][k2]));
		}
		else
		{
			long long ans=-1e18;
			if(l1!=r1)
				for(int i=l1;i<=r1;i++)
					ans=Max(ans,Min(Min(stb[l2][k2],stb[r2-(1<<k2)+1][k2])*1l*sta[i][0],Max(tb[l2][k2],tb[r2-(1<<k2)+1][k2]) *1l*sta[i][0]));
			else
			{
				for(int i=l2;i<=r2;i++)
					ans=Min(ans,sta[l1][0]*stb[i][0]));
			}
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
