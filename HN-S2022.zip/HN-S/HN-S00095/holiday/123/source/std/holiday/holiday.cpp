#include <bits/stdc++.h>
using namespace std;
long long n, m, headhc[50005];
struct SC {
	long long sc, id;
} a[2600];
bool cmp1(SC x, SC y) {
	if (x.sc == y.sc) {
		return x.id < y.id;
	}
	return x.sc < y.sc;
}
// ----------------------------- // ���ڼ�¼ u �� v ����̻��˴������� 
long long k;// ��໻�˴����� 
struct EDGE1 {
	long long u, v, w, next;
} e[50005];
long long hc[2005/*���*/][2005/*��ÿ����ľ���*/];
bool hcvis[2005][2005];
long long ehccnt;
void addhc(long long u, long long v, long long w) {
	ehccnt++;
	e[ehccnt].u = u;
	e[ehccnt].v = v;
	e[ehccnt].w = w;
	e[ehccnt].next = headhc[u];
	headhc[u] = ehccnt;
}
/*
add(u, v, 1);��Ȼ����ط��� 1���������������ٴ����� hc[u][v] - 1�� 
add(v, u, 1);
*/
struct Node {
	long long id, num;
	bool operator <(const Node& b) const {
		if (b.num == num) {
			return b.id < id;
		}
		return b.num < num;
	}
};
void dijkstrahc(long long st) {
	priority_queue<Node> q;
	hc[st][st] = 0;
	q.push((Node){st, 0}); // (Node) һ�������٣����� 
	while (!q.empty()) {
		long long id = q.top().id;
		long long num = q.top().num;
		q.pop();
		if (hcvis[st][id]) {
			continue;
		}
		hcvis[st][id] = 1;
		for (long long i = headhc[id]; i != 0; i = e[i].next) {
			long long v = e[i].v;
			long long w = e[i].w;
			if (hc[st][id] + w < hc[st][v]) {
				hc[st][v] = hc[st][id] + w;
				q.push((Node){v, hc[st][v]});
			}
		}
	}
}
//------------------------------
// ----------------------------- // ���ڼ�¼ u �� v ������������
//bool jgvis[2005]; //�����ĵ㡣
struct cf{
	long long u, step, num;
	vector<long long> v;
};
queue<cf> q;//��һ��ȥ�ĸ��㡣 
long long bfs() {
	long long maxx = 0;
	while (!q.empty()) {
		q.pop(); 
	}
	q.push((cf){1, 0, 0});
	while (!q.empty()) {
		long long u = q.front().u;
		long long step = q.front().step;
		long long num = q.front().num;
		vector<long long> op = q.front().v;
		//cout << u << " " << step << " " << num << "\n"; 
		q.pop();
		//if (op[0] == u || op[1] == u || op[2] == u || op[3] == u || op[4] == u) {
		//	continue;
		//}
		bool f = 1;
		for (long long i = 0; i < op.size(); i++) {
			if (op[i] == u) {
				f = 0;
			}
		}
		//cout << op.size() << "\n";
		if (!f) {
			continue;
		}
		op.push_back(u);
		/*
		if (jgvis[u]) {
			continue;
		} 
		jgvis[]
		*/
		if (step >= 4) {
			if (hc[u][1] - 1 <= k) {
				maxx = max(maxx, num);
			}
			continue;
		}
		for (long long i = /*headhc[u]*/2; i /*!= 0*/ <= n; /*i = e[i].next*/i++) {
			long long v = i/*e[i].v*/;
			if (hc[u][v] - 1 <= k) {
				//cout << num << "\n";
				q.push((cf){v, step + 1, num + a[v].sc, op});
			}
		}
	}
	return maxx;
}
long long dp[2005][5];
int main() {
	//freopen("holiday2.in", "r", stdin);
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin >> n >> m >> k;
	for (long long i = 2; i <= n; i++) {
		cin >> a[i].sc;
		a[i].id = i;
	}
	//stable_sort(a + 1, a + 1 + n, cmp1);
	for (long long i = 1; i <= n; i++) {
		for (long long j = 1; j <= n; j++) {
			hc[i][j] = 1096666666666666666;
		}
	}
	for (long long i = 1; i <= m; i++) {
		long long u, v;
		cin >> u >> v;
		addhc(u, v, 1);
		addhc(v, u, 1);
	}
	for (long long i = 1; i <= n; i++) {
		dijkstrahc(i);
	}
	//cout << hc[5][8] << "\n";
	// ��ϲ�ң�dijkstra ��һ�׶Σ����ˣ���ʽ��ɣ�����
	long long ans = 0;
	
	//if (n <= 150) {
	ans = bfs();
	cout << ans << "\n";
	return 0;
	//}
	/*
	for (long long m = 0; m <= k; m++) {  
		dp[1][m] += a[1].sc;
	}
	for (long long i = 2; i <= n; i++){ //��ǰ�㡣 
		
		for (long long m = 0; m <= k; m++) {  
			dp[i][m] += a[i].sc;
		}
		
		//dp[i][0] += a[i].sc;
		for (long long j = 1; j <= n; j++) { // �ĸ���ת�ƹ�����
			if (hc[i][j] - 1 > k) {
				continue;
			}
			if (i == j) {
				continue;
			}
      dp[i][k] = 0;
			//for (long long m = 0; m <= k - 1; m++) { //��ʣ�¼������ε㡣 
			for (long long m = k - 1; m >= 0; m--) { //��ʣ�¼������ε㡣
				dp[i][m] = max(dp[i][m], dp[i][m] + dp[j][m + 1]); 
				ans = max(dp[i][m], ans);
			} 
		}
	}
	cout << ans << "\n";
	*/
	return 0;
}
/*
CCF �Ұ��㣡����
I love you!!! CCF!!!
�ɰ��� CCF�� 
CCF ̫�ɰ��ˡ� 

update������������ ToT��
û���ˡ� 
*/
