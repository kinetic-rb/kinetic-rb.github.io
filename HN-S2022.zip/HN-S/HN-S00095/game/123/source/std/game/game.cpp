#include <bits/stdc++.h>
using namespace std;
long long n, m, q, a[100005], b[100005], c[5005][5005];
long long ans;
int main() {
	//freopen("game3.in", "r", stdin);
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	for (long long i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (long long i = 1; i <= m; i++) {
		cin >> b[i];
	}
	for (long long i = 1; i <= n; i++) {
		for (long long j = 1; j <= m; j++) {
			c[i][j] = a[i] * b[j];
		}
	}
	// С L ѡ���У�С Q ѡ���С�
	/*  
	for (long long i = 1; i <= n; i++) {
		for (long long j = 1; j <= m; j++) {
			cout << c[i][j] << " ";
		}
		cout << "\n"; 
	}
	*/
	while (q--) {
		long long l1, r1; // L
		long long l2, r2; // Q
		cin >> l1 >> r1 >> l2 >> r2;
		long long x = 0, y = 0;
		long long maxx = -11451419198102147;
		for (long long i = l1; i <= r1; i++) {
			long long minn = 11451419198102147;
			for (long long j = l2; j <= r2; j++) {
				minn = min(c[i][j], minn);
			}
			if (minn > maxx) {
				x = i;
				maxx = minn;
			}
		}
		
		long long minn = 11451419198102147;
		for (long long i = l2; i <= r2; i++) {
			if (c[x][i] < minn) {
				y = i;
				minn = c[x][i];
			}
		}
		//cout << x << " " << y << "\n";
		cout << c[x][y] << "\n";
	}
	return 0;
}
/*
�Ұ� CCF�� 
*/
