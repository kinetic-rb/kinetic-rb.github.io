#include <bits/stdc++.h>
using namespace std;
int n, m, k, a[200005];
int dist[200005];
struct EDGE {
	int u, v, w, next;
} e[200005];
int head[200005], ecnt;
void add(int u, int v, int w) {
	ecnt++;
	e[ecnt].u = u;
	e[ecnt].v = v;
	e[ecnt].w = w;
	e[ecnt].next = head[u];
	head[u] = ecnt;
}
struct Node {
	int id, num;
	const operator <(const Node&b) const {
		if (b.num == num) {
			return b.id < id;
		}
		return b.num < num;
	}
};
bool vis[200005];
void dijkstra(int st) {
	for (int i = 1; i <= n; i++) {
		vis[i] = 0;
	}
	priority_queue<Node> q;
	q.push((Node){st, 0});
	while (!q.empty()) {
		int id = q.top().id;
		int num = q.top().num;
		if (vis[id]) {
			continue;
		}
		vis[id] = 0;
		for (int i = head[id]; i != 0; i = e[i].next) {
			int v = e[i].v;
			int w = e[i].w;
			w = w - a[id];
			if (dist[id] + w < dist[v]) {
				dist[v] = dist[id] + w;
				q.push((Node){v, dist[v]});
			}
		}
	}
}
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= m; i++) {
		int u, v;
		cin >> u >> v;
		add(u, v, a[u] + a[v]);
		add(v, u, a[u] + a[v]);
	}
	while (k--) {
		int u, v;
		cin >> u >> v;
		dijkstra(u);
		cout << u + v << "\n";
	}
	return 0;
}
