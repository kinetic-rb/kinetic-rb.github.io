#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[3000]={0},ans=0;
bool b[3000]={0};
vector<int>v[3000];
void dfs(int z,int st,int ds,int last,long long s){
	if(st>k)return;
	if(ds>4)return;
	for(int i=0;i<v[z].size();i++){
		int nx=v[z][i];
		if(ds==4&&nx==1){
			ans=max(ans,s);	
			continue;
		}
		if(!b[nx]){
			b[nx]=1;
			dfs(nx,0,ds+1,z,s+a[nx]);
			b[nx]=0;
		}
		if(nx!=last&&st<k)dfs(nx,st+1,ds,z,s);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>a[i];
	}
	for(int i=0;i<m;i++){
		int x,y;
		cin>>x>>y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	b[1]=1;
	dfs(1,0,0,1,0);
	cout<<ans;
	return 0;
}

