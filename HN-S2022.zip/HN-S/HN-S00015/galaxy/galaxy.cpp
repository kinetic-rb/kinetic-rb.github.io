#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int a,b,c;
bool ba[1005][1005]={0},bb[1005][1005]={0};
bool bp[10005]={0};
int cds[10005]={0},rds[10005]={0};
bool check(){
	for(int i=1;i<=n;i++)
		if(cds[i]>1||(cds[i]==0&&rds[i]==0)){
			return false;
		}
	return true;	
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++){
		cin>>a>>b;
		cds[a]++;
		rds[b]++;
		ba[a][b]=1;
		bb[a][b]=1;
	}
	cin>>q;
	for(int i=0;i<q;i++){
		cin>>a;
		if(a==1){
			cin>>b>>c;
			if(ba[b][c])cds[b]--;
			if(ba[b][c])rds[c]--;
			ba[b][c]=0;
		}else if(a==2){
			cin>>b;
			for(int i=1;i<=n;i++){
				if(ba[b][i])rds[i]--;
				ba[b][i]=0;
			}
			cds[b]=0;
		}else if(a==3){
			cin>>b>>c;
			if(!ba[b][c])cds[b]++;
			if(!ba[b][c])rds[c]++;
			ba[b][c]=1;
		}else if(a==4){
			cin>>b;
			for(int i=1;i<=n;i++){
				if(bb[b][i]&&!ba[b][i]){
					ba[b][i]=1;
					rds[i]++;
					cds[b]++;
				}		
			}
		}
		if(check())cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}



