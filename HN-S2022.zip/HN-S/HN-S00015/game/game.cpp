#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a[100010],b[100010];
long long c[1001][1001];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=0;i<n;i++)cin>>a[i];
	for(int i=0;i<m;i++)cin>>b[i];
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++)c[i][j]=a[i]*b[j];
	}
	for(int i=0;i<q;i++){
		long long lx,rx,ly,ry,mins=-1e18,maxs=1e18,x=0,y=0;
		cin>>lx>>rx>>ly>>ry;
		for(int j=lx-1;j<rx;j++){
			long long mi=1e18;
			for(int k=ly-1;k<ry;k++){
				mi=min(mi,c[j][k]);
			}
			if(mi>mins){
				mins=mi;
				x=j;
			}
		}
		for(int j=ly-1;j<ry;j++){
			if(c[x][j]<maxs){
				maxs=c[x][j];
				y=j;
			}
		}
		cout<<c[x][y]<<endl;
	}
	return 0;
}

