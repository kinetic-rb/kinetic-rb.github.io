#include<bits/stdc++.h>
#define gc getchar 
#define uLL long long
using namespace std;
const int N=2505,M=1e4+5,INF=1e9;
const uLL INFL=5e18;
int read()
{
	int o=0;
	char c=gc();
	while(c>'9'||c<'0') c=gc();
	while(c<='9'&&c>='0')
	{
		o=(o<<3)+(o<<1)+c-'0';
		c=gc();
	}
	return o;
}
uLL readll()
{
	uLL o=0;
	char c=gc();
	while(c>'9'||c<'0') c=gc();
	while(c<='9'&&c>='0')
	{
		o=(o<<3)+(o<<1)+c-'0';
		c=gc();
	}
	return o;
}
int n,m,k,es=0;
int h[N],dis[N][N];
bool g[N][N],vis[N][2];
uLL a[N];
struct edge
{
	int en,next;
}e[M<<1];
void ineg(int st,int en)
{
	es++;
	e[es].en=en;
	e[es].next=h[st];
	h[st]=es;
}
struct dote
{
	int i,dis;
};
bool operator <(dote x,dote y)
{
	if(x.dis!=y.dis) return x.dis>y.dis;
	return x.i>y.i;
}
void dij(int st)
{
	priority_queue<dote> q;
	memset(vis,0,sizeof(vis));
	dis[st][st]=0;
	dote sd;
	sd.i=st;
	sd.dis=0;
	q.push(sd);
	while(!q.empty())
	{
		int o=q.top().i;
		q.pop();
		if(vis[o][0]||dis[st][o]>k) continue;
		vis[o][0]=1;
		for(int i=h[o];i;i=e[i].next)
		{
			int to=e[i].en;
			if((!vis[to][0])&&dis[st][to]>dis[st][o]+1)
			{
				dis[st][to]=dis[st][o]+1;
				sd.i=to;
				sd.dis=dis[st][to];
				q.push(sd);
			}
		}
	} 
} 
uLL ans=-1;
int s[N][3];
void sol()
{
	for(int i=2;i<=n;i++)
	{
		if(!g[1][i]) continue;
		for(int j=2;j<=n;j++)
			if(g[i][j])
			{
				if(a[i]>a[s[j][1]])
				{
					s[j][2]=s[j][1];
					s[j][1]=i;
				}
				else if(a[i]>a[s[j][2]]) s[j][2]=i;
			}
	}
	for(int i=2;i<=n;i++)
	{
		if(s[i][1]==1) continue;
		for(int j=2;j<=n;j++)
			if(g[i][j]&&s[j][1]!=1)
			{
				uLL sum=a[i]+a[j];
				if(s[j][1]==i) continue;
				if(s[i][1]==j)
				{
					ans=max(ans,sum+a[s[i][2]]+a[s[j][1]]);
					continue;
				}
				if(s[i][1]==s[j][1])
				{
					ans=max(ans,sum+max(a[s[i][2]]+a[s[j][1]],a[s[i][1]]+a[s[j][2]]));
					continue;
				}
				ans=max(ans,sum+a[s[i][1]]+a[s[j][1]]);
			}
	}
} 
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	m=read();
	k=read();
	a[1]=-INFL;
	for(int i=2;i<=n;i++) a[i]=readll();
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			g[i][j]=0;
			dis[i][j]=INF;
		}
		h[i]=0;
	}
	for(int i=1;i<=m;i++)
	{
		int in1=read(),in2=read();
		ineg(in1,in2);
		ineg(in2,in1);
		g[in1][in2]=g[in2][in1]=1;
	}
	if(k)
	{
		k++;
		for(int i=1;i<=n;i++)
		{
			dij(i);
			for(int j=1;j<=n;j++)
				if(i!=j&&dis[i][j]<=k) g[i][j]=1; 
		}
	}
	for(int i=1;i<=n;i++) s[i][1]=s[i][2]=1;
	sol();
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
