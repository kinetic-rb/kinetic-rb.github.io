#include<bits/stdc++.h>
#define gc getchar
#define LL long long
#define Pa printf("%lld\n",ans)
#define P0 printf("0\n")
#define Con continue
using namespace std;
const int N=1e5+5,INF=1e9+5;
int read()
{
	int o=0,f=1;
	char c=gc();
	while(c>'9'||c<'0')
	{
		if(c=='-') f=-1;
		c=gc();
	}
	while(c<='9'&&c>='0')
	{
		o=(o<<3)+(o<<1)+c-'0';
		c=gc();
	}
	return o*f;
}
struct tree
{
	int l,r,mid;
	int zax,zin,fax,fin;
	bool hz,hf,hl;
}ta[N<<2],tb[N<<2];
tree emp; 
int a[N],b[N];
tree merge(tree o,tree x,tree y)
{
	o.hf=x.hf|y.hf;
	o.fax=max(x.fax,y.fax);
	o.fin=min(x.fin,y.fin);
	o.hz=x.hz|y.hz;
	o.zax=max(x.zax,y.zax);
	o.zin=min(x.zin,y.zin);
	o.hl=x.hl|y.hl;
	return o;
}
void builda(int o,int l,int r)
{
	ta[o]=emp;
	ta[o].l=l;
	ta[o].r=r;
	if(l==r)
	{
		if(a[l]>0)
		{
			ta[o].hz=1;
			ta[o].zax=ta[o].zin=a[l];
		}
		if(a[l]<0)
		{
			ta[o].hf=1;
			ta[o].fax=ta[o].fin=-a[l];
		}
		if(a[l]==0) ta[o].hl=1;
		return;
	}
	int mid=(l+r)>>1;
	ta[o].mid=mid;
	builda(o<<1,l,mid);
	builda((o<<1)|1,mid+1,r);
	ta[o]=merge(ta[o],ta[o<<1],ta[(o<<1)|1]);
}
void buildb(int o,int l,int r)
{
	tb[o]=emp;
	tb[o].l=l;
	tb[o].r=r;
//	cout<<l<<' '<<r<<endl;
//	cout<<tb[o].l<<' '<<tb[o].r<<endl;
	if(l==r)
	{
		if(b[l]>0)
		{
			tb[o].hz=1;
			tb[o].zax=tb[o].zin=b[l];
		}
		if(b[l]<0)
		{
			tb[o].hf=1;
			tb[o].fax=tb[o].fin=-b[l];
		}
		if(b[l]==0) tb[o].hl=1;
		return;
	}
	int mid=(l+r)>>1;
	tb[o].mid=mid;
	buildb(o<<1,l,mid);
	buildb((o<<1)|1,mid+1,r);
	tb[o]=merge(tb[o],tb[o<<1],tb[(o<<1)|1]);
}
tree xw(tree t[],int o,int l,int r)
{
//	cout<<o<<' '<<t[o].l<<' '<<t[o].r<<endl;
	if(t[o].l>=l&&t[o].r<=r) return t[o];
	tree u=emp;
	if(l<=t[o].mid) u=merge(u,u,xw(t,o<<1,l,r));
	if(r>t[o].mid) u=merge(u,u,xw(t,(o<<1)|1,l,r));
	return u;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	emp.hz=emp.hf=emp.hl=0;
	emp.zax=emp.fax=0;
	emp.zin=emp.fin=INF;
	int n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	builda(1,1,n);
	buildb(1,1,m);
	for(int i=1;i<=q;i++)
	{
		int l1=read(),r1=read(),l2=read(),r2=read();
		LL ans;
		tree o1=xw(ta,1,l1,r1),o2=xw(tb,1,l2,r2);
//		cout<<0<<endl;
		int f1=(o1.hf<<2)+(o1.hl<<1)+(o1.hz),f2=(o2.hf<<2)+(o2.hl<<1)+(o2.hz),f=(f1<<3)+f2;
		if(f1==2||f2==2)
		{
			P0;
			Con;
		}
		if(f1==3)
		{
			if(f2==1)
			{
				ans=(LL)o1.zax*o2.zin;
				Pa;
				Con;
			}
			P0;
			Con;
		}
		if(f2==3)
		{
			if(f1==4)
			{
				ans=(LL)-1*o1.fin*o2.zax;
				Pa;
				Con;
			}
			P0;
			Con;
		}
		if(f1==6)
		{
			if(f2==4)
			{
				ans=(LL)o1.fax*o2.fin;
				Pa;
				Con;
			}
			P0;
			Con;
		}
		if(f2==6)
		{
			if(f1==1)
			{
				ans=(LL)-1*o1.zin*o2.fax;
				Pa;
				Con;
			}
			P0;
			Con;
		}
		if(f1==1)
		{
			if(f2==1)
			{
				ans=(LL)o1.zax*o2.zin;
				Pa;
				Con;
			}
			ans=(LL)-1*o1.zin*o2.fax;
			Pa;
			Con;
		}
		if(f2==4)
		{
			ans=(LL)o1.fax*o2.fin;
			Pa;
			Con;
		}
		if(f2==1)
		{
			if(f1==4)
			{
				ans=(LL)-1*o1.fin*o2.zax;
				Pa;
				Con;
			}
			ans=(LL)o1.zax*o2.zin;
			Pa;
			Con;
		}
		if(f1==4)
		{
			ans=(LL)-1*o1.fin*o2.zax;
			Pa;
			Con;
		}
		if(f1==7)
		{
			P0;
			Con;
		}
		LL sum1=(LL)o1.fin*o2.zax,sum2=(LL)o1.zin*o2.fax;
		ans=-min(sum1,sum2);
		Pa;
	}
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
