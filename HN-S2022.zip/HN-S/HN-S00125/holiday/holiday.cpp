#include<bits/stdc++.h>
using namespace std;
int o,q,n,m,k,p[10001],z=1,x,i,j,s1[202]={0},maxi=0,a[5001][5001];
struct so{
	int pts;
	int node;
}s[201];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout); 
	cin>>n>>m>>k;
	for(i=2;i<=n;i++){
		cin>>p[i];
		s[i].pts=p[i];
		s[i].node=1;
	}
	p[1]=0;
	for(i=1;i<=m;i++){
		cin>>o>>q;
		a[o][q]=1;
		a[q][o]=1;
	}
	if(k==0){
		for(i=1;i<n;i++){
			for(j=i+1;j<=n;j++){
				if(a[i][j]==1&&s[i].node<4){
					if(s[j].pts>=s[i].pts+p[j]){
					}
					else{
						s[j].pts=s[i].pts+p[j];
						s[j].node=s[i].node+1;
						maxi=max(maxi,s[j].pts);
					}
				}
			}
		}
		cout<<maxi;
	}
	if(k>=0){
		for(x=1;x<=n/k;x++){
			int o=x*k;
			for(i=o+1;i<=2*o;i++){
				for(j=i+1;j<=i+1+k;j++){
					if(s[j].pts+1>=s[i].pts+p[j]){
						s[j].pts=s[j].pts;
					}
					else if(s[i].pts+p[j]>s[j].pts-1){
						if(s[i].node<4){
							s[j].node=max(x+1,s[i].node+1);
							s[j].pts=s[i].pts+p[j];
						}
						else{
							s[j].pts=s[j].pts;
						}
					} 
					maxi=max(maxi,s[j].pts);
			}
			}
		}
	}
	cout<<maxi;
	return 0;
} 
