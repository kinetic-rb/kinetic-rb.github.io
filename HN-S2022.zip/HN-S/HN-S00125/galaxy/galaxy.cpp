#include<bits/stdc++.h>
using namespace std;
int a[5000][5000]={0};
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q,t,s,u,v;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		a[u][v]=1;
	}
	cin>>q;
	for(int h=1;h<=q;h++){
		cin>>t;
		if(t==1){
			cin>>u>>v;
			a[u][v]=2;
		}
		if(t==2){
			cin>>u;
				for(int y=1;y<=n;y++){
					if(a[u][y]==1){
						a[u][y]=2;
					}
				if(a[y][u]==1){
					a[y][u]=2;
				}
			}
		}
		if(t==3){
			cin>>u>>v;
			a[u][v]=1;
		}
		if(t==4){
			cin>>u;
				for(int y=1;y<=n;y++){
					if(a[u][y]==2){
						a[u][y]=1;
					}
				if(a[y][u]==2){
					a[y][u]=1;
				}
			}
		}
		for(int x=1;x<=n;x++){
			s=0;
			for(int y=1;y<=n;y++){
				if(a[x][y]==1){
					s++;
				}
				if(s>1){
					u=1;
				}
			}
		}
		if(u!=1){
			u=0;
		for(int x=1;x<=n;x++){
			for(int y=1;y<=n;y++){
				if(a[x][y]==1&&a[y][x]==1){
					int u=1;
				}
			}
		}
		if(u!=1){
			cout<<"NO"<<endl;
		}
		else{
			cout<<"YES"<<endl;
		}
	}
}
	return 0;
}
