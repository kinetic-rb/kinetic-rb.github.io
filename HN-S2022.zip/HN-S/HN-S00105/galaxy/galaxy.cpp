#include<bits/stdc++.h>
using namespace std;
int main(){
//付宇翔HN-00105
  freopen("galaxy.in","open","R");
  freopen("galaxy.out","out","W");
	return 0;
}