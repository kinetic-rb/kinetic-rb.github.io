#include<bits/stdc++.h>
using namespace std;
int main(){
//付宇翔HN-S0015
  freopen("game.in","open","R");
  freopen("game.out","out","W");
	return 0;
}