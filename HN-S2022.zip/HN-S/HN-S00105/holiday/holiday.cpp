#include<bits/stdc++.h>
using namespace std;
int main(){
//付宇翔HN-S0015
  freopen("holiday.in","open","R");
  freopen("holiday.out","out","W");
  int n,m,k;
  cin>>n>>m>>k;
  
  return 0;
}