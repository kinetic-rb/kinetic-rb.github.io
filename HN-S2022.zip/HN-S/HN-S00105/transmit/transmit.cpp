#include<bits/stdc++.h>
using namespace std;
int main(){
//付宇翔HN-S00105
  freopen("transmit.in","open","R");
  freopen("transmit.out","out","W");
	return 0;
}