#include<bits/stdc++.h>
using namespace std;
int jingdian[3000],s[100001],e[100001];
int visit(int start,int k){
	int maxx=0,flag;
	for(int l=0;l<k;l++){
		for(int i=0;i<2500;i++){
			start=flag;
			if(s[i]==start) start=e[i];
			if(jingdian[start]>maxx){
				maxx=jingdian[start];
				flag=start;
			}
		}
	}
	return flag; 
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k,q=4;
	int start=1,sum=0;
	cin>>n>>m>>k;
	for(int i=0;i<n;i++){
		cin>>jingdian[i];
	}
	for(int i=0;i<m;i++){
		cin>>s[i]>>e[i];
	}
	while(q--){
		start=visit(start,k);
		sum+=jingdian[start];
	}
	cout<<sum;
	fclose(stdin);
	fclose(stdout);	
	return 0;
} 


