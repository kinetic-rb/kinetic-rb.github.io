#include<bits/stdc++.h>
using namespace std;
int a[1000000],b[1000000];
bool z(int l,int r,char x){
	for(int i=l;i<=r;i++){
		if(x=='a'){	
			if(a[i]>0) return true;
		}else if(x=='b'){
			if(b[i]>0) return true;
		} 	
	}
	return false;
}
bool f(int l,int r,char x){
	for(int i=l;i<=r;i++){
		if(x=='a'){	
			if(a[i]<0) return true;
		}else if(x=='b'){
			if(b[i]<0) return true;
		}
	}
	return false;
}
bool zero(int l,int r,char x){
	for(int i=l;i<=r;i++){
		if(x=='a'){	
			if(a[i]==0) return true;
		}else if(x=='b'){
			if(b[i]==0) return true;
		}
	}
	return false;
}
int maxx(int l,int r,char x){
	int maxn=-1;
	if(x=='a'){
		for(int i=l;i<=r;i++){
			maxn=max(maxn,a[i]);
		}
	}else if(x=='b'){
		for(int i=l;i<=r;i++){
			maxn=max(maxn,b[i]);
		}
	}
	return maxn;
}
int minn(int l,int r,char x){
	int maxn=100000;
	if(x=='a'){
		for(int i=l;i<=r;i++){
			maxn=min(maxn,a[i]);
		}
	}else if(x=='b'){
		for(int i=l;i<=r;i++){
			maxn=min(maxn,b[i]);
		}
	}
	return maxn;
}
int absminn(int l,int r,char x){
	int maxn=1000000;
	if(x=='a'){
		for(int i=l;i<=r;i++){
			if(abs(maxn)>abs(a[i])){
				maxn=a[i];
			}
		}
	}else if(x=='b'){
		for(int i=l;i<=r;i++){
			if(abs(maxn)>abs(b[i])){
				maxn=b[i];
			}
		}
	}
	return maxn;
}
int absmaxx(int l,int r,char x){
	int maxn=-1;
	if(x=='a'){
		for(int i=l;i<=r;i++){
			if(abs(maxn)>abs(a[i])){
				maxn=a[i];
			}
		}
	}else if(x=='b'){
		for(int i=l;i<=r;i++){
			if(abs(maxn)>abs(b[i])){
				maxn=b[i];
			}
		}
	}
	return maxn;
}
int game(int l1,int r1,int l2,int r2){
	char a='a',b='b';
	if(z(l1,r1,a)&&f(l1,r1,a)&&zero(l1,r1,a)&&f(l2,r2,b))  return 0;
	if(z(l1,r1,a)&&f(l1,r1,a)&&zero(l1,r1,a)&&!f(l2,r2,b))  return maxx(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&f(l1,r1,a)&&!zero(l1,r1,a)&&!f(l2,r2,b))  return maxx(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&f(l1,r1,a)&&f(l2,r2,b)&&z(l2,r2,b))  return abs(absminn(l1,r1,a))*absminn(l2,r2,b);
	if(z(l1,r1,a)&&!f(l2,r2,b))  return maxx(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&!f(l1,r1,a)&&!zero(l1,r1,a)&&f(l2,r2,b))  	return minn(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&!f(l1,r1,a)&&!zero(l1,r1,a)&&!f(l2,r2,b))  	return maxx(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&!f(l1,r1,a)&&!f(l2,r2,b)&&zero(l1,r1,a))  	return maxx(l1,r1,a)*minn(l2,r2,b);
	if(z(l1,r1,a)&&!f(l1,r1,a)&&f(l2,r2,b)&&zero(l1,r1,a))  	return 0;
	if(!z(l1,r1,a)&&!zero(l1,r1,a)&&!z(l2,r2,b)&&!zero(l2,r2,b))	return minn(l1,r1,a)*maxx(l2,r2,b);
	if(!z(l1,r1,a)&&!zero(l1,r1,a)&&!f(l2,r2,b))  	return maxx(l1,r1,a)*minn(l2,r2,b);
	if(!z(l1,r1,a)&&!f(l1,r1,a))	return 0;
	return 0;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,cnt1=0;
	int l1,r1,l2,r2;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	for(int i=0;i<q;i++){
		cin>>l1>>r1>>l2>>r2;
		cout<<game(l1,r1,l2,r2)<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
