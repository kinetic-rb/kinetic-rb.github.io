#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int m,n;
	cin>>n>>m
	for(int i=0;i<m;i++){
		cin>>n;
	}
	cin>>m;
	for(int i=0;i<m;i++){
		cout<<"NO";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

