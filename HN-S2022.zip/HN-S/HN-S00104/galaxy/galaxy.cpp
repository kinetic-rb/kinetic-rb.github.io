#include<bits/stdc++.h>
#include<vector>
using namespace std;
struct edge{
	int v,type;
	edge(int v=-1,int type=-1): v(v),type(type){}
};
vector<edge>e[500003];
int out[500003];
bool vis[500003];
int n,m,q;
void adg(int u,int v){
	e[u].push_back(edge(v,1));
	out[u]++;
}
void del(int u,int v){
	int len=e[u].size();
	for(int i=0;i<len;i++){
		edge j=e[u][i];
		if(j.v==v){
			e[u][i].type=0;
//			E[i][u].type=0;
			out[u]--;
			return;
		}
	}
}
void delt(int u){
	for(int i=1;i<=n;i++){
		int len=e[i].size();
		for(int j=0;j<len;j++){
			if(e[i][j].v==u&&e[i][j].type){
				e[i][j].type=0;
				out[i]--;
			}
		}
	}
}
void ins(int u,int v){
	int len=e[u].size();
	for(int i=0;i<len;i++){
		edge j=e[u][i];
		if(j.v==v){
			e[u][i].type=1;
			out[u]++;
			return;
		}
	}
}
void inst(int u){
	for(int i=1;i<=n;i++){
		int len=e[i].size();
		for(int j=0;j<len;j++){
			if(e[i][j].v==u&&!e[i][j].type){
				e[i][j].type=1;
				out[i]++;
			}
		}
	}
}
bool flag;
void dfs(int u,int fa){
	for(edge v:e[u]){
		if(vis[v.v]==1){
			flag=1;
			return;
		}
		vis[v.v]=1;
		if(!flag)dfs(v.v,u);
	}
}
bool check(){
//	for(int i=1;i<=n;i++){
//		cout<<out[i]<<' ';
//	}cout<<'\n';
	for(int i=1;i<=n;i++){
		if(out[i]!=1){
			return 0;
		}
	}
	for(int i=1;i<=n;i++){
		dfs(i,-1);
		if(!flag)return 0;
		flag=0;
		for(int j=1;j<=n;j++)vis[j]=0;
	}
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m;
	for(int i=1,u,v;i<=m;i++){
		cin>>u>>v;
		adg(u,v);
	}
	cin>>q;
	while(q--){
		int t,u,v;
		cin>>t>>u;
		if(t==1){
			cin>>v;
			del(u,v);
//		cout<<"AA\n";
		}else if(t==2){
			delt(u);
//		cout<<"FF\n";
		}else if(t==3){
			cin>>v;
			ins(u,v);
//		cout<<"XL\n";
		}else{
			inst(u);
//		cout<<"XY\n";
		}
		if(check())cout<<"YES\n";
		else cout<<"NO\n";
//		cout<<"WW\n";
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2

*/
