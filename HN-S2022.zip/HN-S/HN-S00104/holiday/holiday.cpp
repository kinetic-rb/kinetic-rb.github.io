#include<bits/stdc++.h>
#include<vector>
#define pb push_back
#define mp make_pair
#define fi first
#define se second
using namespace std;
int a[2503];
vector<int>e[2503];
int n,m,k,ans,mxa,mxb;
int vis[2503],vis_nta[2503],in[2503];
pair<int,int>stk[10];int top;
bool check(int u,int N){
	for(int i=1;i<=N;i++){
		if(u==stk[i].fi){
			return 1;
		}
	}
	return 0;
}
int sum(int N){
	int suM=0;
	for(int i=1;i<=N;i++){
		suM+=stk[i].se;
	}
	return suM;
}
void dfs(int u,int fa,int step){
	if(step>5)return;
	if(step==5&&u==1){
		ans=max(ans,stk[1].se+stk[2].se+stk[3].se+stk[4].se);
		return;
	}
	for(int v:e[u]){
		if(!check(v,top)){
			stk[++top]=mp(v,a[v]);
			dfs(v,u,step+1);
			top--;
		}
	}
}
void dfs_sto(int u,int fa,int step,int dur){
	if(step>5)return;
	if(dur >k)return;
	if(step==5&&u==1){
		ans=max(ans,stk[1].se+stk[2].se+stk[3].se+stk[4].se);
//		cerr<<ans<<'\n';
		return;
	}
	if(step<5&&sum(top)+mxb*(4-step)<ans)return;
	for(int v:e[u]){
		if(!check(v,top)){
			stk[++top]=mp(v,a[v]);
			memset(vis,0,sizeof vis);
			dfs_sto(v,u,step+1,0);
			top--;
		}
		
		if(!vis[v]){
			vis[v]=1;
			dfs_sto(v,u,step,dur+1);
		}
	}
}
void dfs_nta(int u){
	for(int v:e[u]){
		if(!vis_nta[v]){
			vis_nta[v]=1;
			dfs_nta(v);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>a[i];
		mxb=max(mxb,a[i]);
	}
	for(int i=1,x,y;i<=m;i++){
		cin>>x>>y;
		e[x].pb(y);
		e[y].pb(x);
		in[x]=1,in[y]=1; 
	}
	int f=0;
	for(int i=1;i<=n;i++){
		if(!in[i]){
			f=1;
			break;
		}
	}
	if(!f){
		if(k>n-1){
			sort(a+1,a+n+1,greater<int>());
			cout<<a[1]+a[2]+a[3]+a[4];
			return 0;
		}
		if(k==0){
			dfs(1,-1,0);
			cout<<ans;
			return 0;
		}
		dfs_sto(1,-1,0,0);
		cout<<ans;
		return 0;
	}else{
		int cnt=0;
		cerr<<"WHY DID CCF MAKE THIS???";
		dfs_nta(1);
		for(int i=1;i<=n;i++){
			if(vis_nta[i]){
				cnt++;
				mxa=max(mxa,a[i]);
			}
		}
		mxb=mxa;
		if(k>cnt-1){
			sort(a+1,a+n+1,greater<int>());
			cout<<a[1]+a[2]+a[3]+a[4];
			return 0;
		}
		if(k==0){
			dfs(1,-1,0);
			cout<<ans;
			return 0;
		}
		dfs_sto(1,-1,0,0);
		cout<<ans;
		return 0;
	}
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

*/
