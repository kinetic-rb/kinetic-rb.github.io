#include<bits/stdc++.h>

using namespace std;
int a[100003],b[100003];
int main(){
	int l1,r1,l2,r2,n,m,q;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	while(q--){
		cin>>l1>>r1>>l2>>r2;
		long long maxn=-1e18-3;
		for(int i=l1;i<=r1;i++){
			long long minn=1e18+3;
			for(int j=l2;j<=r2;j++){
				minn=min(minn,1ll*a[i]*b[j]);
			}
			maxn=max(maxn,minn);
		}
		cout<<maxn<<'\n';
	}
	return 0;
}

