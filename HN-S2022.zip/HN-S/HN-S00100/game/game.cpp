#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <assert.h>
#define int long long

const int maxn = 1e5 + 5, INF = 0x3f3f3f3f3f3f3f3f;

int n, m, q, a[maxn], b[maxn];

namespace segtree
{
	#define ls(x) ((x) << 1)
	#define rs(x) ((x) << 1 | 1)
	
	struct node
	{
		int lv, rv;
		
		node()
		{
			lv = -INF;
			rv = INF;
		}
	}tr[maxn << 2];
	
	void push_up(int u)
	{
		if(tr[ls(u)].lv > tr[rs(u)].lv)		tr[u].lv = tr[ls(u)].lv;
		else								tr[u].lv = tr[rs(u)].lv;
		
		if(tr[ls(u)].rv < tr[rs(u)].rv)		tr[u].rv = tr[ls(u)].rv;
		else								tr[u].rv = tr[rs(u)].rv;
	}
	
	inline void build(int u, int l, int r)
	{
		if(l == r)
		{
			if(a[l] == 0)
			{
				tr[u].lv = tr[u].rv = 0;
				return;
			}
			
			if(a[l] > 0)	tr[u].rv = a[l], tr[u].lv = -INF;
			if(a[l] < 0)	tr[u].lv = a[l], tr[u].rv = INF; 
			
			return;
		}
		
		int mid = l + r >> 1;
		build(ls(u), l, mid);
		build(rs(u), mid + 1, r);
		
		push_up(u);
	}
	
	inline node upd(node &x, node &y)
	{
		node res;
		
		if(x.lv > y.lv)		res.lv = x.lv;
		else				res.lv = y.lv;
		
		if(x.rv < y.rv)		res.rv = x.rv;
		else				res.rv = y.rv;
		
		return res;
	}
	
	node query(int u, int l, int r, int L, int R)
	{
		if(L <= l && r <= R)
			return tr[u];
		
		int mid = l + r >> 1;
		node r1, r2;
		
		if(L <= mid)	r1 = query(ls(u), l, mid, L, R);
		if(R > mid)		r2 = query(rs(u), mid + 1, r, L, R);
		
		return upd(r1, r2);
	}
}

int lg[maxn], mxB[maxn][21], mnB[maxn][21], mxA[maxn][21], mnA[maxn][21];
namespace ST
{
	void init()
	{
		for(int i = 2; i <= std::max(n, m); ++i)
			lg[i] = lg[i >> 1] + 1;
		
		for(int i = 1; i <= lg[n]; ++i)
			for(int j = 1; j + (1 << i) - 1 <= n; ++j)
			{
				mxA[j][i] = std::max(mxA[j][i - 1], mxA[j + (1 << i - 1)][i - 1]);
				mnA[j][i] = std::min(mnA[j][i - 1], mnA[j + (1 << i - 1)][i - 1]);
			}
		
		for(int i = 1; i <= lg[m]; ++i)
			for(int j = 1; j + (1 << i) - 1 <= m; ++j)
			{
				mxB[j][i] = std::max(mxB[j][i - 1], mxB[j + (1 << i - 1)][i - 1]);
				mnB[j][i] = std::min(mnB[j][i - 1], mnB[j + (1 << i - 1)][i - 1]);
			}
	}
	
	int qry_mxA(int L, int R)
	{
		int len = lg[R - L + 1];
		return std::max(mxA[L][len], mxA[R - (1 << len) + 1][len]);
	}
	
	int qry_mnA(int L, int R)
	{
		int len = lg[R - L + 1];
		return std::min(mnA[L][len], mnA[R - (1 << len) + 1][len]);
	}
	
	int qry_mxB(int L, int R)
	{
		int len = lg[R - L + 1];
		return std::max(mxB[L][len], mxB[R - (1 << len) + 1][len]);
	}
	
	int qry_mnB(int L, int R)
	{
		int len = lg[R - L + 1];
		return std::min(mnB[L][len], mnB[R - (1 << len) + 1][len]);
	}
}

signed main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	memset(mnA, 0x3f, sizeof(mnA));
	memset(mnB, 0x3f, sizeof(mnB));
	memset(mxA, -0x3f, sizeof(mxA));
	memset(mxB, -0x3f, sizeof(mxB));
	
	
	scanf("%lld%lld%lld", &n, &m, &q);
	
	for(int i = 1; i <= n; ++i)
	{
		scanf("%lld", a + i);
		mxA[i][0] = mnA[i][0] = a[i];
	}
	
	for(int i = 1; i <= m; ++i)
	{
		scanf("%lld", b + i);
		mxB[i][0] = mnB[i][0] = b[i];
	}
	
	ST::init();
	segtree::build(1, 1, n);
	
	for(int i = 1, l1, r1, l2, r2; i <= q; ++i)
	{
		scanf("%lld%lld%lld%lld", &l1, &r1, &l2, &r2);
		
		int mxB = ST::qry_mxB(l2, r2),
			mnB = ST::qry_mnB(l2, r2),
			mxA = ST::qry_mxA(l1, r1),
			mnA = ST::qry_mnA(l1, r1),
			res = -INF, res1;
		
		if(mnB >= 0)
		{
			res1 = std::min(mxA * mnB, mxA * mxB);
			res = std::max(res, res1);
		}
		
		if(mxB <= 0)
		{
			res1 = std::min(mnA * mnB, mnA * mxB);
			res = std::max(res, res1);
		}
		
		
		segtree::node tmp = segtree::query(1, 1, n, l1, r1);
		
		if(tmp.lv == -INF)
		{
			res = std::max(res, std::min(tmp.rv * mnB, tmp.rv * mxB));
		}
		
		if(tmp.rv == INF)
		{
			res = std::max(res, std::min(tmp.lv * mxB, tmp.lv * mnB));
		}
		
		if(tmp.lv != -INF && tmp.rv != INF)
		{
			int tmp1 = std::min(tmp.lv * mxB, tmp.lv * mnB);
			int tmp2 = std::min(tmp.rv * mnB, tmp.rv * mxB); 
			res = std::max(res, std::max(tmp1, tmp2));
		}
			
		
		printf("%lld\n", res);
	}
	
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

*/
