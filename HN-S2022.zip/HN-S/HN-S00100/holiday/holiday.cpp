#include <cstdio>
#include <algorithm>
#define int long long

const int maxn = 2505, maxm = 1e4 + 5;

struct node
{
	int to, nxt;
}edge[maxm << 1];
int head[maxn], cnt = 1, n, m, k, w[maxn], ans, lim[5];

inline void add(int u, int v)
{
	edge[++cnt] = {v, head[u]};
	head[u] = cnt;
}

bool vis[maxn];
void dfs(int u, int st, int cg, int sum)
{
	if(cg == 4 && u == 1)
	{
		ans = std::max(ans, sum);
		return;
	}
	
	if(sum + lim[4 - cg] <= ans)
		return;
	
	if(cg == 4 && st > k)
		return;
	
	for(int i = head[u]; i; i = edge[i].nxt)
	{
		int v = edge[i].to;
		
		if(st <= k)		dfs(v, st + 1, cg, sum);
		if(cg < 4 && !vis[u])
		{
			vis[u] = 1;
			dfs(v, 1, cg + 1, sum + w[u]);
			vis[u] = 0;
		}		
	}
}

int tmp[maxn];
signed main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	scanf("%lld%lld%lld", &n, &m, &k);
	for(int i = 2; i <= n; ++i)
	{
		scanf("%lld", w + i);
		tmp[i] = w[i];
	}
		
	std::sort(tmp + 1, tmp + n + 1);
	for(int i = 1; i <= 4; ++i)
		lim[i] = lim[i - 1] + tmp[n - i + 1];
	
	for(int i = 1, x, y; i <= m; ++i)
	{
		scanf("%lld%lld", &x, &y);
		add(x, y);
		add(y, x);
	}
	
	vis[1] = 1;
	dfs(1, 0, 0, 0);
	
	printf("%lld", ans);
	
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

20 50 100



*/
