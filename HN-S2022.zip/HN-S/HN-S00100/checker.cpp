#include <iostream>

int main()
{
	for(int i = 1; ; ++i)
	{
		printf("now %d:\n", i);
		
		system("maker.exe");
		system("baoli.exe");
		system(".exe");
		
		if(system("fc .out .ans"))
		{
			puts("WA!");
			return 0;
		} 
		
		puts("AC!");
	}
	
	return 0;
}

