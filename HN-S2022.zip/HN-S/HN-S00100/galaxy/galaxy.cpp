#include <cstdio>
#include <algorithm>
#include <vector>
#include <stack>
#include <cstring>

const int maxn = 1e3 + 5;

std::vector<int> edge[maxn], rev[maxn];
int head[maxn], cnt = 1, n, m, q, out[maxn], ocnt;
bool mp[maxn][maxn];

bool vis[maxn], ab[maxn];
int dfn[maxn], low[maxn], dfn_cnt, res, clr[maxn], scccnt, sz[maxn];
std::stack<int> st;
void tarjan(int u)
{
	dfn[u] = low[u] = ++dfn_cnt;
	st.push(u);
	vis[u] = 1;
	
	for(auto v : edge[u])
	{
		if(!mp[u][v])	continue;
		
		if(!dfn[v])
		{
			tarjan(v);
			low[u] = std::min(low[u], low[v]);
		}
		else if(vis[v])
			low[u] = std::min(low[u], dfn[v]);
		
		if(sz[clr[v]] > 1 || ab[v])
			res = ab[u] = 1;
	}
	
	if(low[u] == dfn[u])
	{
		++scccnt;
		int tmp;
		
		do
		{
			tmp = st.top();
			st.pop();
			
			clr[tmp] = scccnt;
			++sz[scccnt];
			vis[tmp] = 0;
		}while(tmp != u);
		
		if(sz[u] > 1)
			res = ab[u] = 1;
	}
}

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for(int i = 1, u, v; i <= m; ++i)
	{
		scanf("%d%d", &u, &v);
		++out[u];
		mp[u][v] = 1;
		edge[u].push_back(v);
		rev[v].push_back(u);
	}
	
	for(int i = 1; i <= n; ++i)
		if(out[i] == 1)
			++ocnt;
	
	scanf("%d", &q);
	
	int t, u, v;
	while(q--)
	{
		scanf("%d", &t);
		
		if(t == 1)
		{
			scanf("%d%d", &u, &v);
			mp[u][v] = 0;
			if(out[u] == 1)	--ocnt;
			--out[u];
			if(out[u] == 1)	++ocnt;
		}
		
		if(t == 2)
		{
			scanf("%d", &u);
			for(auto v : rev[u])
			{
				if(!mp[v][u])	continue;
				mp[v][u] = 0;
				if(out[v] == 1)	--ocnt;
				--out[v];
				if(out[v] == 1)	++ocnt;
			}
		}
		
		if(t == 3)
		{
			scanf("%d%d", &u, &v);
			mp[u][v] = 1;
			if(out[u] == 1)	--ocnt;
			++out[u];
			if(out[u] == 1)	++ocnt;
		}
		
		if(t == 4)
		{
			scanf("%d", &u);
			for(auto v : rev[u])
			{
				if(mp[v][u])	continue;
				mp[v][u] = 1;
				if(out[v] == 1)	--ocnt;
				++out[v];
				if(out[v] == 1)	++ocnt;
			}
		}/*
		printf("    ");
		for(int i = 1; i <= n; ++i)
		printf("%d ", out[i]);puts("");*/
		
		if(ocnt != n)
			puts("NO");
		else
		{
			for(int i = 1; i <= n; ++i)
				if(out[i] == 0)
				{
					puts("NO");
					continue;
				}
			
			
			memset(low, 0, sizeof(low));
			memset(dfn, 0, sizeof(dfn));
			memset(clr, 0, sizeof(clr));
			memset(sz, 0, sizeof(sz));
			memset(ab, 0, sizeof(ab));
			scccnt = 0;
			dfn_cnt = 0;
			
			for(int i = 1; i <= n; ++i)
				if(!dfn[i])
				{
					res = 0;
					
					tarjan(i);
					if(res == 0)
					{
						puts("NO");
						goto nxt;
					}
				}
					
			puts("YES");
			
			nxt:;
		}
	}
	
	return 0;
}

/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2


*/
