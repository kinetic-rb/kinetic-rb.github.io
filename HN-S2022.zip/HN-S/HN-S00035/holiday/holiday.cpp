#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()

{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k,map;
	cin>>n>>m>>k;
	int arr[n - 1];
	int a = 0;
	for(int i = 0; i < n - 1; i++)
	{
		cin>>a;
		arr[i] = a;
	}
	
	
	for(int j = 0; j < n; j++)
	{
		for(int z = 0; z < n - j; z++)
		{
			if(arr[z - 1] > arr[z])
			{
				map = arr[z];
				arr[z] = arr[z - 1];
				arr[z - 1] = map;
			}
		}
    }
	int zong = arr[n] + arr[n - 1] + arr[n - 2] + arr[n - 3];
	cout<<zong<<endl;
	return(0);
}
	
	
	
	
	
