#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()

{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int arr[1];
	
	return(0);
}
	
	
