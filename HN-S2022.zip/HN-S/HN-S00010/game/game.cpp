#include <bits/stdc++.h>
using namespace std;
long m,n,q;
long long A[100005],B[100005];
long long Amxz=-1,Amnz=114514810,Amxf=-114514810,Amnf=1,Bmx=-114514810,Bmn=114514810;
bool f1=0,f2=0,f3=0;
long long ans;
long long t1,t2;
long long ans1,ans2,ans3,ans4;
long long ans5=0;
long long l1,l2,r1,r2;
int main(){
	freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++){
    	cin>>A[i];
	}
	for(int i=1;i<=m;i++){
		cin>>B[i];
	}
    for(int i=1;i<=q;i++){
    	Amxz=-1;
		Amnz=114514810;
		Amxf=-114514810;
		Amnf=1;
		Bmx=-114514810;
		Bmn=114514810;
    	f1=0;
    	f2=0;
    	f3=0;
    	cin>>l1>>r1>>l2>>r2;
    	for(int j=l1;j<=r1;j++){
    		if(A[j]>=Amxz && A[j]>0) Amxz=A[j];
    		if(A[j]<=Amnz && A[j]>0) Amnz=A[j];
    		if(A[j]>=Amxf && A[j]<0) Amxf=A[j];
    		if(A[j]<=Amnf && A[j]<0) Amnf=A[j];
    		if(A[j]==0)  f1=1;
		}
		for(int j=l2;j<=r2;j++){
    		if(B[j]>=Bmx) Bmx=B[j];
    		if(B[j]<=Bmn) Bmn=B[j];
		}
		if(Amxz>0){
			f2=1;
			ans1=Amxz*Bmn;
			ans2=Amnz*Bmn;
		}
		if(f1){
			ans5=0;
		}
		if(Amxf<0){
			f3=1;
			ans3=Amxf*Bmx;
			ans4=Amnf*Bmx;
		}
		if(f1) ans=0;
		if(f2){
			if(ans1>=ans2){
				t1=ans1;
			}
			else{
				t1=ans2;
			}
			if(t1>=ans || (!f1)){
				ans=t1;
			}
		}
		if(f3){
			if(ans3>=ans4){
				t2=ans3;
			}
			else{
				t2=ans4;
			}
			if(t2>=ans || (!f1 && !f2)) ans=t2;
		}
		cout<<ans<<endl;
	}
	return 0;
}
