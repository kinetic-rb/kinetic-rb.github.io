#include <bits/stdc++.h>
using namespace std;
long n,m,k;
struct obj{
	int xyz;
	int cnts;
};
struct node{
	vector <int> q1;
}roa[2505];
long a[2505]={0};
long long ansmx=-114514;
long long ans=0;
vector <int> v; 
bool check(int fi,int cnt3){
    queue <obj> q;
    int dir;
    q.push((obj){fi,cnt3});
    while(!q.empty()){
    	if(q.front().cnts>k){
    		return false;
		}
    	dir=q.front().xyz;
    	for(int i=0;i<roa[dir].q1.size();i++){
    		if(roa[dir].q1[i]==1) {
    			return true;
			}
    		q.push((obj){roa[dir].q1[i],q.front().cnts+1});
		}
		q.pop();
	}
}
void dfs(int fi,int cnt1,int cnt2){
	long long t;
	if(cnt1==4){
		if(fi==1 || check(fi,cnt2)){
			if(ans>=ansmx){
				ansmx=ans;
			}
		}
	}
	else{
		if(cnt2==k){
			for(int i=0;i<roa[fi].q1.size();i++){
				if(fi==1 && cnt1==0 && cnt2==0){
					dfs(roa[fi].q1[i],0,0);
					continue;
				}
				else if(a[fi]==0){
				    break;
				} 
				ans+=a[fi];
				t=a[fi];
				a[fi]=0;
				v.push_back(fi);
		        dfs(roa[fi].q1[i],cnt1+1,0);
		        v.pop_back();
		        a[fi]=t;
		        ans-=a[fi];
			}
		}
		else{
		    for(int i=0;i<roa[fi].q1.size();i++){
				if(a[fi]!=0){
		    	    ans+=a[fi];
		    	    t=a[fi];
				    a[fi]=0;
				    v.push_back(fi);
		    	    dfs(roa[fi].q1[i],cnt1+1,0);
		    	    v.pop_back();
		    	    a[fi]=t;
		    	    ans-=a[fi];
		    }
		    	//ת�� 
		    	dfs(roa[fi].q1[i],cnt1,cnt2+1);
			}
		} 
	}
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    int x,y;
    cin>>n>>m>>k;
    for(int i=2;i<=n;i++){
    	cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		roa[x].q1.push_back(y);
		roa[y].q1.push_back(x);
	}
	dfs(1,0,0);
	cout<<ansmx;
	return 0;
}
