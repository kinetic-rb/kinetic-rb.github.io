#include<math.h>
#include<stdio.h>
#include<string.h>
#include<algorithm>

const int N=1e5+5,inf=0x7f7f7f7f;

inline int read()
{
	int v=0,flag=0;char ch=getchar();
	while('0'>ch||ch>'9') flag|=ch=='-',ch=getchar();
	while('0'<=ch&&ch<='9') v=v*10+(ch&15),ch=getchar();
	return flag? -v:v;
}

int q;

struct Sequence
{
	int n;
	int val[N][2],sum[N];
	int ST[N][20][4];

	inline void Init()
	{
		for(int i=1;i<=n;i++)
		{
			int x=read();
			if(x>0) val[i][1]=+x;
			if(x<0) val[i][0]=-x;
			sum[i]=sum[i-1]+!x;
		}
		
		for(int i=1;i<=n;i++) ST[i][0][0]=val[i][1];
		for(int j=1;(1<<j)<=n;j++)
			for(int i=1;i<=n-(1<<j)+1;i++)
				ST[i][j][0]=std::max(ST[i][j-1][0],ST[i+(1<<j-1)][j-1][0]);

		for(int i=1;i<=n;i++) ST[i][0][1]=val[i][1]? val[i][1]:inf;
		for(int j=1;(1<<j)<=n;j++)
			for(int i=1;i<=n-(1<<j)+1;i++)
				ST[i][j][1]=std::min(ST[i][j-1][1],ST[i+(1<<j-1)][j-1][1]);

		for(int i=1;i<=n;i++) ST[i][0][2]=val[i][0];
		for(int j=1;(1<<j)<=n;j++)
			for(int i=1;i<=n-(1<<j)+1;i++)
				ST[i][j][2]=std::max(ST[i][j-1][2],ST[i+(1<<j-1)][j-1][2]);

		for(int i=1;i<=n;i++) ST[i][0][3]=val[i][0]? val[i][0]:inf;
		for(int j=1;(1<<j)<=n;j++)
			for(int i=1;i<=n-(1<<j)+1;i++)
				ST[i][j][3]=std::min(ST[i][j-1][3],ST[i+(1<<j-1)][j-1][3]);
	}

	inline int Ask(int L,int R,int type)
	{
		if(type==4) return sum[R]-sum[L-1];

		int p=log2(R-L+1);
		if(type&1) return std::min(ST[L][p][type],ST[R-(1<<p)+1][p][type]);
		else return std::max(ST[L][p][type],ST[R-(1<<p)+1][p][type]);
	}
}A,B;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);

	A.n=read(),B.n=read(),q=read();
	A.Init(),B.Init();

	while(q--)
	{
		int l1=read(),r1=read(),l2=read(),r2=read();

		int tmp;
		long long ans=-0x7f7f7f7f7f7f7f7f;

		if(A.Ask(l1,r1,0))
		{
			if(tmp=B.Ask(l2,r2,2)) ans=std::max(ans,-1ll*tmp*A.Ask(l1,r1,1));
			else if(tmp=B.Ask(l2,r2,4)) ans=std::max(ans,0ll);
			else ans=std::max(ans,1ll*A.Ask(l1,r1,0)*B.Ask(l2,r2,1));
		}

		if(A.Ask(l1,r1,2))
		{
			if(tmp=B.Ask(l2,r2,0)) ans=std::max(ans,-1ll*tmp*A.Ask(l1,r1,3));
			else if(tmp=B.Ask(l2,r2,4)) ans=std::max(ans,0ll);
			else ans=std::max(ans,1ll*A.Ask(l1,r1,2)*B.Ask(l2,r2,3));
		}

		if(A.Ask(l1,r1,4)) ans=std::max(ans,0ll);

		printf("%lld\n",ans);
	}

	return 0;
}
//100pts
