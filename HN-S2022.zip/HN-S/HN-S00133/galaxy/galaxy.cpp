#include<stdio.h>
#include<string.h>

const int N=1e3+5;

inline int read()
{
	int v=0,flag=0;char ch=getchar();
	while('0'>ch||ch>'9') flag|=ch=='-',ch=getchar();
	while('0'<=ch&&ch<='9') v=v*10+(ch&15),ch=getchar();
	return flag? -v:v;
}

int n,m,q;
int to[N][N];

int cnt,first[N],nxt[N*10],ver[N*10];
inline void add(int u,int v) {ver[++cnt]=v,nxt[cnt]=first[u],first[u]=cnt;}

int deg[N],num;
inline void inc(int x,int val)
{
	if(deg[x]==1) num--;
	deg[x]+=val;
	if(deg[x]==1) num++;
}

int able[N];

inline void dfs(int x,int dis)
{
	if(dis>n) return able[x]=1,void();
	for(int i=first[x],p;i;i=nxt[i])
	if(to[x][p=ver[i]]==1)
	{
		if(able[p]) return able[x]=1,void();
		dfs(p,dis+1);
		if(able[p]) return able[x]=1,void();
	}
}

inline int chk()
{
	if(num^n) return 0;

	memset(able,0,sizeof able);
	for(int i=1;i<=n;i++)
	{
		if(!able[i]) dfs(i,0);
		if(!able[i]) return 0;
	}

	return 1;
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);

	n=read(),m=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		to[u][v]=1,inc(u,1),add(u,v);
	}

	q=read();
	while(q--)
	{
		int opt=read(),u=read();
		if(opt==1) to[u][read()]=-1,inc(u,-1);
		if(opt==2)
		{
			for(int i=1;i<=n;i++)
			if(to[i][u]==1) to[i][u]=-1,inc(i,-1);
		}
		if(opt==3) to[u][read()]=1,inc(u,1);
		if(opt==4)
		{
			for(int i=1;i<=n;i++)
			if(to[i][u]==-1) to[i][u]=1,inc(i,1);
		}

		puts(chk()? "YES":"NO");
	}

	return 0;
}
//40pts
