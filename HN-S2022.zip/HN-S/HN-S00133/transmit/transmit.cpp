#include<stdio.h>
#include<string.h>
#include<algorithm>

const int N=2e5+5;

inline int read()
{
	int v=0,flag=0;char ch=getchar();
	while('0'>ch||ch>'9') flag|=ch=='-',ch=getchar();
	while('0'<=ch&&ch<='9') v=v*10+(ch&15),ch=getchar();
	return flag? -v:v;
}

int n,q,k,a[N];

#define findson(x) for(int i=first[x],p;i;i=nxt[i]) if((p=to[i])^fa[x])

int cnt,first[N],nxt[N<<1],to[N<<1];
inline void add(int u,int v)
{
	to[++cnt]=v,nxt[cnt]=first[u],first[u]=cnt;
	to[++cnt]=u,nxt[cnt]=first[v],first[v]=cnt;
}

int fa[N],son[N],top[N];
int dep[N],sz[N];
long long sum[N];

inline void dfs1(int x)
{
	dep[x]=dep[fa[x]]+(sz[x]=1),sum[x]=sum[fa[x]]+a[x];
	findson(x)
	{
		fa[p]=x,dfs1(p),sz[x]+=sz[p];
		son[x]=sz[son[x]]>sz[p]? son[x]:p;
	}
}

inline void dfs2(int x,int _top)
{
	top[x]=_top;
	if(son[x]) dfs2(son[x],_top);
	findson(x) if(p^son[x]) dfs2(p,p);
}

inline int lca(int x,int y)
{
	while(top[x]^top[y])
	if(dep[top[x]]>dep[top[y]]) x=fa[top[x]];
	else y=fa[top[y]];

	return dep[x]<dep[y]? x:y;
}

inline long long Ask(int x,int y) {return sum[x]+sum[y]-sum[lca(x,y)];}

int seq[N];
long long f[N];
inline void Get(int x,int y,int len)
{
	int cnt1=0,cnt2=len+1;
	while(dep[x]>dep[y]) seq[++cnt1]=x,x=fa[x];
	while(dep[y]>dep[x]) seq[--cnt2]=y,y=fa[y];
	while(x^y)
	{
		seq[++cnt1]=x,x=fa[x];
		seq[--cnt2]=y,y=fa[y];
	}
	seq[++cnt1]=x;
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);

	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<n;i++) add(read(),read());

	dfs1(1),dfs2(1,1);

	if(k==1) while(q--) printf("%lld\n",Ask(read(),read()));
	else
	{
		while(q--)
		{
			int x=read(),y=read();
			int len=dep[x]+dep[y]-dep[lca(x,y)];
			Get(x,y,len);
			for(int i=1;i<=len;i++) f[i]=0x7f7f7f7f7f7f;
			f[1]=a[seq[1]];
			for(int i=1;i<=len;i++)
				for(int j=i+1;j<=std::min(len,i+k);j++)
					f[j]=std::min(f[j],f[i]+a[seq[j]]);
			printf("%lld\n",f[len]);
		}
	}

	return 0;
}
//16pts
