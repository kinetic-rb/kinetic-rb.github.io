#include<stdio.h>
#include<string.h>
#include<algorithm>

typedef long long ll;
const int N=2505;

inline ll read()
{
	ll v=0,flag=0;char ch=getchar();
	while('0'>ch||ch>'9') flag|=ch=='-',ch=getchar();
	while('0'<=ch&&ch<='9') v=v*10+(ch&15),ch=getchar();
	return flag? -v:v;
}

int n,m,k;
int dis[N][N];
ll val[N],ans;

int cnt,first[N],nxt[N<<8],to[N<<8];
inline void add(int u,int v)
{
	to[++cnt]=v,nxt[cnt]=first[u],first[u]=cnt;
	to[++cnt]=u,nxt[cnt]=first[v],first[v]=cnt;
}

inline void dfs(int level,int now,int c1,int c2,int c3,int c4)
{
	if(level==5)
	{
		ans=std::max(ans,val[c1]+val[c2]+val[c3]+val[c4]);
		return;
	}

	for(int i=2;i<=n;i++)
	if(dis[now][i]<=k&&i^c1&&i^c2&&i^c3&&i^c4)
	{
		if(level==1) dfs(level+1,i,i,c2,c3,c4);
		else if(level==2) dfs(level+1,i,c1,i,c3,c4);
		else if(level==3) dfs(level+1,i,c1,c2,i,c4);
		else if(level==4) if(dis[i][1]<=k) dfs(level+1,i,c1,c2,c3,i);
	}
}

int vis[N],que[N],head,tail;
inline void bfs(int s)
{
	vis[s]=que[head=tail=1]=s,dis[s][s]=0;

	while(head<=tail)
	{
		int x=que[head++];
		
		for(int i=first[x],p;i;i=nxt[i])
		if(vis[p=to[i]]^s)
		{
			vis[que[++tail]=p]=s;
			dis[s][p]=dis[s][x]+1;
		}
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);

	memset(dis,0x3f,sizeof dis);

	n=read(),m=read(),k=read()+1;
	for(int i=2;i<=n;i++) val[i]=read();

	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		add(u,v);
	}
	for(int i=1;i<=n;i++) bfs(i);

	dfs(1,1,0,0,0,0);

	printf("%lld",ans);

	return 0;
}
//70pts
