#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long a[1005],b[1005],c[1005][1005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	while(q--){
		int z,x,p,v;
		scanf("%d%d%d%d",&z,&x,&p,&v);
		long long op=-0x3f3f3f3f3f3f3f;
		for(int i=z;i<=x;i++){
			long long lp=0x3f3f3f3f3f3f3f;
			for(int j=p;j<=v;j++){
				if(lp>c[i][j]){
					lp=c[i][j];
				}
			}
			if(op<lp){
				op=lp;
			}
		}
		cout<<op<<endl;
	}
	return 0;
}
