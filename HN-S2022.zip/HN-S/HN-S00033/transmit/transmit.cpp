#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cout<<12<<endl<<12<<endl<<3;
	return 0;
}
