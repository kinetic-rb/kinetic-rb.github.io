#include<bits/stdc++.h>//˼·�������Ҫ������ֵ�����ȣ������ÿ���㵽��һ��������·�����������Ҫ��ʱ�����ܹ��ĵ�����ֵ�Ƕ��� 
using namespace std;
int n,m,k,b[305][305],lp[305];
long long a[1005];
long long dp[305][305];
inline int dfs(int x,long long ans,int op){
	if(op==4){
		if(dp[1][x]<ans){
			dp[1][x]=ans;
		}
		return 0;
	}
	for(int l=2;l<=n;++l){
		if(lp[l]==0&&b[x][l]<=k+1){
			lp[l]=1;
			op++;
			dfs(l,ans+a[l],op);
			op--;
			lp[l]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(b,0x3f3f3f3f3f3f,sizeof(b));
	memset(dp,0,sizeof(dp));
	memset(lp,0,sizeof(lp));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	int x[305],y[305];
	for(int i=1;i<=m;++i){
		scanf("%d%d",&x[i],&y[i]);
		b[x[i]][y[i]]=b[y[i]][x[i]]=1;
		for(int j=1;j<=n;++j){
			if(b[y[i]][j]!=0x3f3f3f3f3f3f3f){
				b[x[i]][j]=b[j][x[i]]=min(b[x[i]][j],b[x[i]][y[i]]+b[y[i]][j]);
			}
		}
		for(int j=1;j<=n;++j){
			if(b[x[i]][j]!=0x3f3f3f3f3f3f3f){
				b[y[i]][j]=b[j][y[i]]=min(b[y[i]][j],b[y[i]][x[i]]+b[x[i]][j]);
			}
		}
	}
	for(int i=m;i>=1;--i){
		b[x[i]][y[i]]=b[y[i]][x[i]]=1;
		for(int j=1;j<=n;++j){
			if(b[y[i]][j]!=0x3f3f3f3f3f3f3f){
				b[x[i]][j]=b[j][x[i]]=min(b[x[i]][j],b[x[i]][y[i]]+b[y[i]][j]);
			}
		}
		for(int j=1;j<=n;++j){
			if(b[x[i]][j]!=0x3f3f3f3f3f3f3f){
				b[y[i]][j]=b[j][y[i]]=min(b[y[i]][j],b[y[i]][x[i]]+b[x[i]][j]);
			}
		}
	}
	for(int i=m;i>=1;--i){
		b[x[i]][y[i]]=b[y[i]][x[i]]=1;
		for(int j=1;j<=n;j++){
			if(b[y[i]][j]!=0x3f3f3f3f3f3f3f){
				b[x[i]][j]=b[j][x[i]]=min(b[x[i]][j],b[x[i]][y[i]]+b[y[i]][j]);
			}
		}
		for(int j=1;j<=n;++j){
			if(b[x[i]][j]!=0x3f3f3f3f3f3f3f){
				b[y[i]][j]=b[j][y[i]]=min(b[y[i]][j],b[y[i]][x[i]]+b[x[i]][j]);
			}
		}
	}
	dfs(1,0,0);
    long long op=0;
    for(int i=2;i<=n;++i){
    	if(op<dp[1][i]&&b[i][1]<=k+1){
    		op=dp[1][i];
		}
	}
	printf("%lld",op);
	return 0;
} 
