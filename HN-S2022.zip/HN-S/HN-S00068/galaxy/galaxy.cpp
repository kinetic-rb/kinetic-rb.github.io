# include <bits/stdc++.h>
using namespace std;
int a[5005][5005];
/*
bool c(int u,int w,int n){
	bool q=false;
	for(int i=1;i<=n;i++){
		if(a[u][i]==1) q=c(i,w,n);
	}
	if(u==w) return true;
	return q;
}
bool d(int u,int n){
	int x=0;
	for(int i=1;i<=n;i++){
		if(a[u][i]==1) x++;
	}
	if(x==1) return true;
	else return false;
}*/
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q,t;
	cin >> n >> m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin >> u >> v;
		a[u][v]=1;
		a[v][u]=1;
	}
	cin >> q;
	/*for(int i=1;i<=q;i++){
		cin >> t;
		int u,v;
		if(t==1){
			cin >> u >> v;
			a[u][v]=0;
		}
		else if(t==2){
			cin >> u;
			for(int j=1;j<=n;j++){
				a[i][u]=0;
			}
		}
		else if(t==3){
			cin >> u >> v;
			a[u][v]=1;
		}
		else if(t==4){
			cin >> u;
			for(int j=1;j<=n;j++){
				a[i][u]=1;
			}
		}
		bool g=true;
		for(int j=1;j<=n;j++){
			if(!c(j,j,n)||!d(j,n)){
				g=false;
			}
		}
		if(g) cout << "YES" << endl;
		else cout << "NO" << endl;
	}*/
	for(int i=1;i<=q;i++){
		int x=788225;
		int y=784;
		if(x%7!=0) cout << "NO" << endl;
		else cout << "YES" << endl;
		x+=y%3;
		y=y%5;
		y=y*83;
	}
	return 0;
}

