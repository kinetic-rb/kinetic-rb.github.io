# include <bits/stdc++.h>
using namespace std;
int a[2505],b[2505][2505],vis[2505];
int f(int s,int e,int n,int k){
	int q=0,p=0;
	if(s==e) return a[s];
	for(int i=1;i<=n;i++){
		if(b[i][s]==1&&k>=1){
			q+=f(i,e,n,k-1);
			p=max(p,q);
		}
	}
	return p;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	cin >> n >> m >> k;
	a[1]=0;
	for(int i=2;i<=n;i++){
		cin >> a[i];
	}
	int x,y;
	for(int i=1;i<=m;i++){
		cin >> x >> y;
		b[x][y]=1;
		b[y][x]=1;
	}
	int maxx=0,next,ans=0;
	for(int i=1;i<=n;i++){
		maxx=max(maxx,f(1,i,n,k));
	}
	for(int i=1;i<=n;i++){
		if(f(1,i,n,k)==maxx){
			vis[i]=1;
			next=i;
			ans+=maxx;
			maxx=0;
		} 
	}
	for(int i=1;i<=n;i++){
		if(vis[i]!=1) maxx=max(maxx,f(next,i,n,k));
	}
	for(int i=1;i<=n;i++){
		if(f(next,i,n,k)==maxx){
			vis[i]=1;
			next=i;
			ans+=maxx;
			maxx=0;
		} 
	}
	for(int i=1;i<=n;i++){
		if(vis[i]!=1) maxx=max(maxx,f(next,i,n,k));
	}
	for(int i=1;i<=n;i++){
		if(f(next,i,n,k)==maxx){
			next=i;
			ans+=maxx;
			maxx=0;
		} 
	}
	cout << ans;
	return 0;
}

