# include <bits/stdc++.h>
using namespace std;
long long a[100005],b[100005],c[100005][100005];
long long choose_Q(long long b[],long long l2,long long r2,long long l){
	long long minn=100001;
	for(int i=l2;i<=r2;++i){
		minn=min(minn,c[l][i]);
	}
	for(int i=l2;i<=r2;++i){
		if(c[l][i]==minn){
			return i;
		}
	}
}
long long choose_L(long long a[],long long b[],long long l1,long long r1,long long l2,long long r2){
	long long maxx=-100001;
	for(int i=l1;i<=r1;++i){
		maxx=max(maxx,c[i][choose_Q(b,l2,r2,i)]);//Qxiaobiao
	}
	return maxx;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	long long l1,r1,l2,r2;
	cin >> n >> m >> q;
	for(int i=1;i<=n;++i){
		cin >> a[i];
	}
	for(int i=1;i<=m;++i){
		cin >> b[i];
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;++i){
		cin >> l1 >> r1 >> l2 >> r2;
		cout << choose_L(a,b,l1,r1,l2,r2) << endl;
	}
	return 0;
}

