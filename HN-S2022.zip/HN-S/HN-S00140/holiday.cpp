#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2560;
int read()
{
	int xq=0,fq=1;
	char ch=getchar();
	while(!isdigit(ch)) fq=ch=='-'?-1:1,ch=getchar();
	while(isdigit(ch)) xq=(xq<<1)+(xq<<3)+(ch^48),ch=getchar();
	return xq*fq;
}
int n,m,k;
int a[11451],b[maxn],ans,tot,top,x,y;
int head[maxn*4],nxt[maxn*4],son[maxn*4];
int head1[maxn*4],nxt1[maxn*4],son1[maxn*4];
void add1(int x,int y)
{
	nxt1[++top]=head1[x];
	head1[x]=top;
	son1[top]=y;
	//printf("x%lld %lld %lld\n",x,y,son[top]);
}
void add(int x,int y)
{
	nxt[++top]=head[x];
	head[x]=top;
	son[top]=y;
	//printf("x%lld %lld %lld\n",x,y,son[top]);
}
bool bl[2501][2501],cxk[2568];
map<int,int> mp;
void dfs(int x,int fa,int dep,int now)
{
	if(dep>k)
	{
		return ;
	}//printf("e%lld %lld\n",x,now);
	if(x!=now&&!bl[now][x])
	{
		add(x,now);
		add(now,x);
		//printf("x%lld %lld\n",x,now);
		bl[now][x]=1;
		bl[x][now]=1;
	}
	for(int i=head1[x];i;i=nxt1[i])
	{
		int u=son1[i];
		if(u!=fa)
		{
			dfs(u,x,dep+1,now);
		}
	}
}
void dfsc(int x,int dep,int sum)
{
	
	//printf("%lld %lld %lld\n",x,dep,sum);
	if(dep==4)
	{
		if(bl[x][1])
			ans=max(ans,sum);
		
		return ;
	}
	for(int i=head[x];i;i=nxt[i])
	{
		int u=son[i];
		//printf("yty%lld %lld ",u,x);
		//cout<<cxk[x]<<endl;
		if(cxk[u])
		{
			continue;
		}
		cxk[x]=1;
		dfsc(u,dep+1,sum+a[u]);
		cxk[x]=0;
	}
	
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	k++;//�ڵ��� 
	for(int i=1;i<n;i++)
	{
		a[i+1]=read();
		//printf("=%lld=",ac[i+1]);
	}
	for(int i=1;i<=m;i++)
	{
		x=read();
		y=read();
		add1(x,y);
		add1(y,x);
		//printf("x%lld %lld\n",xc[i],yc[i]);
	}
	for(int i=1;i<=n;i++)
	{
		dfs(i,0,0,i);
	}
	dfsc(1,0,0);
	printf("%lld",ans);
	return 0;
}
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

8 8 1
 9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

*/
