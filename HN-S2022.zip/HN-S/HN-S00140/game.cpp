#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=114514;
int read()
{
	int xq=0,fq=1;
	char ch=getchar();
	while(!isdigit(ch)) fq=ch=='-'?-1:1,ch=getchar();
	while(isdigit(ch)) xq=(xq<<1)+(xq<<3)+(ch^48),ch=getchar();
	return xq*fq;
}
int n,m,k;
int a[114514],b[maxn],ans,tot,top,x,y,amax,amin,bmax,bmin;
bool flag;
map<int,int> mp;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	k=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=m;i++)
	{
		b[i]=read();
		//printf("[%lld]\n ",b[i]);
	}
	
	for(int i=1,l1,r1,l2,r2;i<=k;i++)
	{
		l1=read();
		r1=read();
		l2=read();
		r2=read();
		if(l1==r1&&l2==r2)
		{
			printf("%lld\n",a[l1]*b[l2]);
			continue;
		}
		amax=a[l1];
		amin=a[l1];
		bmax=b[l2];
		bmin=b[l2];
		for(int j=l1;j<=r1;j++)
		{
			amax=max(amax,a[j]);
			amin=min(amin,a[j]);
		}
		for(int j=l2;j<=r2;j++)
		{
			bmax=max(bmax,b[j]);
			bmin=min(bmin,b[j]);
		}
		//printf("ii%lld %lld %lld %lld\n",amax,amin,bmax,bmin);
		if(bmin==0)
		{
			printf("0\n");
			continue;
		}
		if(bmin>0)
		{
			if(amax>=0)
				printf("%lld\n",amax*bmin);
			else
				printf("%lld\n",amax*bmax);
			continue;
		}
		if(bmin<0)
		{
			if(bmax<=0)
			{
				printf("%lld\n",amin*bmax);
				continue;
			}
			else
			{
				if(amax==0||amin==0)
				{
					printf("0\n");
					continue;
				}
				if(amax<0)
				{
					printf("%lld\n",amax*bmax);
					continue;
				}
				if(amin>0)
				{
					printf("%lld\n",amin*bmin);
					continue;
				}
				x=amax,y=amin;
				flag=1;
				for(int j=l1;j<=r1;j++)
				{
					if(a[j]==0)
					{
						printf("0\n");
						flag=0;
						break;
					}
					if(a[j]>0)
					{
						x=min(x,a[j]);
					}
					if(a[j]<0)
					{
						y=max(y,a[j]);
					}
				}
				if(flag)
					printf("%lld\n",max(x*bmin,y*bmax));
			}	
		}	
	}	
	
	return 0;
}
/*
5 5 3
-114514 1919810 233 23 2
1 2 3 -4 -5


6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

*/
