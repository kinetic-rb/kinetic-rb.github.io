#include<bits/stdc++.h>
using namespace std;
#define RI register int
#define int long long 
inline int read() {
	RI x=0,w=0;register char ch=0;
	while(!isdigit(ch)) w|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return w?-x:x;
}
const int MAXN=2e5+1,MAXLOG=20;
int N,Q,K;
int a[MAXN];
vector<int> dian[MAXN];
inline void Add(int x,int y) {
	dian[x].push_back(y);	
}
namespace sub1 {
	int dep[MAXN],depp[MAXN],anc[MAXN][MAXLOG];
	inline void dfs(int x,int fa) {
		dep[x]=dep[fa]+1; anc[x][0]=fa; depp[x]=depp[fa]+a[x];
		for(RI i=1;i<MAXLOG;i++) 
			anc[x][i]=anc[anc[x][i-1]][i-1];
		for(RI i=0;i<dian[x].size();i++) {
			int nx=dian[x][i];
			if(nx==fa) continue ;
			dfs(nx,x);
		}
	}
	inline int LCA(int x,int y) {
		if(dep[x]<dep[y]) swap(x,y);
		for(RI i=MAXLOG-1;i>=0;i--) 
			if(dep[anc[x][i]]>=dep[y]) x=anc[x][i];
		if(x==y) return x;
		for(RI i=MAXLOG-1;i>=0;i--)
			if(anc[x][i]!=anc[y][i]) x=anc[x][i],y=anc[y][i];
		return anc[x][0];
	}	
	inline void sub1() {
		dfs(1,0);
		int x,y;
		while(Q--) {
			x=read(),y=read(); int lca=LCA(x,y);
			printf("%lld\n",depp[x]+depp[y]-depp[lca]-depp[anc[lca][0]]);
		}
	}
}
namespace sub2 {
	int dis[2001][2001],dist[2001][2001],rt;
	inline void dfs(int x,int fa) {
		for(RI i=0;i<dian[x].size();i++) {
			int nx=dian[x][i];
			if(nx==fa) continue ;
			dis[rt][nx]=dis[rt][x]+1;
			dfs(nx,x);
		}
	}
	inline void sub2() {
		for(RI i=1;i<=N;i++) 
			rt=i,dfs(i,0);
		memset(dist,0x3f,sizeof dist);
		for(RI i=1;i<=N;i++) 
			for(RI j=1;j<=N;j++) 
				if(dis[i][j]<=K) dist[i][j]=a[j];
		for(RI k=1;k<=N;k++) 
			for(RI i=1;i<=N;i++) 
				for(RI j=1;j<=N;j++) 
					dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
		int x,y;
		while(Q--) {
			x=read(),y=read();
			printf("%lld\n",dist[x][y]+a[x]);
		}
	}
}
signed main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	N=read(),Q=read(),K=read();
	for(RI i=1;i<=N;i++) a[i]=read();
	int x,y;
	for(RI i=1;i<N;i++) {
		x=read(),y=read();
		Add(x,y),Add(y,x);	
	}
	if(K==1) sub1::sub1();
	else sub2::sub2();
	return 0;
}

