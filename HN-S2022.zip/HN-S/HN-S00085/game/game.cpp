#include<bits/stdc++.h>
using namespace std;
#define RI register int
#define int long long 
inline int read() {
	RI x=0,w=0;register char ch=0;
	while(!isdigit(ch)) w|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return w?-x:x;
}
const int MAXN=1e5+1,MAXLOG=20,INF=1e18;
int N,M,Q;
int maxn0[MAXN][MAXLOG],minn0[MAXN][MAXLOG];
int maxna[MAXN][MAXLOG],minna[MAXN][MAXLOG];
int maxnb[MAXN][MAXLOG],minnb[MAXN][MAXLOG];
int pre[MAXN],pre1[MAXN],pre2[MAXN];
int lg[MAXN];
inline int askmaxna(int l,int r) {
	int k=lg[r-l+1];
	return max(maxna[l][k],maxna[r-(1<<k)+1][k]);
}
inline int askminna(int l,int r) {
	int k=lg[r-l+1];
	return min(minna[l][k],minna[r-(1<<k)+1][k]);
}
inline int askmaxn0(int l,int r) {
	int k=lg[r-l+1];
	return max(maxn0[l][k],maxn0[r-(1<<k)+1][k]);
}
inline int askminn0(int l,int r) {
	int k=lg[r-l+1];
	return min(minn0[l][k],minn0[r-(1<<k)+1][k]);
}
inline int askmaxnb(int l,int r) {
	int k=lg[r-l+1];
	return max(maxnb[l][k],maxnb[r-(1<<k)+1][k]);
}
inline int askminnb(int l,int r) {
	int k=lg[r-l+1];
	return min(minnb[l][k],minnb[r-(1<<k)+1][k]);
}
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	N=read(),M=read(),Q=read(); 
	int x;
	for(RI i=1;i<=N;i++) {
		x=read(); pre[i]=pre[i-1]+(x==0); pre1[i]=pre1[i-1]+(x<0); pre2[i]=pre2[i-1]+(x>0);
		maxna[i][0]=minna[i][0]=x;
		if(x>0) {
			minn0[i][0]=x;
			maxn0[i][0]=-INF;
		}
		else {
			minn0[i][0]=INF;
			maxn0[i][0]=x;
		}
	}
	for(RI i=1;i<=M;i++) maxnb[i][0]=minnb[i][0]=read();
	for(RI i=1;i<MAXLOG;i++) 
		for(RI j=1;j+(1<<i)-1<=N;j++) {
			minn0[j][i]=min(minn0[j][i-1],minn0[j+(1<<i-1)][i-1]);
			maxn0[j][i]=max(maxn0[j][i-1],maxn0[j+(1<<i-1)][i-1]);
			minna[j][i]=min(minna[j][i-1],minna[j+(1<<i-1)][i-1]);
			maxna[j][i]=max(maxna[j][i-1],maxna[j+(1<<i-1)][i-1]);
		}
	for(RI i=1;i<MAXLOG;i++) 
		for(RI j=1;j+(1<<i)-1<=M;j++) {
			maxnb[j][i]=max(maxnb[j][i-1],maxnb[j+(1<<i-1)][i-1]);
			minnb[j][i]=min(minnb[j][i-1],minnb[j+(1<<i-1)][i-1]);
		}
	for(RI i=2;i<=max(N,M);i++) lg[i]=lg[i>>1]+1;
	int l1,r1,l2,r2;
	while(Q--) {
		l1=read(),r1=read(),l2=read(),r2=read();
		int k=askminnb(l2,r2),kk=askmaxnb(l2,r2),ans=-INF;
		if(pre2[r1]>pre2[l1-1]) {
			if(k<0) ans=max(ans,k*askminn0(l1,r1));
			else ans=max(ans,k*askmaxna(l1,r1));
		}
		if(pre1[r1]>pre1[l1-1]) {
			if(kk<0) ans=max(ans,kk*askminna(l1,r1));
			else ans=max(ans,kk*askmaxn0(l1,r1));
		}
		if(pre[r1]>pre[l1-1]) ans=max(ans,0ll);
		printf("%lld\n",ans);
	}
	return 0;
}
//100 pts dont gua!!!
