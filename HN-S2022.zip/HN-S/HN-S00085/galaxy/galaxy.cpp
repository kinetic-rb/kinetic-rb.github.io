#include<bits/stdc++.h>
using namespace std;
#define RI register int
inline int read() {
	RI x=0,w=0;register char ch=0;
	while(!isdigit(ch)) w|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return w?-x:x;
}
const int MAXN=1e5+1;
int N,M,Q;
vector<int> dian[MAXN];
vector<bool> pd[MAXN];
map<pair<int,int>,int> m; 
inline void Add(int x,int y) {
	dian[x].push_back(y);
	pd[x].push_back(1);	
	m[make_pair(x,y)]=dian[x].size()-1;
}
bool vis[MAXN],flag;
int sum[MAXN];
inline void dfs(int x) {
	for(RI i=0;i<dian[x].size();i++) {
		int nx=dian[x][i];
		if(vis[nx] || flag) {flag=1; return ;}	
		vis[nx]=1;
		dfs(nx);
	}
}
inline bool check() {
	memset(sum,0,sizeof sum);
	for(RI i=1;i<=N;i++) 
		for(RI j=0;j<dian[i].size();j++) 
			if(pd[i][j]) sum[dian[i][j]]++; 
	for(RI i=1;i<=N;i++) if(sum[i]!=1) return 0;
	for(RI i=1;i<=N;i++) {	
		flag=0; memset(vis,0,sizeof vis);
		vis[i]=1; 
		dfs(i); if(!flag) return 0;
	}
	return 1;
}
signed main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	N=read(),M=read();
	int opt,x,y;
	for(RI i=1;i<=M;i++) {
		x=read(),y=read();
		Add(y,x);
	}
	Q=read();
	while(Q--) {
		opt=read(),x=read();
		if(opt&1) y=read();
		if(opt==1) pd[y][m[make_pair(y,x)]]=0;
		else if(opt==2) 
			for(RI i=0;i<dian[x].size();i++) pd[x][i]=0;
		else if(opt==3) pd[y][m[make_pair(y,x)]]=1;
		else if(opt==4) 
			for(RI i=0;i<dian[x].size();i++) pd[x][i]=1;
		if(check()) puts("YES");
		else puts("NO");
	}
	return 0;
}

