#include<bits/stdc++.h>
using namespace std;
#define RI register int
#define int long long 
inline int read() {
	RI x=0,w=0;register char ch=0;
	while(!isdigit(ch)) w|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return w?-x:x;
}
const int MAXN=2501;
int N,M,K;
int a[MAXN];
int dis[MAXN][MAXN];
int maxx[MAXN],secmax[MAXN],thdmax[MAXN];
vector<int> dian[MAXN];
inline void Add(int x,int y) {dian[x].push_back(y);}
inline void bfs(int S) {
	queue<int> q; q.push(S);
	while(q.size()) {
		int x=q.front(); q.pop();
		for(RI i=0;i<dian[x].size();i++) {
			int nx=dian[x][i];
			if(dis[S][nx]) continue ;
			dis[S][nx]=dis[S][x]+1;	
			q.push(nx);
		}
	}
}
signed main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	N=read(),M=read(),K=read();
	for(RI i=2;i<=N;i++) a[i]=read();
	int x,y;
	for(RI i=1;i<=M;i++) {
		x=read(),y=read();
		Add(x,y),Add(y,x);
	}
	for(RI i=1;i<=N;i++) bfs(i);	
	for(RI i=2;i<=N;i++) {
		for(RI j=2;j<=N;j++) {
			if(i==j || dis[1][j]>K+1 || dis[i][j]>K+1) continue ;
			if(a[maxx[i]]<a[j]) maxx[i]=j;
			else if(a[secmax[i]]<a[j]) secmax[i]=j;
			else if(a[thdmax[i]]<a[j]) thdmax[i]=j;
		}
	}
	int ans=0;
	for(RI i=2;i<=N;i++) 
		for(RI j=i+1;j<=N;j++) {
			if(dis[i][j]>K+1) continue ;
			if(maxx[i]!=maxx[j] && maxx[i]!=j && maxx[j]!=i && maxx[i] && maxx[j]) ans=max(ans,a[i]+a[j]+a[maxx[i]]+a[maxx[j]]);
			if(secmax[i]!=maxx[j] && secmax[i]!=j && maxx[j]!=i && secmax[i] && maxx[j]) ans=max(ans,a[i]+a[j]+a[secmax[i]]+a[maxx[j]]);
			if(thdmax[i]!=maxx[j] && thdmax[i]!=j && maxx[j]!=i && thdmax[i] && maxx[j]) ans=max(ans,a[i]+a[j]+a[thdmax[i]]+a[maxx[j]]);
			if(maxx[i]!=secmax[j] && maxx[i]!=j && secmax[j]!=i && maxx[i] && secmax[j]) ans=max(ans,a[i]+a[j]+a[maxx[i]]+a[secmax[j]]);
			if(secmax[i]!=secmax[j] && secmax[i]!=j && secmax[j]!=i && secmax[i] && secmax[j]) ans=max(ans,a[i]+a[j]+a[secmax[i]]+a[secmax[j]]);
			if(thdmax[i]!=secmax[j] && thdmax[i]!=j && secmax[j]!=i && thdmax[i] && secmax[j]) ans=max(ans,a[i]+a[j]+a[thdmax[i]]+a[secmax[j]]);
			if(maxx[i]!=thdmax[j] && maxx[i]!=j && thdmax[j]!=i && maxx[i] && thdmax[j]) ans=max(ans,a[i]+a[j]+a[maxx[i]]+a[thdmax[j]]);
			if(secmax[i]!=thdmax[j] && secmax[i]!=j && thdmax[j]!=i && secmax[i] && thdmax[j]) ans=max(ans,a[i]+a[j]+a[secmax[i]]+a[thdmax[j]]);
			if(thdmax[i]!=thdmax[j] && thdmax[i]!=j && thdmax[j]!=i && thdmax[i] && thdmax[j]) ans=max(ans,a[i]+a[j]+a[thdmax[i]]+a[thdmax[j]]);
		}
	cout<<ans;
	return 0;
}
//100 pts dont gua!!!
