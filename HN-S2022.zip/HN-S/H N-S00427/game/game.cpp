#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,p,l1,r1,l2,r2;
	long long a[100086],b[100086],js,pd,pdz,pdzz,num,numz,aaa;
	cin>>n>>m>>p;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=m;i++)cin>>b[i];
	for(int i=1;i<=p;i++)
	{
		cin>>l1>>r1>>l2>>r2;
		numz=-99999999;
		for(int j=l1;j<=r1;j++)
		{
			num=999999999;
			for(int k=l2;k<=r2;k++)
			{
				if(a[j]*b[k]<num)num=a[j]*b[k];
			}
			if(num>numz)numz=num;
		}
	    cout<<numz;
	}
	return 0;
}
