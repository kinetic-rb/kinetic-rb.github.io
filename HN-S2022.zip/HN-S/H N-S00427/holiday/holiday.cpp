#include<bits/stdc++.h>
using namespace std;
int po[2600],ch[2600][2600]={0};
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k,a1,a2;
	cin>>n>>m>>k;
	for(int i=1;i<=n-1;i++)
	{
		cin>>po[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>a1>>a2;
	}
	sort(po+1,po+n);
	cout<<po[n-1]+po[n-2]+po[n-3]+po[n-4];
	
	return 0;
}
