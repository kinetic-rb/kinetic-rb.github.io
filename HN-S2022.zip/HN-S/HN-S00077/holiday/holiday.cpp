#include <bits/stdc++.h>
using namespace std;
struct d{
int r,l;
};
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,k,m,ans=0,f[2500]={0},ls=0;
	cin >> n >> m >> k;
	int a[n+1]={0},hash[n+1]={0}; d b[m+2]={0,0};
	for(int i=2; i<=n; i++){
		cin >> a[i];
		hash[i]=1;
	}
	for(int i=0; i<m; i++){
		cin >> b[i+2].r >> b[i+2].l;
		if(b[i+2].r==1 || b[i+2].l==1){
			f[max(b[i+2].r,b[i+2].l)]=1; ls++;
		}
	}
	int fs=0,x;
	for(int i=0; i<ls; i++){
		int x1=i,fs1=0,fs2=0,js=0;
		if(f[i]){
			f[i]=0;
			while(js<3){
				fs1=0;
				for(int j=0; j<=k; j++){
					for(int q=2; q<m+2; q++){
						if(b[q].r==x && a[b[q].l]>fs1 && hash[b[q].l]==1){
							fs1=a[b[q].l]; x1=b[q].l;
						}else if(b[q].l==x && a[b[q].r]>fs1 && hash[b[q].r]==1){
							fs1=a[b[q].r]; x1=b[q].r;
						}
					}
					x=x1; hash[x1]=0;
				}
				fs2+=fs1;
				js++;
			}
			if(f[x1])fs=max(fs,fs2);
			f[x1]=1;
			for(int i=2; i<=n; i++)hash[i]=1;
		}
	}
	cout <<fs+a[x];
	return 0;
}
