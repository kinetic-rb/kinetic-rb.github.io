#include <bits/stdc++.h>
using namespace std;
long long MAX=-3875820019684212736;
struct game{
	long long l1,r1,l2,r2;
};
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,q;
	cin >> n >> m >> q;
	long long a[n],b[m],c[n][m]; game gm[q];
	for(long long i=0; i<n; i++){
		cin >> a[i];
	}
	for(long long i=0; i<m; i++){
		cin >> b[i];
	}
	for(long long i=0; i<q; i++){
		cin >> gm[i].l1 >> gm[i].r1 >> gm[i].l2 >> gm[i].r2;
	}
	for(long long i=0; i<n; i++){
		for(int j=0; j<m; j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(long long i=0; i<q; i++){
		long long mx=MAX;
		for(long long j=gm[i].l1-1; j<=gm[i].r1-1; j++){
			for(long long k=gm[i].l2-1; k<=gm[i].r2-1; k++){
				if(mx<c[j][k]){
					mx=c[j][k];
				}
			}
		}
		cout << mx << endl;
	}
	return 0;
}
