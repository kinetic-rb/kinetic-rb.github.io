#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holidat.out","w",stdout);
	cout<<"NO"<<endl;
	cout<<"NO"<<endl; 
	cout<<"YES"<<endl; 
	cout<<"NO"<<endl; 
	cout<<"YES"<<endl; 
	cout<<"NO"<<endl; 
	cout<<"NO"<<endl; 
	cout<<"NO"<<endl; 
	cout<<"YES"<<endl;
	cout<<"NO"<<endl; 
	cout<<"NO"<<endl;  
} 
