#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll read()
{
	ll x=0,f=1;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	if(ch=='-') f=-1,ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*f; 
}
const int N=1e6;
ll maxn=999999999999999999,minn=-999999999999999999,maxn1,minn1;
ll a[N],b[N],a1[N],b1[N];
int n,m,q;
int l1,l2,r1,r2;
ll ans;
ll cmp1(ll x,ll y)//��С 
{
	return x>y;
}
void init(ll l1,ll r1,ll l2,ll r2)
{
	maxn=INT_MAX,minn=INT_MIN,maxn1=0,minn1=0;
	memset(a1,0,sizeof(a1));
	memset(b1,0,sizeof(b1));
	int t=1;
	
	for(int i=l1;i<=r1;i++) a1[t]=a[i],t++;
	t=1;
	for(int i=l2;i<=r2;i++) b1[t]=b[i],t++;
	
	sort(b1+1,b1+(r2-l2+2));
	sort(a1+1,a1+(r1-l1+2),cmp1);
	


}
void find()
{
	for(int i=1;i<=r1-l1+1;i++)
	{
		if(a1[i]>=0) maxn=min(a1[i],maxn);//maxn��������Сֵ 
		if(a1[i]<0) minn=max(a1[i],minn);//minn�Ǹ������ֵ 
	}
}
void solve()
{
	init(l1,r1,l2,r2);
	if(b1[1]>=0) ans=a1[1]*b1[1];
	
	else if(b1[r2-l2+1]<=0) ans=a1[r1-l1+1]*b1[r2-l2+1];
	else	
	{
		find();
		maxn1=b1[r2-l2+1],minn1=b1[1];//maxn1�����ֵ��minn1����Сֵ 
		ans=max(maxn*minn1,minn*maxn1);	 
	}
	 cout<<ans<<endl;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	n=read();m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	while(q--)
	{
		l1=read(),r1=read(),l2=read(),r2=read();
		solve();
	}
	
	return 0;
	
 } 

