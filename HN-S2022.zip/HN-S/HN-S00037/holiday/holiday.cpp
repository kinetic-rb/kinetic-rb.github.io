#include<bits/stdc++.h>
using namespace std;
#define ll long long


int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holidat.out","w",stdout);
	cout<<27;
 } 
