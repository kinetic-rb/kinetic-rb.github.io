#include<bits/stdc++.h>
using namespace std;
const int N=1e5+50;
const int INF=1e9+7;
int n,m,q;
int a[N],b[N];
struct Treea {
	int l,r;
	int min1=INF,min2=-INF,max1=-INF,max2=INF;
	void clear() {
		min1=INF,min2=-INF,max1=-INF,max2=INF;
	}
	void print() {
		printf("min+:%d min-:%d max+:%d max-:%d\n",min1,min2,max1,max2);
	}
}tra[N*4];
void update_a(int p) {
	tra[p].max1=max(tra[p<<1].max1,tra[p<<1|1].max1);
	tra[p].max2=min(tra[p<<1].max2,tra[p<<1|1].max2);
	tra[p].min1=min(tra[p<<1].min1,tra[p<<1|1].min1);
	tra[p].min2=max(tra[p<<1].min2,tra[p<<1|1].min2);
}
void build_a(int l,int r,int p) {
	tra[p].l=l,tra[p].r=r;
	if(l==r) {
		tra[p].max1=a[l];
		tra[p].max2=a[l];
		tra[p].min1=(a[l]>=0)?a[l]:(1e9+7);
		tra[p].min2=(a[l]<=0)?a[l]:(-1e9-7);
		return;
	} 
	int mid=l+r>>1;
	build_a(l,mid,p<<1);
	build_a(mid+1,r,p<<1|1);
	update_a(p);
}
Treea ansa;
void query_a(int l,int r,int p) {
	if(tra[p].l>=l&&tra[p].r<=r) {
		ansa.max1=max(ansa.max1,tra[p].max1);
		ansa.max2=min(ansa.max2,tra[p].max2);
		ansa.min1=min(ansa.min1,tra[p].min1);
		ansa.min2=max(ansa.min2,tra[p].min2);
		return;
	}
	int mid=tra[p].l+tra[p].r>>1;
	if(l<=mid) query_a(l,r,p<<1);
	if(r>mid) query_a(l,r,p<<1|1);
}
struct Treeb {
	int l,r;
	int min1=INF,min2=-INF,max1=-INF,max2=INF;
	void clear() {
		min1=INF,min2=-INF,max1=-INF,max2=INF;
	}
	void print() {
		printf("min+:%d min-:%d max+:%d max-:%d\n",min1,min2,max1,max2);
	}
}trb[N*4];
void update_b(int p) {
	trb[p].max1=max(trb[p<<1].max1,trb[p<<1|1].max1);
	trb[p].max2=min(trb[p<<1].max2,trb[p<<1|1].max2);
	trb[p].min1=min(trb[p<<1].min1,trb[p<<1|1].min1);
	trb[p].min2=max(trb[p<<1].min2,trb[p<<1|1].min2);
}
void build_b(int l,int r,int p) {
	trb[p].l=l,trb[p].r=r;
	if(l==r) {
		trb[p].max1=b[l];
		trb[p].max2=b[l];
		trb[p].min1=(b[l]>=0)?b[l]:(1e9+7);
		trb[p].min2=(b[l]<=0)?b[l]:(-1e9-7);
		return;
	} 
	int mid=l+r>>1;
	build_b(l,mid,p<<1);
	build_b(mid+1,r,p<<1|1);
	update_b(p);
}
Treeb ansb;
void query_b(int l,int r,int p) {
	if(trb[p].l>=l&&trb[p].r<=r) {
		ansb.max1=max(ansb.max1,trb[p].max1);
		ansb.max2=min(ansb.max2,trb[p].max2);
		ansb.min1=min(ansb.min1,trb[p].min1);
		ansb.min2=max(ansb.min2,trb[p].min2);
		return;
	}
	int mid=trb[p].l+trb[p].r>>1;
	if(l<=mid) query_b(l,r,p<<1);
	if(r>mid) query_b(l,r,p<<1|1);
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	for(int i=1;i<=m;++i) scanf("%d",&b[i]);
	build_a(1,n,1),build_b(1,m,1);
	while(q--) {
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ansa.clear(),ansb.clear();
		query_a(l1,r1,1),query_b(l2,r2,1);
		if(ansb.max1<0) {
			if(ansa.max2>=0) printf("%lld\n",1ll*ansa.min1*ansb.max2);
			else printf("%lld\n",1ll*ansa.max2*ansb.min2);
		}
		else if(ansb.max2>=0) {
			if(ansa.max1<0) printf("%lld\n",1ll*ansa.min2*ansb.max1);
			else printf("%lld\n",1ll*ansa.max1*ansb.min1);
		}
		else printf("%lld\n",max(1ll*ansa.min1*ansb.max2,1ll*ansa.min2*ansb.max1));
	}
	return 0;
}
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

*/
