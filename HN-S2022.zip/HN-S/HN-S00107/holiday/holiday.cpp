#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2505,M=2e4+5;
int n;
struct Edge {
	int nxt,to;
}e[M];
int head[N],cnt;
void add(int a,int b) {
	e[++cnt].nxt=head[a];
	e[cnt].to=b;
	head[a]=cnt;
}
int d[N][N];
bitset<N> vis,t[N];
priority_queue<pair<int,int> >q;
void dij(int s) {
	while(!q.empty()) q.pop();
	memset(d[s],0x3f,sizeof(d[s]));
	vis=0;
	d[s][s]=0;
	q.push(make_pair(-d[s][s],s)); 
	while(!q.empty()) {
		int t=q.top().second;
		q.pop();
		if(vis[t]) continue;
		vis[t]=1;
		for(int i=head[t];i;i=e[i].nxt) {
			int u=e[i].to;
			if(d[s][t]+1<d[s][u]) d[s][u]=d[s][t]+1,q.push(make_pair(-d[s][u],u));
		}
	}
}
int m,k;
ll a[N];
int p[N];
ll maxx[N],maxxp[N],maxx2[N],maxx2p[N];
ll ans;
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	++k;
	for(int i=2;i<=n;++i) scanf("%lld",&a[i]);
	for(int i=1,x,y;i<=m;++i) scanf("%d%d",&x,&y),add(x,y),add(y,x);
	for(int i=1;i<=n;++i) dij(i);
	for(int i=2;i<=n;++i)
		for(int j=2;j<=n;++j)
			if(d[1][i]<=k&&d[i][j]<=k&&i!=j) {
				if(a[i]+a[j]>=maxx[j]) maxx2p[j]=maxxp[j],maxxp[j]=i,maxx2[j]=maxx[j],maxx[j]=a[i]+a[j];
				else if(a[i]+a[j]>=maxx2[j]) maxx2p[j]=i,maxx2[j]=a[i]+a[j];
			}
	for(int i=2;i<=n;++i)
		for(int j=2;j<=n;++j) {
			if(i==j) continue;
			if(d[i][j]>k) continue;
			if(maxxp[j]==i) continue;
			else if(maxxp[i]==j) continue;
			else if(maxxp[i]==maxxp[j]) ans=max(ans,max(maxx[i]+maxx2[j],maxx[j]+maxx2[i]));
			else ans=max(ans,maxx[i]+maxx[j]);
		}
	printf("%lld\n",ans);
	return 0;
}
