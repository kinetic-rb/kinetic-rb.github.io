#include <bits/stdc++.h>
#define int long long
using namespace std;

ifstream fin("transmit.in");
ofstream fout("transmit.out");

struct node {
	int id;
	int dt;
	vector<int> to,can;
}com[200020];

int n,q,k,x,y,s,t;
int arr[200020],ans=1000000000000000;
bool vis[200020];

void can(int p,int r,int s) {
	if(vis[p]) {
		return;
	}
	vis[p]=true;
	com[s].can.push_back(p);
	if(r==k) {
		return;
	}
	for(int i = 0;i < com[p].to.size();i++) {
		can(com[p].to[i],r+1,s);
	}
	vis[p]=false;
}

void DFS(int p,int v) {
	//cout<<p<<' '<<v<<' '<<ans<<endl;
	if(vis[p]) {
		return;
	}
	if(p==t) {
		ans=min(ans,v+arr[p]);
		return;
	}
	if(v>ans) {
		return;
	}
	vis[p]=true;
	for(int i = 0;i < com[p].can.size();i++) {
		DFS(com[p].can[i],v+arr[p]);
	}
	vis[p]=false;
}

signed main() {
	fin>>n>>q>>k;
	for(int i = 1;i <= n;i++) {
		fin>>arr[i];
	}
	for(int i = 1;i < n;i++) {
		fin>>x>>y;
		com[x].to.push_back(y);
		com[y].to.push_back(x);
	}
	for(int i = 1;i <= n;i++) {
		fill(vis,vis+n+5,false);
		can(i,0,i);
	}
	for(int i = 1;i <= q;i++) {
		fill(vis,vis+n+5,false);
		ans=1000000000000000;
		fin>>s>>t;
		DFS(s,0);
		fout<<ans<<endl;
	}
	return 0;
}
