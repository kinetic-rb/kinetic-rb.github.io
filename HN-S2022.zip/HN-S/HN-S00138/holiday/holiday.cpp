#include <bits/stdc++.h>
using namespace std;

ifstream fin("holiday.in");
ofstream fout("holiday.out");

struct node {
	int dt;
	vector<int> to;
}arr[2525];

int n,m,k,x,y,ans,num=INT_MIN,ind=1;
bool vis[2525];

void DFS(int p,int d) {
	if(!vis[p]&&p!=1) {
		if(num<arr[p].dt) {
			num=arr[p].dt;
			ind=p;
		}
	}
	if(d==k) {
		return;
	}
	for(int i = 0;i < arr[p].to.size();i++) {
		DFS(arr[p].to[i],d+1);
	}
}

int main() {
	fin>>n>>m>>k;
	for(int i = 2;i <= n;i++) {
		fin>>arr[i].dt;
	}
	for(int i = 1;i <= m;i++) {
		fin>>x>>y;
		arr[x].to.push_back(y);
		arr[y].to.push_back(x);
	}
	for(int i = 1;i <= 4;i++) {
		num=INT_MIN;
		DFS(ind,-1);
		vis[ind]=true;
		ans+=num;
		//cout<<num<<endl;
	}
	fout<<ans<<endl;
	return 0;
}
