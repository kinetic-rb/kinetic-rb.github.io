#include <bits/stdc++.h>
#define data hole
using namespace std;

struct hole {
	int to;
	bool d;
};

struct vectorldt {
	data arr[500010];
	int tail=0;
	void push(data n) {
		arr[++tail]=n;
	}
	void pop() {
		tail--;
	}
	void emplace(data n,int d) {
		arr[d]=n;
	}
	int size() {
		return tail;
	}
	data i(int p) {
		return arr[p];
	}
	bool empty() {
		return tail==0;
	}
};

/*
struct vectorld {
	int arr[500010];
	int tail=0;
	void push(int n) {
		arr[++tail]=n;
	}
	void pop() {
		tail--;
	}
	void emplace(int n,int d) {
		arr[d]=n;
	}
	int size() {
		return tail;
	}
	int i(int p) {
		return arr[p];
	}
	bool empty() {
		return tail==0;
	}
};
*/

struct gala {
	bool whil,from,d;
	int toc;
	vectorldt pre,next;
	map<int,int> mn,mp;
}arrd[500050];

bool vis[500050];

int n,m,u,v,q,o,x,y;

bool DFS(int p,int r) {
	//cout<<p<<' '<<r<<endl;
	if(vis[p]) {
		return true;
	}
	vis[p]=true;
	vectorldt v(arrd[p].next);
	for(int i = 0;i < v.size();i++) {
		if(v.i(i).d) {
			continue;
		}
		if(DFS(v.i(i).to,r+1)) {
			return vis[p]=true;
		}
	}
	return vis[p]=false;
}

int main() {
	cin>>n>>m;
	for(int i = 1;i <= m;i++) {
		cin>>u>>v;
		arrd[u].next.push((hole){v,false});
		arrd[v].pre.push((hole){u,false});
		arrd[u].toc++,arrd[v].toc++;
		arrd[u].mn[v]=arrd[u].next.size()-1;
		arrd[v].mp[u]=arrd[v].pre.size()-1;
	}
	for(int i = 1;i <= n;i++) {
		arrd[i].from=arrd[i].toc==1;
		if(vis[i]||DFS(i,1)) {
			arrd[i].whil=true;
		}
	}
	cin>>q;
	for(int i = 1;i <= q;i++) {
		cin>>o;
		switch(o) {
			case 1:
				cin>>x>>y;
				arrd[x].next.emplace((hole){y,true},arrd[x].mn[y]);
				arrd[y].pre.emplace((hole){x,true},arrd[y].mp[x]);
		}
	}
	return 0;
}
