#include <bits/stdc++.h>
using namespace std;

ifstream fin("game.in");
ofstream fout("game.out");

int n,m,q;
int nr[100010],mr[100010];
int c[1010][1010];

int main() {
	fin>>n>>m>>q;
	for(int i = 1;i <= n;i++) {
		fin>>nr[i];
	}
	for(int i = 1;i <= m;i++) {
		fin>>mr[i];
	}
	for(int i = 1;i <= n;i++) {
		for(int j = 1;j <= m;j++) {
			c[i][j]=nr[i]*mr[j];
		}
	}
	return 0;
}
