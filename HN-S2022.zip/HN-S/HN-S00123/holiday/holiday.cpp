#include<bits/stdc++.h>
#define N 2510
#define M 7010
#define INF 1145141919 
using namespace std;
struct node{
	int next,to;
}e[M*M];
int n,m,k;
long long ans,a[N];
int cnt,top[N];
int d[N][N];
bool bj[N][N],vis[N];
void add(int x,int y){	//���� 
	cnt++;
	e[cnt].next=top[x];
	e[cnt].to=y;
	top[x]=cnt;
}
void dfs(int x){
	for(int i=top[x];i;i=e[i].next){
		int y=e[i].to;
		d[x][y]=d[y][x]=0;
		if(!bj[x][y]){
			bj[x][y]=1;
			dfs(y);
			for(int j=1;j<=n;j++){
				d[x][j]=d[j][x]=min(min(d[x][j],d[j][x]),d[y][j]+1);
			}
		} 
	}
}
void dfs2(int x,int step,long long sum){	//���·�� 
	vis[x]=1;
	sum+=a[x];
	if(step==4){
		if(d[x][1]<=k){				//����Ƿ��ܷ��ؼ� 
			ans=max(ans,sum);
		}
		vis[x]=0;
		return;
	}
	for(int i=top[x];i;i=e[i].next){
		int y=e[i].to;
		if(vis[y]==0){
			dfs2(y,step+1,sum);
		}
	}
	vis[x]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout); 
	memset(e,0,sizeof(e));
	memset(top,0,sizeof(top));
	cnt=0;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			d[i][j]=d[j][i]=INF;
		}
	}
	a[1]=0; 
	for(int i=2;i<=n;i++){
		scanf("%lld",&a[i]);	//�����ķ��� 
	}
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);	//����� 
		add(x,y);
		add(y,x);
	}
	dfs(1);
	for(int i=1;i<=n;i++){		//��С��k�ı� 
		for(int j=i+1;j<=n;j++){
			if(d[i][j]<=k && d[i][j]!=0){
				add(i,j);
				add(j,i);
			}
		}
	}
	dfs2(1,0,0);
	printf("%lld",ans);
	return 0;
}
