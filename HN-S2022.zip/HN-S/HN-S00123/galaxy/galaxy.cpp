#include<bits/stdc++.h>
#define N 10000
using namespace std;
int n,m,q,a[N][N],bj[N];
int cd[N],rdd[N],rd[N];
queue<int> dl;
int tuopu(){
	for(int i=1;i<=n;i++){
		rdd[i]=rd[i];
		bj[i]=0;
		if(cd[i]!=1)return false;
		if(rdd[i]==0){
			dl.push(i);
		}
	}
	while(!dl.empty()){
		int x=dl.front();
		bj[x]=1;
		dl.pop();
		for(int i=1;i<=n;i++){
			if(a[x][i]==1){
				rdd[i]--;
				if(rdd[i]==0){
					dl.push(i);
				}
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(bj[i]!=1)return true;
	}
	return false;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		a[u][v]=1;
		rd[v]++;
		cd[u]++;
	}
	scanf("%d",&q);
	for(int w=1;w<=q;w++){
		int t;
		scanf("%d",&t);
		if(t==1){
			int x,y;
			scanf("%d%d",&x,&y);
			a[x][y]=-1;
			rd[y]--;
			cd[x]--;
		}
		if(t==2){
			int x;
			scanf("%d",&x);
			for(int i=1;i<=n;i++){
				if(a[i][x]==1){
					a[i][x]=-1;
					rd[x]--;
					cd[i]--;
				} 
			}
		}
		if(t==3){
			int x,y;
			scanf("%d%d",&x,&y);
			a[x][y]=1;
			rd[y]++;
			cd[x]++;
		}
		if(t==4){
			int x;
			scanf("%d",&x);
			for(int i=1;i<=n;i++){
				if(a[i][x]==-1){
					a[i][x]=1;
					rd[x]++;
					cd[i]++;
				} 
			}
		}
		bool v=tuopu();
		if(v==0)printf("NO\n");
		else printf("YES\n");
	}
	return 0;
}
