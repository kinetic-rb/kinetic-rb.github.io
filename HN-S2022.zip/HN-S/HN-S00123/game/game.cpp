#include<bits/stdc++.h>
#define N 100010 
using namespace std;
int n,m,q;
long long a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	} 
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2,lx;
		long long maxx=-1e15;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(int i=l1;i<=r1;i++){
			long long sum=1e15;
			for(int j=l2;j<=r2;j++){
				if(a[i]*b[j]<sum){
					sum=a[i]*b[j];
				}
			}
			if(sum>maxx){
				maxx=sum,lx=a[i];
			}
		}
		printf("%lld\n",maxx);
	}
	return 0;
}
