#include <bits/stdc++.h>
using namespace std;
long long p[2555],maxn,n,k;
bool line[2555][2555],yline[2555][2555];
bool vis[2555];
//string sx,num[] = {"1","2","3","4","5","6","7","8","9"};
void f(int k,int u,int st) {
	if(k < 0) {
		return;
	}
	if(u != st) {
		line[st][u] = line[u][st] = 1;
	}
	for(int i = 1;i <= n;i++) {
		if(yline[u][i]) {
			f(k - 1,i,st);
		}
	}
}
void dfs(int bk,int dk,int w,long long f) {
	if(dk == 5) {
		if(w == 1) {
			maxn = max(maxn,f);
		}
		return;
	}
	bool _f = 0;
	if(bk == 0) {
		_f = 1;
		if(vis[w]) {
			return ;
		} else {
			vis[w] = 1;
		}
	}
	if(bk > k) {
		return;
	}
	for(int i = 1;i <= n;i++) {
		if(line[w][i]) {
//			string sx_ = sx;
//			sx_.append(num[i - 1]);
			dfs(0,dk + 1,i,f + p[i]);
			dfs(bk + 1,dk,i,f);
		}
	}
	if(_f) {
		vis[w] = 0;	
	}
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int m;
	scanf("%d %d %d",&n,&m,&k);
	for(int i = 2;i <= n;i++) {
		scanf("%d",&p[i]);
	}
	for(int i = 1;i <= m;i++) {
		int x,y;
		scanf("%d %d",&x,&y);
		line[x][y] = line[x][y] = 1;
	}
	dfs(0,0,1,0);
	printf("%d",maxn);
	return 0;
}
