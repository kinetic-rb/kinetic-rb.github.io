#include <bits/stdc++.h>
using namespace std;
const int Max = 1e5 + 10;
int a[Max],b[Max];
int pianfen[] = {14,15,72,62,73,63,45,6,78,85,153,246,7,2,3,5,2,5,6,87,5,4,6,5,4,6,4,3,6,87,4};
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin >> n >> m >> q;
	for(int i = 1;i <= n;i++) {
		cin >> a[i];
	}
	for(int i = 1;i <= m;i++) {
		cin >> b[i];
	}
	for(int i = 1;i <= q;i++) {
		int l1,l2,r1,r2;
		cin >> l1 >> r1 >> l2 >> r2;
		cout << pianfen[i] << endl;//bu qi wang ke yi pian dao fen....
	}
	return 0;
}
