#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("galaxy.in","w",stdout);
	freopen("galaxy.out","w",stdout);
	return 0;
}
