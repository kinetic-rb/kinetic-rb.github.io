#include <bits/stdc++.h>
using namespace std;
const int Max = 22222;
int v[Max];
bool line[Max][Max];
long long minn,n,k,yminn;
const string num[] = {"1","2","3","4","5","6","7","8","9"};
void dfs(int w,int m,long long f,int bk) {
	if(f >= minn) {
		return;
	}
	if(bk > k) {
		return;
	}
	if(w == m) {
		minn = min(minn,f);
		return;
	}
	for(int i = 1;i <= n;i++) {
		if(line[w][i]) {
			dfs(i,m,f,bk + 1);
			dfs(i,m,f + v[i],0);
		}
	}
}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int q;
	scanf("%d %d %d",&n,&q,&k);
	for(int i = 1;i <= n;i++) {
		scanf("%d",&v[i]);
		yminn += v[i];
	}
	for(int i = 2;i <= n;i++) {
		int a,b;
		scanf("%d %d",&a,&b);
		line[a][b] = line[b][a] = 1;
	}
	while(q--) {
		int a,b;
		minn = yminn;
		scanf("%d %d",&a,&b);
		dfs(a,b,0,0);
		printf("%d\n",minn + v[a] + v[b]);
	}
	return 0;
}
//10 5
