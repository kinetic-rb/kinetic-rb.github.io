#include <bits/stdc++.h>
using namespace std;
namespace io{
	inline int read(){
		int x=0;
		bool flag=true;
		char c=getchar();
		while(c<'0'||c>'9'){
			if(c=='-'){
				flag=false;
			}
			c=getchar();
		}
		while('0'<=c&&c<='9'){
			x=(x<<1)+(x<<3)+c-'0';
			c=getchar();
		}
		return (flag?x:~(x-1));
	}
}
using namespace io;
const int N=2600;
int n,m,c,a[N];
struct Edge{
	int to,next;
}edge[N*4*2];
int num=0,head[N];
void addEdge(int from,int to){
	num++;
	edge[num].to=to;
	edge[num].next=head[from];
	head[from]=num;
}
int dis[N][N];
void Floyd(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i==j) continue;
			for(int k=1;k<=n;k++){
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
			} 
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[i][j]--;
		}
	}
}
bool vis[N];
long long ans=0;
void dfs(int x,long long num,int last){
	if(x>4){
		if(dis[last][1]<=c)
			ans=max(ans,num);
		return;
	}
	for(int i=2;i<=n;i++){
		if(vis[i]) continue;
		if(dis[last][i]<=c){
			vis[i]=true;
			dfs(x+1,num+a[i],i);
			vis[i]=false;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(dis,0x3f,sizeof(dis));
	memset(vis,false,sizeof(vis));
	scanf("%d%d%d",&n,&m,&c);
	for(int i=2;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		addEdge(x,y);
		addEdge(y,x);
		dis[x][y]=dis[y][x]=1;
	}
	Floyd();
	vis[1]=true;
	dfs(1,0,1);
	cout<<ans;
	return 0;
}
