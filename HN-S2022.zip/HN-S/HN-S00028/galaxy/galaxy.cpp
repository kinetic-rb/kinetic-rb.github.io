#include <bits/stdc++.h>
using namespace std;
const int N=30100;
int n,m;
bool edge[N][N];
bool use[N][N];
int ind[N],outd[N];
bool topo(){
	queue<int>q;
	int in[N];
	for(int i=1;i<=n;i++){
		in[i]=ind[i];
		if(!in[i])
			q.push(i);
	}
	int num=0;
	while(!q.empty()){
		int x=q.front();
		q.pop();
		num++;
		for(int i=1;i<=n;i++){
			if(edge[x][i]&&!use[x][i]){
				in[i]--;
				if(!in[i]) q.push(i);
			}
		}
	}
	if(num==n) return false;
	return true;
}
int x,y;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		edge[x][y]=true;
		outd[x]++;
		ind[y]++;
	}
	int q;
	cin>>q;
	for(int k=1;k<=q;k++){
		int opt;
		scanf("%d",&opt);
		if(opt==1){
			scanf("%d%d",&x,&y);
			use[x][y]=true;
			outd[x]--;
			ind[y]--;
		} else if(opt==2){
			scanf("%d",&x);
			for(int i=1;i<=n;i++){
				if(edge[i][x]&&!use[i][x]){
					use[i][x]=true;
					outd[i]--;
					ind[x]--;
				}
			}
		} else if(opt==3){
			scanf("%d%d",&x,&y);
			use[x][y]=false;
			outd[x]++;
			ind[y]++;
		}else{
			scanf("%d",&x);
			for(int i=1;i<=n;i++){
				if(edge[i][x]&&use[i][x]){
					use[i][x]=false;
					outd[i]++; 
					ind[x]++;
				}
			}
		}
		bool flag=true; 
		for(int i=1;i<=n;i++){
			if(outd[i]!=1){
				cout<<"NO\n";
				flag=false;
				break;
			}
		}
		if(flag){
			if(topo()){
				cout<<"YES\n";
			} else{
				cout<<"NO\n";
			}
		}
	}
	return 0;
}
