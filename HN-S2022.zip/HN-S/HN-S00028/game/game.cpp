#include <bits/stdc++.h>
#define read(a) scanf("%d",&a)
using namespace std;
const int N=11010;
int n,m,q;
int a[N],b[N];
int c[N][N];
struct TREE{
	int l,r;
	int minn;
}tree[N][N];
void build(int f,int root,int l,int r){
	tree[f][root].l=l,tree[f][root].r=r;
	if(l==r){
		tree[f][root].minn=c[f][l];
		return;
	}
	int mid=(l+r)>>1;
	int leftroot=root<<1;
	int rightroot=root<<1|1;
	build(f,leftroot,l,mid);
	build(f,rightroot,mid+1,r);
	tree[f][root].minn=min(tree[f][leftroot].minn,tree[f][rightroot].minn);
	return;
}
int query(int f,int root,int l,int r){
	if(l<=tree[f][root].l&&tree[f][root].r<=r){
		return tree[f][root].minn;
	}
	int mid=(tree[f][root].l+tree[f][root].r)>>1;
	int leftroot=root<<1;
	int rightroot=root<<1|1;
	int minn=1e9;
	if(mid>=l){
		minn=min(minn,query(f,leftroot,l,r));
	}
	if(mid<r){
		minn=min(minn,query(f,rightroot,l,r));
	}
	return minn;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=m;i++) read(b[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
		build(i,1,1,m);
	}
	while(q--){
		int l1,r1,l2,r2;
		read(l1);
		read(r1);
		read(l2);
		read(r2);
		int ans=-1e9;
		for(int i=l1;i<=r1;i++){
			ans=max(ans,query(i,1,l2,r2));
		}
		cout<<ans<<endl;
	}
	return 0;
}
