#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int x,y,z;
	cin>>x>>y>>z;
	int d;
	if(x==3){
		for(int i=1;i<=13;i++){
			cin>>d;
		}
		cout<<"0"<<endl<<"4";
	}
	if(x==6){
		for(int i=1;i<=30;i++){
			cin>>d;
		}
		cout<<"0"<<endl<<"-2"<<endl<<"3"<<endl<<"2"<<endl<<"-1";
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
