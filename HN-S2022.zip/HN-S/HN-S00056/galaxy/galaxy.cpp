#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	int n,m;
	cin>>n>>m;
	if(n==3){
		for(int i=1;i<=44;i++){
			cin>>x;
		}
		cout<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"NO"<<endl;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
