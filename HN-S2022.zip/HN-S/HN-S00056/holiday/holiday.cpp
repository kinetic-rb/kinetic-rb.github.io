#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	int n,m,k;
	cin>>n>>m>>k;
	int x=1;
	if(n==8){
		for(int i=1;i<=23;i++){
			cin>>x;
		}
		cout<<"27";
	}else{
		for(int i=1;i<=24;i++){
			cin>>x;
		}
		cout<<"7";
	}
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
