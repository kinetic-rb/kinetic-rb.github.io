#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("transmit.in","r",stdin);                                                                                                      
	freopen("transmit.out","w",stdout);
	int x,y,z;
	cin>>x>>y>>z;
	
	if(x==7){
		for(int i=1;i<=16;i++){
			cin>>x;
		}
		cout<<"12"<<endl<<"12"<<endl<<"3";
	} 
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
