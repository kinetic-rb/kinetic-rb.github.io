#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int c[2500];
int maxn=-1;
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<n;i++)
	{
		cin>>c[i];
	}
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		if(a==1)
		{
			maxn=max(maxn,c[b-1]);
		}
		else if(b==1)
		{
			maxn=max(maxn,c[a-1]);
		}
	}
	cout<<maxn;
	return 0;
}
