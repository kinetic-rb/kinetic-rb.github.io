#include<bits/stdc++.h>
using namespace std;
int n,q,k;
vector<int> G[200001];
int v[200001];int s,t;
bool vis[200001];
long long dfs(int x,int now){
	if(k==1){
		if(x==t){
			return v[x];
		} 
		long long tmp=0x7fffffffffff;
		for(int i=0;i<G[x].size();i++){
			if(!vis[G[x][i]]){
				vis[G[x][i]]=1;
				tmp=min(dfs(G[x][i],1),tmp);
				vis[G[x][i]]=0;
			}
		}
		return v[x]+tmp;
	}
	else{
		
		if(x==t) return v[x];
		long long tmp=0x7fffffffffff;
		for(int i=0;i<G[x].size();i++){
			if(!vis[G[x][i]]){
				vis[G[x][i]]=1;
				if(now!=0)
					tmp=min(dfs(G[x][i],now-1),tmp);
				else
					tmp=min(dfs(G[x][i],k),tmp);
				vis[G[x][i]]=0;
			}
		}
		if(now==0)
			return tmp+v[x];
		else
			return tmp;
	}
}
int read(){
	int si=1,num=0;
	char c;
	c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') si=-1;
	for(;isdigit(c);c=getchar()) num=num*10+c-'0';
	return si*num;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();q=read();k=read();
	for(int i=1;i<=n;i++){
		v[i]=read();
	}
	for(int i=1;i<n;i++){
		int u,v;
		u=read();v=read();
		G[u].push_back(v);
		G[v].push_back(u);
	}
	for(int i=1;i<=q;i++){
		s=read();t=read();
		vis[s]=1;
		if(k==1)
			cout<<dfs(s,k)<<endl;
		else
			cout<<dfs(s,k)+v[s]<<endl;
		vis[s]=0;
	}
	return 0;
}



