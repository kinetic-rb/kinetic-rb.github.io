#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a[100001],b[100001],n,m,q;
int read(){
	int s=1,num=0;
	char c;
	c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') s=-1;
	for(;isdigit(c);c=getchar()) num=num*10+c-'0';
	return s*num;
}
bool af1,af2,bf1,bf2;
int maxa=-1000000000,maxb=-1000000000;
int mina=1000000000,minb=1000000000;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=m;i++){
		b[i]=read();
	}
	int l1,l2,r1,r2;
	for(int i=1;i<=q;i++){
		l1=read();
		r1=read();
		l2=read();
		r2=read();
		af1=af2=bf1=bf2=false;
		for(int j=l1;j<=r1;j++){
			if(a[j]>0) af1=true;
			else if(a[j]) af2=true;
			if(a[j]>maxa) maxa=a[j];
			if(a[j]<mina) mina=a[j];
		}
		for(int j=l2;j<=r2;j++){
			if(b[j]>0) bf1=true;
			else if(b[j]) bf2=true;
			if(b[j]>maxb) maxb=b[j];
			if(b[j]<minb) minb=b[j];
		}
		if((!af1&&!af2)||(!bf1&&!bf2)) cout<<0<<endl;
		else if(af1&&bf1&&!bf2) cout<<(long long)maxa*minb<<endl;
		else if(af1&&!af2&&bf2) cout<<(long long)mina*maxb<<endl;
		else if(!af1&&af2&&bf1) cout<<(long long)maxa*maxb<<endl;
		else if(!af1&&af2&&!bf1) cout<<(long long) mina*maxb<<endl;
		else cout<<(long long)maxa*minb<<endl;
	}
	return 0;
}

