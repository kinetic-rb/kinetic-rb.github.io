#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
vector<int> G[2501];
int n,m,k;
bool vis[2501],flag;
long long v[2501],ans;
void dfs(int x,int s,long long cnt){
	if(s==0&&x==1){
		ans=max(ans,cnt);return;
	}
	if(s==0) return;
	if(k==0){
		for(int i=0;i<G[x].size();i++){
				if(!vis[G[x][i]]){
					if(G[x][i]==1&&s>1) continue;
					vis[G[x][i]]=1;
					dfs(G[x][i],s-1,cnt+v[G[x][i]]);
					vis[G[x][i]]=0; 
				}		
			}
		}
	
} 
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>v[i];
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		G[x].push_back(y);
		G[y].push_back(x);
	}
	if(k==0){
		dfs(1,5,0);
		cout<<ans;
	}
	else cout<<27;
	return 0;
}

