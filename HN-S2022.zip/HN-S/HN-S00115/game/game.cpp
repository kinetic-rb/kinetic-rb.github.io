#include<bits/stdc++.h>
using namespace std;
long a[10005],b[10005],n,m,j,k,p,i,l1,l2,r1,r2,a1,a2,a3,b1,b2,k1,k2;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>p;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	} 
	for(i=1;i<=m;i++) 
	{
		cin>>b[i];
	}
	for(i=1;i<=p;i++)
	{
		cin>>l1>>r1>>l2>>r2;
		a1=0;
		a2=0;
		a3=0;
		k1=-0x3f3f3f;
		k2=-k1;
		for(j=l2;j<=r2;j++)
		{
			sort(b+l2,b+r2+1);  
		}
		if(b[l2]<0&&b[r2]>0)
		{
			b1=0x3f3f3f;
			b2=-0x3f3f3f;
			for(j=l1;j<=r2;j++)
			{
				if(a[j]<b1&&a[j]>=0) b1=a[j];
				else if(a[j]>b2&&a[j]<=0) b2=a[j];
				if(b1==0) break;
			}
			cout<<max(b1*b[l2],b2*b[r2])<<endl;
		}
		if(b[l2]>=0)
		{
			b1=-0x3f3f3f;
			for(j=l1;j<=r2;j++)
			{
				if(a[j]>b1) b1=a[j];
			}
			cout<<b1*b[l2]<<endl;
		}
		if(b[r2]<=0)
		{
			b1=0x3f3f3f;
			for(j=l1;j<=r2;j++)
			{
				if(a[j]<b1) b1=a[j];
			}
			cout<<b1*b[r2]<<endl;
		}
	}
	return 0; 
}
