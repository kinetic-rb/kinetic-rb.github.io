#include<bits/stdc++.h>
using namespace std;
int a[2505][2505],b[2505],c[2505],n,m,l,k,i,j,x,y,ans;
void dfs(int k,int m)
{
	if(m==0)
	{
		if(a[k][1]==1)
		{
			ans=max(ans,l);
		}
		return;
	}
	for(i=2;i<=n;i++)
	{
		if(a[k][i]==1&&c[i]==0)
		{
			l+=b[i];
			c[k]=1;
			dfs(i,m-1);
			c[k]=0;
			l-=b[i];
		}
	}
	return;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(i=2;i<=n;i++) scanf("%d",&b[i]);
	for(i=1;i<=m;i++)
	{
		scanf("%d",&x);
		scanf("%d",&y);
		a[x][y]=1;
		a[y][x]=1;
	}
	dfs(1,4);
	cout<<ans;
}
