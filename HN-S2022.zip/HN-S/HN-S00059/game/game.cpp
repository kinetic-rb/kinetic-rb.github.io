#include <bits/stdc++.h>
using namespace std;

#define re register
const int maxn = 1e5;
const int maxm = 1e5;
const long long INF = 9223372036854775807ll - 1;

long long A[maxn], B[maxm];
int main()
{
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    int n, m, Q;
    scanf("%d%d%d", &n, &m, &Q);
    for (re int i = 1; i <= n; ++i)
    {
        scanf("%lld", &A[i]);
    }
    for (re int i = 1; i <= m; ++i)
    {
        scanf("%lld", &B[i]);
    }
    while (Q--)
    {
        re int l1, r1, l2, r2;
        scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
        re long long Ans = -INF;
        for (re int i = l1; i <= r1; ++i)
        {
            re long long res = INF;
            for (re int j = l2; j <= r2; ++j)
            {
                res = min(res, A[i] * B[j]);
            }
            Ans = max(res, Ans);
        }
        printf("%lld\n",Ans);
    }
    return 0;
}