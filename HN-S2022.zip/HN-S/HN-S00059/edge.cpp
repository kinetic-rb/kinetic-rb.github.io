#include <bits/stdc++.h>
using namespace std;

#define re register

const int maxm = 10000 * 2 + 10;
const int maxn = 2500 + 100;

struct node
{
    int next, to;
} edge[maxm];
int head[maxn], cnt;

static inline void add(const int &u, const int &v)
{
    edge[++cnt].to = v;
    edge[cnt].next = head[u];
    head[u] = cnt;
}
static inline void make_edge(const int &from, const int &to)
{
    add(from, to);
    add(to, from);
}

struct NODE
{
    long long value;
    int id;
} x[maxn];

bool operator<(const NODE &A, const NODE &B)
{
    return A.value > B.value;
}

bitset<maxn> vis;
void dfs(int x)
{
    vis[x] = 1;
    for (re int i = head[x]; i; i = edge[i].next)
    {
        re int &y = edge[i].to;
        if (!vis[y])
        {
            dfs(y);
        }
    }
}
int DIS[maxn][maxn];
int main()
{
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);

    int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    ++k;
    for (re int i = 2; i <= n; ++i)
    {
        scanf("%lld", &x[i].value);
        x[i].id = i;
    }
    sort(x + 1, x + 1 + n);
    memset(DIS, 0x3f, sizeof(DIS));
    for (re int i = 1; i <= n; ++i)
    {
        DIS[i][i] = 0;
    }
    for (re int i = 1; i <= m; ++i)
    {
        re int tmpu, tmpv;
        scanf("%d%d", &tmpu, &tmpv);
        DIS[tmpu][tmpv] = 1;
        DIS[tmpv][tmpu] = 1;
        make_edge(tmpu, tmpv);
    }

    for (re int k = 1; k <= n; ++k)
    {
        for (re int i = 1; i <= n; ++i)
        {
            for (re int j = 1; j <= n; ++j)
            {
                DIS[i][j] = min(DIS[i][k] + DIS[k][j], DIS[i][j]);
            }
        }
    }
    long long Ans = 0;
    for (re int i1 = 1; i1 <= n; ++i1)
    {
        vis[i1] = 1;
        for (re int i2 = 1; i2 <= n; ++i2)
        {
            if (!vis[i2])
            {
                vis[i2] = 1;
                for (re int i3 = 1; i3 <= n; ++i3)
                {
                    if (!vis[i3])
                    {
                        vis[i3] = 1;
                        for (re int i4 = 1; i4 <= n; ++i4)
                        {
                            if (!vis[i4])
                            {
                                if (DIS[1][x[i1].id] <= k and DIS[x[i1].id][x[i2].id] <= k and DIS[x[i2].id][x[i3].id] <= k and DIS[x[i3].id][x[i4].id] <= k and DIS[x[i4].id][1] <= k)
                                {
                                    Ans = max(Ans, x[i1].value + x[i2].value + x[i3].value + x[i4].value);
                                }
                            }
                        }
                        vis[i3] = 0;
                    }
                }
                vis[i2] = 0;
            }
        }
        vis[i1] = 0;
    }
    cout << Ans << '\n';
    return 0;
}
