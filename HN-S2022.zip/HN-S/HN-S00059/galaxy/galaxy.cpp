#include <bits/stdc++.h>
using namespace std;

#define re register

const int maxm = 5e5 * 8 + 10;
const int maxn = 5e5 + 100;

struct node
{
    int next, to;
    bool dis, able;
} edge[maxm];
int head[maxn], cnt = 1;

static inline void add(const int &u, const int &v, const int &w)
{
    edge[++cnt].to = v;
    edge[cnt].next = head[u];
    edge[cnt].dis = w;
    edge[cnt].able = 1;
    head[u] = cnt;
}
static inline void make_edge(const int &from, const int &to)
{
    add(from, to, 1);
    add(to, from, 0);
}

int n, m;
void T1(const int &u, const int &v);
void T2(const int &u);
void T3(const int &u, const int &v);
void T4(const int &u);

bitset<maxn> vis;
bool check()
{
    for (re int i = 1; i <= n; ++i)
    {
        int cnt = 0;
        for (re int j = head[i]; j; j = edge[j].next)
        {
            if (edge[j].dis and edge[j].able)
            {
                if (cnt > 1)
                {
                    return 0;
                }
                ++cnt;
            }
        }
        if (cnt != 1)
        {
            return 0;
        }
        for (re int k = 1; k <= maxn; ++k)
            vis[k] = 0;
        queue<int> q;
        q.push(i);
        bool res = 0;
        while (!q.empty())
        {
            int now = q.front();
            vis[now] = 1;
            q.pop();
            for (re int j = head[now]; j; j = edge[j].next)
            {
                int &y = edge[j].to;
                if (vis[y])
                {
                    res = 1;
                    break;
                }
                q.push(y);
            }
            if (res == 1)
                break;
        }
        if (!res)
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);

    scanf("%d%d", &n, &m);
    for (re int i = 1; i <= m; ++i)
    {
        int tmp_u, tmp_v;
        scanf("%d%d", &tmp_u, &tmp_v);
        make_edge(tmp_u, tmp_v);
    }
    int Q;
    scanf("%d", &Q);
    int cnt = 0;
    while (Q--)
    {
        ++cnt;
        int opt;
        scanf("%d", &opt);
        // cout << "NOW" << cnt << endl;
        if (opt == 1)
        {
            int U, V;
            // cout << "OPT1";
            scanf("%d%d", &U, &V);
            // cout << U << V << endl;
            T1(U, V);
            puts((check() ? "YES" : "NO"));
        }
        if (opt == 2)
        {
            int U;
            scanf("%d", &U);
            T2(U);
            puts((check() ? "YES" : "NO"));
        }
        if (opt == 3)
        {
            int U, V;
            scanf("%d%d", &U, &V);
            T3(U, V);
            puts((check() ? "YES" : "NO"));
        }
        if (opt == 4)
        {
            int U;
            scanf("%d", &U);
            // cout << "U" << U << endl;
            T4(U);
            puts((check() ? "YES" : "NO"));
            // cout << check() << endl;
        }
        // for (re int i = head[1]; i; i = edge[i].next)
        // {
        //     if (edge[i].able and edge[i].dis)
        //         cout << edge[i].to << ' ';
        // }
        // cout << endl;
        // for (re int i = head[2]; i; i = edge[i].next)
        // {
        //     if (edge[i].able and edge[i].dis)
        //         cout << edge[i].to << ' ';
        // }
        // cout << endl;
        // for (re int i = head[3]; i; i = edge[i].next)
        // {
        //     if (edge[i].able and edge[i].dis)
        //         cout << edge[i].to << ' ';
        // }

        // cout << endl
        //      << endl;
    }
    return 0;
}

void T1(const int &u, const int &v)
{
    for (re int i = head[u]; i; i = edge[i].next)
    {
        int &y = edge[i].to;
        if (y == v and edge[i].dis == 1)
        {
            edge[i].able = 0;
            return;
        }
    }
}
void T2(const int &u)
{
    for (re int i = head[u]; i; i = edge[i].next)
    {
        if (edge[i].dis == 0)
        {
            edge[i].able = 0;
            edge[i ^ 1].able = 0;
        }
    }
}
void T3(const int &u, const int &v)
{
    for (re int i = head[u]; i; i = edge[i].next)
    {
        int &y = edge[i].to;
        if (y == v and edge[i].dis == 1)
        {
            edge[i].able = 1;
            return;
        }
    }
}
void T4(const int &u)
{
    for (re int i = head[u]; i; i = edge[i].next)
    {
        if (edge[i].dis == 0)
        {
            edge[i].able = 1;
            edge[i ^ 1].able = 1;
        }
    }
}