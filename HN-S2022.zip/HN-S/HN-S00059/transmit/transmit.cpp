// #include <bits/stdc++.h>
// using namespace std;

// #define re register

// const int maxm = 2e5 * 2 + 10;
// const int maxn = 2e5 + 100;

// struct node
// {
//     int next, to;
// } edge[maxm];
// int head[maxn], cnt;

// static inline void add(const int &u, const int &v)
// {
//     edge[++cnt].to = v;
//     edge[cnt].next = head[u];
//     head[u] = cnt;
// }
// static inline void make_edge(const int &from, const int &to)
// {
//     add(from, to);
//     add(to, from);
// }

// int num[maxn];
// bool vis[maxn];
// int dfs(int x, int fa, int sum, int V)
// {
//     if (x == V)
//     {
//         return sum;
//     }
//     for (re int i = head[x]; i; i = edge[i].next)
//     {
//         re int &y = edge[i].to;
//         if (!vis[y])
//         {
//             dfs(y, x, sum + num[y], V);
//             vis[y] = 1;
//         }
//     }
// }
// int main()
// {
//     freopen("transmit.in", "r", stdin);
//     // freopen("transmit.out", "w", stdout);
//     int n, q, k;
//     scanf("%d%d%d", &n, &q, &k);
//     for (re int i = 1; i <= n; ++i)
//     {
//         scanf("%d", &num[i]);
//     }
//     for (re int i = 1; i <= n - 1; ++i)
//     {
//         int tmpu, tmpv;
//         scanf("%d%d", &tmpu, &tmpv);
//         make_edge(tmpu, tmpv);
//     }
//     while (q--)
//     {
//         int From, To;
//         scanf("%d%d", &From, &To);
//         cout << From << ' ' << To << endl;
//         cout << dfs(From, 0, 0, To) << '\n';
//     }
//     return 0;
// }
