#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<queue>

using i64 = long long;
using namespace std;

namespace Program
{
    const int MAXN = 2505;
    const int MAXM = 10005;
    const i64 INF = 0x3F3F3F3F3F3F3F3F;

    int n, m, k, tot = 1, hd[MAXN], nxt[MAXM << 1], to[MAXM << 1], dis[MAXN][MAXN];
    i64 s[MAXN], mx[MAXN][3][2];
    bool vis[MAXN], g[MAXN][MAXN], c[MAXN];

    inline void Link(int u, int v) { return ++tot, nxt[tot] = hd[u], to[tot] = v, hd[u] = tot, void(); }

    inline void BFS(int st)
    {
        queue<int> q; q.push(st), dis[st][st] = 0, vis[st] = true;
        
        while(!q.empty())
        {
            int u = q.front(); q.pop();
            
            for(register int i = hd[u]; i; i = nxt[i])
            {
                int v = to[i];
                if(vis[v]) continue;
                vis[v] = true, dis[st][v] = dis[st][u] + 1, q.push(v);
            }
        }

        return;
    }

    inline void Update(int i, int j)
    {
        for(register int k = 0; k < 3; k++) if(s[j] > mx[i][k][0])
        {
            for(register int t = 2; t > k; t--) mx[i][t][0] = mx[i][t - 1][0], mx[i][t][1] = mx[i][t - 1][1];
            mx[i][k][0] = s[j], mx[i][k][1] = j; break;
        }
        return;
    }

    inline bool Same(int a, int b, int c, int d) { return a == b || a == c || a == d || b == c || b == d || c == d; }

    inline int Run()
    {
        freopen("holiday.in", "r", stdin);
        freopen("holiday.out", "w", stdout);

        ios :: sync_with_stdio(false);

        cin >> n >> m >> k;

        for(register int i = 2; i <= n; i++) cin >> s[i];
    
        for(register int i = 1, u = 0, v = 0; i <= m; i++)
        {
            cin >> u >> v;
            Link(u, v), Link(v, u);
        }

        for(register int i = 1; i <= n; i++)
        {
            for(register int j = 1; j <= n; j++) vis[j] = false;
            BFS(i);
        }

        for(register int i = 1; i <= n; i++)
        {
            for(register int j = 1; j <= n; j++) if(i != j)
            {
                if(dis[i][j] - 1 <= k)
                {
                    g[i][j] = true;
                    if(i == 1) c[j] = true;
                    if(j == 1) c[i] = true;
                }
            }
        }

        for(register int i = 2; i <= n; i++)
        {
            mx[i][0][0] = -INF, mx[i][1][0] = -INF - 1, mx[i][2][0] = -INF - 2;
            for(register int j = 2; j <= n; j++) if(i != j && g[i][j] && c[j]) Update(i, j);
        }

        i64 ans = 0;

        for(register int i = 2; i < n; i++)
        {
            for(register int j = i + 1; j <= n; j++) if(g[i][j])
            {
                for(register int a = 0; a < 3; a++) if(mx[i][a][1])
                {
                    for(register int b = 0; b < 3; b++) if(mx[j][b][1])
                    {
                        if(!Same(i, j, mx[i][a][1], mx[j][b][1])) ans = max(ans, s[i] + s[j] + mx[i][a][0] + mx[j][b][0]);
                    }
                }
            }
        }

        cout << ans << endl;

        return 0;
    }
}

int main() { return Program :: Run(); }