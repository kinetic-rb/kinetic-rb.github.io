#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<queue>

using namespace std;

namespace Program
{
    const int MAXN = 1005;
    const int MAXM = 10005;

    int n, m, q, tot, hd[MAXN], nxt[MAXM], to[MAXM], top, stk[MAXN], len, cir[MAXN], cnt[MAXN];
    bool g[MAXN][MAXN], ban[MAXN][MAXN], vis[MAXN], OK[MAXN];
    vector<int> vec[MAXN];

    inline void Link(int u, int v) { return ++tot, nxt[tot] = hd[u], to[tot] = v, hd[u] = tot, void(); }

    inline bool DFS(int u)
    {
        if(vis[u])
        {
            int k = 0;
            while(k != u)
            {
                k = stk[top--];
                cir[++len] = k;
            }
            return true;
        }

        stk[++top] = u, vis[u] = true;

        for(register int i = hd[u]; i; i = nxt[i])
        {
            int v = to[i];
            if(ban[u][v]) continue;
            DFS(v);
        }

        vis[u] = false;

        return 0;
    }

    inline int Run()
    {
        freopen("galaxy.in", "r", stdin);
        freopen("galaxy.out", "w", stdout);

        ios :: sync_with_stdio(false);

        cin >> n >> m;
        
        for(register int i = 1, u = 0, v = 0; i <= m; i++)
        {
            cin >> u >> v;
            Link(u, v), ++cnt[u], g[u][v] = true, vec[v].push_back(u);
        }

        cin >> q;

        while(q--)
        {
            int t = 0;
            cin >> t;

            if(t == 1)
            {
                int u = 0, v = 0;
                cin >> u >> v;
                ban[u][v] = true, --cnt[u];
            }

            if(t == 2)
            {
                int u = 0;
                cin >> u;
                for(register int i = 1; i <= n; i++) if(g[i][u] && !ban[i][u]) ban[i][u] = true, --cnt[i];
            }

            if(t == 3)
            {
                int u = 0, v = 0;
                cin >> u >> v;
                ban[u][v] = false, ++cnt[u];
            }

            if(t == 4)
            {
                int u = 0;
                cin >> u;
                for(register int i = 1; i <= n; i++) if(g[i][u] && ban[i][u]) ban[i][u] = false, ++cnt[i];
            }

            bool flag = true;
            for(register int i = 1; i <= n; i++) if(cnt[i] != 1) { flag = false; break; }

            if(!flag) { puts("NO"); continue; }

            len = 0, DFS(1);

            if(len)
            {
                for(register int i = 1; i <= n; i++) OK[i] = false;

                queue<int> q;
                for(register int i = 1; i <= len; i++) q.push(cir[i]), OK[cir[i]] = true;

                while(!q.empty())
                {
                    int u = q.front(); q.pop();
                    
                    for(auto v : vec[u]) if(!ban[v][u])
                    {
                        if(!OK[v]) OK[v] = true, q.push(v);
                    }
                }

                flag = true;
                for(register int i = 1; i <= n; i++) if(!OK[i]) { flag = false; break; }

                if(!flag) puts("NO"); else puts("YES");
            }
            else puts("NO");
        }

        return 0;
    }
}

int main() { return Program :: Run(); }