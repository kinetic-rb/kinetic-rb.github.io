#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>

using namespace std;

namespace Program
{
    const int MAXN = 100005;
    const int MAXLOG = 18;
    const int INF = 0x3F3F3F3F;

    int n, m, q, a[MAXN], b[MAXN], tmp[MAXN];
    int lg2[MAXN];

    struct ST_Max
    {
        int st[MAXLOG][MAXN];
        
        inline void Build(int *f, int len)
        {
            for(register int i = 1; i <= len; i++) st[0][i] = f[i];
            for(register int j = 1; j < MAXLOG; j++) for(register int i = 1; i + (1 << j) - 1 <= len; i++) st[j][i] = max(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
            return;
        }

        inline int Max(int l, int r)
        {
            int k = lg2[r - l + 1];
            return max(st[k][l], st[k][r - (1 << k) + 1]);
        }
    } mxa, mxan, mxb, mxbn;

    struct ST_Min
    {
        int st[MAXLOG][MAXN];

        inline void Build(int *f, int len)
        {
            for(register int i = 1; i <= len; i++) st[0][i] = f[i];
            for(register int j = 1; j < MAXLOG; j++) for(register int i = 1; i + (1 << j) - 1 <= len; i++) st[j][i] = min(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
            return;
        }

        inline int Min(int l, int r)
        {
            int k = lg2[r - l + 1];
            return min(st[k][l], st[k][r - (1 << k) + 1]);
        }
    } mia, miap, mib, mibp;

    inline int Run()
    {
        freopen("game.in", "r", stdin);
        freopen("game.out", "w", stdout);

        ios :: sync_with_stdio(false);

        cin >> n >> m >> q;
        for(register int i = 1; i <= n; i++) cin >> a[i];
        for(register int i = 1; i <= m; i++) cin >> b[i];

        lg2[0] = -1; for(register int i = 1; i <= max(n, m); i++) lg2[i] = lg2[i >> 1] + 1;

        mxa.Build(a, n), mia.Build(a, n);
        for(register int i = 1; i <= n; i++) tmp[i] = (a[i] <= 0 ? a[i] : -INF);
        mxan.Build(tmp, n);
        for(register int i = 1; i <= n; i++) tmp[i] = (a[i] >= 0 ? a[i] : INF);
        miap.Build(tmp, n);

        mxb.Build(b, m), mib.Build(b, m);
        for(register int i = 1; i <= m; i++) tmp[i] = (b[i] <= 0 ? b[i] : -INF);
        mxbn.Build(tmp, m);
        for(register int i = 1; i <= m; i++) tmp[i] = (b[i] >= 0 ? b[i] : INF);
        mibp.Build(tmp, m);

        while(q--)
        {
            int l1 = 0, r1 = 0, l2 = 0, r2 = 0;
            cin >> l1 >> r1 >> l2 >> r2;

            int amx = mxa.Max(l1, r1), namx = mxan.Max(l1, r1), bmx = mxb.Max(l2, r2), nbmx = mxbn.Max(l2, r2);
            int ami = mia.Min(l1, r1), pami = miap.Min(l1, r1), bmi = mib.Min(l2, r2), pbmi = mibp.Min(l2, r2);

            pair<long long, int> pa[4], pb[4]; memset(pa, 0, sizeof pa), memset(pb, 0, sizeof pb);

            pa[0] = make_pair(1LL * amx * bmi, amx), pa[1] = make_pair(pami == INF ? -(1LL * INF * INF) : 1LL * pami * bmi, pami), pa[2] = make_pair(1LL * ami * bmx, ami), pa[3] = make_pair(namx == -INF ? -(1LL * INF * INF) : 1LL * namx * bmx, namx);
            pb[0] = make_pair(1LL * bmx * amx, bmx), pb[1] = make_pair(pbmi == INF ? (1LL * INF * INF) : 1LL * pbmi * amx, pbmi), pb[2] = make_pair(1LL * bmi * ami, bmi), pb[3] = make_pair(nbmx == -INF ? (1LL * INF * INF) : 1LL * nbmx * ami, nbmx);

            sort(pa, pa + 4), sort(pb, pb + 4);
            cout << 1LL * pa[3].second * pb[0].second << endl;
        }

        return 0;
    }
}

int main() { return Program :: Run(); }