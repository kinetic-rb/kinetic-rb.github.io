#include<iostream>
#include<cstdio>
#include<cstdlib>

using i64 = long long;
using namespace std;

namespace Program
{
    const int MAXN = 200005;
    const int MAXLOG = 20;
    const i64 INF = 0x3F3F3F3F3F3F3F3F;

    int n, q, k, tot = 1, hd[MAXN], nxt[MAXN << 1], to[MAXN << 1], f[MAXN][MAXLOG], dep[MAXN], len;
    i64 val[MAXN], sum[MAXN], seq[MAXN], g[MAXN][3];

    inline void Link(int u, int v) { return ++tot, nxt[tot] = hd[u], to[tot] = v, hd[u] = tot, void(); }

    inline int LCA(int u, int v)
    {
        if(dep[u] < dep[v]) swap(u, v);
        for(register int i = MAXLOG - 1; i >= 0; i--) if(dep[f[u][i]] >= dep[v]) u = f[u][i];
        if(u == v) return u;
        for(register int i = MAXLOG - 1; i >= 0; i--) if(f[u][i] != f[v][i]) u = f[u][i], v = f[v][i];
        return f[u][0];
    }

    inline void DFS(int u, int fa)
    {
        f[u][0] = fa, dep[u] = dep[fa] + 1, sum[u] = sum[fa] + val[u];
        for(register int i = 1; i < MAXLOG && f[u][i - 1]; i++) f[u][i] = f[f[u][i - 1]][i - 1];

        for(register int i = hd[u]; i; i = nxt[i])
        {
            int v = to[i];
            if(v == fa) continue;
            DFS(v, u);
        }

        return;
    }

    inline int Run()
    {
        freopen("transmit.in", "r", stdin);
        freopen("transmit.out", "w", stdout);

        ios :: sync_with_stdio(false);

        cin >> n >> q >> k;
        
        for(register int i = 1; i <= n; i++) cin >> val[i];

        for(register int i = 1, u = 0, v = 0; i < n; i++)
        {
            cin >> u >> v;
            Link(u, v), Link(v, u);   
        }

        DFS(1, 0);

        while(q--)
        {
            int u = 0, v = 0;
            cin >> u >> v;
            
            int w = LCA(u, v);

            if(k == 1) cout << sum[u] + sum[v] - sum[w] - sum[f[w][0]] << endl;
            
            else
            {
                len = dep[u] + dep[v] - dep[w] - dep[f[w][0]];

                int p = 1, q = len;
                while(u != w) seq[p++] = val[u], u = f[u][0];
                while(v != w) seq[q--] = val[v], v = f[v][0];
                seq[p++] = val[w];

                g[1][0] = seq[1];
                for(register int i = 1; i < k; i++) g[1][i] = INF;

                for(register int i = 2; i < len; i++)
                {
                    for(register int j = 0; j < k; j++)
                    {
                        if(j == 0)
                        {
                            g[i][j] = INF;
                            for(register int t = 0; t < k; t++) g[i][j] = min(g[i][j], g[i - 1][t] + seq[i]);
                        }
                        else g[i][j] = g[i - 1][j - 1];
                    }
                }

                g[len][0] = INF;
                for(register int i = 0; i < k; i++) g[len][0] = min(g[len][0], g[len - 1][i] + seq[len]);

                cout << g[len][0] << endl;
            }
        }

        return 0;
    }
}

int main() { return Program :: Run(); }