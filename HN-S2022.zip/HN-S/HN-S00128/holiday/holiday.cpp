#include<bits/stdc++.h>
#define il inline 
#define int ll
#define ll long long 
#define ull unsigned long long
#define MP make_pair
#define pb push_back
#define fi first
#define se second
#define CLK (double)clock()/CLOCKS_PER_SEC
using namespace std;
int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
const int N=2505;
int n,m,K,a[N],dis[N][N],f[N],g[N],vis[N];
bool chk(int a,int b,int c,int d){
    return !(a==b||b==c||c==d||a==c||a==d||b==d);
}
vector<int>G[N];
namespace Brute1{
    const int N=25;
    int dis[N][N],f[(1<<20)][N],cnt[(1<<20)];
    void main(){
        memset(dis,0x3f,sizeof dis);
        for(int i=1;i<=n;i++){
            dis[i][i]=0;
            for(auto j:G[i])dis[i][j]=dis[j][i]=1;
        }
        for(int k=1;k<=n;k++){
            for(int i=1;i<=n;i++){
                if(dis[i][k]>K)continue;
                for(int j=1;j<=n;j++){
                    if(dis[k][j]>K)continue;
                    if(dis[i][j]>dis[i][k]+dis[k][j])dis[i][j]=dis[i][k]+dis[k][j];
                }
            }
        }
        //for(int i=1;i<=n;i++){for(int j=1;j<=n;j++)cout<<dis[i][j]<<' ';cout<<"\n";}
        int tot=(1<<n)-1;
        memset(f,0x80,sizeof f);f[1][1]=0;
        for(int S=1;S<=tot;S++){
            cnt[S]=cnt[S-(S&(-S))]+1;
            //cout<<S<<' '<<cnt[S]<<"\n";
            if(cnt[S]>=5)continue;
            for(int i=1;i<=n;i++){
                if((S>>i-1)&1^1)continue;
                //if(S==1&&i==1)cout<<"Yes\n";
                //if(f[S][i]<0)continue;
                for(int j=1;j<=n;j++){
                    if((S>>j-1)&1)continue;
                    if(dis[i][j]>K)continue;
                    //if(S==1&&i==1)cout<<S<<' '<<i<<' '<<j<<"\n";
                    f[S|(1<<j-1)][j]=max(f[S|(1<<j-1)][j],f[S][i]+a[j]);
                }
            }
        }
        int ans=0;
        for(int S=1;S<=tot;S++){
            for(int i=1;i<=n;i++){
                if((S>>i-1)&1^1)continue;
                //if(f[S][i]>0)cout<<f[S][i]<<"\n";
                if(cnt[S]==5&&dis[i][1]<=K)ans=max(ans,f[S][i]);
            }
        }
        cout<<ans;
    }
}
namespace Brute2{
    const int N=305;
    int dis[N][N],f[N],g[N];
    bool chk(int a,int b,int c,int d){
        return !(a==b||b==c||c==d||a==c||a==d||b==d);
    }
    void main(){
        memset(dis,0x3f,sizeof dis);
        for(int i=1;i<=n;i++){
            dis[i][i]=0;
            for(auto j:G[i])dis[i][j]=dis[j][i]=1;
        }
        for(int k=1;k<=n;k++){
            for(int i=1;i<=n;i++){
                if(dis[i][k]>K)continue;
                for(int j=1;j<=n;j++){
                    if(dis[k][j]>K)continue;
                    if(dis[i][j]>dis[i][k]+dis[k][j])dis[i][j]=dis[i][k]+dis[k][j];
                }
            }
        }
        //for(int i=1;i<=n;i++){for(int j=1;j<=n;j++)cout<<dis[i][j]<<' ';cout<<"\n";}
        a[0]=-1e18;
        for(int i=2;i<=n;i++){
            if(dis[1][i]>K)continue;
            for(int j=2;j<=n;j++){
                if(dis[i][j]>K||i==j)continue;
                if(a[f[j]]<a[i])g[j]=f[j],f[j]=i;
                else if(a[g[j]]<a[i])g[j]=i;
            }
        }
        int ans=0;
        for(int i=2;i<=n;i++){
            for(int j=2;j<=n;j++){
                if(i==j||dis[i][j]>K)continue;
                if(chk(i,j,f[i],f[j])){ans=max(ans,a[i]+a[j]+a[f[i]]+a[f[j]]);continue;}
                if(chk(i,j,f[i],g[j]))ans=max(ans,a[i]+a[j]+a[f[i]]+a[g[j]]);
                if(chk(i,j,g[i],f[j]))ans=max(ans,a[i]+a[j]+a[g[i]]+a[f[j]]);
                if(chk(i,j,g[i],g[j]))ans=max(ans,a[i]+a[j]+a[g[i]]+a[g[j]]);
            }
        }
        cout<<ans<<"\n";
    }
}
void bfs(int s){
    memset(dis[s],0x3f,sizeof dis[s]);dis[s][s]=0;
    memset(vis,0,sizeof vis);
    queue<int>q;q.push(s);vis[s]=1;
    while(!q.empty()){
        int x=q.front();q.pop();
        for(auto y:G[x]){
            if(vis[y])continue;vis[y]=1;
            dis[s][y]=dis[s][x]+1;
            if(dis[s][y]<=K)q.push(y);
        }
    }
}
signed main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    n=read();m=read();K=read()+1;
    for(int i=2;i<=n;i++)a[i]=read();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        G[x].pb(y);G[y].pb(x);
    }
    // if(n<=20){Brute1::main();return 0;}
    // if(n<=300){Brute2::main();return 0;}
    for(int i=1;i<=n;i++)bfs(i);
    a[0]=-1e18;
    for(int i=2;i<=n;i++){
        if(dis[1][i]>K)continue;
        for(int j=2;j<=n;j++){
            if(dis[i][j]>K||i==j)continue;
            if(a[f[j]]<a[i])g[j]=f[j],f[j]=i;
            else if(a[g[j]]<a[i])g[j]=i;
        }
    }
    int ans=0;
    for(int i=2;i<=n;i++){
        for(int j=2;j<=n;j++){
            if(i==j||dis[i][j]>K)continue;
            if(chk(i,j,f[i],f[j])){ans=max(ans,a[i]+a[j]+a[f[i]]+a[f[j]]);continue;}
            if(chk(i,j,f[i],g[j]))ans=max(ans,a[i]+a[j]+a[f[i]]+a[g[j]]);
            if(chk(i,j,g[i],f[j]))ans=max(ans,a[i]+a[j]+a[g[i]]+a[f[j]]);
            if(chk(i,j,g[i],g[j]))ans=max(ans,a[i]+a[j]+a[g[i]]+a[g[j]]);
        }
    }
    cout<<ans<<"\n";//printf("%.6lf",CLK);
    return 0;
}