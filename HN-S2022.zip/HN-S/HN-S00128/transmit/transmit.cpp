#include<bits/stdc++.h>
#define il inline 
#define int ll
#define ll long long 
#define ull unsigned long long
#define MP make_pair
#define pb push_back
#define fi first
#define se second
#define CLK (double)clock()/CLOCKS_PER_SEC
using namespace std;
int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
const int N=2e5+5;
int n,Q,k,v[N],d[N],anc[N][22],f[N][5],g[N][5];
vector<int>G[N];
namespace Brute{
    void prework(int x,int fa){
        d[x]=d[fa]+1;anc[x][0]=fa;
        for(int i=1;i<=20;i++)anc[x][i]=anc[anc[x][i-1]][i-1];
        for(auto y:G[x]){
            if(y==fa)continue;
            prework(y,x);
        }
    }
    int LCA(int a,int b){
        if(d[a]>d[b])swap(a,b);
        for(int i=20;i>=0;i--)if(d[a]<=d[anc[b][i]])b=anc[b][i];
        if(a==b)return a;
        for(int i=20;i>=0;i--)if(anc[a][i]!=anc[b][i])a=anc[a][i],b=anc[b][i];
        return anc[a][0];
    }
    void dfs(int x,int lim,int ty){
        while(1){
            int y=x;x=anc[x][0];
            for(int i=0;i<=k;i++){
                if(!ty){
                    if(i==0)for(int j=0;j<k;j++)f[x][0]=min(f[x][0],f[y][j]+v[x]);
                    else f[x][i]=min(f[x][i],f[y][i-1]);
                }
                else {
                    if(i==0)for(int j=0;j<k;j++)g[x][0]=min(g[x][0],g[y][j]+v[x]);
                    else g[x][i]=min(g[x][i],g[y][i-1]);
                }
            }
            if(x==lim)return ;
        }
    }
    void main(){
        prework(1,0);
        for(int _=1;_<=Q;_++){
            int s=read(),t=read(),tmp=LCA(s,t);
            memset(f,0x3f,sizeof f);memset(g,0x3f,sizeof g);
            f[s][0]=v[s];g[t][0]=v[t];
            if(s!=tmp)dfs(s,tmp,0);if(t!=tmp)dfs(t,tmp,1);
            int ans=1e18;
            for(int i=0;i<=k;i++){
                for(int j=0;j<=k;j++){
                    //cout<<i<<' '<<j<<' '<<f[tmp][i]+g[tmp][j]<<"\n";
                    if(i==0&&j==0)ans=min(ans,f[tmp][0]+g[tmp][0]-v[tmp]);
                    else if(i+j<=k)ans=min(ans,f[tmp][i]+g[tmp][j]);
                }
            }
            cout<<ans<<"\n";
        }
    }
}
signed main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    n=read();Q=read();k=read();
    for(int i=1;i<=n;i++)v[i]=read();
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        G[x].pb(y);G[y].pb(x);
    }
    //if(n<=2000){Brute::main();cout<<CLK;return 0;}
    Brute::main();
    return 0;
}