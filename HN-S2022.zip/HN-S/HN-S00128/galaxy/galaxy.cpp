#include<bits/stdc++.h>
#define il inline 
#define int ll
#define ll long long 
#define ull unsigned long long
#define MP make_pair
#define pb push_back
#define pii pair<int,int>
#define fi first
#define se second
#define CLK (double)clock()/CLOCKS_PER_SEC
using namespace std;
int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
const int N=2e5+5;
int n,m,q,d[N],dfn[N],low[N],tot,on[N],scc[N],Scc,num[N],mk[N],vis[N],had[N];
stack<int>S;
pii E[N];
map<pii,int>mp;
vector<int>G[N];
void Tarjan(int x){
    dfn[x]=low[x]=++tot;S.push(x);on[x]=1;
    for(auto y:G[x]){
        if(!dfn[y])Tarjan(y),low[x]=min(low[x],low[y]);
        else if(on[y])low[x]=min(low[x],dfn[y]);
    }
    if(dfn[x]==low[x]){
        scc[x]=++Scc;on[x]=0;num[Scc]++;
        while(S.top()!=x){
            int y=S.top();S.pop();
            scc[y]=Scc;on[y]=0;num[Scc]++;
        }
        S.pop();
    }
}
signed main(){
    freopen("galaxy.in","r",stdin);
//    freopen("galaxy.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<=n;i++)had[i]=1;
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        E[i]={x,y};mp[MP(x,y)]=i;vis[i]=1;
    }
    q=read();
    for(int _=1;_<=q;_++){
        int t=read();
        if(t==1){
            int x=read(),y=read();vis[mp[MP(x,y)]]=0;
        }
        if(t==2){
            int x=read();had[x]=0;
        }
        if(t==3){
            int x=read(),y=read();vis[mp[MP(x,y)]]=1;
        }
        if(t==4){
            int x=read();had[x]=1;
        }
        for(int i=1;i<=n;i++)G[i].clear(),d[i]=0,num[i]=0,mk[i]=0;
        memset(dfn,0,sizeof dfn);memset(on,0,sizeof on);tot=Scc=0;
        int ok=1;
        for(int i=1;i<=m;i++){
            int x=E[i].fi,y=E[i].se;if(!had[y]||!vis[i])continue;
            G[x].pb(y);d[x]++;
        }
        //for(int i=1;i<=n;i++)cout<<d[i]<<' ';cout<<"\n";
        for(int i=1;i<=n;i++)if(d[i]!=1){ok=0;break;}
        if(!ok){puts("NO");continue;}
        for(int i=1;i<=n;i++)if(!dfn[i])Tarjan(i);
        for(int i=1;i<=n;i++)if(num[scc[i]]>1)mk[i]=1;
        //for(int i=1;i<=n;i++)cout<<mk[i]<<' ';cout<<"\n";
        for(int i=1;i<=m;i++){
            int x=E[i].fi,y=E[i].se;if(!had[y]||!vis[i]||scc[x]==scc[y])continue;
            //cout<<x<<' '<<y<<"\n";
            if(mk[y])mk[x]=1;
        }
        //for(int i=1;i<=n;i++)cout<<mk[i]<<' ';cout<<"\n";
        for(int i=1;i<=n;i++)if(!mk[i]){ok=0;break;}
        if(!ok)puts("NO");else puts("YES");
    }
    return 0;
}