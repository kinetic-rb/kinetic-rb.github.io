#include<bits/stdc++.h>
#define il inline 
#define int ll 
#define ll long long 
#define ull unsigned long long
#define MP make_pair
#define pb push_back
#define fi first
#define se second
#define CLK (double)clock()/CLOCKS_PER_SEC
using namespace std;
int read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
const int N=1e5+5;
int n,m,q,a[N],b[N],lg[N],mna[N][22],mxa[N][22],mnza[N][22],mxfa[N][22],mnb[N][22],mxb[N][22],mnzb[N][22],mxfb[N][22];
namespace Brute1{
    void main(){
        for(int _=1;_<=q;_++){
            int l1=read(),r1=read(),l2=read(),r2=read();
            int ans=-1e18;
            for(int i=l1;i<=r1;i++){
                int res=1e18;
                for(int j=l2;j<=r2;j++)res=min(res,a[i]*b[j]);
                ans=max(ans,res);
            }
            cout<<ans<<"\n";
        }
    }
}
namespace Brute2{
    void main(){
        for(int _=1;_<=q;_++){
            int l1=read(),r1=read(),l2=read(),r2=read();
            int mna=1e9,mxa=-1e9,mxfa=-1e9,mnza=1e9,mnb=1e9,mxb=-1e9,mxfb=-1e9,mnzb=1e9;
            for(int i=l1;i<=r1;i++){
                mxa=max(mxa,a[i]),mna=min(mna,a[i]);
                if(a[i]<=0)mxfa=max(mxfa,a[i]);
                if(a[i]>=0)mnza=min(mnza,a[i]);
            }
            for(int i=l2;i<=r2;i++){
                mxb=max(mxb,b[i]),mnb=min(mnb,b[i]);
                if(b[i]<=0)mxfb=max(mxfb,b[i]);
                if(b[i]>=0)mnzb=min(mnzb,b[i]);
            }
            int res=1e18,ans=-1e18;
            if(mnb<0&&mxa>0)res=min(res,mnza*mnb);
            if(mxb>0&&mxa>0)res=min(res,mxa*mnzb);
            if(res<1e18)ans=max(ans,res);//cout<<res<<' ';
            res=1e18;
            if(mnb<0&&mna<0)res=min(res,mna*mxfb);
            if(mxb>0&&mna<0)res=min(res,mxfa*mxb);
            if(res<1e18)ans=max(ans,res);//cout<<res<<' ';
            cout<<ans<<"\n";
        }
    }
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read();m=read();q=read();
    for(int i=1;i<=n;i++)a[i]=read();
    for(int i=1;i<=m;i++)b[i]=read();
    if(n<=200){Brute1::main();return 0;}
    if(n<=1000){Brute2::main();return 0;}
    lg[0]=-1;for(int i=1;i<=max(n,m);i++)lg[i]=lg[i/2]+1;
    // memset(mna,0x3f,sizeof mna);
    // memset(mnza,0x3f,sizeof mna);
    // memset(mnb,0x3f,sizeof mnb);
    // memset(mnzb,0x3f,sizeof mnb);
    // memset(mxa,0x80,sizeof mxa);
    // memset(mxfa,0x80,sizeof mxfa);
    // memset(mxb,0x80,sizeof mxb);
    // memset(mxfb,0x80,sizeof mxfb);
    for(int i=1;i<=max(n,m);i++){
        for(int j=0;j<=20;j++){
            mna[i][j]=mnza[i][j]=mnb[i][j]=mnzb[i][j]=1e9;
            mxa[i][j]=mxfa[i][j]=mxb[i][j]=mxfb[i][j]=-1e9;
        }
    }
    for(int i=1;i<=n;i++){
        mna[i][0]=mxa[i][0]=a[i];
        if(a[i]>=0)mnza[i][0]=a[i];
        if(a[i]<=0)mxfa[i][0]=a[i];
    }
    for(int i=1;i<=nz;i++){
        mnb[i][0]=mxb[i][0]=b[i];
        if(b[i]>=0)mnzb[i][0]=b[i];
        if(b[i]<=0)mxfb[i][0]=b[i];
    }
    // for(int i=1;i<=max(n,m);i++){
    //     for(int j=0;j<=20;j++)cout<<mna[i][j]<<' '<<mxa[i][j]<<"\n";
    // }
    for(int j=1;j<=20;j++){
        for(int i=1;i+(1<<j)-1<=n;i++){
            mxa[i][j]=max(mxa[i][j-1],mxa[i+(1<<j-1)][j-1]);
            mna[i][j]=min(mna[i][j-1],mna[i+(1<<j-1)][j-1]);
            mxfa[i][j]=max(mxfa[i][j-1],mxfa[i+(1<<j-1)][j-1]);
            mnza[i][j]=min(mnza[i][j-1],mnza[i+(1<<j-1)][j-1]);
        }
        for(int i=1;i+(1<<j)-1<=m;i++){
            mxb[i][j]=max(mxb[i][j-1],mxb[i+(1<<j-1)][j-1]);
            mnb[i][j]=min(mnb[i][j-1],mnb[i+(1<<j-1)][j-1]);
            mxfb[i][j]=max(mxfb[i][j-1],mxfb[i+(1<<j-1)][j-1]);
            mnzb[i][j]=min(mnzb[i][j-1],mnzb[i+(1<<j-1)][j-1]);
        }
    }
    /*for(int i=1;i<=max(n,m);i++){
        for(int j=0;j<=20;j++)cout<<mxfb[i][j]<<' ';
        cout<<"\n";
    }*/
    for(int _=1;_<=q;_++){
            int l1=read(),r1=read(),l2=read(),r2=read();
            int tmp=lg[r1-l1+1];
            int cmna=min(mna[l1][tmp],mna[r1-(1<<tmp)+1][tmp]);
            int cmxa=max(mxa[l1][tmp],mxa[r1-(1<<tmp)+1][tmp]);
            int cmnza=min(mnza[l1][tmp],mnza[r1-(1<<tmp)+1][tmp]);
            int cmxfa=max(mxfa[l1][tmp],mxfa[r1-(1<<tmp)+1][tmp]);
            tmp=lg[r2-l2+1];
            int cmnb=min(mnb[l2][tmp],mnb[r2-(1<<tmp)+1][tmp]);
            int cmxb=max(mxb[l2][tmp],mxb[r2-(1<<tmp)+1][tmp]);
            int cmnzb=min(mnzb[l2][tmp],mnzb[r2-(1<<tmp)+1][tmp]);
            int cmxfb=max(mxfb[l2][tmp],mxfb[r2-(1<<tmp)+1][tmp]);
            int res=1e18,ans=-1e18;
            //cout<<cmna<<' '<<cmxa<<' '<<cmnb<<' '<<cmxb<<"\n";
            //cout<<cmnza<<' '<<cmxfa<<' '<<cmnzb<<' '<<cmxfb<<"\n";
            if(cmnb<0&&cmxa>0)res=min(res,cmnza*cmnb);
            if(cmxb>0&&cmxa>0)res=min(res,cmxa*cmnzb);
            if(res<1e18)ans=max(ans,res);//cout<<res<<' ';
            res=1e18;
            if(cmnb<0&&cmna<0)res=min(res,cmna*cmxfb);
            if(cmxb>0&&cmna<0)res=min(res,cmxfa*cmxb);
            if(res<1e18)ans=max(ans,res);//cout<<res<<' ';
            cout<<ans<<"\n";
        }
    //printf("%.6lf",CLK);
    return 0;
}