#include<bits/stdc++.h>
using namespace std;
int a[100005],b[100005],amx[100005][21],amn[100005][21],a0[100005][21],bmx[100005][21],bmn[100005][21],b0[100005][21],lg[100005];
int l1,r1,l2,r2,n,m,q;
int main()
{
 	ifstream fin("game.in");
 	ofstream fout("game.out");
 	fin>>n>>m>>q;
 	lg[1]=0;
 	for(int i=2;i<=100000;i++)
 	{
 		lg[i]=lg[i/2]+1;
 	}
 	for(int i=1;i<=n;i++)
 	{
 		fin>>a[i];
 		if(a[i]==0)a0[i][0]=1;
 		amx[i][0]=amn[i][0]=a[i];
 	}
 	for(int i=1;i<=m;i++)
 	{
 		fin>>b[i];
 		if(b[i]==0)b0[i][0]=1;
 		bmx[i][0]=bmn[i][0]=b[i];
 	}
 	for(int j=1;j<=20;j++)
 	{
 		for(int i=1;i<=n;i++)
 		{
 			int k=min(n,i+(1<<(j-1)));
 			amx[i][j]=max(amx[i][j-1],amx[k][j-1]);
 			amn[i][j]=min(amn[i][j-1],amn[k][j-1]);
 			a0[i][j]=a0[i][j-1]|a0[k][j-1];
 		}
 	}
 	for(int j=1;j<=20;j++)
 	{
 		for(int i=1;i<=m;i++)
 		{
 			int k=min(m,i+(1<<(j-1)));
 			bmx[i][j]=max(bmx[i][j-1],bmx[k][j-1]);
 			bmn[i][j]=min(bmn[i][j-1],bmn[k][j-1]);
 			b0[i][j]=b0[i][j-1]|b0[k][j-1];
 		}
 	}
 	for(int i=1;i<=q;i++)
 	{
 		fin>>l1>>r1>>l2>>r2;
 		int amax=max(amx[l1][lg[r1-l1+1]],amx[r1-(1<<lg[r1-l1+1])+1][r1-l1+1]);
 		int amin=min(amn[l1][lg[r1-l1+1]],amn[r1-(1<<lg[r1-l1+1])+1][r1-l1+1]);
 		int a_0=a0[l1][lg[r1-l1+1]]|a0[r1-(1<<lg[r1-l1+1])+1][r1-l1+1];
 		int bmax=max(bmx[l2][lg[r2-l2+1]],bmx[r2-(1<<lg[r2-l2+1])+1][r2-l2+1]);
 		int bmin=min(bmn[l2][lg[r2-l2+1]],bmn[r2-(1<<lg[r2-l2+1])+1][r2-l2+1]);
 		int b_0=b0[l2][lg[r2-l2+1]]|b0[r2-(1<<lg[r2-l2+1])+1][r2-l2+1];
 		long long ans=1;
 		if(l1==r1)
 		{
 			if(a[l1]>=0)ans=a[l1]*bmin;
 			else ans=a[l1]*bmax;
 		}
 		else if(l2==r2)
 		{
 			if(b[l2]>=0)ans=b[l2]*amax;
 			else ans=b[l2]*amin;
 		}
		else
		{
			ans=amax*bmin;
		}
 		fout<<ans<<"\n";
 	}
 	return 0;
}
