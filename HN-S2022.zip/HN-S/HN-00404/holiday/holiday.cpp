#include<bits/stdc++.h>
using namespace std;
int n,m,k,vis[2505],l,r;
long long a[2505];
vector<int>nbr[2505];
long long dfs(int cur,int tm)
{
	vis[cur]=1;
	if(tm==5&&cur!=1)return -1;
	if(tm==5&&cur==1)return 0;
	long long ans=-1;
	for(unsigned int i=0;i<nbr[cur].size();i++)
	{
		int to=nbr[cur][i];
		if(vis[to]==0||(to==1&&tm==4))ans=max(ans,dfs(to,tm+1));
	}
	vis[cur]=0;
	if(ans==-1)return -1;
	return ans+a[cur];
}
int main()
{
 	ifstream fin("holiday.in");
 	ofstream fout("holiday.out");
 	fin>>n>>m>>k;k++;
 	a[1]=0;
 	for(int i=2;i<=n;i++)
 	{
 		fin>>a[i]; 
 	}
 	for(int i=1;i<=m;i++)
 	{
 		fin>>l>>r;
 		nbr[l].push_back(r);
 		nbr[r].push_back(l);
	}
	fout<<dfs(1,0);
	return 0;
}
