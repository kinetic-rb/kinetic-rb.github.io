#include<bits/stdc++.h>
using namespace std;
int vis[500005],vis2[500005],res[500005];
int out[500005];
int n,m,q,l,r,ans;
struct node
{
	int to,ava;
};
vector<node>nbr[500005];
bool dfs(int cur)
{
	if(res[cur]==1)return true;
	vis[cur]=vis2[cur]=1;
	for(unsigned int i=0;i<nbr[cur].size();i++)
	{
		int t=nbr[cur][i].to;
		if(nbr[cur][i].ava==0)continue;
		if(vis[t])
		{
			res[t]=1;
			return true;
		}
		if(dfs(t)==0)return false;
	}
	return true;
}
int main()
{
 	ifstream fin("galaxy.in");
 	ofstream fout("galaxy.out");
 	fin>>n>>m;
 	for(int i=1;i<=m;i++)
 	{
 		fin>>l>>r;
 		nbr[l].push_back((node){r,1});
		out[l]=out[l]+1;
 	}
 	ans=0;
 	for(int i=1;i<=n;i++)
 	{
 		if(out[i]==1)ans++;
 	}
 	fin>>q;
 	int opt,l,r;
 	for(int i=1;i<=q;i++)
 	{
 		fin>>opt>>l;
		if(opt==1)
		{
			fin>>r;
			for(int j=0;j<nbr[l].size();j++)
			{
				int t=nbr[l][j].to;
				if(t==r&&nbr[l][j].ava==1)
				{
					nbr[l][j].ava=0;
					out[l]=out[l]-1;
					break;
				}
			}
		}
		if(opt==2)
		{
			for(int j=0;j<nbr[l].size();j++)
			{
				int t=nbr[l][j].to;
				for(int k=0;k<nbr[t].size();k++)
				{
					int tt=nbr[t][k].to,ta=nbr[t][k].ava;
					if(tt==l&&ta==1)
					{
						nbr[t][k].ava=0;
						out[t]=out[t]-1;
						break;
					}
				}
			}
		}
		if(opt==3)
		{
			fin>>r;
			for(int j=0;j<nbr[l].size();j++)
			{
				int t=nbr[l][j].to;
				if(t==r&&nbr[l][j].ava==0)
				{
					nbr[l][j].ava=1;
					out[l]=out[l]+1;
					break;
				}
			}
		}
		if(opt==4)
		{
			for(int j=0;j<nbr[l].size();j++)
			{
				int t=nbr[l][j].to;
				for(int k=0;k<nbr[t].size();k++)
				{
					int tt=nbr[t][k].to,ta=nbr[t][k].ava;
					if(tt==l&&ta==0)
					{
						nbr[t][k].ava=1;
						out[t]=out[t]+1;
						break;
					}
				}
			}
		}
		ans=0;
 		for(int i=1;i<=n;i++)
 		{
 			if(out[i]==1)ans++;
 		}
		if(ans!=n)
		{
			fout<<"NO\n";
			continue;
		}
		int flg=1;
		memset(vis2,0,sizeof(vis2));
		memset(res,0,sizeof(res));
		for(int j=1;j<=n;j++)
		{
			if(!vis2[j])
			{
				memset(vis,0,sizeof(vis));
				if(!dfs(j))
				{
					flg=0;
					break;
				}
			}
		}
		if(flg==1)fout<<"YES\n";
		else fout<<"NO\n"; 
 	}
 	return 0;
}
