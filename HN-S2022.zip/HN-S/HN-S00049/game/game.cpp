#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[100100],b[100100];
int x,y,x2,y2,l=1,x3,y3;
long long ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=1;i<=m;i++)
	cin>>b[i];
	for(int i=1;i<=n;i++)
	if(a[i]<0)
	l=0;
	for(int i=1;i<=m;i++)
	if(b[i]<0)
	l=0;
	for(int i=1;i<=q;i++){
		cin>>x>>y>>x2>>y2;
		if(l==1){
			x3=0;
			y3=1e9;
			for(int j=x;j<=y;j++)
			x3=max(x3,a[j]);
			for(int j=x2;j<=y2;j++)
			y3=min(y3,b[j]);
			ans=1;
			ans=ans*x3*y3;
			cout<<ans<<endl;
			continue;
	}
	    if(x==y){
	    	long long xx=1;
	    	ans=a[x]*b[x2];
	    	for(int j=x2;j<=y2;j++)
	    	ans=max(ans,xx*a[x]*b[j]);
	    	cout<<ans<<endl;
	    	continue;
		}
		if(x2==y2){
	    	long long xx=1;
	    	ans=a[x]*b[x2];
	    	for(int j=x;j<=y;j++)
	    	ans=max(ans,xx*a[j]*b[x2]);
	    	cout<<ans<<endl;
	    	continue;
		}
		ans=-1e18;
		for(int i=x;i<=y;i++){
		long long x3=1e18,x4=1;
		for(int j=x2;j<=y2;j++)
			x3=min(x3,x4*a[i]*b[j]);
			ans=max(ans,x3);
		}
		cout<<ans<<endl;
    }
    return 0;
}
