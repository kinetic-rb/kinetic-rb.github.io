#include<bits/stdc++.h>
using namespace std;
int n,m,k,x,y;
bool v2[2510];
long long ans;
int a[2510][2510];
int v[2510][2510];
long long b[3010];
int dfs(int x,int s,long long s2){
	if(s==5&&x!=1)return 0;	
	if(s==5){
	ans=max(ans,s2);
	return 0;
	}
	if(s!=0)v2[x]=1;
	for(int i=1;i<=n;i++)
	if(v2[i]==0&&v[x][i]==1)
	dfs(i,s+1,s2+b[i]);
	v2[x]=0;
	return 0;
}
int find(int x,int y,int s){
	if(a[x][y]<=s)return 0;
	a[x][y]=s;
	for(int i=1;i<=n;i++)
	if(v[y][i]==1){
	find(x,i,s+1);
	}
	return 0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	b[1]=0;
	for(int i=2;i<=n;i++)
	cin>>b[i];
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	a[i][j]=1e9;
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		v[x][y]=1;
		v[y][x]=1;
	} 
	for(int i=1;i<=n;i++)
	find(i,i,1);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	if(i!=j&&a[i][j]-2<=k)
	v[i][j]=1;
	dfs(1,0,0);
	cout<<ans;
	return 0;
} 
