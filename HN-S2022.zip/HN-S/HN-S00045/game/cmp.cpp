#include <bits/stdc++.h>
using namespace std;
ifstream fin1("game.out"),fin2("game3.ans");
signed main(){
	long long x,y;
	int pos=0;
	while(fin1>>x){
		fin2>>y;pos++;
		if(x!=y){
			cout<<"WA"<<endl;
			cout<<pos<<' '<<x<<' '<<y<<endl;
			return 0;
		}
	}
}
