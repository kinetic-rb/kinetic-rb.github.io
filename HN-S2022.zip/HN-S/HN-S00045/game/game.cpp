#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+50,inf=1e9+5;
inline int read(){
	int s=0,w=1,ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)){s=(s<<3)+(s<<1)+ch-48;ch=getchar();}
	return s*w;
}
struct node{
	int l,r,mip,mxn,mx,mi;
	#define l(o,x) tree[o][x].l
	#define r(o,x) tree[o][x].r
	#define mip(o,x) tree[o][x].mip
	#define mxn(o,x) tree[o][x].mxn
	#define mx(o,x) tree[o][x].mx
	#define mi(o,x) tree[o][x].mi
}tree[2][maxn*4];
void pushup(int x,int t){
	mip(t,x)=min(mip(t,x<<1),mip(t,x<<1|1));
	mxn(t,x)=max(mxn(t,x<<1),mxn(t,x<<1|1));
	mi(t,x)=min(mi(t,x<<1),mi(t,x<<1|1));
	mx(t,x)=max(mx(t,x<<1),mx(t,x<<1|1));
}
int n,m;
int a[2][maxn];
void build(int x,int l,int r,int t){
	l(t,x)=l;r(t,x)=r;
	if(l==r){
		mip(t,x)=inf;if(a[t][l]>=0)mip(t,x)=a[t][l];
		mxn(t,x)=-inf;if(a[t][l]<0)mxn(t,x)=a[t][l];
		mi(t,x)=a[t][l];
		mx(t,x)=a[t][l];
		return;
	}
	int mid=(l+r)>>1;
	build(x<<1,l,mid,t);
	build(x<<1|1,mid+1,r,t);
	pushup(x,t);
}
int mip[2],mxn[2],mx[2],mi[2];
void chkmin(int &a,int b){a=(a>b?b:a);}
void chkmax(int &a,int b){a=(a<b?b:a);}
void query(int x,int l,int r,int t){
	if(l(t,x)>=l&&r(t,x)<=r){
		chkmin(mip[t],mip(t,x));
		chkmax(mxn[t],mxn(t,x));
		chkmin(mi[t],mi(t,x));
		chkmax(mx[t],mx(t,x));
		return;
	}
	int mid=(l(t,x)+r(t,x))>>1;
	if(l<=mid)query(x<<1,l,r,t);
	if(r>mid)query(x<<1|1,l,r,t);
}
void out(){
	cerr<<mi[0]<<' '<<mx[0]<<' '<<mip[0]<<' '<<mxn[0]<<endl;
	cerr<<mi[1]<<' '<<mx[1]<<endl;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int Q;
	n=read();m=read();Q=read();
	for(int i=1;i<=n;i++)a[0][i]=read();
	for(int i=1;i<=m;i++)a[1][i]=read();
	build(1,1,n,0);build(1,1,m,1);
	for(int pos=1;pos<=Q;pos++){
		mip[0]=mip[1]=mi[0]=mi[1]=inf;
		mxn[0]=mxn[1]=mx[0]=mx[1]=-inf;
		int l1=read(),r1=read(),l2=read(),r2=read();
		query(1,l1,r1,0);query(1,l2,r2,1);
		if(pos==0){
			cerr<<"***** "<<l1<<' '<<r1<<' '<<l2<<' '<<r2<<endl;
			out();
		}
		printf("%lld\n",max(max(mx[0]>=0?1ll*mx[0]*mi[1]:-1ll*inf*inf,
		mi[0]<0?1ll*mi[0]*mx[1]:-1ll*inf*inf),
		max(mip[0]!=inf?1ll*mip[0]*mi[1]:-1ll*inf*inf,
		mxn[0]!=-inf?1ll*mxn[0]*mx[1]:-1ll*inf*inf)));
	}
	return 0;
}
