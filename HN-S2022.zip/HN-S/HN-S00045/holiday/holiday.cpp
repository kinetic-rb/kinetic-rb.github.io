#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int s=0,w=1,ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)){s=(s<<3)+(s<<1)+ch-48;ch=getchar();}
	return s*w;
}
const int maxn=2550,maxm=1e4+50;
int n,m,K;
int cnt,head[maxn],to[maxm*2],nex[maxm*2];ll a[maxn];
int ex[maxm],ey[maxm];
queue<int>q;
void add(int x,int y){to[++cnt]=y;nex[cnt]=head[x];head[x]=cnt;}
namespace BF{
	int dis[30][30];
	void bfs(int s){
		memset(dis[s],-1,sizeof(dis[s]));
		dis[s][s]=0;
		q.push(s);
		while(!q.empty()){
			int u=q.front();q.pop();
			for(int i=head[u];i;i=nex[i]){
				int v=to[i];
				if(dis[s][v]==-1){dis[s][v]=dis[s][u]+1;q.push(v);}
			}
		}
	}
	void main(){
		ll ans=0;
		for(int i=1;i<=n;i++)bfs(i);
		for(int i=2;i<=n;i++){
			for(int j=2;j<=n;j++){
				if(i==j)continue;
				for(int k=2;k<=n;k++){
					if(i==k||j==k)continue;
					for(int p=2;p<=n;p++){
						if(p==i||p==j||p==k)continue;
						if(dis[1][i]<=K&&dis[i][j]<=K&&dis[j][k]<=K&&dis[k][p]<=K&&dis[p][1]<=K)
							ans=max(ans,a[i]+a[j]+a[k]+a[p]);
					}
				}
			}
		}
		printf("%lld\n",ans);
	}
}
namespace BFK0{
	bool bj[maxn];
	void main(){
		for(int i=head[1];i;i=nex[i]){
			int v=to[i];
			bj[v]=1;
		}
		ll ans=0;
		for(int i=1;i<=m;i++){
			int x=ex[i],y=ey[i];
			for(int e1=head[x];e1;e1=nex[e1]){
				int v1=to[e1];if(bj[v1]==0)continue;
				for(int e2=head[y];e2;e2=nex[e2]){
					int v2=to[e2];
					if(bj[v2]==0||v1==v2)continue;
					ans=max(ans,a[x]+a[y]+a[v1]+a[v2]);
				}
			}
		}
		printf("%lld\n",ans);
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();K=read()+1;
	for(int i=2;i<=n;i++)scanf("%lld",a+i);
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		add(x,y);add(y,x);
		ex[i]=x;ey[i]=y;
	}
	if(n<=20)BF::main();
	else if(K==0)BFK0::main();
	return 0;
}
