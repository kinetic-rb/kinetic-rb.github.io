#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int s=0,w=1,ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)){s=(s<<3)+(s<<1)+ch-48;ch=getchar();}
	return s*w;
}
const int maxn=2e5+50;
int n,Q,K,cnt,head[maxn],to[maxn*2],nex[maxn*2],a[maxn];
void add(int x,int y){to[++cnt]=y;nex[cnt]=head[x];head[x]=cnt;}
namespace BF2{
	int up[maxn],pa[maxn],tot,dep[maxn];
	ll f[maxn];
	void dfs(int u,int fa){
		up[u]=fa;dep[u]=dep[fa]+1;
		for(int i=head[u];i;i=nex[i])if(to[i]!=fa)dfs(to[i],u);
	}
	int tmp[maxn];
	void getpath(int x,int y){
		tot=0;int tp=0;
		if(dep[x]>dep[y]){
			while(dep[x]>dep[y])pa[++tot]=x,x=up[x];
		}
		if(dep[y]>dep[x]){
			while(dep[y]>dep[x])tmp[++tp]=y,y=up[y];
		}
		while(x!=y){
			pa[++tot]=x;tmp[++tp]=y;
			x=up[x];y=up[y];
		}
		pa[++tot]=x;while(tp)pa[++tot]=tmp[tp],tp--;
	}
	void main(){
		dfs(1,0);
		while(Q--){
			int x=read(),y=read();
			getpath(x,y);
			f[1]=a[x];
			for(int i=2;i<=tot;i++){
				ll tmp=f[i-1];
				for(int j=i-1;j>=i-K;j--){
					if(j==0)break;
					tmp=min(tmp,f[j]);
				}
				f[i]=tmp+a[pa[i]];
			}
			printf("%lld\n",f[tot]);
		}
	}
}
namespace BF1{
	int up[maxn][20],dep[maxn];
	ll sum[maxn];
	void dfs(int u,int fa){
		sum[u]=sum[fa]+a[u];
		dep[u]=dep[fa]+1;
		up[u][0]=fa;
		for(int i=1;i<20;i++)up[u][i]=up[up[u][i-1]][i-1];
		for(int i=head[u];i;i=nex[i]){
			int v=to[i];if(v==fa)continue;
			dfs(v,u);
		}
	}
	int getlca(int x,int y){
		if(dep[x]<dep[y])swap(x,y);
		for(int i=19;i>=0;i--)if(dep[up[x][i]]>=dep[y])x=up[x][i];
		if(x==y)return x;
		for(int i=19;i>=0;i--)if(up[x][i]!=up[y][i])x=up[x][i],y=up[y][i];
		return up[x][0];
	}
	void main(){
		while(Q--){
			int x=read(),y=read();
			int lca=getlca(x,y);
			printf("%lld\n",sum[x]+sum[y]-2*sum[lca]+a[lca]);
		}
	}
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();Q=read();K=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	if(K==1)BF1::main();
	else{
		BF2::main();
	}
	return 0;
}
