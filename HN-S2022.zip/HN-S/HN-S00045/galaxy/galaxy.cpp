#include <bits/stdc++.h>
using namespace std;
const int maxn=1e3+50,maxm=1e4+50;
int n,m,Q;
inline int read(){
	int s=0,w=1,ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)){s=(s<<3)+(s<<1)+ch-48;ch=getchar();}
	return s*w;
}
int d[maxn];bool td[maxn],tb[maxm];
int ex[maxm],ey[maxm];
map<pair<int,int>,int>mp;
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){ex[i]=read();ey[i]=read();mp[make_pair(ex[i],ey[i])]=i;}
	Q=read();
	for(int pos=1;pos<=Q;pos++){
//		cout<<"*** "<<pos<<endl;
		int op=read(),x=read(),y;
		if(op==1||op==3){
			y=read();
			if(op==1)tb[mp[make_pair(x,y)]]=1;
			else tb[mp[make_pair(x,y)]]=0;
		}else{
			if(op==2){
				for(int i=1;i<=m;i++)if(ey[i]==x)tb[i]=1;
			}else{
				for(int i=1;i<=m;i++)if(ey[i]==x)tb[i]=0;
			}
		}
		memset(d,0,sizeof(d));
		for(int i=1;i<=m;i++)if(tb[i]==0&&td[ey[i]]==0&&td[ex[i]]==0)d[ex[i]]++;
		int flag=1;
		for(int i=1;i<=n;i++)if(td[i]==0&&d[i]!=1)flag=0;
//		for(int i=1;i<=n;i++)cout<<d[i]<<' ';cout<<endl;
		if(flag)puts("YES");
		else puts("NO");
	}
	return 0;
}
