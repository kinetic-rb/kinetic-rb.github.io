#include <bits/stdc++.h>
#define ll long long
#define RI register
#define IN inline
#define I inline ll
#define B inline bool
#define V inline void
#define vd void()
#define RP pair<ll,ll>
#define fi first
#define se second
#define m_p make_pair
using namespace std;
const ll maxn=1e5+10;
const ll inf=1e18;

bool Begin;
ll n,m,q;
ll a[maxn];
ll b[maxn];

I read(){
    ll x=0,f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return f?-x:x;
}

ll ans;

namespace _60pts{
    ll c[1010][1010];
    ll f[12][1010][1010];

    I qry(ll l,ll r,ll k){
        ll lg=log2(r-l+1);
        return min(f[lg][k][l],f[lg][k][r-(1<<lg)+1]);
    }

    V sol(){
        for(RI int i=1;i<=n;++i)
            for(RI int j=1;j<=m;++j){
                c[i][j]=a[i]*b[j];
                f[0][i][j]=c[i][j];
            }
        for(RI int k=1;k<=n;++k){
            for(RI int i=1;i<=10;++i)
                for(RI int j=1;j+(1<<i)-1<=m;++j)
                    f[i][k][j]=min(f[i-1][k][j],f[i-1][k][j+(1<<(i-1))]);
        }
        for(RI int i=1;i<=q;++i){
            ll l1=read(),r1=read(),l2=read(),r2=read();ans=-inf;
            for(RI int j=l1;j<=r1;++j) ans=max(ans,qry(l2,r2,j));
            printf("%lld\n",ans);
        }
    }
}

namespace _75pts{
    ll f[23][maxn];
    ll g[23][maxn];

    I qrf(ll l,ll r){
        ll lg=log2(r-l+1);
        return max(f[lg][l],f[lg][r-(1<<lg)+1]);
    }

    I qrg(ll l,ll r){
        ll lg=log2(r-l+1);
        return min(g[lg][l],g[lg][r-(1<<lg)+1]);
    }

    V sol(){
        for(RI int i=1;i<=n;++i) f[0][i]=a[i];
        for(RI int i=1;i<=m;++i) g[0][i]=b[i];
        for(RI int i=1;i<=22;++i)
            for(RI int j=1;j+(1<<i)-1<=n;++j) f[i][j]=max(f[i-1][j],f[i-1][j+(1<<(i-1))]);
        for(RI int i=1;i<=22;++i)
            for(RI int j=1;j+(1<<i)-1<=m;++j) g[i][j]=min(g[i-1][j],g[i-1][j+(1<<(i-1))]);
        for(RI int i=1;i<=q;++i){
            ll l1=read(),r1=read(),l2=read(),r2=read();
            printf("%lld\n",qrf(l1,r1)*qrg(l2,r2));
        }
    }

}

namespace _85pts{
    ll f[23][maxn];
    ll g[23][maxn];

    I qrf(ll l,ll r){
        ll lg=log2(r-l+1);
        return max(f[lg][l],f[lg][r-(1<<lg)+1]);
    }

    I qrg(ll l,ll r){
        ll lg=log2(r-l+1);
        return min(g[lg][l],g[lg][r-(1<<lg)+1]);
    }

    V sol(){
        for(RI int i=1;i<=n;++i) f[0][i]=a[i];
        for(RI int i=1;i<=m;++i) g[0][i]=b[i];
        for(RI int i=1;i<=22;++i)
            for(RI int j=1;j+(1<<i)-1<=n;++j) f[i][j]=max(f[i-1][j],f[i-1][j+(1<<(i-1))]);
        for(RI int i=1;i<=22;++i)
            for(RI int j=1;j+(1<<i)-1<=m;++j) g[i][j]=min(g[i-1][j],g[i-1][j+(1<<(i-1))]);
        for(RI int i=1;i<=q;++i){
            ll l1=read(),r1=read(),l2=read(),r2=read();
            if(l1==r1) printf("%lld\n",a[l1]*qrg(l2,r2));
            else printf("%lld\n",b[l2]*qrf(l1,r1));
        }
    }
}

bool End;

signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    // cerr<<(&End-&Begin)/1024.0/1024.0<<"\n";
    n=read(),m=read(),q=read();
    bool ok=0;
    for(RI int i=1;i<=n;++i) a[i]=read(),ok|=(a[i]<=0);
    for(RI int i=1;i<=m;++i) b[i]=read(),ok|=(b[i]<=0);
    if(n<=1000) return _60pts::sol(),0;
    if(!ok) return _75pts::sol(),0;
    return _85pts::sol(),0;
    return 0;
} 