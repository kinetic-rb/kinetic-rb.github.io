#include <bits/stdc++.h>
#define ll long long
#define RI register
#define IN inline
#define I inline ll
#define B inline bool
#define V inline void
#define vd void()
#define RP pair<ll,ll>
#define fi first
#define se second
#define m_p make_pair
using namespace std;
const ll maxn=2e5+10;
const ll inf=1e18;

bool Begin;
ll n,q,k;
ll a[maxn];
ll hd[maxn];
ll cnt;
struct Node{ll nx,to;}e[maxn<<1];

V add(ll x,ll y){
    e[++cnt].to=y;
    e[cnt].nx=hd[x];
    hd[x]=cnt;
}

I read(){
    ll x=0,f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return f?-x:x;
}

ll f[maxn];
ll fa[maxn];
ll dep[maxn];
ll siz[maxn];
ll son[maxn];
ll top[maxn];
ll w[maxn];

V dfs1(ll x){
    dep[x]=dep[fa[x]]+1,siz[x]=1;
    for(RI int i=hd[x];i;i=e[i].nx){
        ll to=e[i].to;
        if(to==fa[x]) continue;
        fa[to]=x,w[to]=w[x]+a[to],dfs1(to);
        siz[x]+=siz[to];
        if(siz[to]>siz[son[x]])
            son[x]=to;
    }
}

V dfs2(ll x,ll tp){
    top[x]=tp;
    if(son[x]) dfs2(son[x],tp);
    for(RI int i=hd[x];i;i=e[i].nx)
        if(e[i].to!=son[x]&&e[i].to!=fa[x])
            dfs2(e[i].to,e[i].to);
}

I LCA(ll x,ll y){
    for(;top[x]!=top[y];dep[top[x]]>dep[top[y]]?x=fa[top[x]]:y=fa[top[y]]);
    return dep[x]<dep[y]?x:y;
}

namespace G{
    ll hd[maxn];
    ll cnt;
    struct node{
        ll nx,to,dis;
    }e[maxn<<1];
    ll vit[maxn];

    V add(ll x,ll y,ll z){
        e[++cnt].to=y;
        e[cnt].nx=hd[x];
        e[cnt].dis=z;
        hd[x]=cnt;
    }

    priority_queue<RP,vector<RP>,greater<RP> >q;

    V dij(ll ds[],ll S){
        while(!q.empty()) q.pop();
        for(RI int i=1;i<=n;++i) vit[i]=0,ds[i]=inf;
        ds[S]=0;q.push(m_p(ds[S],S));
        while(!q.empty()){
            ll x=q.top().se;q.pop();
            if(vit[x]) continue;
            vit[x]=1;
            for(RI int i=hd[x];i;i=e[i].nx){
                ll to=e[i].to;
                if(ds[to]>ds[x]+e[i].dis)
                    ds[to]=ds[x]+e[i].dis,q.push(m_p(ds[to],to));
            }
        }
    }

}

namespace sub1{
    ll c[maxn];
    ll d[maxn];
    ll st[3010][3010];
    ll ct,at;

    I D(ll u,ll v){
        ll lca=LCA(u,v);
        return dep[u]+dep[v]-(dep[lca]<<1);
    }

    V sol(){
        for(RI int i=1;i<=n;++i)
            for(RI int j=i+1;j<=n;++j)
                if(D(i,j)<=k) G::add(i,j,a[j]),G::add(j,i,a[i]);
        for(RI int i=1;i<=n;++i) G::dij(st[i],i);
        for(RI int ac=1;ac<=q;++ac){
            ll x=read(),y=read();
            printf("%lld\n",st[x][y]+a[x]);
        }
    }
}

namespace sub2{
    V sol(){
        for(RI int i=1;i<=q;++i){
            ll x=read(),y=read();
            ll lca=LCA(x,y);
            // cerr<<w[fa[lca]]<<"\n";
            printf("%lld\n",w[x]+w[y]-w[lca]-w[fa[lca]]);
        }
    }
}
bool End;

signed main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    // cerr<<(&End-&Begin)/1024.0/1024.0<<"\n";
    n=read(),q=read(),k=read();
    for(RI int i=1;i<=n;++i) a[i]=read();
    for(RI int i=1,x,y;i<n;++i) x=read(),y=read(),add(x,y),add(y,x);
    w[1]=a[1],dfs1(1),dfs2(1,1);
    if(k==1) return sub2::sol(),0;
    else return sub1::sol(),0;
    return 0;
} 