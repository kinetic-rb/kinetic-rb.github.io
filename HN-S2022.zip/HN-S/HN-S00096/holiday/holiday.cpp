#include <bits/stdc++.h>
#define ll long long
#define RI register
#define IN inline
#define I inline ll
#define B inline bool
#define V inline void
#define vd void()
#define RP pair<ll,ll>
#define fi first
#define se second
#define m_p make_pair
using namespace std;
const ll maxn=2500+10;
const ll maxm=2e4+10;

bool Begin;
ll n,m,k;
ll hd[maxn];
ll cnt;
struct Node{ll nx,to;}e[maxm<<1];

V add(ll x,ll y){
    e[++cnt].to=y;
    e[cnt].nx=hd[x];
    hd[x]=cnt;
}

ll a[maxn];

I read(){
    ll x=0,f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return f?-x:x;
}

queue<ll>q;
RP st[maxn][maxn];
ll ln[maxn];
bool mp[maxn][maxn];
ll d[maxn];
bool f[maxn];
ll ans;

B cmp(RP ax,RP bx) {return ax.first>bx.first;}

V reb(ll x){
    while(!q.empty()) q.pop();
    for(RI int i=1;i<=n;++i) d[i]=-1;
    q.push(x),d[x]=0;
    while(!q.empty()){
        ll u=q.front();q.pop();
        for(RI int i=hd[u];i;i=e[i].nx){
            ll v=e[i].to;
            if(d[v]!=-1) continue;
            d[v]=d[u]+1;
            if(d[v]>k+1) continue;
            q.push(v);
            if(x==1) f[v]=1;
            else if(f[v]==1) st[x][++ln[x]]=m_p(a[v],v);
            mp[x][v]=mp[v][x]=1;
        }
    }
    sort(st[x]+1,st[x]+ln[x]+1,cmp);
}

ll c[maxn];
set<RP>xp;
bool End;

signed main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    // cerr<<(&End-&Begin)/1024.0/1024.0<<"\n";
    n=read(),m=read(),k=read();
    for(RI int i=2;i<=n;++i) a[i]=read();
    for(RI int i=1,x,y;i<=m;++i) x=read(),y=read(),add(x,y),add(y,x);
    for(RI int i=1;i<=n;++i) reb(i);
    for(RI int i=2;i<=n;++i)
        for(RI int j=i+1;j<=n;++j)
            if(mp[i][j] && ln[i] && ln[j]){
                ll dx=0,dy=0,x=-1,y=-1;xp.clear();
                while(xp.size()<2&&(dx<ln[i]||dy<ln[j])){
                    if(dx<ln[i]) x=st[i][++dx].se;
                    if(dy<ln[j]) y=st[j][++dy].se;

                    if(x!=-1&&x!=i&&x!=j) xp.insert(m_p(a[x],x));
                    if(y!=-1&&y!=i&&y!=j) xp.insert(m_p(a[y],y));
                }
                if(xp.size()>=2){
                    ll mx1,mx2;mx1=mx2=0;
                    for(auto it=xp.begin();it!=xp.end();++it)
                        if((*it).fi>mx1) mx2=mx1,mx1=(*it).fi;
                        else mx2=(*it).fi;
                    ans=max(ans,a[i]+a[j]+mx1+mx2);
                }
            }
    printf("%lld\n",ans);
    return 0;
} 