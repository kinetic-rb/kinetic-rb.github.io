#include <bits/stdc++.h>
#define ll long long
#define RI register
#define IN inline
#define I inline ll
#define B inline bool
#define V inline void
#define vd void()
#define RP pair<ll,ll>
#define fi first
#define se second
#define m_p make_pair
#define pb push_back
using namespace std;
const ll maxn=5e5+10;
const ll maxm=1e4+10;

bool Begin;
ll n,q,m;

I read(){
    ll x=0,f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
    return f?-x:x;
}

ll hd[maxn];
ll cnt;
struct Node{ll nx,to;}e[maxn<<1];

namespace sub1{
    map<RP,bool>mp;
    ll vit[maxn];
    vector<ll>E[maxn];

    V add(ll x,ll y){
        e[++cnt].to=y;
        e[cnt].nx=hd[x];
        hd[x]=cnt;
    }

    ll in[maxn];
    ll sz[maxn];
    ll av[maxn];
    ll low[maxn];
    ll dfn[maxn];
    ll tim;
    ll scc;
    ll sc[maxn];
    ll mth[maxn];
    stack<ll>st;

    V tarjan(ll x){
        low[x]=dfn[x]=++tim,vit[x]=1,st.push(x);
        for(RI int i=hd[x];i;i=e[i].nx){
            ll to=e[i].to;
            if(!av[to]) continue;
            if(!mp[m_p(x,to)]) continue;
            if(!dfn[to]){
                tarjan(to);
                low[x]=min(low[x],low[to]);
            }
            else if(vit[to]) low[x]=min(low[x],low[to]);
            
        }
        if(dfn[x]==low[x]){
            ++scc;
            while(st.top()!=x) sc[st.top()]=scc,vit[st.top()]=0,st.pop(),++sz[scc];
            sc[st.top()]=scc,vit[st.top()]=0,st.pop(),++sz[scc];
        }
    }

    B dfs(ll x){
        if(mth[x]) return true;
        for(RI int i=hd[x];i;i=e[i].nx)
            if(av[e[i].to]&&mp[m_p(x,e[i].to)])
                if(dfs(e[i].to)) return mth[x]=1,true;
        return false;

    }

    B Check(){
        // for(RI int i=1;i<=n;++i) cerr<<in[i]<<" ";cerr<<"\n";
        for(RI int i=1;i<=n;++i) if(in[i]!=1) return false;
        for(RI int i=1;i<=n;++i) dfn[i]=low[i]=vit[i]=sc[i]=mth[i]=sz[i]=0;
        tim=scc=0;
        for(RI int i=1;i<=n;++i) if(!dfn[i]) tarjan(i);
        for(RI int i=1;i<=n;++i) if(sz[sc[i]]>=2) mth[i]=1;
        for(RI int i=1;i<=n;++i) if(!mth[i]) if(!dfs(i)) return false;
        return true;

    }

    V del(ll x){
        for(RI int to:E[x]) if(mp[m_p(to,x)]) --in[to],mp[m_p(to,x)]=0;
    }

    V ins(ll x){
        for(RI int to:E[x]) if(!mp[m_p(to,x)]) ++in[to],mp[m_p(to,x)]=1;
    }

    V sol(){
        for(RI int i=1;i<=n;++i) av[i]=1;
        for(RI int i=1,x,y;i<=m;++i)
            x=read(),y=read(),add(x,y),++in[x],mp[m_p(x,y)]=1,E[y].pb(x);
        q=read();
        for(RI int i=1;i<=q;++i){
            ll op=read(),x=read(),y;
            if(op==1) y=read(),mp[m_p(x,y)]=0,--in[x];
            if(op==2) del(x);
            if(op==3) y=read(),mp[m_p(x,y)]=1,++in[x];
            if(op==4) ins(x);
            // cerr<<i<<": ";
            puts(Check()?"YES":"NO");
        }
    }
}
bool End;

signed main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    // cerr<<(&End-&Begin)/1024.0/1024.0<<"\n";
    n=read(),m=read();
    return sub1::sol(),0;
    return 0;
} 