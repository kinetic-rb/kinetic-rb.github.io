#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int a[100005],b[100005];
int lx,ry,ls,rs;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=q;i++)
	{
		cin>>lx>>ry>>ls>>rs;
		long long maix=-1e10;
		for(int j=lx;j<=ry;j++)
		{
			
			if(a[j]<0)
			{
				long long ma=-1e9;
				for(int k=ls;k<=rs;k++)
				{
					ma=max(ma,(long long)(b[k]));
				}
				maix=max(maix,ma*a[j]);
			}
			if(a[j]==0)
			{
				maix=max(maix,(long long)(0));
			}
			if(a[j]>0)
			{
				long long mi=1e10;
				for(int k=ls;k<=rs;k++)
				{
					mi=min(mi,(long long)(b[k]));
				}
				maix=max(maix,(long long)a[j]*mi);
			}
		}
		cout<<maix<<"\n";
	}
	return 0;
} 
