#include<bits/stdc++.h>
using namespace std;
int n,q,k;
int v[2005];
int a[2005],b[2005];
vector<int>bian[2005];
int s,t;
bool vis[2005];
int mi=1e9;
void dfs(int x,int y,int sum)
{
	if(x==y)
	{
		mi=min(mi,sum);
		return ;
	}
	for(int i=0;i<bian[x].size();i++)
	{
		if(vis[bian[x][i]]==0)
		{
			vis[bian[x][i]]=1;
			dfs(bian[x][i],y,sum+v[bian[x][i]]);
			vis[bian[x][i]]=0;
		}
	}
	return ;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>v[i];
	}
	for(int i=1;i<=n-1;i++)
	{
		cin>>a[i]>>b[i];
		bian[a[i]].push_back(b[i]);
		bian[b[i]].push_back(a[i]);
	}
	for(int i=1;i<=q;i++)
	{
		cin>>s>>t;
		mi=1e9;
		vis[s]=1;
		dfs(s,t,v[s]);
		vis[s]=0;
		cout<<mi<<"\n";
	}
	return 0;
} 

