#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int aa[2505];
int x,y;
vector<int> a[2505],b[2505];
bool vis[2505][2505];
bool v[2505];
int maix=-1e9;
void bfs(int cur,int i,int q)
{
	int l=a[q].size();
	if(cur==k+1)
	{
		return ;
	}
	for(int j=0;j<l;j++)
	{
		if(vis[i][a[q][j]]==0)
		{
			b[i].push_back(a[q][j]);
			vis[i][a[q][j]]=1;
		}
		if(v[a[q][j]]==0)
		{
			v[a[q][j]]=1;
			bfs(cur+1,i,a[q][j]);
			v[a[q][j]]=0;
		}
	}
	return ;
}
void check(int x,int sum)
{
	for(int i=0;i<a[x].size();i++)
	{
		if(a[x][i]==1)
		{
			maix=max(maix,sum);
			return ;
		}
	}
	return ;
}
void dfs(int cur,int now,int sum)
{
	if(cur==4)
	{
		check(now,sum);
		return ;
	}
	for(int i=0;i<b[now].size();i++)
	{
		if(v[b[now][i]]==0)
		{
			v[b[now][i]]=1;
			dfs(cur+1,b[now][i],sum+aa[b[now][i]]);
			v[b[now][i]]=0;
			
		}
		
	}
	return ;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
	{
		cin>>aa[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		a[x].push_back(y);
		a[y].push_back(x); 
	}
	for(int i=1;i<=n;i++)
	{
		vis[i][i]=1;
		bfs(0,i,i);
	} 
	dfs(0,1,0);
	cout<<maix;
	return 0;
} 
