## 题意
给定 $N$，和 $P_2, P_3, \cdots, P_N$，表示第 $i$ 个人的父亲是 $P_i$。问第 $N$ 个人是第 $1$ 个人的第几级后代。

$2 \leq N \leq 50, 1 \leq P_i < i \left(2 \leq i \leq N\right)$

## 题解
暴力跳即可。

## [代码](https://raw.verge.tk/rb-tree/rb-tree/main/Code/AT/AGC263B.txt)