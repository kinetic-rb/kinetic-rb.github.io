#include <iostream>

using namespace std;

signed main() {
  int a, b;
  cin >> a >> b;
  cout << a + b;
  return 0;
}